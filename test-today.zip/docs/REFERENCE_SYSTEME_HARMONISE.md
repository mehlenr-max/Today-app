# Référence du système harmonisé — Gestion des interactions

> **Copie de référence.** Ce document décrit l'état du système harmonisé de gestion des interactions à la date ci-dessous. Il n'est pas exécuté par l'application ; il sert de point de comparaison pour les évolutions futures. En cas de divergence avec le code, le code l'emporte — il faut alors mettre ce document à jour.

- **Date de référence :** 2026-10-07
- **Portée :** Modèle d'états des interactions (DateThread), verrous de disponibilité (DateLock), marqueurs de session, suspension/reprise, annulations, blocage après refus personnel, nettoyage et reset administrateur.
- **Fichiers sources correspondants :** `base44/shared/datethread.ts`, `base44/shared/stale-cleanup.ts`, `base44/shared/challenge-cleanup.ts`, `base44/shared/messages.ts`, `base44/functions/deliverChallenge/entry.ts`, `base44/functions/deliverResult/entry.ts`, `base44/functions/cancelDate/entry.ts`, `base44/functions/resetMyInteractions/entry.ts`.

---

## 1. Modèle d'états (DateThread)

Un `DateThread` représente une interaction entre deux utilisateurs pour un jour donné. La clé `thread_key` est déterministe : `{dateKey}_{userA_userB}` (user_ids triés lexicographiquement) — un seul fil par paire/jour, quel que soit le sens du défi.

| Stade | Valeur `state` | Description |
|------:|----------------|-------------|
| 0 | *(pas de thread)* | Aucune interaction. |
| 1 | `pending_challenge` | Un défi a été envoyé, en attente du PPC. |
| 2 | `ppc_resolved` | Le pierre-papier-ciseaux est résolu ; un gagnant est désigné. |
| 3 | `place_proposed` | Le gagnant a proposé un lieu au perdant, en attente de réponse. |
| 3b | `place_refused` | Le perdant a refusé le lieu pour raisons non personnelles (lieu/nourriture). La paire reste ouverte — le gagnant peut re-proposer. |
| 4 | `accepted` | Le perdant a accepté le lieu. Le date est confirmé. |
| — | `suspended` | L'interaction est en pause : l'un des deux a confirmé un date ailleurs. Le stade précédent est conservé dans `suspended_from_state` pour reprise. |
| — | `cancelled` | Le date a été annulé après confirmation. |
| — | `no_match` | Paire fermée (refus personnel, ou indisponibilité de l'autre partie). |

Champs notables :
- `version` : incrémenté à chaque transition (optimistic locking).
- `has_been_confirmed` : posé à `true` à la transition vers `accepted`, **jamais** remis à `false`. Permet à `cancelDate` de distinguer une annulation après confirmation d'une annulation avant.
- `suspended_from_state` : stade précédent avant suspension — permet de reprendre exactement au même point.
- `stale_closed` : legacy (ancien `cleanupStaleProposals`). Conservé pour compatibilité ; les nouveaux threads utilisent `suspended`.
- `place_json` : JSON `{name, address, time}` du lieu proposé/accepté.
- `refusal_reasons` : JSON array des raisons de refus (`place`, `food`, `personal`).

---

## 2. Règles de transition

Toutes les transitions passent par `transitionThreadState` (service role), qui applique une **garde de version** : `updateMany({ thread_key, version: expectedVersion }, { $set: { state, version: expectedVersion+1, ... } })`. Si `updated !== 1`, la transition échoue explicitement (`THREAD_VERSION_CONFLICT`). L'état relu est vérifié après écriture (`THREAD_STATE_MISMATCH` si divergence).

Transitions autorisées par fonction :

| Fonction (type) | Transition | Conditions / notes |
|-----------------|-----------|--------------------|
| `deliverChallenge` | (création) → `pending_challenge` | Idempotent via `thread_key`. Anti-doublon : un `incomingChallenge` non résolu existe déjà → bloqué. Anti-re-défi après refus personnel : thread `no_match` + `refusal_reasons` contient `personal` → bloqué. |
| `deliverResult` `notifyWinner` | → `ppc_resolved` | Le perdant notifie le gagnant. `winner_user_id` = destinataire. |
| `deliverResult` `notifyChallengeLost` | → `ppc_resolved` | Le gagnant défié notifie le challenger qu'il a perdu. `winner_user_id` = caller. |
| `deliverResult` `notifyLoser` | → `place_proposed` | Le gagnant propose un lieu. Garde : si le gagnant a un lock actif → refusé. Ferme les anciens messages `loserAccept` et refus (append-only). |
| `deliverResult` `notifyWinnerConfirmed` | → `accepted` | Le perdant accepte le lieu. **Lock atomique** des deux parties (voir §4). `has_been_confirmed` posé. |
| `deliverResult` `notifyWinnerRefused` (final) | → `no_match` | Refus pour raisons **personnelles** uniquement. Paire fermée, marqueurs `'personal_refusal'` posés (voir §5). |
| `deliverResult` `notifyWinnerRefused` (non-final) | → `place_refused` | Refus lieu/nourriture (pas personnel). Paire reste ouverte. Aucun changement de flags. |
| `cancelDate` | → `cancelled` ou reset paire | Selon `has_been_confirmed` (voir §6). |
| `suspendOtherInteractions` | actif → `suspended` | Pose `suspended_from_state`. |
| `resumeSuspendedInteractions` | `suspended` → `suspended_from_state` | Restaure le stade précédent. |

---

## 3. Suspension et reprise

Quand un utilisateur **confirme** un date (`notifyWinnerConfirmed`), ses autres interactions actives sont **suspendues** (pas fermées) via `suspendOtherInteractions` :

- Couvre tous les stades actifs : `pending_challenge`, `ppc_resolved`, `place_proposed`, `place_refused`.
- Le stade précédent est préservé dans `suspended_from_state`.
- Les actions en attente (`incomingChallenge`, `loserAccept`, `playerTurn`, `winnerChoosePlace`, `refusalWithReasons`) sont fermées en préservant l'original dans `action_json` : `{ state: 'closed', suspended_action: {...} }`.
- Un message de suspension est envoyé des deux côtés.

Quand un utilisateur est **libéré** (annulation de son date confirmé), `resumeSuspendedInteractions` :
- Restaure le stade (`suspended_from_state`) de chaque thread suspendu.
- Restaure les actions depuis `suspended_action`.
- Envoie un message de reprise des deux côtés.
- Gère aussi les threads legacy (`stale_closed` + `no_match`) en notifiant sans reprendre, puis remet `stale_closed = false`.

---

## 4. Verrous de disponibilité (DateLock)

Un `DateLock` par utilisateur par jour. Clé : `{dateKey}_{userId}`. `locked = true` = utilisateur indisponible pour un date aujourd'hui.

- **Acquisition atomique** (`acquireLock`) : upsert idempotent par `lock_key` + CAS `updateMany({ lock_key, locked: { $ne: true } }, { $set: { locked: true, reason, thread_key } })`. Un seul appel peut flipper `locked` de false→true.
- **`acquireOrVerifyLock`** : si le lock est déjà acquis sur **ce** thread → re-confirmation idempotente (`alreadyHeld = true`, ne pas libérer). Si lock actif sur un **autre** thread → conflit, bloquer.
- Le lock **survit à l'annulation** : seule la `reason` change (`date_confirmed` → `cancelled_after_confirm`). L'annulateur reste indisponible jusqu'à minuit.
- `reason` : `date_confirmed` ou `cancelled_after_confirm`.

À la confirmation (`notifyWinnerConfirmed`) :
1. Lock du gagnant (`acquireOrVerifyLock`). Si échec → thread → `no_match` (`stale_closed: true`), message "gagnant indisponible", refus.
2. Lock du perdant (caller). Si échec → libérer le lock du gagnant (seulement si nouvellement acquis), thread → `no_match`, refus.
3. Les deux locks acquis → transition `accepted`, écritures post-transition (shadow session, profile `accepted_date_key`, message confirmation, nettoyage marqueurs), puis suspension des autres interactions des deux parties.

---

## 5. Blocage après refus personnel

Un refus pour raisons **personnelles** (`personal` dans `refusal_reasons`) ferme la paire pour la journée :

- `deliverResult` `notifyWinnerRefused` (final) :
  - Transition → `no_match` avec `refusal_reasons`.
  - `markPersonalRefusalLockout` pose le marqueur `'personal_refusal'` dans `challenged_profiles` des **deux** sessions (au lieu de les effacer). Le bouton "Défier" reste désactivé et survit au rechargement.
  - Les deux parties sont libérées : `deleteLock` + `resumeSuspendedInteractions` pour chacune.
- `deliverChallenge` : anti-re-défi — si le thread de la paire est `no_match` avec `refusal_reasons` contenant `personal` → bloqué (`personal_refusal_lockout`).

Un refus **non final** (lieu/nourriture, pas personnel) :
- Transition → `place_refused`. La paire reste ouverte. Le gagnant peut re-proposer un autre lieu ou annuler. Aucun changement de flags.

---

## 6. Annulations (`cancelDate`)

- Si le thread est déjà `cancelled` ou `no_match` → réponse idempotente.
- **Après confirmation** (`has_been_confirmed = true`) :
  - Le thread → `cancelled`.
  - L'annulateur reste indisponible : `updateLockReason(..., 'cancelled_after_confirm')`.
  - L'autre partie est libérée : `deleteLock` + `resumeSuspendedInteractions`.
- **Avant confirmation** (proposition en attente) :
  - Reset de la paire : thread → `no_match`, marqueurs nettoyés (`cleanChallengeMarkers`), locks supprimés si présents.
  - Les deux parties redeviennent disponibles et se réapparaissent dans leurs decks respectifs.
- Les actions en attente entre les deux sont fermées (`closePendingActionsBetween`).

---

## 7. Marqueurs de session (`challenged_profiles`)

Map `profileId → valeur` dans `UserSession.challenged_profiles` :
- `'incoming'` : défi entrant en attente.
- `true` : défi sortant (écrit côté client, optimiste — **pas** source de vérité serveur).
- `'personal_refusal'` : paire bloquée pour la journée après refus personnel.

- `cleanChallengeMarkers` : supprime les marqueurs des deux côtés (à la résolution d'un défi, confirmation, annulation). Évite les marqueurs fantômes qui bloqueraient les futurs défis.
- `markPersonalRefusalLockout` : pose `'personal_refusal'` des deux côtés (au refus personnel). Le bouton reste désactivé sur la journée.

---

## 8. Nettoyage et reset administrateur

### Reset administrateur (`resetMyInteractions`)
Réservé à l'admin (`role === 'admin'` ou `romain@memmo.be`). Pour le jour en cours (Europe/Brussels) :
1. Supprime tous les `UserMessage` du jour.
2. `updateMany` sur toutes les `UserSession` du jour : `$set` (`challenged_profiles`, `passed_profiles`, `challenge_dates`, `physical_affinity` → `'{}'`, `match_count` → 0, `has_accepted_date` → false) + `$unset` (`accepted_date_details`). `$unset` garantit que les champs sont vraiment vidés.
3. `updateMany` sur **tous** les `Profile` : `$set` (`challenge_dates_map`, `quiz_proposed_map` → `'{}'`) + `$unset` (`accepted_date_key`).
4. Supprime tous les `DateThread` du jour.
5. Supprime tous les `DateLock` du jour.

Retourne les comptes avant reset (messages, sessions, profils, threads, locks).

### Nettoyages programmés (workflows)
- `clearAcceptedDates` : efface `accepted_date_key` des profils dont la date ne correspond pas au jour courant (Europe/Brussels).
- `cleanupOldMessages`, `cleanupOldThreads`, `cleanupOrphanProfiles`, `cleanupOrphanCloudinary` : nettoyage des données anciennes / orphelines.
- `autoOfflineInactive` : passage hors ligne des profils inactifs (7 jours).
- `handleReportCreated` : auto-block au 2e signalement.

---

## 9. Principes directeurs

1. **Machine à états stricte** : chaque transition passe par `transitionThreadState` avec garde de version. Aucune écriture d'état en dehors de cette fonction.
2. **Source de vérité serveur** : les marqueurs clients sont optimistes ; la détection des doublons et des lockouts repose sur le backend (messages + threads + locks).
3. **Locks atomiques** : acquisition via CAS MongoDB (`updateMany` + filtre `locked: { $ne: true }`). Un seul appel peut acquérir.
4. **Suspension, pas fermeture** : un date confirmé suspend les autres interactions (stade préservé), ne les ferme pas. La reprise restaure le stade exact.
5. **Lockout persistant après refus personnel** : le marqueur `'personal_refusal'` survit au rechargement et bloque le défi jusqu'à minuit.
6. **`$unset` pour le nettoyage** : `updateMany` avec `$unset` plutôt que `bulkUpdate` avec `null` pour garantir la suppression des champs.
7. **Idempotence** : `thread_key` / `lock_key` déterministes ; les opérations sont sûres sous double-clic.
8. **Aucun timer automatique** : les compteurs de réponse ont été retirés ; l'état pilote l'UI, pas l'inverse.