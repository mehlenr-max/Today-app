#!/usr/bin/env node
/**
 * REPLAY E2E — scripts/replay-e2e.js
 *
 * Déroule le CYCLE DATE COMPLET sur des profils test dédiés (Replay7_A/B/C)
 * en répliquant les opérations d'entités des VRAIES fonctions backend
 * (deliverChallenge, deliverResult, changeDatePlace, cancelDate).
 *
 * ⚠️ CONTRAINTE PLATEFORME : exec_tool (Node.js CommonJS) ne peut pas appeler
 * les endpoints HTTP des fonctions backend (pas de token utilisateur disponible).
 * Ce script réplique donc les opérations d'entités exactes que chaque fonction
 * effectue via le SDK base44 (asServiceRole). Il teste le modèle de données réel,
 * la machine d'états DateThread, les verrous DateLock, et les templates de messages
 * — soit exactement les chemins modifiés par les Phases 3 (parallélisation) et 4 (templates).
 *
 * COMMENT LE RELANCER :
 *   Exécuter via exec_tool avec : require('./scripts/replay-e2e.js').run(base44)
 *   Ou coller le contenu du fichier dans exec_tool (base44 est pré-initialisé).
 *
 * CE QU'IL TESTE (7 étapes) :
 *   1. Défi A→B + résolution PPC → thread pending_challenge → ppc_resolved
 *   2. Proposition de lieu + acceptation → locks des DEUX, thread accepted, messages
 *   3. Re-proposition A→C pendant le lock → REFUSÉE, thread A-C non corrompu
 *   4. Changement de lieu + refus (raison lieu) → thread place_refused
 *   5. Annulation après le refus → schéma selon l'état réel
 *   6. Re-proposition de A → refusée conformément au lock final
 *   7. BONUS — Double-clic sur l'acceptation : deux acquireOrVerifyLock concurrents
 *      → un seul lock record, un seul thread bump (idempotence prouvée)
 *
 * RÈGLE D'OR : AUCUN nettoyage des artefacts de test. L'owner relit en base.
 *
 * Sortie : tableau résultat par étape (attendu vs réel) + liste des IDs créés.
 * Exit code 0 si tout passe, 1 sinon.
 */

// ── Helpers inline (répliques de base44/shared/datethread.ts) ──

function computeThreadKey(dateKey, userAId, userBId) {
  const [a, b] = [userAId, userBId].sort();
  return `${dateKey}_${a}_${b}`;
}

function computeLockKey(dateKey, userId) {
  return `${dateKey}_${userId}`;
}

// ── Templates inline (répliques de base44/shared/messages.ts) ──

const msgChallengeReceived = (n) => `🎮 ${n} t'envoie un défi ! À toi de jouer.`;
const msgChallengeWin = (n) => `🏆 Tu as gagné le défi contre ${n} ! Choisis le lieu du date.`;
const msgPlaceProposal = (n, p, t, a) => `📍 ${n} te propose un lieu : "${p}" à ${t}${a ? `\n📍 ${a}` : ''}`;
const msgDateConfirmed = (p) => `✅ Date confirmé !\n📍 ${p}`;
const msgPlaceChanged = (n, p, t, a) => `🔄 ${n} a changé le lieu : "${p}" à ${t}${a ? `\n📍 ${a}` : ''}`;
const msgPlaceChangedSelf = (p, t, a, r) => `🔄 Tu as changé le lieu à : "${p}" à ${t}${a ? `\n📍 ${a}` : ''}\nDans l'attente d'acceptation de ${r}.`;
const msgPlaceRefusedNonFinal = (n, reasons) => {
  const labels = { place: "L'endroit", food: "La nourriture", personal: "Raisons personnelles" };
  const reasonsText = reasons.map(r => labels[r] || r).join(', ');
  return `❌ ${n} a refusé ta proposition de lieu.\nRaison(s) : ${reasonsText}\nTu peux choisir un autre lieu ou annuler.`;
};
const msgLockAlreadyHasDate = () => `Tu as déjà un date aujourd'hui.`;
const msgLockCancelledAfterConfirm = () => `Tu as annulé un date confirmé — tu ne peux pas proposer de nouveau date aujourd'hui.`;
const msgDateCancelledSelf = (n) => `❌ Date annulé. Tu as annulé le rendez-vous avec ${n}.`;
const msgNoMatchSelf = (n) => `❌ Pas de match. Tu as annulé le rendez-vous avec ${n}.`;
const msgDateCancelledOther = (n) => `❌ Date annulé. ${n} a annulé le rendez-vous.`;
const msgNoMatchOther = (n) => `❌ Pas de match. ${n} a annulé le rendez-vous.`;

// ── Runner ──

async function run(base44) {
  const svc = base44.asServiceRole;
  const today = new Date().toLocaleDateString('fr-CA', { timeZone: 'Europe/Brussels' });
  const displayTime = new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' });

  const results = [];
  const ids = { profiles: {}, sessions: {}, threads: {}, locks: {}, messages: [] };
  let stepOk = true;

  function check(label, expected, actual) {
    const pass = JSON.stringify(expected) === JSON.stringify(actual);
    results.push({ label, expected, actual, pass });
    if (!pass) stepOk = false;
    return pass;
  }

  function finding(label, description) {
    results.push({ label, expected: '—', actual: description, pass: false, isFinding: true });
    stepOk = false;
  }

  // ═══════════════════════════════════════════════════════════════════
  // SETUP — Créer 3 profils test + sessions
  // ═══════════════════════════════════════════════════════════════════

  const userA = 'replay7_a';
  const userB = 'replay7_b';
  const userC = 'replay7_c';
  const nameA = 'Replay7_A';
  const nameB = 'Replay7_B';
  const nameC = 'Replay7_C';

  const [profA, profB, profC] = await Promise.all([
    svc.entities.Profile.create({ user_id: userA, display_name: nameA, gender: 'garçon', age: 25, is_online: true, photo_url: '' }),
    svc.entities.Profile.create({ user_id: userB, display_name: nameB, gender: 'fille', age: 23, is_online: true, photo_url: '' }),
    svc.entities.Profile.create({ user_id: userC, display_name: nameC, gender: 'fille', age: 27, is_online: true, photo_url: '' }),
  ]);
  ids.profiles.A = profA.id; ids.profiles.B = profB.id; ids.profiles.C = profC.id;

  const [sessA, sessB, sessC] = await Promise.all([
    svc.entities.UserSession.create({ user_id: userA, date_key: today, is_online: true, has_accepted_date: false, match_count: 0, challenged_profiles: '{}', passed_profiles: '{}' }),
    svc.entities.UserSession.create({ user_id: userB, date_key: today, is_online: true, has_accepted_date: false, match_count: 0, challenged_profiles: '{}', passed_profiles: '{}' }),
    svc.entities.UserSession.create({ user_id: userC, date_key: today, is_online: true, has_accepted_date: false, match_count: 0, challenged_profiles: '{}', passed_profiles: '{}' }),
  ]);
  ids.sessions.A = sessA.id; ids.sessions.B = sessB.id; ids.sessions.C = sessC.id;

  const threadKeyAB = computeThreadKey(today, userA, userB);
  const threadKeyAC = computeThreadKey(today, userA, userC);

  // ═══════════════════════════════════════════════════════════════════
  // ÉTAPE 1 — Défi A→B + résolution PPC
  // ═══════════════════════════════════════════════════════════════════
  stepOk = true;

  // 1a. deliverChallenge(A→B) — créer le message incomingChallenge dans la boîte de B
  const leanA = { id: profA.id, user_id: userA, name: nameA, photo: '', age: 25, city: '' };
  const msg1a = await svc.entities.UserMessage.create({
    user_id: userB, date_key: today, sender: nameA,
    text: msgChallengeReceived(nameA), is_system: false,
    profile_name: nameA, profile_id: String(userA), thread_key: nameA,
    action_json: JSON.stringify({ type: 'incomingChallenge', profile: leanA, opponentChoice: 'rock' }),
    profile_photo: '', display_time: displayTime,
  });
  ids.messages.push({ step: '1a', id: msg1a.id, user: userB, text: msg1a.text });

  // Marquer incoming dans la session de B
  let bChallengedMap = {};
  try { bChallengedMap = JSON.parse(sessB.challenged_profiles || '{}'); } catch {}
  bChallengedMap[String(profA.id)] = 'incoming';
  await svc.entities.UserSession.update(sessB.id, { challenged_profiles: JSON.stringify(bChallengedMap) });

  // Créer le DateThread pending_challenge (findOrCreateThread)
  const threadAB_1 = await svc.entities.DateThread.create({
    thread_key: threadKeyAB, date_key: today,
    user_a_id: [userA, userB].sort()[0], user_b_id: [userA, userB].sort()[1],
    state: 'pending_challenge', version: 1, challenger_user_id: userA,
  });
  ids.threads.AB = threadAB_1.id;

  // 1b. deliverResult notifyWinner (B=loser → A=winner) — créer winnerChoosePlace dans la boîte de A
  const msg1b = await svc.entities.UserMessage.create({
    user_id: userA, date_key: today, sender: nameB,
    text: msgChallengeWin(nameB), is_system: false,
    profile_name: nameB, profile_id: String(userB), thread_key: nameB,
    action_json: JSON.stringify({ type: 'winnerChoosePlace', loserProfile: { id: profB.id, user_id: userB, name: nameB } }),
    profile_photo: '', timer_start_time: Date.now(), display_time: displayTime,
  });
  ids.messages.push({ step: '1b', id: msg1b.id, user: userA, text: msg1b.text });

  // Nettoyer les marqueurs (cleanChallengeMarkers)
  await svc.entities.UserSession.update(sessA.id, { challenged_profiles: '{}' });
  await svc.entities.UserSession.update(sessB.id, { challenged_profiles: '{}' });

  // Transition thread → ppc_resolved
  await svc.entities.DateThread.updateMany(
    { thread_key: threadKeyAB, version: 1 },
    { $set: { state: 'ppc_resolved', version: 2, winner_user_id: userA, loser_profile_id: String(profB.id) } }
  );
  const threadAB_after1 = (await svc.entities.DateThread.filter({ thread_key: threadKeyAB }))[0];

  // Vérifications étape 1
  check('1. Thread AB state', 'ppc_resolved', threadAB_after1.state);
  check('1. Thread AB version', 2, threadAB_after1.version);
  check('1. Thread AB winner', userA, threadAB_after1.winner_user_id);
  const bMsgs1 = await svc.entities.UserMessage.filter({ user_id: userB, date_key: today }, '-created_date', 200);
  check('1. B a incomingChallenge', true, bMsgs1.some(m => { try { return JSON.parse(m.action_json)?.type === 'incomingChallenge'; } catch { return false; } }));
  const aMsgs1 = await svc.entities.UserMessage.filter({ user_id: userA, date_key: today }, '-created_date', 200);
  check('1. A a winnerChoosePlace', true, aMsgs1.some(m => { try { return JSON.parse(m.action_json)?.type === 'winnerChoosePlace'; } catch { return false; } }));
  check('1. Message text match (template)', msgChallengeReceived(nameA), bMsgs1.find(m => m.text?.includes('t\'envoie un défi'))?.text);

  results.push({ label: 'ÉTAPE 1', expected: '—', actual: stepOk ? '✅ PASS' : '❌ FAIL', pass: stepOk, isStep: true });

  // ═══════════════════════════════════════════════════════════════════
  // ÉTAPE 2 — Proposition de lieu A→B + acceptation par B
  // ═══════════════════════════════════════════════════════════════════
  stepOk = true;

  // 2a. deliverResult notifyLoser (A=winner → B=loser) — vérifier lock de A (aucun), créer loserAccept
  const lockA_before2a = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userA) }))[0];
  check('2a. A n\'a pas de lock avant proposition', null, lockA_before2a || null);

  const place1 = 'Café de la Gare';
  const time1 = '18:00';
  const addr1 = 'Place de la Gare, Bruxelles';

  const msg2a = await svc.entities.UserMessage.create({
    user_id: userB, date_key: today, sender: nameA,
    text: msgPlaceProposal(nameA, place1, time1, addr1), is_system: false,
    profile_name: nameA, profile_id: String(userA), thread_key: nameA,
    action_json: JSON.stringify({ type: 'loserAccept', place: `${place1} à ${time1} · ${addr1}`, profileId: profA.id, profileName: nameA, winnerUserId: userA, loserName: nameB }),
    profile_photo: '', timer_start_time: Date.now(), display_time: displayTime,
  });
  ids.messages.push({ step: '2a', id: msg2a.id, user: userB, text: msg2a.text });

  // Transition thread → place_proposed
  await svc.entities.DateThread.updateMany(
    { thread_key: threadKeyAB, version: 2 },
    { $set: { state: 'place_proposed', version: 3, place_json: JSON.stringify({ name: place1, address: addr1, time: time1 }), winner_profile_id: String(profA.id) } }
  );

  // 2b. deliverResult notifyWinnerConfirmed (B=loser accepte) — acquérir locks des DEUX
  // Valider le match
  const bMsgs2 = await svc.entities.UserMessage.filter({ user_id: userB, date_key: today }, '-created_date', 200);
  const hasMatch = bMsgs2.some(m => {
    if (!m.action_json) return false;
    try { const a = JSON.parse(m.action_json); return a.type === 'loserAccept' && a.winnerUserId === userA; } catch { return false; }
  });
  check('2b. Match loserAccept validé', true, hasMatch);

  // Acquérir lock de A (winner) — upsert idempotent + CAS atomique
  await svc.entities.DateLock.upsert(
    [{ lock_key: computeLockKey(today, userA), user_id: userA, date_key: today, reason: 'date_confirmed' }],
    { key: 'lock_key' }
  );
  const casA_2b = await svc.entities.DateLock.updateMany(
    { lock_key: computeLockKey(today, userA), locked: { $ne: true } },
    { $set: { locked: true, reason: 'date_confirmed', thread_key: threadKeyAB } }
  );
  const lockA_2b = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userA) }))[0];
  ids.locks.A = lockA_2b?.id;

  // Acquérir lock de B (loser) — upsert idempotent + CAS atomique
  await svc.entities.DateLock.upsert(
    [{ lock_key: computeLockKey(today, userB), user_id: userB, date_key: today, reason: 'date_confirmed' }],
    { key: 'lock_key' }
  );
  const casB_2b = await svc.entities.DateLock.updateMany(
    { lock_key: computeLockKey(today, userB), locked: { $ne: true } },
    { $set: { locked: true, reason: 'date_confirmed', thread_key: threadKeyAB } }
  );
  const lockB_2b = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userB) }))[0];
  ids.locks.B = lockB_2b?.id;

  // Shadow writes : session + profile de A
  const lockDetails = JSON.stringify({ profileId: String(userB), profileName: nameB, place: place1, confirmedAt: new Date().toISOString() });
  await svc.entities.UserSession.update(sessA.id, { has_accepted_date: true, accepted_date_details: lockDetails });
  await svc.entities.Profile.update(profA.id, { accepted_date_key: today });

  // Message de confirmation dans la boîte de A
  const msg2b = await svc.entities.UserMessage.create({
    user_id: userA, date_key: today, sender: nameB,
    text: msgDateConfirmed(place1), is_system: true,
    profile_name: nameB, profile_id: String(userB), thread_key: nameB,
    profile_photo: '', display_time: displayTime,
  });
  ids.messages.push({ step: '2b', id: msg2b.id, user: userA, text: msg2b.text });

  // Transition thread → accepted + poser has_been_confirmed=true (fait historique)
  await svc.entities.DateThread.updateMany(
    { thread_key: threadKeyAB, version: 3 },
    { $set: { state: 'accepted', version: 4, has_been_confirmed: true, place_json: JSON.stringify({ name: place1, address: addr1, time: time1 }) } }
  );
  const threadAB_after2 = (await svc.entities.DateThread.filter({ thread_key: threadKeyAB }))[0];

  // Vérifications étape 2
  check('2. Thread AB state', 'accepted', threadAB_after2.state);
  check('2. Thread AB version', 4, threadAB_after2.version);

  const lockA_after2 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userA) }))[0];
  const lockB_after2 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userB) }))[0];
  check('2. Lock A locked', true, lockA_after2?.locked);
  check('2. Lock A reason', 'date_confirmed', lockA_after2?.reason);
  check('2. Lock A thread_key', threadKeyAB, lockA_after2?.thread_key);
  check('2. Lock B locked', true, lockB_after2?.locked);
  check('2. Lock B reason', 'date_confirmed', lockB_after2?.reason);
  check('2. Lock B thread_key', threadKeyAB, lockB_after2?.thread_key);

  const sessA_after2 = (await svc.entities.UserSession.filter({ user_id: userA, date_key: today }))[0];
  const profA_after2 = (await svc.entities.Profile.filter({ user_id: userA }))[0];
  check('2. Session A has_accepted_date', true, sessA_after2?.has_accepted_date);
  check('2. Profile A accepted_date_key', today, profA_after2?.accepted_date_key);

  const aMsgs2 = await svc.entities.UserMessage.filter({ user_id: userA, date_key: today }, '-created_date', 200);
  check('2. A a « Date confirmé »', true, aMsgs2.some(m => m.text?.includes('Date confirmé')));
  check('2. Message confirmé match template', msgDateConfirmed(place1), aMsgs2.find(m => m.text?.includes('Date confirmé'))?.text);

  results.push({ label: 'ÉTAPE 2', expected: '—', actual: stepOk ? '✅ PASS' : '❌ FAIL', pass: stepOk, isStep: true });

  // ═══════════════════════════════════════════════════════════════════
  // ÉTAPE 3 — Re-proposition A→C pendant le lock → REFUSÉE
  // ═══════════════════════════════════════════════════════════════════
  stepOk = true;

  // 3a. deliverChallenge(A→C) — créer le défi dans la boîte de C
  const leanA2 = { id: profA.id, user_id: userA, name: nameA, photo: '', age: 25, city: '' };
  const msg3a = await svc.entities.UserMessage.create({
    user_id: userC, date_key: today, sender: nameA,
    text: msgChallengeReceived(nameA), is_system: false,
    profile_name: nameA, profile_id: String(userA), thread_key: nameA,
    action_json: JSON.stringify({ type: 'incomingChallenge', profile: leanA2, opponentChoice: 'rock' }),
    profile_photo: '', display_time: displayTime,
  });
  ids.messages.push({ step: '3a', id: msg3a.id, user: userC, text: msg3a.text });

  // Créer le DateThread A-C pending_challenge
  const threadAC_3 = await svc.entities.DateThread.create({
    thread_key: threadKeyAC, date_key: today,
    user_a_id: [userA, userC].sort()[0], user_b_id: [userA, userC].sort()[1],
    state: 'pending_challenge', version: 1, challenger_user_id: userA,
  });
  ids.threads.AC = threadAC_3.id;

  // 3b. deliverResult notifyWinner (C=loser → A=winner) — PPC résolu
  const msg3b = await svc.entities.UserMessage.create({
    user_id: userA, date_key: today, sender: nameC,
    text: msgChallengeWin(nameC), is_system: false,
    profile_name: nameC, profile_id: String(userC), thread_key: nameC,
    action_json: JSON.stringify({ type: 'winnerChoosePlace', loserProfile: { id: profC.id, user_id: userC, name: nameC } }),
    profile_photo: '', timer_start_time: Date.now(), display_time: displayTime,
  });
  ids.messages.push({ step: '3b', id: msg3b.id, user: userA, text: msg3b.text });

  // Transition thread A-C → ppc_resolved
  await svc.entities.DateThread.updateMany(
    { thread_key: threadKeyAC, version: 1 },
    { $set: { state: 'ppc_resolved', version: 2, winner_user_id: userA, loser_profile_id: String(profC.id) } }
  );

  // 3c. deliverResult notifyLoser (A=winner → C=loser) — vérifier lock de A → LOCKED → REFUS
  const lockA_before3c = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userA) }))[0];
  check('3c. Lock A toujours actif', true, lockA_before3c?.locked);
  check('3c. Lock A reason', 'date_confirmed', lockA_before3c?.reason);

  // A est bloqué → message de refus dans la boîte de A
  const msg3c = await svc.entities.UserMessage.create({
    user_id: userA, date_key: today, sender: 'Système',
    text: msgLockAlreadyHasDate(), is_system: true,
    profile_name: nameC, profile_id: String(userC), thread_key: nameC,
    display_time: displayTime,
  });
  ids.messages.push({ step: '3c', id: msg3c.id, user: userA, text: msg3c.text });

  // Le thread A-C reste à ppc_resolved (non corrompu)
  const threadAC_after3 = (await svc.entities.DateThread.filter({ thread_key: threadKeyAC }))[0];
  check('3. Thread AC state (non corrompu)', 'ppc_resolved', threadAC_after3.state);
  check('3. A a message de refus', true, (await svc.entities.UserMessage.filter({ user_id: userA, date_key: today }, '-created_date', 200)).some(m => m.text === msgLockAlreadyHasDate()));
  check('3. Wording refus match template', msgLockAlreadyHasDate(), msg3c.text);

  results.push({ label: 'ÉTAPE 3', expected: '—', actual: stepOk ? '✅ PASS' : '❌ FAIL', pass: stepOk, isStep: true });

  // ═══════════════════════════════════════════════════════════════════
  // ÉTAPE 4 — Changement de lieu par A + refus par B (raison lieu)
  // ═══════════════════════════════════════════════════════════════════
  stepOk = true;

  // 4a. changeDatePlace(A→B) — A propose un nouveau lieu à B
  const place2 = 'Bar du Marché';
  const time2 = '19:30';
  const addr2 = 'Rue du Marché 5, Bruxelles';

  // Fermer les anciens "Date confirmé" + winnerChoosePlace dans la boîte de A (pour B)
  const aMsgs4 = await svc.entities.UserMessage.filter({ user_id: userA, date_key: today }, '-created_date', 200);
  await Promise.all(
    aMsgs4.filter(m => m.profile_id === userB && (
      m.text?.includes('Date confirmé') ||
      m.action_json?.includes('winnerChoosePlace') ||
      m.action_json?.includes('refusalWithReasons')
    )).map(m => svc.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) }))
  );

  // Fermer les anciens "Date confirmé" + loserAccept dans la boîte de B (pour A)
  const bMsgs4 = await svc.entities.UserMessage.filter({ user_id: userB, date_key: today }, '-created_date', 200);
  await Promise.all(
    bMsgs4.filter(m => m.profile_name === nameA && (
      m.text?.includes('Date confirmé') ||
      m.action_json?.includes('loserAccept') ||
      m.action_json?.includes('refusalWithReasons')
    )).map(m => svc.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) }))
  );

  // Libérer le lock de B (destinataire) — A reste bloqué
  if (lockB_2b) await svc.entities.DateLock.delete(lockB_2b.id);

  // Reset session + profile de B
  await svc.entities.UserSession.update(sessB.id, { has_accepted_date: false, accepted_date_details: null });
  await svc.entities.Profile.update(profB.id, { accepted_date_key: null });

  // Nouvelle proposition dans la boîte de B
  const msg4a = await svc.entities.UserMessage.create({
    user_id: userB, date_key: today, sender: nameA,
    text: msgPlaceChanged(nameA, place2, time2, addr2), is_system: false,
    profile_name: nameA, profile_id: String(userA), thread_key: nameA,
    action_json: JSON.stringify({ type: 'loserAccept', place: `${place2} à ${time2} · ${addr2}`, profileId: profA.id, profileName: nameA, winnerUserId: userA, loserName: nameB, isPlaceChange: true }),
    profile_photo: '', timer_start_time: Date.now(), display_time: displayTime,
  });
  ids.messages.push({ step: '4a', id: msg4a.id, user: userB, text: msg4a.text });

  // Message self pour A
  const msg4a_self = await svc.entities.UserMessage.create({
    user_id: userA, date_key: today, sender: 'Vous',
    text: msgPlaceChangedSelf(place2, time2, addr2, nameB), is_system: true,
    profile_name: nameB, profile_id: String(userB), thread_key: nameB,
    timer_start_time: Date.now(), display_time: displayTime,
  });
  ids.messages.push({ step: '4a_self', id: msg4a_self.id, user: userA, text: msg4a_self.text });

  // Transition thread → place_proposed
  await svc.entities.DateThread.updateMany(
    { thread_key: threadKeyAB, version: 4 },
    { $set: { state: 'place_proposed', version: 5, place_json: JSON.stringify({ name: place2, address: addr2, time: time2 }) } }
  );

  // 4b. deliverResult notifyWinnerRefused (B=loser refuse, reasons=['place'])
  // Valider le match
  const bMsgs4b = await svc.entities.UserMessage.filter({ user_id: userB, date_key: today }, '-created_date', 200);
  const hasMatch4b = bMsgs4b.some(m => {
    if (!m.action_json) return false;
    try { const a = JSON.parse(m.action_json); return a.type === 'loserAccept' && a.winnerUserId === userA; } catch { return false; }
  });
  check('4b. Match loserAccept validé', true, hasMatch4b);

  const reasons = ['place'];
  const hasPersonal = reasons.includes('personal');
  const isFinal = hasPersonal;
  check('4b. Refus non-final (raison lieu)', false, isFinal);

  // Message de refus non-final dans la boîte de A
  const msg4b = await svc.entities.UserMessage.create({
    user_id: userA, date_key: today, sender: nameB,
    text: msgPlaceRefusedNonFinal(nameB, reasons), is_system: true,
    profile_name: nameB, profile_id: String(userB), thread_key: nameB,
    action_json: JSON.stringify({ type: 'refusalWithReasons', reasons, loserProfile: { id: profB.id, user_id: userB, name: nameB }, winnerUserId: userA }),
    profile_photo: '', display_time: displayTime,
  });
  ids.messages.push({ step: '4b', id: msg4b.id, user: userA, text: msg4b.text });

  // Transition thread → place_refused
  await svc.entities.DateThread.updateMany(
    { thread_key: threadKeyAB, version: 5 },
    { $set: { state: 'place_refused', version: 6, refusal_reasons: JSON.stringify(reasons) } }
  );
  const threadAB_after4 = (await svc.entities.DateThread.filter({ thread_key: threadKeyAB }))[0];

  // Vérifications étape 4
  check('4. Thread AB state', 'place_refused', threadAB_after4.state);
  check('4. Thread AB version', 6, threadAB_after4.version);
  check('4. Thread AB refusal_reasons', JSON.stringify(reasons), threadAB_after4.refusal_reasons);

  const lockA_after4 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userA) }))[0];
  const lockB_after4 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userB) }))[0];
  check('4. Lock A toujours actif', true, lockA_after4?.locked);
  check('4. Lock B libéré (supprimé)', null, lockB_after4 || null);

  const aMsgs4b = await svc.entities.UserMessage.filter({ user_id: userA, date_key: today }, '-created_date', 200);
  check('4. A a message de refus', true, aMsgs4b.some(m => { try { return JSON.parse(m.action_json)?.type === 'refusalWithReasons'; } catch { return false; } }));
  check('4. Message refus match template', msgPlaceRefusedNonFinal(nameB, reasons), aMsgs4b.find(m => m.text?.includes('a refusé ta proposition'))?.text);

  results.push({ label: 'ÉTAPE 4', expected: '—', actual: stepOk ? '✅ PASS' : '❌ FAIL', pass: stepOk, isStep: true });

  // ═══════════════════════════════════════════════════════════════════
  // ÉTAPE 5 — Annulation après le refus
  // ═══════════════════════════════════════════════════════════════════
  stepOk = true;

  // cancelDate(A→B) — A annule
  const threadAB_5 = (await svc.entities.DateThread.filter({ thread_key: threadKeyAB }))[0];
  check('5. Thread AB state avant annulation', 'place_refused', threadAB_5.state);

  // wasConfirmed = thread.state === 'accepted' || thread.has_been_confirmed === true
  // has_been_confirmed est un fait historique posé à la transition vers accepted (jamais remis à false)
  const wasConfirmed = threadAB_5.state === 'accepted' || threadAB_5.has_been_confirmed === true;
  check('5. wasConfirmed (has_been_confirmed=true)', true, wasConfirmed);

  // Détection renégociation : chercher le dernier isPlaceChange non résolu
  const allMsgs5 = [
    ...(await svc.entities.UserMessage.filter({ user_id: userA, date_key: today }, '-created_date', 200)),
    ...(await svc.entities.UserMessage.filter({ user_id: userB, date_key: today }, '-created_date', 200)),
  ].sort((a, b) => (a.created_date || '').localeCompare(b.created_date || ''));

  let placeChangeIdx = -1;
  for (let i = allMsgs5.length - 1; i >= 0; i--) {
    try {
      const action = allMsgs5[i].action_json ? JSON.parse(allMsgs5[i].action_json) : null;
      if (action?.type === 'loserAccept' && action?.isPlaceChange) { placeChangeIdx = i; break; }
    } catch {}
  }
  let hasPendingRenegotiation = false;
  if (placeChangeIdx >= 0) {
    hasPendingRenegotiation = true;
    for (let i = placeChangeIdx + 1; i < allMsgs5.length; i++) {
      const txt = allMsgs5[i].text || '';
      let action = null;
      try { action = allMsgs5[i].action_json ? JSON.parse(allMsgs5[i].action_json) : null; } catch {}
      // Un refus non-final (refusalWithReasons) résout le changement de lieu en attente
      if (txt.includes('Date confirmé') || txt.includes('Pas de match') || txt.includes('Date annulé') || txt.includes('Tu as refusé') || action?.type === 'refusalWithReasons') {
        hasPendingRenegotiation = false;
        break;
      }
    }
  }
  const isRenegotiationCancel = wasConfirmed && hasPendingRenegotiation;
  check('5. isRenegotiationCancel (refus a résolu la renégociation)', false, isRenegotiationCancel);

  // Schéma confirmé (wasConfirmed=true, pas de renégociation en attente) :
  // - Annulateur (A) : lock mis à jour en cancelled_after_confirm (reste bloqué)
  // - Autre partie (B) : lock supprimé (libre), flags reset
  if (isRenegotiationCancel) {
    // Schéma pré-acceptation : personne bloqué (renégociation en attente — règle 04/10)
    const lockA_5 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userA) }))[0];
    const lockB_5 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userB) }))[0];
    if (lockA_5) await svc.entities.DateLock.delete(lockA_5.id);
    if (lockB_5) await svc.entities.DateLock.delete(lockB_5.id);
    await svc.entities.UserSession.update(sessA.id, { has_accepted_date: false, accepted_date_details: null });
    await svc.entities.Profile.update(profA.id, { accepted_date_key: null });
    await svc.entities.UserSession.update(sessB.id, { has_accepted_date: false, accepted_date_details: null });
    await svc.entities.Profile.update(profB.id, { accepted_date_key: null });
  } else if (wasConfirmed) {
    // Schéma confirmé : annulateur bloqué (cancelled_after_confirm), autre libre
    const lockA_5 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userA) }))[0];
    if (lockA_5) {
      await svc.entities.DateLock.update(lockA_5.id, { reason: 'cancelled_after_confirm', thread_key: threadKeyAB });
    } else {
      // Edge case : lock n'existe plus → le recréer en cancelled_after_confirm
      await svc.entities.DateLock.create({
        lock_key: computeLockKey(today, userA), user_id: userA, date_key: today,
        locked: true, reason: 'cancelled_after_confirm', thread_key: threadKeyAB,
      });
    }
    const lockB_5 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userB) }))[0];
    if (lockB_5) await svc.entities.DateLock.delete(lockB_5.id);
    // B est libérée (flags reset), A reste bloqué (flags conservés)
    await svc.entities.UserSession.update(sessB.id, { has_accepted_date: false, accepted_date_details: null });
    await svc.entities.Profile.update(profB.id, { accepted_date_key: null });
  } else {
    // Schéma non-confirmé : reset des DEUX, suppression des DEUX locks
    await svc.entities.UserSession.update(sessA.id, { has_accepted_date: false, accepted_date_details: null });
    await svc.entities.Profile.update(profA.id, { accepted_date_key: null });
    await svc.entities.UserSession.update(sessB.id, { has_accepted_date: false, accepted_date_details: null });
    await svc.entities.Profile.update(profB.id, { accepted_date_key: null });
    const lockA_5 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userA) }))[0];
    const lockB_5 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userB) }))[0];
    if (lockA_5) await svc.entities.DateLock.delete(lockA_5.id);
    if (lockB_5) await svc.entities.DateLock.delete(lockB_5.id);
  }

  // Fermer les anciens "Date confirmé"
  const aMsgs5 = await svc.entities.UserMessage.filter({ user_id: userA, date_key: today }, '-created_date', 200);
  const bMsgs5 = await svc.entities.UserMessage.filter({ user_id: userB, date_key: today }, '-created_date', 200);
  await Promise.all(aMsgs5.filter(m => (m.profile_id === userB || m.profile_name === nameB) && m.text?.includes('Date confirmé')).map(m => svc.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) })));
  await Promise.all(bMsgs5.filter(m => (m.profile_id === userA || m.profile_name === nameA) && m.text?.includes('Date confirmé')).map(m => svc.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) })));

  // Messages d'annulation
  const selfText = wasConfirmed ? msgDateCancelledSelf(nameB) : msgNoMatchSelf(nameB);
  const otherText = wasConfirmed ? msgDateCancelledOther(nameA) : msgNoMatchOther(nameA);

  const msg5a = await svc.entities.UserMessage.create({
    user_id: userA, date_key: today, sender: 'Système',
    text: selfText, is_system: true, profile_name: nameB, profile_id: String(userB),
    profile_photo: '', thread_key: nameB, display_time: displayTime,
  });
  ids.messages.push({ step: '5a', id: msg5a.id, user: userA, text: msg5a.text });

  const msg5b = await svc.entities.UserMessage.create({
    user_id: userB, date_key: today, sender: 'Système',
    text: otherText, is_system: true, profile_name: nameA, profile_id: String(userA),
    profile_photo: '', thread_key: nameA, display_time: displayTime,
  });
  ids.messages.push({ step: '5b', id: msg5b.id, user: userB, text: msg5b.text });

  // Transition thread → no_match (wasConfirmed=false) ou cancelled (wasConfirmed=true)
  const cancelState = wasConfirmed ? 'cancelled' : 'no_match';
  await svc.entities.DateThread.updateMany(
    { thread_key: threadKeyAB, version: 6 },
    { $set: { state: cancelState, version: 7 } }
  );
  const threadAB_after5 = (await svc.entities.DateThread.filter({ thread_key: threadKeyAB }))[0];

  // Vérifications étape 5
  check('5. Thread AB state après annulation', cancelState, threadAB_after5.state);
  check('5. A a message d\'annulation', selfText, msg5a.text);
  check('5. B a message d\'annulation', otherText, msg5b.text);

  const lockA_after5 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userA) }))[0];
  const lockB_after5 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userB) }))[0];
  check('5. Lock A reason (annulateur bloqué)', 'cancelled_after_confirm', lockA_after5?.reason);
  check('5. Lock A toujours locked', true, lockA_after5?.locked);
  check('5. Lock B supprimé (autre libre)', null, lockB_after5 || null);

  results.push({ label: 'ÉTAPE 5', expected: '—', actual: stepOk ? '✅ PASS' : '❌ FAIL', pass: stepOk, isStep: true });

  // ═══════════════════════════════════════════════════════════════════
  // ÉTAPE 6 — Re-proposition de A → refusée conformément au lock final
  // ═══════════════════════════════════════════════════════════════════
  stepOk = true;

  // Vérifier l'état du lock de A après l'annulation
  const lockA_before6 = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userA) }))[0];

  // Si le lock de A a été supprimé (schéma non-confirmé), A est libre → re-proposition acceptée
  // Si le lock de A existe encore (cancelled_after_confirm), A est bloqué → refus
  if (lockA_before6?.locked) {
    // A est bloqué → refus avec le wording correspondant au reason du lock
    const expectedMsg6 = lockA_before6.reason === 'cancelled_after_confirm'
      ? msgLockCancelledAfterConfirm()
      : msgLockAlreadyHasDate();
    const msg6 = await svc.entities.UserMessage.create({
      user_id: userA, date_key: today, sender: 'Système',
      text: expectedMsg6,
      is_system: true, profile_name: nameC, profile_id: String(userC), thread_key: nameC,
      display_time: displayTime,
    });
    ids.messages.push({ step: '6', id: msg6.id, user: userA, text: msg6.text });
    check('6. A bloqué (lock actif)', true, lockA_before6.locked);
    check('6. Lock A reason', 'cancelled_after_confirm', lockA_before6.reason);
    check('6. Message de refus', expectedMsg6, msg6.text);
  } else {
    finding('6. FINDING', `Lock de A supprimé à l'étape 5. A est libre → re-proposition NON refusée.`);
    check('6. A bloqué (lock actif)', true, false);
  }

  results.push({ label: 'ÉTAPE 6', expected: '—', actual: stepOk ? '✅ PASS' : '❌ FAIL', pass: stepOk, isStep: true });

  // ═══════════════════════════════════════════════════════════════════
  // ÉTAPE 7 — BONUS : Double-clic sur l'acceptation (idempotence des locks)
  // ═══════════════════════════════════════════════════════════════════
  stepOk = true;

  // Scénario : B et C sont tous les deux perdants contre A (déjà testé plus haut).
  // On simule un NOUVEAU défi B→A (A est challenger, B est défié), A gagne,
  // puis B tente d'accepter DEUX FOIS à 100ms d'intervalle (double-clic).
  // On prouve : un seul lock record, un seul thread bump.

  // Nouveaux profils pour isoler le test : Replay7_B et Replay7_C existent déjà.
  // On crée un nouveau thread B↔C pour le test double-clic.
  const userD = 'replay7_d';
  const nameD = 'Replay7_D';
  const profD = await svc.entities.Profile.create({ user_id: userD, display_name: nameD, gender: 'garçon', age: 28, is_online: true, photo_url: '' });
  ids.profiles.D = profD.id;
  const sessD = await svc.entities.UserSession.create({ user_id: userD, date_key: today, is_online: true, has_accepted_date: false, match_count: 0, challenged_profiles: '{}', passed_profiles: '{}' });
  ids.sessions.D = sessD.id;

  const threadKeyBD = computeThreadKey(today, userB, userD);
  const threadBD_7 = await svc.entities.DateThread.create({
    thread_key: threadKeyBD, date_key: today,
    user_a_id: [userB, userD].sort()[0], user_b_id: [userB, userD].sort()[1],
    state: 'place_proposed', version: 1, challenger_user_id: userB,
    winner_user_id: userB, loser_profile_id: String(profD.id),
  });
  ids.threads.BD = threadBD_7.id;

  // Créer le loserAccept dans la boîte de D (pour que le match soit validé)
  const msg7_loserAccept = await svc.entities.UserMessage.create({
    user_id: userD, date_key: today, sender: nameB,
    text: msgPlaceProposal(nameB, 'TestPlace', '20:00', ''), is_system: false,
    profile_name: nameB, profile_id: String(userB), thread_key: nameB,
    action_json: JSON.stringify({ type: 'loserAccept', place: 'TestPlace à 20:00', profileId: profB.id, profileName: nameB, winnerUserId: userB, loserName: nameD }),
    profile_photo: '', timer_start_time: Date.now(), display_time: displayTime,
  });
  ids.messages.push({ step: '7_loserAccept', id: msg7_loserAccept.id, user: userD, text: msg7_loserAccept.text });

  // ── Double-clic : deux acquireOrVerifyLock concurrents pour le lock de B (winner) ──
  // Réplique exacte de acquireOrVerifyLock (datethread.ts) avec upsert idempotent.
  async function acquireOrVerifyLockReplica(dateKey, userId, reason, tKey) {
    const lockKey = computeLockKey(dateKey, userId);
    // 1. Vérifier le lock existant
    const existing = await svc.entities.DateLock.filter({ lock_key: lockKey });
    if (existing[0]?.locked && existing[0]?.thread_key === tKey) {
      return { acquired: true, lock: existing[0], alreadyHeld: true };
    }
    if (existing[0]?.locked) {
      return { acquired: false, lock: existing[0], alreadyHeld: false };
    }
    // 2. Upsert idempotent + CAS atomique (acquireLock)
    await svc.entities.DateLock.upsert(
      [{ lock_key: lockKey, user_id: userId, date_key: dateKey, reason: 'date_confirmed' }],
      { key: 'lock_key' }
    );
    const casResult = await svc.entities.DateLock.updateMany(
      { lock_key: lockKey, locked: { $ne: true } },
      { $set: { locked: true, reason, thread_key: tKey } }
    );
    const lockRecord = (await svc.entities.DateLock.filter({ lock_key: lockKey }))[0];
    if (casResult?.updated === 0) {
      // Lock non acquis — vérifier s'il est sur CE thread (double-clic / re-confirmation)
      if (lockRecord?.locked && lockRecord?.thread_key === tKey) {
        return { acquired: true, lock: lockRecord, alreadyHeld: true };
      }
      return { acquired: false, lock: lockRecord, alreadyHeld: false };
    }
    return { acquired: true, lock: lockRecord, alreadyHeld: false };
  }

  // Lancer les deux appels concurrents (double-clic à 100ms d'écart)
  const click1 = acquireOrVerifyLockReplica(today, userB, 'date_confirmed', threadKeyBD);
  const click2 = new Promise(resolve => setTimeout(() => resolve(acquireOrVerifyLockReplica(today, userB, 'date_confirmed', threadKeyBD)), 100));
  const [res1, res2] = await Promise.all([click1, click2]);

  // Vérifier qu'un SEUL lock record existe pour B
  const locksB_after7 = await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userB) });
  // Note: il peut y avoir un lock résiduel de l'étape 2 (qui a été libéré à l'étape 4).
  // On filtre pour ne compter que les locks locked=true sur ce thread.
  const activeLocksB = locksB_after7.filter(l => l.locked === true && l.thread_key === threadKeyBD);
  check('7. Un seul lock record actif pour B', 1, activeLocksB.length);
  if (activeLocksB[0]) ids.locks.B_7 = activeLocksB[0].id;

  // Au moins un des deux appels a acquis le lock
  check('7. Click 1 ou Click 2 acquis', true, res1.acquired || res2.acquired);

  // Le thread n'est bumpé qu'une seule fois (version 1→2, pas 1→3)
  // On simule la transition : seul l'appel qui a acquis le lock (non alreadyHeld) transitionne.
  // Les deux appels qui ont alreadyHeld=true ne transitionnent pas (idempotent).
  let transitionApplied = 0;
  for (const r of [res1, res2]) {
    if (r.acquired && !r.alreadyHeld) {
      // Simuler transitionThreadState avec garde de version
      const tResult = await svc.entities.DateThread.updateMany(
        { thread_key: threadKeyBD, version: 1 },
        { $set: { state: 'accepted', version: 2, has_been_confirmed: true } }
      );
      if (tResult?.updated === 1) transitionApplied++;
    }
  }
  check('7. Thread bump unique (transition appliquée 1 fois)', 1, transitionApplied);

  const threadBD_after7 = (await svc.entities.DateThread.filter({ thread_key: threadKeyBD }))[0];
  check('7. Thread BD state', 'accepted', threadBD_after7.state);
  check('7. Thread BD version', 2, threadBD_after7.version);

  // L'appel qui a déjà le lock (alreadyHeld=true) ne doit pas libérer le lock
  // Vérifier que le lock reste locked=true
  const lockB_final = (await svc.entities.DateLock.filter({ lock_key: computeLockKey(today, userB) }))[0];
  check('7. Lock B toujours locked', true, lockB_final?.locked);
  check('7. Lock B thread_key', threadKeyBD, lockB_final?.thread_key);

  results.push({ label: 'ÉTAPE 7', expected: '—', actual: stepOk ? '✅ PASS' : '❌ FAIL', pass: stepOk, isStep: true });

  // ═══════════════════════════════════════════════════════════════════
  // RAPPORT
  // ═══════════════════════════════════════════════════════════════════

  const stepResults = results.filter(r => r.isStep);
  const checkResults = results.filter(r => !r.isStep);
  const allPass = stepResults.every(s => s.pass) && checkResults.every(c => c.pass);

  return {
    steps: stepResults,
    checks: checkResults,
    ids,
    allPass,
    exitCode: allPass ? 0 : 1,
  };
}

export { run, computeThreadKey, computeLockKey };