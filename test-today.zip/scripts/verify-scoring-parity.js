#!/usr/bin/env node
/**
 * TEST DE PARITÉ — scripts/verify-scoring-parity.js
 *
 * Vérifie que les deux copies isomorphes du module de scoring restent identiques :
 *   - src/lib/scoring.js         (frontend, source de vérité)
 *   - base44/shared/scoring.ts   (backend, jumeau isomorphe)
 *
 * Deux niveaux de vérification :
 *   1. PARITÉ STRUCTURELLE  : compare le code des deux fichiers (commentaires exclus).
 *      Si le code diffère, les deux copies ont divergé — échec immédiat.
 *   2. PARITÉ COMPORTEMENTALE : charge le module frontend et calcule les scores sur
 *      16 cas représentatifs (morphologie, astro, personnalité, global, filtres).
 *      Vérifie que chaque score correspond à la valeur attendue.
 *
 * COMMENT LE RELANCER :
 *   node scripts/verify-scoring-parity.js
 *
 * CE QU'IL COMPARE EXACTEMENT :
 *   - Le contenu des deux fichiers, stripping les lignes de commentaires (// ...) et
 *     les lignes vides, puis diff caractère pour caractère.
 *   - Les scores calculés par calculateMatchScore, getCosmicScore,
 *     getPersonalityScore, getGlobalScore, calculatePersonalityCompatibility,
 *     getDistanceKm, ageMatchesRange, distanceMatchesRange sur 16 cas de test.
 *
 * Sortie : exit code 0 si tout passe, exit code 1 sinon.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, '..');
const FRONTEND = path.join(ROOT, 'src', 'lib', 'scoring.js');
const BACKEND = path.join(ROOT, 'base44', 'shared', 'scoring.ts');

let failures = 0;
let passes = 0;
const details = [];

// ─── 1. PARITÉ STRUCTURELLE ───────────────────────────────────────────────────
function stripComments(content) {
  return content
    .split('\n')
    .filter(line => {
      const trimmed = line.trim();
      return trimmed !== '' && !trimmed.startsWith('//');
    })
    .join('\n');
}

try {
  const frontendRaw = fs.readFileSync(FRONTEND, 'utf8');
  const backendRaw = fs.readFileSync(BACKEND, 'utf8');
  const frontendCode = stripComments(frontendRaw);
  const backendCode = stripComments(backendRaw);

  if (frontendCode === backendCode) {
    passes++;
    details.push('✅ PARITÉ STRUCTURELLE : code identique (commentaires exclus)');
  } else {
    failures++;
    details.push('❌ PARITÉ STRUCTURELLE : divergence détectée');
    const fLines = frontendCode.split('\n');
    const bLines = backendCode.split('\n');
    const maxLines = Math.max(fLines.length, bLines.length);
    let diffShown = 0;
    for (let i = 0; i < maxLines && diffShown < 10; i++) {
      if (fLines[i] !== bLines[i]) {
        details.push(`   ligne ${i + 1}:`);
        details.push(`     frontend: ${fLines[i] || '(absent)'}`);
        details.push(`     backend : ${bLines[i] || '(absent)'}`);
        diffShown++;
      }
    }
  }
} catch (e) {
  failures++;
  details.push(`❌ PARITÉ STRUCTURELLE : erreur de lecture — ${e.message}`);
}

// ─── 2. PARITÉ COMPORTEMENTALE ─────────────────────────────────────────────────
// Charge le module frontend (source de vérité). Si la parité structurelle passe,
// le backend produit les mêmes scores — inutile de le charger séparément.
let scoring;
try {
  scoring = await import('file://' + FRONTEND);
} catch (e) {
  failures++;
  details.push(`❌ Impossible de charger le module : ${e.message}`);
  console.error(details.join('\n'));
  process.exit(1);
}

function check(name, expected, got) {
  const ok = expected === got;
  if (ok) {
    passes++;
    details.push(`✅ ${name}: ${got}`);
  } else {
    failures++;
    details.push(`❌ ${name}: attendu=${expected}, obtenu=${got}`);
  }
}

// Cas 1 : matchScore identical/identical → 95
check('matchScore identical/identical', 95,
  scoring.calculateMatchScore(
    { ownPhysicalTraits: ['fine'], likes: [], desired_physical_traits: ['fine'] },
    { seeking: 'fille', desiredTraits: ['fine'], physicalAffinityMap: {} },
    { own_physical_traits: ['fine'] }
  )
);

// Cas 2 : matchScore opposite/opposite → 25
check('matchScore opposite/opposite', 25,
  scoring.calculateMatchScore(
    { ownPhysicalTraits: ['pulpeuse'], likes: [], desired_physical_traits: ['pulpeuse'] },
    { seeking: 'fille', desiredTraits: ['fine'], physicalAffinityMap: {} },
    { own_physical_traits: ['fine'] }
  )
);

// Cas 3 : matchScore opposite/identical → 45
check('matchScore opposite/identical', 45,
  scoring.calculateMatchScore(
    { ownPhysicalTraits: ['pulpeuse'], likes: [], desired_physical_traits: ['fine'] },
    { seeking: 'fille', desiredTraits: ['fine'], physicalAffinityMap: {} },
    { own_physical_traits: ['fine'] }
  )
);

// Cas 4 : matchScore gender incompatible → 0
check('matchScore genderIncompatible', 0,
  scoring.calculateMatchScore(
    { ownPhysicalTraits: ['fine'], likes: ['La féminité', 'La gentillesse'], desired_physical_traits: ['fine'] },
    { seeking: 'garçon', desiredTraits: ['fine'], physicalAffinityMap: {} },
    { own_physical_traits: ['fine'] }
  )
);

// Cas 5 : cosmicScore FEU/AIR sameAsc sameElem → 100 (95+5+5=105 capped)
check('cosmicScore FEU/AIR sameAsc sameElem', 100,
  scoring.getCosmicScore(
    { astro_sign: 'Bélier', astro_ascendant: 'Lion' },
    { astro_sign: 'Gémeaux', astro_ascendant: 'Lion' }
  )
);

// Cas 6 : cosmicScore null (no sign)
check('cosmicScore null', null,
  scoring.getCosmicScore({}, { astro_sign: 'Bélier' })
);

// Cas 7 : globalScore match + cosmic + personality (test uniquement) → 80
// 80*0.45 + 90*0.25 + 70*0.30 = 36 + 22.5 + 21 = 79.5 → 80
check('globalScore match + cosmic + personality', 80, scoring.getGlobalScore(80, 90, 70));

// Cas 8 : globalScore only match → 50
check('globalScore only match', 50, scoring.getGlobalScore(50, null, null));

// Cas 9 : globalScore no scores → 50
check('globalScore no scores', 50, scoring.getGlobalScore(null, null, null));

// Cas 10 : personalityCompat identical → 100
check('personalityCompat identical', 100,
  scoring.calculatePersonalityCompatibility(
    { social: 50, emotionnel: 50, modeVie: 50, relationnel: 50, valeurs: 50 },
    { social: 50, emotionnel: 50, modeVie: 50, relationnel: 50, valeurs: 50 }
  )
);

// Cas 11 : distanceKm same city → 0
check('distanceKm same city', 0, scoring.getDistanceKm('Bruxelles', 'Bruxelles'));

// Cas 12 : ageMatches 30 in 25-35 → true
check('ageMatches 30 in 25-35', true, scoring.ageMatchesRange(30, ['25-35']));

// Cas 13 : distanceMatches null → false
check('distanceMatches null', false, scoring.distanceMatchesRange(null, '0-5'));

// Cas 14 : matchScore with affinity bonus → 100 (95 + 15 capped)
check('matchScore with affinity bonus', 100,
  scoring.calculateMatchScore(
    { ownPhysicalTraits: ['fine'], likes: [], desired_physical_traits: ['fine'] },
    { seeking: 'fille', desiredTraits: ['fine'], physicalAffinityMap: { fine: 8 } },
    { own_physical_traits: ['fine'] }
  )
);

// Cas 15-16 : getPersonalityScore removed (personality scoring retiré du menu flamme)

// ─── RAPPORT ──────────────────────────────────────────────────────────────────
console.log('═══════════════════════════════════════════════════════════════');
console.log('  TEST DE PARITÉ SCORING — frontend vs backend');
console.log('═══════════════════════════════════════════════════════════════');
console.log('  Fichiers comparés :');
console.log('    Frontend : src/lib/scoring.js');
console.log('    Backend  : base44/shared/scoring.ts');
console.log('  Résultat  : ' + passes + ' réussis, ' + failures + ' échoués');
console.log('───────────────────────────────────────────────────────────────');
details.forEach(d => console.log('  ' + d));
console.log('═══════════════════════════════════════════════════════════════');

if (failures > 0) {
  console.error('\n❌ ÉCHEC : ' + failures + ' vérification(s) ont échoué.');
  console.error('   Les deux copies ont divergé — corrigez avant de continuer.');
  process.exit(1);
} else {
  console.log('\n✅ SUCCÈS : parité parfaite (' + passes + ' vérifications).');
  process.exit(0);
}