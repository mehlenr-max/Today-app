#!/usr/bin/env deno run
/**
 * VÉRIFICATION DES NOTIFICATIONS PUSH — scripts/verify-push.ts
 *
 * Prouve la règle d'or : un message réellement créé dans la boîte d'un AUTRE
 * utilisateur déclenche exactement un push, et zéro en cas de rejeu (retry,
 * écriture append-once rejouée) ou de cas ignoré (soi-même, système, admin).
 *
 * Le module testé (base44/shared/push-core.ts) ne dépend d'aucun import
 * plateforme : on lui injecte un faux client Base44 et on observe les envois.
 *
 * LANCER :
 *   deno run scripts/verify-push.ts
 *
 * Sortie : exit code 0 si tout passe, 1 sinon.
 */

import {
  decideMessagePush,
  dispatchMessagePush,
  buildPushBody,
} from '../base44/shared/push-core.ts';

let failures = 0;
let passes = 0;

function check(label: string, actual: unknown, expected: unknown) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) {
    passes++;
    console.log(`  ✅ ${label}`);
  } else {
    failures++;
    console.log(`  ❌ ${label}\n     attendu : ${JSON.stringify(expected)}\n     obtenu  : ${JSON.stringify(actual)}`);
  }
}

// Faux client Base44 : PushLog en mémoire + espion sur SendPushNotification.
function fakeBase44(opts: { failSend?: boolean; users?: Record<string, any> } = {}) {
  const logs: any[] = [];
  const sends: any[] = [];
  let seq = 0;

  const PushLog = {
    filter: async (query: any) => logs.filter((l) => l.dedupe_key === query.dedupe_key),
    create: async (data: any) => {
      const row = { id: `log_${++seq}`, ...data };
      logs.push(row);
      return row;
    },
    update: async (id: string, patch: any) => {
      const row = logs.find((l) => l.id === id);
      if (row) Object.assign(row, patch);
      return row;
    },
  };

  const base44 = {
    asServiceRole: {
      entities: {
        PushLog,
        User: { filter: async (query: any) => (opts.users?.[query.id] ? [opts.users[query.id]] : []) },
      },
      integrations: {
        Core: {
          SendPushNotification: async (payload: any) => {
            if (opts.failSend) throw new Error('502 push unavailable');
            sends.push(payload);
            return { ok: true };
          },
        },
      },
    },
  };

  return { base44, logs, sends };
}

const SENDER = 'u_sender';
const RECIPIENT = 'u_recipient';

function msg(over: any = {}) {
  return {
    id: 'msg_1',
    user_id: RECIPIENT,
    profile_id: SENDER,
    profile_name: 'Léa',
    sender: 'Léa',
    is_system: false,
    action_json: null,
    ...over,
  };
}

const users = {
  [RECIPIENT]: { id: RECIPIENT, role: 'user', language: 'fr' },
};

// ── 1. Défi PPC : un seul push, texte dédié ──
console.log('\n1. Défi PPC (nouveau jeu)');
{
  const { base44, sends, logs } = fakeBase44({ users });
  const message = msg({ action_json: JSON.stringify({ type: 'incomingChallenge' }) });

  const first = await dispatchMessagePush(base44, { message, fromUserId: SENDER });
  check('premier envoi accepté', first.sent, true);
  check('exactement 1 push', sends.length, 1);
  check('titre « ToDay »', sends[0]?.title, 'ToDay');
  check('corps FR du défi PPC', sends[0]?.content, 'Léa te lance un défi');
  check('journal marqué sent', logs[0]?.status, 'sent');

  // Rejeu du même message (retry réseau, rejeu de l'appelant)
  const retry = await dispatchMessagePush(base44, { message, fromUserId: SENDER });
  check('rejeu : ignoré', retry.skipped, 'duplicate');
  check('rejeu : toujours 1 push', sends.length, 1);
  check('rejeu : une seule ligne de journal', logs.length, 1);
}

// ── 2. Défi quiz : texte dédié ──
console.log('\n2. Défi quiz (nouveau jeu)');
{
  const { base44, sends } = fakeBase44({ users });
  const message = msg({ id: 'msg_quiz', action_json: JSON.stringify({ type: 'quizQuestions' }) });
  await dispatchMessagePush(base44, { message, fromUserId: SENDER });
  check('exactement 1 push', sends.length, 1);
  check('corps FR du défi quiz', sends[0]?.content, 'Léa te lance un défi quiz');
}

// ── 3. Message ordinaire : aucun contenu de message dans le push ──
console.log('\n3. Nouveau message');
{
  const { base44, sends } = fakeBase44({ users });
  const message = msg({ id: 'msg_chat', text: 'Mon adresse est 12 rue X' });
  await dispatchMessagePush(base44, { message, fromUserId: SENDER });
  check('exactement 1 push', sends.length, 1);
  check('corps générique', sends[0]?.content, 'Nouveau message de Léa');
  check('aucun contenu du message', String(sends[0]?.content).includes('12 rue X'), false);
}

// ── 4. Cas ignorés ──
console.log('\n4. Cas ignorés (zéro push)');
{
  const { base44, sends } = fakeBase44({ users });
  const self = msg({ id: 'msg_self', user_id: SENDER, profile_id: SENDER });
  const selfRes = await dispatchMessagePush(base44, { message: self, fromUserId: SENDER });
  check('envoi à soi-même', selfRes.skipped, 'ignored');
  check('envoi à soi-même : motif', selfRes.motif, 'soi_meme');
  check('envoi à soi-même : 0 push', sends.length, 0);

  const system = msg({ id: 'msg_sys', profile_id: '', sender: 'Système', profile_name: '' });
  check('message système', (await dispatchMessagePush(base44, { message: system, fromUserId: '' })).skipped, 'ignored');

  const systemSender = msg({ id: 'msg_sys2', sender: 'Système', profile_name: 'Système' });
  const sysSenderRes = await dispatchMessagePush(base44, { message: systemSender, fromUserId: SENDER });
  check('expéditeur « Système »', sysSenderRes.skipped, 'ignored');
  check('expéditeur « Système » : motif', sysSenderRes.motif, 'emetteur_systeme');
  check('cas ignorés : 0 push', sends.length, 0);
}

// ── 4 bis. Le compte admin reçoit ses notifications (exclusion supprimée) ──
console.log('\n4 bis. Destinataire admin');
{
  const adminUsers = { [RECIPIENT]: { id: RECIPIENT, role: 'admin', language: 'fr' } };
  const { base44, sends } = fakeBase44({ users: adminUsers });
  const res = await dispatchMessagePush(base44, { message: msg({ id: 'msg_admin' }), fromUserId: SENDER });
  check('destinataire admin : notifié', res.sent, true);
  check('destinataire admin : 1 push', sends.length, 1);
  check('destinataire admin : texte FR', sends[0]?.content, 'Nouveau message de Léa');
}
console.log('\n4 ter. Destinataire inexistant / recherche en échec');
{
  // La recherche aboutit sans résultat → destinataire inexistant, aucun envoi.
  const { base44, sends } = fakeBase44({ users: {} });
  const res = await dispatchMessagePush(base44, { message: msg({ id: 'msg_ghost' }), fromUserId: SENDER });
  check('destinataire inexistant : ignoré', res.skipped, 'ignored');
  check('destinataire inexistant : motif', res.motif, 'destinataire_inexistant');
  check('destinataire inexistant : 0 push', sends.length, 0);
}
{
  // La recherche échoue (panne) : l'absence n'est pas prouvée, on notifie quand même.
  const { base44, sends } = fakeBase44({ users });
  base44.asServiceRole.entities.User.filter = async () => { throw new Error('user lookup down'); };
  const res = await dispatchMessagePush(base44, { message: msg({ id: 'msg_lookup_down' }), fromUserId: SENDER });
  check('recherche en échec : notifié quand même', res.sent, true);
  check('recherche en échec : 1 push', sends.length, 1);
}

// ── 5. Multilingue (langue du destinataire) ──
console.log('\n5. Multilingue');
{
  check('FR message', buildPushBody('message', 'Léa', 'fr'), 'Nouveau message de Léa');
  check('NL message', buildPushBody('message', 'Léa', 'nl'), 'Nieuw bericht van Léa');
  check('EN message', buildPushBody('message', 'Léa', 'en'), 'New message from Léa');
  check('NL défi', buildPushBody('ppc', 'Léa', 'nl'), 'Léa daagt je uit');
  check('EN quiz', buildPushBody('quiz', 'Léa', 'en'), 'Léa sent you a quiz challenge');
  check('langue inconnue → FR', buildPushBody('message', 'Léa', 'de'), 'Nouveau message de Léa');

  const nlUsers = { [RECIPIENT]: { id: RECIPIENT, role: 'user', language: 'nl' } };
  const { base44, sends } = fakeBase44({ users: nlUsers });
  await dispatchMessagePush(base44, { message: msg({ id: 'msg_nl' }), fromUserId: SENDER });
  check('destinataire NL reçoit le texte NL', sends[0]?.content, 'Nieuw bericht van Léa');
}

// ── 6. Service push en panne : aucune exception, journal en failed ──
console.log('\n6. Panne du service push (l’appelant n’est jamais cassé)');
{
  const { base44, sends, logs } = fakeBase44({ users, failSend: true });
  let threw = false;
  let result: any = null;
  try {
    result = await dispatchMessagePush(base44, { message: msg({ id: 'msg_fail' }), fromUserId: SENDER });
  } catch {
    threw = true;
  }
  check('aucune exception', threw, false);
  check('résultat neutre', result?.skipped, 'error');
  check('aucun envoi compté', sends.length, 0);
  check('journal marqué failed', logs[0]?.status, 'failed');
  check('erreur consignée', String(logs[0]?.error || '').includes('502'), true);

  // Un retry après la panne est ignoré (la clé est déjà réservée) : pas de double envoi.
  const retry = await dispatchMessagePush(base44, { message: msg({ id: 'msg_fail' }), fromUserId: SENDER });
  check('retry après panne : ignoré', retry.skipped, 'duplicate');
}

// ── 7. Décision pure : clé d'idempotence = id du message ──
console.log('\n7. Clé d’idempotence');
{
  const decision = decideMessagePush({ message: msg({ id: 'abc' }), fromUserId: SENDER, recipientUser: users[RECIPIENT] });
  check('clé = msg:<id>', decision?.dedupeKey, 'msg:abc');
  check('titre ToDay par défaut', decision?.title, 'ToDay');
  check('lien de repli', decision?.link, '/');
}

// ── Bilan ──
console.log(`\n${failures === 0 ? '✅' : '❌'} ${passes} vérifications passées, ${failures} échec(s).`);
if (failures > 0) Deno.exit(1);