# ToDay — Métadonnées App Store

## Identité de l'app
- **Nom de l'app :** ToDay
- **Sous-titre :** Rencontres du soir · Belgique
- **Bundle ID :** (à définir dans App Store Connect)
- **URL de support :** https://today.app (ou votre domaine publié)
- **URL de politique de confidentialité :** https://<domaine-publié>/privacy
- **URL des conditions d'utilisation :** https://<domaine-publié>/terms

## Description courte (170 caractères max)
ToDay organise un vrai date ce soir, pas une collection de matchs. Un seul date par jour, confirmé avant minuit. 100% gratuit · Belgique.

## Description longue
ToDay, c'est l'appli qui te pousse à sortir ce soir, pas à scroller pendant des heures.

Ici, pas de files de matchs infinies. Tu publies ta carte, tu choisis ce que tu cherches, et ToDay te propose des profils compatibles pour le soir même. Un défi (Pierre-Feuille-Ciseaux) décide qui choisit le lieu. Un seul date par jour, confirmé avant minuit.

• 100% gratuit, sans abonnement ni publicité
• Matching physique, astrologique et de personnalité
• Un seul date par jour, zéro pression
• Modération communautaire automatique
• Photos vérifiées (visage + contenu approprié)
• Disponible dans toute la Belgique

ToDay : don't spend too much time on this app, spend time with your lover.

## Mots-clés (100 caractères max, séparés par virgules)
rencontre,date,soir,belgique,matching,astrologie,personnalite,gratuit,speed,dating

## Catégorie
- **Principale :** Lifestyle
- **Secondaire :** Social Networking

## Classification par âge
- **Âge minimum :** 18+
- Justification : contenu généré par l'utilisateur non filtré (rencontres), possibilité de photos de profil.

## Notes de version (premier lancement)
Bienvenue sur ToDay ! L'appli belge qui t'organise un date ce soir.
• Crée ta carte en 2 minutes
• Lance un défi pour réserver ta place
• Confirme le lieu avant minuit
• 100% gratuit

## Captures d'écran requises
- 6.7" (iPhone 15 Pro Max) : 1290 × 2796 px
- 6.5" (iPhone 11 Pro Max) : 1242 × 2688 px
- 5.5" (iPhone 8 Plus) : 1242 × 2208 px
- iPad 12.9" : 2048 × 2732 px (si support iPad)

## Checklist soumission App Store
- [x] Suppression de compte dans l'app (Profil → Supprimer mon compte)
- [x] Politique de confidentialité publique (/privacy)
- [x] Conditions d'utilisation publiques (/terms)
- [x] Safe areas iOS gérées (env(safe-area-inset-*))
- [x] Navigation bouton retour fonctionnelle (history state)
- [x] Manifest PWA (installable)
- [x] Pas d'accès payant / abonnement caché
- [ ] Apple Sign-In — à activer côté plateforme d'authentification (Base44) si login social utilisé
- [ ] Icône app 1024×1024 (à fournir dans App Store Connect)
- [ ] Captures d'écran (à générer depuis le simulateur)
- [ ] Compte développeur Apple ($99/an)
- [ ] Build via Base44 → Xcode → TestFlight → App Store

## Rappels importants
1. **Apple Sign-In :** si l'authentification propose Google/Facebook, Apple exige "Sign in with Apple". Base44 gère l'auth — vérifier dans les paramètres de l'app que Apple Sign-In est activé.
2. **Account deletion :** déjà implémenté (fonction backend `deleteUserAccount` + bouton UI). Apple vérifie que le flux fonctionne.
3. **Liens externes :** les liens vers politique/conditions sont accessibles AVANT login (page d'accueil).
4. **Pas de paiement :** l'app est 100% gratuite, aucun IAP requis — aucune intégration Stripe/Wix à configurer.
5. **Données minimes :** pas de localisation GPS, pas de contacts, pas de photos hors profil.