import { useState, useEffect } from 'react';

// Seuil de forte luminosité (lux). Soleil direct ~10000-25000, extérieur couvert ~1000-2000, intérieur ~300-500.
const STRONG_LIGHT_LUX = 1000;

// Thème manuel initial : celui choisi par l'utilisateur s'il existe, sinon le noir
// (couleur de base du fond).
export function getInitialManualTheme() {
  try {
    const saved = localStorage.getItem('today_bg_theme');
    if (saved) return saved;
  } catch {}
  return 'dark';
}

// Bascule automatiquement vers le thème 'white' quand la luminosité ambiante dépasse le seuil.
// Utilise l'API AmbientLightSensor si disponible, sinon retombe sur prefers-color-scheme.
export function useAutoLightTheme(autoEnabled, manualTheme) {
  const [effectiveTheme, setEffectiveTheme] = useState(manualTheme);

  useEffect(() => {
    if (!autoEnabled) {
      setEffectiveTheme(manualTheme);
      return;
    }

    let active = true;
    let sensor = null;

    function applyFallback() {
      if (!active) return;
      try {
        const mq = window.matchMedia('(prefers-color-scheme: light)');
        setEffectiveTheme(mq.matches ? 'white' : manualTheme);
      } catch {
        setEffectiveTheme(manualTheme);
      }
    }

    try {
      const Supported = typeof window !== 'undefined' && 'AmbientLightSensor' in window;
      if (Supported) {
        sensor = new window.AmbientLightSensor({ frequency: 1 });
        sensor.addEventListener('reading', () => {
          if (!active) return;
          const lux = sensor.illuminance || 0;
          setEffectiveTheme(lux > STRONG_LIGHT_LUX ? 'white' : manualTheme);
        });
        sensor.addEventListener('error', applyFallback);
        sensor.start();
      } else {
        applyFallback();
      }
    } catch {
      applyFallback();
    }

    return () => {
      active = false;
      if (sensor) {
        try { sensor.stop(); } catch {}
      }
    };
  }, [autoEnabled, manualTheme]);

  return effectiveTheme;
}