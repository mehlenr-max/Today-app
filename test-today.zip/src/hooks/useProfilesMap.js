import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

/**
 * Charge tous les profils (sauf l'utilisateur courant) et les indexe par display_name.
 * Réutilise un cache sessionStorage partagé (TTL 10 min) pour éviter un 2e appel serveur
 * quand plusieurs onglets (Messages, Quiz) montent en même temps.
 *
 * @param {string} userId - ID de l'utilisateur courant (exclu du résultat)
 * @returns {{ profilesMap: Record<string, object>, loading: boolean }}
 */
export function useProfilesMap(userId) {
  const [profilesMap, setProfilesMap] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) return;
    let cancelled = false;

    const buildMap = (list) => {
      const map = {};
      list.forEach(p => {
        // Index principal : user_id (stable — ne change pas quand le pseudo change)
        if (p.user_id) map[p.user_id] = p;
        // Index secondaire : display_name (fallback pour anciens messages sans profile_id)
        if (p.display_name) map[p.display_name] = p;
      });
      return map;
    };

    const cachedData = sessionStorage.getItem('browse_profiles_cache');
    const cacheTime = sessionStorage.getItem('browse_profiles_time');
    if (cachedData && cacheTime && (Date.now() - parseInt(cacheTime, 10) < 600000)) {
      try {
        setProfilesMap(buildMap(JSON.parse(cachedData)));
      } catch {}
      setLoading(false);
      return;
    }

    base44.functions.invoke('getProfilesMap', {}).then(res => {
      if (cancelled) return;
      const list = res.data?.profiles || [];
      setProfilesMap(buildMap(list));
      sessionStorage.setItem('browse_profiles_cache', JSON.stringify(list));
      sessionStorage.setItem('browse_profiles_time', Date.now().toString());
    }).catch(e => console.error('getProfilesMap failed:', e)).finally(() => {
      if (!cancelled) setLoading(false);
    });

    return () => { cancelled = true; };
  }, [userId]);

  return { profilesMap, loading };
}

export default useProfilesMap;