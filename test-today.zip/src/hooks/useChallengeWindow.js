import { useEffect, useState } from 'react';
import { getChallengeWindow } from '@/lib/challenge-window';

// État de la fenêtre des défis, rafraîchi chaque minute (passage de 6 h / 23 h / minuit).
// Un administrateur n'est jamais bloqué : la fenêtre est toujours ouverte pour lui.
export default function useChallengeWindow(isAdmin = false) {
  const [challengeWindow, setChallengeWindow] = useState(() => getChallengeWindow(new Date(), isAdmin));

  useEffect(() => {
    setChallengeWindow(getChallengeWindow(new Date(), isAdmin));
    const id = setInterval(() => setChallengeWindow(getChallengeWindow(new Date(), isAdmin)), 60000);
    return () => clearInterval(id);
  }, [isAdmin]);

  return challengeWindow;
}