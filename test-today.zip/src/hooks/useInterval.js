// Hook pour gérer les intervals de manière clean

import { useEffect, useRef, useCallback } from 'react';

export function useInterval(callback, delay, options = {}) {
  const { enabled = true, immediate = false } = options;
  const savedCallback = useRef(callback);

  // Synchronise la callback
  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  useEffect(() => {
    if (!enabled) return;

    if (immediate) savedCallback.current();

    const id = setInterval(() => savedCallback.current(), delay);
    return () => clearInterval(id);
  }, [delay, enabled, immediate]);
}

export function useMountedRef() {
  const mounted = useRef(true);

  useEffect(() => {
    return () => {
      mounted.current = false;
    };
  }, []);

  return mounted;
}