import { useEffect, useRef } from 'react';
import { registerOverlay, unregisterOverlay } from '../lib/overlay-history';

let overlayCounter = 0;

// Branche le bouton retour natif sur une superposition : tant qu'elle est
// ouverte, le retour la ferme au lieu de quitter la page.
export default function useOverlayBack(isOpen, onClose) {
  const idRef = useRef(null);
  const closeRef = useRef(onClose);

  useEffect(() => {
    closeRef.current = onClose;
  });

  useEffect(() => {
    if (!isOpen) return;
    if (!idRef.current) {
      overlayCounter += 1;
      idRef.current = `overlay_${overlayCounter}`;
    }
    registerOverlay(idRef.current, () => closeRef.current?.());
    return () => unregisterOverlay(idRef.current);
  }, [isOpen]);
}