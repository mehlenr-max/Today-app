import { useSyncExternalStore } from 'react';
import { subscribeQuizUsage, getQuizUsageVersion } from '@/lib/quiz-usage';

// Force un rendu dès qu'un jeu est proposé depuis n'importe quel menu œil
// (deck, messages, jeux) : les trois menus lisent le même état partagé.
export default function useQuizUsageVersion() {
  return useSyncExternalStore(subscribeQuizUsage, getQuizUsageVersion, getQuizUsageVersion);
}