// Hook pour débouncer une valeur ou fonction

import { useState, useEffect } from 'react';

export function useDebounce(value, delay = 500) {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);

  return debouncedValue;
}

export function useDebouncedCallback(callback, delay = 500) {
  const [timeout, setTimeout] = useState(null);

  const debouncedFn = (...args) => {
    if (timeout) clearTimeout(timeout);
    const newTimeout = setTimeout(() => callback(...args), delay);
    setTimeout(newTimeout);
  };

  return debouncedFn;
}