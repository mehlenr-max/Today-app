import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import DarkAuthLayout, {
  darkInputStyle,
  darkPrimaryBtnStyle,
  darkLinkBtnStyle,
} from "@/components/DarkAuthLayout";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await base44.auth.resetPasswordRequest(email);
    } catch {
      // Always show success regardless
    } finally {
      setLoading(false);
      setSent(true);
    }
  };

  return (
    <DarkAuthLayout title="Mot de passe oublié" subtitle="On t'enverra un lien pour le réinitialiser.">
      {sent ? (
        <p style={{ color: "#9f9fae", fontSize: "0.88rem", lineHeight: 1.5, textAlign: "center", margin: 0 }}>
          Si un compte existe avec cet email, tu recevras un lien de réinitialisation rapidement.
        </p>
      ) : (
        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            autoFocus
            required
            style={darkInputStyle}
          />
          <button type="submit" disabled={loading} style={darkPrimaryBtnStyle(loading)}>
            {loading ? "⏳" : "Envoyer le lien"}
          </button>
        </form>
      )}
      <Link to="/login" style={{ ...darkLinkBtnStyle, textAlign: "center" }}>
        ← Retour à la connexion
      </Link>
    </DarkAuthLayout>
  );
}