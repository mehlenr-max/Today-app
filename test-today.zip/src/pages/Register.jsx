import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import DarkAuthLayout, {
  darkInputStyle,
  darkPrimaryBtnStyle,
  darkLinkBtnStyle,
  DarkDivider,
  DarkError,
} from "@/components/DarkAuthLayout";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { toast } from "@/components/ui/use-toast";
import { safeReturnTo } from "@/lib/authReturnTo";
import AgeConfirmModal from "@/components/today/AgeConfirmModal";
import RulesScreen from "@/components/today/RulesScreen";
import LanguageSwitcher from "@/components/today/LanguageSwitcher";
import { useLanguage } from "@/lib/i18n/LanguageContext";

export default function Register() {
  // La langue choisie sur cet écran devient la langue par défaut du profil.
  const { lang } = useLanguage();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const [otpCode, setOtpCode] = useState("");
  const [showAgeConfirm, setShowAgeConfirm] = useState(false);
  const [showRules, setShowRules] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (password !== confirmPassword) {
      setError("Les mots de passe ne correspondent pas");
      return;
    }
    setShowAgeConfirm(true);
  };

  const confirmAgeAndRegister = async () => {
    setShowAgeConfirm(false);
    setLoading(true);
    setError("");
    try {
      await base44.auth.register({ email, password });
      setShowOtp(true);
    } catch (err) {
      setError(err.message || "Échec de l'inscription");
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setError("");
    setLoading(true);
    try {
      const result = await base44.auth.verifyOtp({ email, otpCode });
      if (result?.access_token) {
        base44.auth.setToken(result.access_token);
      }
      // Le compte vient d'être créé : on y enregistre la langue choisie pour que
      // le profil de la personne s'ouvre directement dans sa langue.
      await base44.auth.updateMe({ language: lang }).catch(() => {});
      setShowOtp(false);
      setShowRules(true);
    } catch (err) {
      setError(err.message || "Code de vérification invalide");
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setError("");
    try {
      await base44.auth.resendOtp(email);
      toast({ title: "Code envoyé", description: "Vérifie ton email pour le nouveau code." });
    } catch (err) {
      setError(err.message || "Échec de l'envoi du code");
    }
  };

  const loginLink = "/login" + (safeReturnTo() !== "/" ? "?returnTo=" + encodeURIComponent(safeReturnTo()) : "");

  if (showRules) {
    return (
      <RulesScreen
        onAccept={() => { window.location.href = safeReturnTo(); }}
      />
    );
  }

  if (showOtp) {
    return (
      <DarkAuthLayout
        title="Vérifie ton email"
        subtitle={`Nous avons envoyé un code à ${email}`}
        aboveCard={<LanguageSwitcher />}
      >
        <DarkError>{error}</DarkError>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: "8px" }}>
          <InputOTP
            maxLength={6}
            value={otpCode}
            onChange={setOtpCode}
            autoFocus
            autoComplete="one-time-code"
          >
            <InputOTPGroup>
              <InputOTPSlot index={0} className="border-white/20 bg-white/5 text-white" />
              <InputOTPSlot index={1} className="border-white/20 bg-white/5 text-white" />
              <InputOTPSlot index={2} className="border-white/20 bg-white/5 text-white" />
              <InputOTPSlot index={3} className="border-white/20 bg-white/5 text-white" />
              <InputOTPSlot index={4} className="border-white/20 bg-white/5 text-white" />
              <InputOTPSlot index={5} className="border-white/20 bg-white/5 text-white" />
            </InputOTPGroup>
          </InputOTP>
        </div>
        <button
          onClick={handleVerify}
          disabled={loading || otpCode.length < 6}
          style={darkPrimaryBtnStyle(loading || otpCode.length < 6)}
        >
          {loading ? "⏳" : "Vérifier"}
        </button>
        <p style={{ textAlign: "center", color: "#9f9fae", fontSize: "0.85rem", margin: 0 }}>
          Pas reçu le code ?{" "}
          <button onClick={handleResend} style={{ ...darkLinkBtnStyle, display: "inline", fontWeight: 600 }}>
            Renvoyer
          </button>
        </p>
      </DarkAuthLayout>
    );
  }

  return (
    <DarkAuthLayout
      title="Créer mon compte"
      subtitle="Rejoins ToDay en quelques secondes."
      showLegal
      aboveCard={<LanguageSwitcher />}
    >
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        <DarkError>{error}</DarkError>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoComplete="email"
          autoFocus
          required
          style={darkInputStyle}
        />
        <input
          type="password"
          placeholder="Mot de passe"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="new-password"
          required
          minLength={6}
          style={darkInputStyle}
        />
        <input
          type="password"
          placeholder="Confirme le mot de passe"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          autoComplete="new-password"
          required
          style={darkInputStyle}
        />
        <button type="submit" disabled={loading} style={darkPrimaryBtnStyle(loading)}>
          {loading ? "⏳" : "Créer mon compte"}
        </button>
      </form>

      <button onClick={() => (window.location.href = loginLink)} style={darkLinkBtnStyle}>
        Déjà un compte ? Connecte-toi
      </button>

      {showAgeConfirm && (
        <AgeConfirmModal onConfirm={confirmAgeAndRegister} onCancel={() => setShowAgeConfirm(false)} />
      )}
    </DarkAuthLayout>
  );
}