import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import LoginScreen from '../components/today/LoginScreen';
import HomeTab from '../components/today/HomeTab';
import CardSetupTab from '../components/today/CardSetupTab';
import CreateDateTab from '../components/today/CreateDateTab';
import BrowseTab from '../components/today/BrowseTab';
import MessagesTab from '../components/today/MessagesTab.jsx';
import QuizTab from '../components/today/QuizTab.jsx';
import RpsFlow from '../components/today/RpsFlow';
import WelcomeOnboarding from '../components/today/WelcomeOnboarding';
import ToDayInBrief from '../components/today/ToDayInBrief';
import NextSessionCountdown from '../components/today/NextSessionCountdown';
import HeaderMenu from '../components/today/HeaderMenu';
import { translate } from '@/lib/i18n/engine';
import OfflineDeckGuard from '../components/today/OfflineDeckGuard';
import BottomTabBar from '../components/today/BottomTabBar';
import { consumeOverlayPop } from '../lib/overlay-history';

import { getParisDateKey } from '../lib/today-data';
import { base44 } from '../api/base44Client';
import { useAutoLightTheme, getInitialManualTheme } from '../hooks/useAutoLightTheme';
import { requestNotificationPermission, registerServiceWorker, showLocalNotification } from '../lib/notifications';
import toast, { Toaster } from 'react-hot-toast';
import {
  setUserOnline, isUserOnline, hasAcceptedDateToday,
  getMessagesForToday, addMessageForToday,
  markDateAccepted, markPassed,
  removeMessageActionForToday, getCreatePrefs, markIncomingChallenge,
  hasChallengedToday, hasBeenChallengedByToday, hasPassedToday, markChallenged,
  saveCreatePrefs, clearMessagesForToday, getPassedProfiles,
  getChallengedProfiles, clearThreadMessagesExceptConfirmed,
  getPhysicalAffinityMap, updatePhysicalAffinity, seedSession,
  invalidateCache, reloadSessionAndProfile, getChallengeDates,
} from '../lib/today-store';
import { isQuizMessage } from '../lib/quiz-messages';
// cleanExpiredData supprimé (fonction vide, no-op) — LOT Blindage Scale ITEM 5b

const TABS = [
  { id: 'home',     label: '⌂' },
  { id: 'create',   label: '🔥' },
  { id: 'browse',   label: '❤️' },
  { id: 'messages', label: '💬' },
  { id: 'quiz',     label: '🎲' },
  { id: 'card',     label: '👤' },
];

export default function ToDay4() {
  const [user, setUser] = useState(null);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [manualTheme, setManualTheme] = useState(() => getInitialManualTheme());
  const [autoLight, setAutoLight] = useState(() => localStorage.getItem('today_bg_auto') === 'true');
  const bgTheme = useAutoLightTheme(autoLight, manualTheme);

  // Thèmes sombres → classe .dark sur la racine du document (styles dark natifs)
  useEffect(() => {
    document.documentElement.classList.toggle('dark', bgTheme === 'dark' || bgTheme === 'pink');
  }, [bgTheme]);

  // Le choix de fond (thème manuel ou mode auto) est enregistré sur le compte :
  // il suit l'utilisateur d'un appareil à l'autre.
  function handleBgTheme(theme) {
    setManualTheme(theme);
    localStorage.setItem('today_bg_theme', theme);
    base44.auth.updateMe({ bg_theme: theme }).catch(e => console.error('save bg_theme failed:', e));
  }

  function handleToggleAutoLight() {
    const next = !autoLight;
    setAutoLight(next);
    localStorage.setItem('today_bg_auto', String(next));
    base44.auth.updateMe({ bg_auto: next }).catch(e => console.error('save bg_auto failed:', e));
  }
  const [tab, setTab] = useState('home');
  const [userProfile, setUserProfile] = useState(null);
  const [isOnline, setIsOnline] = useState(false);
  const [prefs, setPrefs] = useState(null);
  const [deckCandidates, setDeckCandidates] = useState([]);
  const [messages, setMessages] = useState([]);
  const [hasNewMessage, setHasNewMessage] = useState(false);
  const [rpsOverlay, setRpsOverlay] = useState(null);
  // Compteur par onglet : incrémenté quand SON onglet est re-tapé → il revient
  // à ses vues racines (les autres onglets ne sont pas touchés).
  const [tabResetTokens, setTabResetTokens] = useState({});
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showRules, setShowRules] = useState(false);
  const [seenProposals, setSeenProposals] = useState(new Set());
  // Session state cached from DB
  const [sessionState, setSessionState] = useState({
    hasAccepted: false,
    challengedProfiles: {},
    passedProfiles: {},
  });
  // Derive "incoming pending" from realtime messages — not only the session cache.
  // A challenge message with action.type === 'incomingChallenge' that hasn't been
  // answered (action still present) means the counterpart has a pending challenge.
  const incomingFromMessages = useMemo(() => {
    const set = new Set();
    (messages || []).forEach(m => {
      let action = m.action;
      if (!action && m.action_json) {
        try { action = typeof m.action_json === 'string' ? JSON.parse(m.action_json) : m.action_json; } catch {}
      }
      if (action?.type === 'incomingChallenge') {
        const pid = action.profile?.id;
        if (pid) set.add(String(pid));
      }
    });
    return set;
  }, [messages]);

  // Règle béton : on ne peut JAMAIS défier un profil avec qui on a une
  // interaction de date active (non terminée). Couvre le cas où l'interaction
  // a progressé au-delà du stade "incoming" (lieu proposé, PPC joué, etc.)
  // — là où challengedProfiles['incoming'] et incomingFromMessages ne bloquent plus.
  const activeDateInteractionUserIds = useMemo(() => {
    const active = new Set();
    const terminated = new Set();
    (messages || []).forEach(m => {
      const pid = m.profile_id;
      if (!pid) return;
      // Ignorer les messages de jeu (onglet 🎲 — interaction séparée des défis date)
      if (isQuizMessage(m)) return;
      const key = String(pid);
      if (m.text?.includes('Pas de match') || m.text?.includes('Date annulé')) {
        terminated.add(key);
      } else {
        active.add(key);
      }
    });
    terminated.forEach(k => active.delete(k));
    return active;
  }, [messages]);

  const contentRef = useRef(null);
  const incomingChallengeTimerRef = useRef(null);
  const tabRef = useRef(tab);
  const messagesRef = useRef(messages);
  const lastDeckReloadRef = useRef(0);
  const handleTabChangeRef = useRef(null);
  useEffect(() => { tabRef.current = tab; }, [tab]);
  useEffect(() => { messagesRef.current = messages; }, [messages]);

  // Titre de page dynamique — point rouge quand messages non lus
  useEffect(() => {
    document.title = hasNewMessage ? '● ToDay' : 'ToDay';
    return () => { document.title = 'ToDay'; };
  }, [hasNewMessage]);

  useEffect(() => {
    base44.auth.me().then(u => {
      if (u) login(u);
    }).catch(e => console.error('auth.me failed:', e));
    // Enregistrer le service worker et demander la permission
    registerServiceWorker();
  }, []);

  useEffect(() => {
    if (user) {
      setTimeout(() => contentRef.current?.scrollTo({ top: 0, behavior: 'instant' }), 50);
    }
  }, [user]);

  useEffect(() => {
    return () => {
      if (incomingChallengeTimerRef.current) clearInterval(incomingChallengeTimerRef.current);
    };
  }, []);

  async function login(u) {
    setUser(u);
    // Demander la permission de notification après login
    requestNotificationPermission();
    // Afficher l'onboarding de bienvenue tant que l'utilisateur ne l'a pas vu
    // (has_seen_onboarding est persisté sur le User). Pas de limite de temps —
    // l'inscription (OTP + règlement) peut prendre plusieurs minutes.
    if (!u.has_seen_onboarding) setShowOnboarding(true);

    // Restaure les préférences de fond enregistrées sur le compte (appareil neuf,
    // réinstallation ou changement de téléphone).
    if (u.bg_theme) {
      setManualTheme(u.bg_theme);
      localStorage.setItem('today_bg_theme', u.bg_theme);
    }
    if (typeof u.bg_auto === 'boolean') {
      setAutoLight(u.bg_auto);
      localStorage.setItem('today_bg_auto', String(u.bg_auto));
    }

    // Un seul appel batch backend : profil + session + messages + candidats scorés
    const res = await base44.functions.invoke('getBrowseDeck', {});
    const data = res.data || {};
    const profileData = data.profile || null;
    const session = data.session || {};
    const msgs = data.messages || [];
    const candidates = data.candidates || [];

    // Amorcer le cache today-store avec la session backend
    seedSession(u.id, session.raw);

    setUserProfile(profileData);
    setDeckCandidates(candidates);
    // Statut en ligne / hors-ligne : c'est un choix persistant (Profile.explicitly_offline),
    // il survit à la déconnexion → on le RESTAURE au lieu de forcer « en ligne ».
    const wasExplicitlyOffline = Boolean(profileData?.explicitly_offline);
    setIsOnline(!wasExplicitlyOffline);
    // Mettre en ligne (debounce 5 min — évite une écriture à chaque reload/naviguation)
    const FIVE_MIN = 5 * 60 * 1000;
    // Fire-and-forget : ces écritures ne bloquent pas le premier rendu.
    // Erreurs loggées (jamais avalées silencieusement).
    if (wasExplicitlyOffline) {
      // Resté hors ligne : la session du jour suit le choix persistant
      if (session.is_online) {
        setUserOnline(u.id, false).catch(e => console.error('setUserOnline failed:', e));
      }
    } else {
      if (!session.is_online) {
        setUserOnline(u.id, true).catch(e => console.error('setUserOnline failed:', e));
      }
      if (profileData) {
        const lastOnlineMs = profileData.last_online_date ? new Date(profileData.last_online_date).getTime() : 0;
        if (Date.now() - lastOnlineMs > FIVE_MIN) {
          base44.entities.Profile.update(profileData.id, { is_online: true, last_online_date: new Date().toISOString() }).catch(e => console.error('Profile.update is_online failed:', e));
        }
      }
    }
    setMessages(msgs);
    // Alerte seulement si un message plus récent que le dernier vu est arrivé
    const dk = getParisDateKey();
    const lastTimestamp = localStorage.getItem(`lastMessageTimestamp:${u.id}:${dk}`) || '';
    // Exclure les jeux — ils déclenchent le badge de l'onglet 🎲, pas Messages
    const nonQuizMsgs = msgs.filter(m => !isQuizMessage(m));
    const latestMsg = nonQuizMsgs[nonQuizMsgs.length - 1];
    if (latestMsg && latestMsg.created_date > lastTimestamp) setHasNewMessage(true);
    // Préférences : session du jour en priorité, sinon profil persisté
    const resolvedPrefs = session.create_prefs || (profileData?.create_prefs ? (() => { try { return JSON.parse(profileData.create_prefs); } catch { return null; } })() : null);
    if (resolvedPrefs) setPrefs(resolvedPrefs);
    // Restaurer seenProposals depuis localStorage
    const storedSeen = localStorage.getItem(`seenProposals:${u.id}:${dk}`);
    if (storedSeen) {
      try { setSeenProposals(new Set(JSON.parse(storedSeen))); } catch {}
    }
    setSessionState(prev => ({
      ...prev,
      hasAccepted: session.has_accepted_date || false,
      passedProfiles: session.passed_profiles || {},
      challengedProfiles: session.challenged_profiles || {},
      challengeDates: session.challenge_dates || {},
      physicalAffinityMap: session.physical_affinity || {},
    }));
    setIsLoadingData(false);
  }

  // Recharge uniquement les candidats scorés (après changement de prefs)
  const reloadDeck = useCallback(async () => {
    try {
      const res = await base44.functions.invoke('getBrowseDeck', {});
      const data = res.data || {};
      if (data.candidates) setDeckCandidates(data.candidates);
      // Filet de sécurité : synchroniser l'état de session + profil depuis le deck
      // (le deck se recharge toutes les 30s et au focus — pas de requête supplémentaire).
      // getBrowseDeck retourne déjà has_accepted_date, challenged_profiles, accepted_date_key.
      const session = data.session || {};
      setSessionState(prev => ({
        ...prev,
        hasAccepted: session.has_accepted_date || false,
        passedProfiles: session.passed_profiles || {},
        challengedProfiles: session.challenged_profiles || {},
        challengeDates: session.challenge_dates || {},
        physicalAffinityMap: session.physical_affinity || {},
      }));
      if (data.profile) {
        setUserProfile(prev => prev ? { ...prev, accepted_date_key: data.profile.accepted_date_key, is_hidden: data.profile.is_hidden } : prev);
      }
    } catch (e) { console.error('reloadDeck failed', e); }
  }, []);

  async function handleToggleOnline() {
    if (!user) return;
    if (!userProfile) { setTab('card'); return; }
    const newState = !isOnline;
    setIsOnline(newState); // optimistic update
    try {
      await setUserOnline(user.id, newState);
      // Synchroniser Profile.is_online pour la visibilité RLS
      if (userProfile?.id) {
        if (newState) {
          // Reconnexion : reset du compteur 7 jours + effacer le marqueur hors-ligne explicite
          await base44.entities.Profile.update(userProfile.id, {
            is_online: true,
            explicitly_offline: false,
            last_online_date: new Date().toISOString(),
          });
          setUserProfile(prev => prev ? { ...prev, is_online: true, explicitly_offline: false, last_online_date: new Date().toISOString() } : prev);
        } else {
          // Mise hors-ligne explicite : disparaît du deck immédiatement
          await base44.entities.Profile.update(userProfile.id, {
            is_online: false,
            explicitly_offline: true,
          });
          setUserProfile(prev => prev ? { ...prev, is_online: false, explicitly_offline: true } : prev);
        }
      }
    } catch (e) {
      console.warn('setUserOnline failed, retrying...', e);
      setTimeout(async () => {
        try { await setUserOnline(user.id, newState); } catch {}
      }, 1500);
    }
  }

  // Repasser en ligne depuis l'écran de garde du deck, puis rafraîchir les candidats
  async function handleGoOnline() {
    await handleToggleOnline();
    reloadDeck();
  }

  function handleProfileSaved(payload) {
    setUserProfile(payload);
    handleTabChange('home');
  }

  // Enregistrement du test de personnalité (obligatoire avant l'accès au deck)
  async function handlePersonalitySave(profile, phrase) {
    try {
      if (userProfile?.id) {
        const update = { personality_profile: JSON.stringify(profile), quiz_phrase: phrase };
        await base44.entities.Profile.update(userProfile.id, update);
        setUserProfile(prev => prev ? { ...prev, ...update } : prev);
      }
    } catch (e) { console.error('personality save failed', e); }
  }

  async function handlePublished(p, updatedProfile) {
    await saveCreatePrefs(user.id, p);
    setPrefs(p);
    // Persister les prefs dans le profil pour survie après déconnexion
    updatedProfile = { ...updatedProfile, create_prefs: JSON.stringify(p) };

    // Sauvegarder les champs du profil en DB
    try {
      let saved;
      if (userProfile?.id) {
        saved = await base44.entities.Profile.update(userProfile.id, { ...updatedProfile, is_online: isOnline });
      } else {
        saved = await base44.entities.Profile.create({ ...updatedProfile, is_online: isOnline });
      }
      setUserProfile(saved || updatedProfile);
    } catch {
      setUserProfile(updatedProfile);
    }

    // Rafraîchir le deck avec les nouvelles préférences AVANT de switcher
    // pour que les scores de compatibilité physique reflètent les critères modifiés
    await reloadDeck();
    handleTabChange('browse');
  }

  async function pushMessage(sender, text, isSystem, profileName = '', action = null, profileId = null, timerStartTime = null) {
    if (!user) return;
    const msg = { user_id: user.id, sender, text, is_system: isSystem, profile_name: profileName, profile_id: profileId, thread_key: profileName || 'system', action, timer_start_time: timerStartTime };
    // Optimistic update — affiche immédiatement
    const optimisticMsg = { ...msg, id: `optimistic_${Date.now()}`, created_date: new Date().toISOString(), timerStartTime: timerStartTime || null, display_time: new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' }) };
    setMessages(prev => [...prev, optimisticMsg]);
    if (tabRef.current !== 'messages') {
      setHasNewMessage(true);
    }
    // Persist en arrière-plan
    addMessageForToday(user.id, msg).catch(e => console.error('addMessageForToday failed:', e));
  }



  // Recharge le profil (quota de jeux par paire) après une action qui le modifie côté serveur
  const refreshProfile = useCallback(async () => {
    if (!user?.id) return;
    try {
      const profiles = await base44.entities.Profile.filter({ user_id: user.id });
      if (profiles[0]) setUserProfile(profiles[0]);
    } catch (e) {
      console.error('refreshProfile failed:', e);
    }
  }, [user?.id]);

  const refreshMessages = useCallback(async () => {
    if (!user) return;
    const [updated, challengedProfiles, challengeDates, passedProfiles, accepted] = await Promise.all([
      getMessagesForToday(user.id),
      getChallengedProfiles(user.id),
      getChallengeDates(user.id),
      getPassedProfiles(user.id),
      hasAcceptedDateToday(user.id),
    ]);
    setMessages(updated);
    setSessionState(prev => ({
      ...prev,
      hasAccepted: accepted,
      challengedProfiles: challengedProfiles || {},
      challengeDates: challengeDates || {},
      passedProfiles: passedProfiles || {},
    }));
  }, [user]);

  // Synchronise session + profil depuis la base (après invalidation du cache).
  // Utilisé par le handler temps réel pour refléter les changements d'état sans rechargement.
  const syncFromDB = useCallback(async () => {
    if (!user) return;
    try {
      const fresh = await reloadSessionAndProfile(user.id);
      setSessionState(prev => ({
        ...prev,
        hasAccepted: fresh.hasAccepted,
        challengedProfiles: fresh.challengedProfiles,
        challengeDates: fresh.challengeDates,
        passedProfiles: fresh.passedProfiles,
        physicalAffinityMap: fresh.physicalAffinityMap,
      }));
      setUserProfile(prev => prev ? { ...prev, accepted_date_key: fresh.accepted_date_key, is_hidden: fresh.is_hidden } : prev);
    } catch (e) {
      console.error('syncFromDB failed:', e);
    }
  }, [user]);

  // Badge refresh — lightweight: re-fetches messages and updates the unread badge state
  const refreshBadge = useCallback(async () => {
    if (!user) return;
    const dk = getParisDateKey();
    const updated = await getMessagesForToday(user.id);
    setMessages(prev => {
      // Détecte tout changement : longueur, premier ID, ou dernier ID
      // (le dernier ID capte les suppressions+créations comme l'annulation de date,
      // où la longueur totale reste identique mais le contenu change)
      if (prev.length === updated.length &&
          prev[0]?.id === updated[0]?.id &&
          prev[prev.length - 1]?.id === updated[updated.length - 1]?.id) return prev;
      return updated;
    });
    if (tabRef.current === 'messages') {
      // Sur l'onglet messages → synchroniser lastMessageTimestamp avec les timestamps DB
      // Jamais en arrière : on ne met à jour que si le nouveau timestamp est plus récent
      const latestMsg = updated[updated.length - 1];
      if (latestMsg) {
        const currentTs = localStorage.getItem(`lastMessageTimestamp:${user.id}:${dk}`) || '';
        if (latestMsg.created_date > currentTs) {
          localStorage.setItem(`lastMessageTimestamp:${user.id}:${dk}`, latestMsg.created_date);
        }
      }
    } else if (tabRef.current === 'quiz') {
      // Sur l'onglet quiz → synchroniser lastQuizTimestamp
      const quizMsgs = updated.filter(m => m.action?.type === 'quizQuestions' || m.action?.type === 'quizAnswers');
      const latest = quizMsgs[quizMsgs.length - 1];
      if (latest) {
        const currentTs = localStorage.getItem(`lastQuizTimestamp:${user.id}:${dk}`) || '';
        if (latest.created_date > currentTs) {
          localStorage.setItem(`lastQuizTimestamp:${user.id}:${dk}`, latest.created_date);
        }
      }
    } else {
      const lastTimestamp = localStorage.getItem(`lastMessageTimestamp:${user.id}:${dk}`) || '';
      // Exclure les jeux — ils déclenchent le badge de l'onglet 🎲, pas Messages
      const nonQuizMsgs = updated.filter(m => !isQuizMessage(m));
      const latestMsg = nonQuizMsgs[nonQuizMsgs.length - 1];
      if (latestMsg && latestMsg.created_date > lastTimestamp) {
        setHasNewMessage(true);
      }
    }
  }, [user]);

  // Abonnement temps réel — reçoit les changements d'état et synchronise depuis la base.
  // Ne se contente PAS de chercher du texte dans le fil : on invalide le cache et on relit
  // la vérité serveur. Un "Date annulé" arrivant APRÈS un "Date confirmé" débloque
  // correctement le non-annulateur (la base a déjà été mise à jour par cancelDate).
  useEffect(() => {
    if (!user) return;
    const unsubscribe = base44.entities.UserMessage.subscribe((event) => {
      if (event.data?.user_id !== user.id) return;
      const text = event.data.text || '';
      const actionJson = event.data.action_json || '';

      // Événements qui changent l'état de session ou de profil → recharger depuis la base.
      const isStateChange =
        text.includes('Date confirmé') ||
        text.includes('Date annulé') ||
        text.includes('Pas de match') ||
        text.includes('Résultat PPC') ||
        text.includes('Tu as perdu') ||
        text.includes('Tu as gagné') ||
        text.includes('a changé le lieu') ||
        text.includes('a refusé ta proposition') ||
        text.includes('te propose un lieu') ||
        actionJson.includes('isPlaceChange') ||
        actionJson.includes('winnerChoosePlace') ||
        actionJson.includes('loserAccept') ||
        actionJson.includes('refusalWithReasons');

      if (isStateChange) {
        syncFromDB();
        reloadDeck();
      }

      refreshBadge();
    });
    return unsubscribe;
  }, [user, refreshBadge, reloadDeck, syncFromDB]);

  // Rafraîchir le badge au retour sur l'onglet + polling léger (15s) en arrière-plan
  useEffect(() => {
    if (!user) return;
    const handleFocus = () => {
      if (!document.hidden) {
        refreshBadge();
        // Rafraîchir le deck pour refléter les profils masqués (modération auto)
        // sans rechargement manuel. Debounce 30s pour éviter les appels excessifs.
        const now = Date.now();
        if (now - lastDeckReloadRef.current > 30000) {
          lastDeckReloadRef.current = now;
          reloadDeck();
        }
      }
    };
    document.addEventListener('visibilitychange', handleFocus);
    window.addEventListener('focus', handleFocus);
    return () => {
      document.removeEventListener('visibilitychange', handleFocus);
      window.removeEventListener('focus', handleFocus);
    };
  }, [user, refreshBadge, reloadDeck]);

  async function handleRpsBackground(type, profile, data) {
    if (type === 'playerTurn') {
      await pushMessage('Système', `🎮 ${profile.name} a joué ! C'est ton tour.`, true, profile.name,
        { type: 'playerTurn', profile: { id: profile.id, user_id: profile.user_id, name: profile.name }, opponentChoice: data.opponentChoice }, profile.user_id);
    } else if (type === 'timeout') {
      await pushMessage('Système', `⏰ ${profile.name} n'a pas répondu. Pas de match.`, true, profile.name);
    } else if (type === 'winnerSent') {
      // Optimistic: retirer immédiatement les actions de l'état local pour éviter le flash du bouton
      setMessages(prev => prev.map(m => {
        if (m.profile_name !== profile.name || !m.action_json) return m;
        try {
          const a = JSON.parse(m.action_json);
          if (a?.type === 'winnerChoosePlace' || a?.type === 'refusalWithReasons') return { ...m, action_json: null };
        } catch {}
        return m;
      }));
      // Maintenant qu'un lieu a été envoyé, supprimer les messages d'action en attente (en parallèle)
      await Promise.all([
        removeMessageActionForToday(user.id, 'winnerChoosePlace', profile.name),
        removeMessageActionForToday(user.id, 'refusalWithReasons', profile.name),
      ]);
      // L'utilisateur a gagné et propose un lieu → l'envoyer au perdant (profile)
      const winnerProfile = {
        id: userProfile?.id,
        user_id: user.id,
        name: userProfile?.display_name || user.full_name || 'Quelqu\'un',
        photo: userProfile?.photo_url || '',
        photo_url_2: userProfile?.photo_url_2 || '',
        photo_url_3: userProfile?.photo_url_3 || '',
        age: userProfile?.age,
        city: userProfile?.city,
      };
      if (profile.user_id) {
        try {
          const res = await base44.functions.invoke('deliverResult', {
            type: 'notifyLoser',
            recipientUserId: profile.user_id,
            senderProfile: winnerProfile,
            place: data.place,
            time: data.time,
            address: data.address || '',
            dateKey: getParisDateKey(),
            winnerUserId: user.id,
          });
          // Serveur a refusé la proposition (gagnant déjà verrouillé) — stopper le flux local.
          // Le serveur a déjà créé un message pour le gagnant ; on ne push PAS "En attente".
          if (res?.data?.blocked) {
            toast.error(res.data?.reason === 'cancelled_after_confirm'
              ? "Tu as annulé un date confirmé — tu ne peux pas proposer de nouveau date aujourd'hui."
              : "Tu as déjà un date aujourd'hui.");
            refreshMessages();
            return;
          }
        } catch (e) {
          console.error('deliverResult notifyLoser failed:', e);
          toast.error('Erreur lors de l\'envoi du lieu. Réessaie.');
          return;
        }
      }
      // Le miroir « En attente » est désormais créé côté serveur par deliverResult/notifyLoser
      // (garde d'idempotence + écriture attendue avant la réponse de succès).
      // NE PAS bloquer le gagnant au moment de la proposition — le blocage n'intervient
      // qu'à la confirmation du lieu. Le gagnant reste libre de défier d'autres profils.
      invalidateCache(user.id);
      reloadDeck();
      refreshMessages();
    } else if (type === 'changePlaceSent') {
      // Changement de lieu après confirmation → changeDatePlace nettoie les anciens messages + renvoie la proposition
      const proposerProfile = {
        id: userProfile?.id,
        user_id: user.id,
        name: userProfile?.display_name || user.full_name || 'Quelqu\'un',
        photo: userProfile?.photo_url || '',
      };
      if (profile.user_id) {
        try {
          await base44.functions.invoke('changeDatePlace', {
            recipientUserId: profile.user_id,
            senderProfile: proposerProfile,
            place: data.place,
            time: data.time,
            address: data.address || '',
            dateKey: getParisDateKey(),
          });
          // Le proposant reste bloqué pendant la renégociation — flags conservés.
        } catch (e) {
          console.error('changeDatePlace failed:', e);
          // Erreur visible (point 3 du périmètre) — présentation seule, la logique du flux lieu est inchangée.
          toast.error('Changement de lieu impossible. Réessaie.');
        }
      }
      await pushMessage('Système', `⏳ Nouveau lieu proposé à ${profile.name} : "${data.place}" à ${data.time}${data.address ? `\n📍 ${data.address}` : ''}`, true, profile.name, null, profile.user_id, Date.now());
      refreshMessages();
    }
  }

  async function handleRpsAction(action) {
    if (action.type === 'playerTurn') {
      setRpsOverlay({ profile: action.profile, initialStep: 'playerTurn', initialOpponentChoice: action.opponentChoice });
    } else if (action.type === 'incomingChallenge') {
      // L'action du défi n'est PAS consommée ici : elle ne l'est qu'après un succès
      // de resolveRps (handleRpsResolve). En cas d'échec serveur, le défi reste rejouable.
      setRpsOverlay({ profile: action.profile, initialStep: 'playerTurn', initialOpponentChoice: action.opponentChoice });
    } else if (action.type === 'winnerChoosePlace') {
      // Le gagnant clique pour choisir le lieu → ouvrir WinnerPlaceModal avec le profil du perdant
      // NE PAS supprimer le message ici — on le supprime seulement quand le lieu est envoyé
      setRpsOverlay({ profile: action.loserProfile, initialStep: 'winnerPlace' });
    }
  }

  // Callbacks pour BrowseTab (async)
  async function handleChallengeSend(profile, senderChoice) {
    // Mise à jour optimiste locale uniquement (grissage du bouton) — la persistance
    // du marqueur en base se fait APRÈS un 200 du backend, jamais avant.
    setSessionState(prev => ({
      ...prev,
      challengedProfiles: { ...prev.challengedProfiles, [String(profile.id)]: true },
      challengeDates: { ...prev.challengeDates, [String(profile.id)]: new Date().toISOString() },
    }));

    // Notifier le profil défié (vrai utilisateur) dans sa boîte de messages
    if (profile.user_id) {
      const challengerProfile = {
        id: userProfile?.id,
        user_id: user.id,
        name: userProfile?.display_name || user.full_name || 'Quelqu\'un',
        photo: userProfile?.photo_url || '',
        photo_url_2: userProfile?.photo_url_2 || '',
        photo_url_3: userProfile?.photo_url_3 || '',
        age: userProfile?.age,
        city: userProfile?.city,
        fiveWords: userProfile?.five_words || '',
        quizPhrase: userProfile?.quiz_phrase || '',
        ownPhysicalTraits: userProfile?.own_physical_traits || [],
        ownPersonalityTraits: userProfile?.own_personality_traits || [],
        personal_flaws: userProfile?.personal_flaws || [],
        gender: userProfile?.gender,
        education: userProfile?.education || '',
        job: userProfile?.job || '',
        height: userProfile?.height || null,
      };
      try {
        await base44.functions.invoke('deliverChallenge', {
          recipientUserId: profile.user_id,
          senderProfileId: userProfile?.id,
          challengerProfile,
          opponentChoice: senderChoice,
          dateKey: getParisDateKey(),
        });
        // Succès : persister le marqueur "true" en base (après le 200)
        await markChallenged(user.id, profile.id);
      } catch (e) {
        const errData = e?.data?.data || e?.data || {};
        if (errData?.blocked && errData?.reason === 'incoming_pending') {
          alert(errData?.message || translate(`${profile.name} t'a déjà envoyé un défi ! Réponds dans tes messages.`));
          // Revert optimistic update — le marker reste 'incoming' côté serveur
          setSessionState(prev => ({
            ...prev,
            challengedProfiles: { ...prev.challengedProfiles, [String(profile.id)]: 'incoming' },
          }));
          return;
        }
        if (errData?.blocked && errData?.reason === 'already_challenged') {
          alert(errData?.message || translate(`Tu as déjà envoyé un défi à ${profile.name}. Attends sa réponse.`));
          // Le marqueur "true" reste justifié (défi déjà envoyé) — on le garde en UI
          await markChallenged(user.id, profile.id);
          return;
        }
        if (errData?.blocked && errData?.reason === 'personal_refusal_lockout') {
          alert(errData?.message || translate(`Suite à un refus pour raisons personnelles, vous ne pouvez plus vous défier aujourd'hui.`));
          // Marquer le profil comme "personal_refusal" pour désactiver le bouton Défier
          setSessionState(prev => ({
            ...prev,
            challengedProfiles: { ...prev.challengedProfiles, [String(profile.id)]: 'personal_refusal' },
          }));
          return;
        }
        if (errData?.blocked && errData?.reason === 'challenge_window_closed') {
          alert(errData?.message || translate('Les défis ne sont possibles que les JEUDIS et SAMEDIS, de 6 h à 23 h (heure belge).'));
          // Revert de l'optimisme UI : aucun défi n'a été envoyé
          setSessionState(prev => {
            const next = { ...prev.challengedProfiles };
            delete next[String(profile.id)];
            return { ...prev, challengedProfiles: next };
          });
          return;
        }
        if (errData?.blocked && errData?.reason === 'already_interacted') {
          alert(errData?.message || translate(`Vous avez déjà interagi aujourd'hui. Vous ne pouvez plus vous défier.`));
          // Marquer la paire comme verrouillée — désactive le bouton Défier
          setSessionState(prev => ({
            ...prev,
            challengedProfiles: { ...prev.challengedProfiles, [String(profile.id)]: 'locked' },
          }));
          return;
        }
        // Autre erreur (réseau, 500…) : rollback complet de l'optimisme UI
        console.error('deliverChallenge failed:', e);
        setSessionState(prev => {
          const next = { ...prev.challengedProfiles };
          delete next[String(profile.id)];
          return { ...prev, challengedProfiles: next };
        });
      }
    } else {
      // Pas de user_id cible — pas d'appel backend, on persiste le marqueur local
      await markChallenged(user.id, profile.id);
    }

    // +2 points par trait physique du profil défié → affine le profil de compatibilité
    // Fire-and-forget : non-critique pour l'UI, évite de bloquer la navigation
    (async () => {
      try {
        const traits = profile.ownPhysicalTraits || [];
        await updatePhysicalAffinity(user.id, traits, false);
        const updatedAffinity = await getPhysicalAffinityMap(user.id);
        setSessionState(prev => ({ ...prev, physicalAffinityMap: updatedAffinity }));
      } catch (e) {
        console.error('updatePhysicalAffinity failed:', e);
      }
    })();
  }

  // Résolution PPC côté serveur (incrément 1b) — UN SEUL appel, aucune écriture client.
  // Le défi (action du message) n'est consommé qu'APRÈS un succès serveur : en cas d'échec il
  // reste cliquable donc rejouable, et resolveRps est idempotent (aucun doublon au retry).
  async function handleRpsResolve(profile, playerChoice, opponentChoice) {
    if (!profile?.user_id) return true;
    try {
      const res = await base44.functions.invoke('deliverResult', {
        type: 'resolveRps',
        opponentUserId: profile.user_id,
        playerChoice,
        opponentChoice,
        dateKey: getParisDateKey(),
      });
      if (!res?.data?.success) throw new Error(res?.data?.error || 'resolveRps failed');
      await Promise.all([
        removeMessageActionForToday(user.id, 'incomingChallenge', profile.name),
        removeMessageActionForToday(user.id, 'playerTurn', profile.name),
      ]);
      invalidateCache(user.id);
      await Promise.all([refreshMessages(), reloadDeck()]);
      return true;
    } catch (e) {
      console.error('resolveRps failed:', e);
      toast.error('Résolution du défi impossible. Réessaie.');
      return false;
    }
  }

  function handleTabChange(t, skipHistory) {
    if (t === 'messages') {
      setHasNewMessage(false);
      // Marquer toutes les propositions de lieux comme vues
      const newSeen = new Set(seenProposals);
      messages.forEach(m => {
        if ((m.text.includes('te propose un lieu') || m.text.includes('propose')) && 
            !m.text.includes('Tu as refusé') && 
            !m.text.startsWith('❌') &&
            !m.text.includes('Date confirmé')) {
          newSeen.add(m.profile_name || m.text);
        }
      });
      setSeenProposals(newSeen);
      if (user) {
        const dk = getParisDateKey();
        // Persister les propositions vues
        localStorage.setItem(`seenProposals:${user.id}:${dk}`, JSON.stringify([...newSeen]));
        // Timestamp du dernier message vu → uniquement les messages DB (pas les optimistes)
        // Les messages optimistes ont des timestamps client plus anciens que la DB, ce qui
        // ferait réapparaître le badge au prochain refresh. On ne descend jamais en arrière.
        const realMsgs = messagesRef.current.filter(m => !m.id?.startsWith('optimistic_'));
        const latestSeen = realMsgs[realMsgs.length - 1];
        const newTs = latestSeen?.created_date || new Date().toISOString();
        const currentTs = localStorage.getItem(`lastMessageTimestamp:${user.id}:${dk}`) || '';
        if (newTs > currentTs) {
          localStorage.setItem(`lastMessageTimestamp:${user.id}:${dk}`, newTs);
        }
      }
    } else if (tabRef.current === 'messages' && user) {
      // Quitte l'onglet messages → marquer tout comme vu jusqu'à maintenant.
      // On utilise « maintenant » comme plancher (et non le dernier message DB) :
      // un message optimiste encore en cours de persistance obtiendra un timestamp
      // serveur ≈ maintenant, donc ne sera pas vu comme « nouveau » au prochain refresh.
      const dk = getParisDateKey();
      const nowTs = new Date().toISOString();
      const currentTs = localStorage.getItem(`lastMessageTimestamp:${user.id}:${dk}`) || '';
      if (nowTs > currentTs) {
        localStorage.setItem(`lastMessageTimestamp:${user.id}:${dk}`, nowTs);
      }
      setHasNewMessage(false);
    }
    if (t === 'quiz' && user) {
      // Entrée sur l'onglet quiz → marquer tous les quiz actuels comme vus
      const dk = getParisDateKey();
      const quizMsgs = messagesRef.current.filter(m =>
        m.action?.type === 'quizQuestions' || m.action?.type === 'quizAnswers'
      );
      const latest = quizMsgs[quizMsgs.length - 1];
      const newTs = latest?.created_date || new Date().toISOString();
      const currentTs = localStorage.getItem(`lastQuizTimestamp:${user.id}:${dk}`) || '';
      if (newTs > currentTs) {
        localStorage.setItem(`lastQuizTimestamp:${user.id}:${dk}`, newTs);
      }
    }
    // Re-tap de l'onglet déjà actif → retour aux vues racines de cet onglet
    // (fiche profil consultée, quiz en cours, défi pierre-papier-ciseaux) et
    // aucune nouvelle entrée d'historique (le retour natif ne doit pas être pollué).
    const isSameTab = t === tabRef.current;
    if (isSameTab) {
      setRpsOverlay(null);
      setTabResetTokens(prev => ({ ...prev, [t]: (prev[t] || 0) + 1 }));
    }
    setTab(t);
    // Pas de retour en haut : chaque onglet conserve sa propre position de défilement.
    // Back stack : pousser l'état dans l'historique du navigateur (sauf navigation par popstate)
    if (!skipHistory && !isSameTab) {
      window.history.pushState({ tab: t }, '', `#tab=${t}`);
    }
  }
  // Toujours disposer de la dernière version de handleTabChange
  handleTabChangeRef.current = handleTabChange;

  // Back stack : le bouton retour du téléphone remonte les onglets
  useEffect(() => {
    const handlePopState = (e) => {
      // Une superposition ouverte a consommé le retour → ne pas changer d'onglet
      if (consumeOverlayPop()) return;
      const prevTab = e.state?.tab;
      if (prevTab && TABS.some(t => t.id === prevTab)) {
        handleTabChangeRef.current?.(prevTab, true);
      } else {
        handleTabChangeRef.current?.('home', true);
      }
    };
    window.addEventListener('popstate', handlePopState);
    // État initial
    window.history.replaceState({ tab: 'home' }, '', '#tab=home');
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Hooks avant early returns — Rules of Hooks (useMemo ne peut pas être après un return)
  const CANCEL_SELF_MARKER = 'Tu as annulé le rendez-vous';
  const isCancelledBlock = useMemo(() => !!userProfile?.accepted_date_key && messages.some(m => m.is_system && m.text?.includes('Date annulé') && m.text?.includes(CANCEL_SELF_MARKER)), [userProfile?.accepted_date_key, messages]);

  // « tab » dans les dépendances : passer sur l'onglet Dé marque les quiz comme vus
  // (lastQuizTimestamp) et doit donc recalculer le badge immédiatement.
  const memoHasPendingQuiz = useMemo(() => {
    if (!user) return false;
    const dk = getParisDateKey();
    const lastTs = localStorage.getItem(`lastQuizTimestamp:${user.id}:${dk}`) || '';
    return messages.some(m =>
      (m.action?.type === 'quizQuestions' || m.action?.type === 'quizAnswers') &&
      m.created_date > lastTs
    );
  }, [user, messages, tab]);

  const memoHasPlayerTurn = useMemo(() => messages.some(m => m.action?.type === 'playerTurn'), [messages]);

  const memoHasNewProposal = useMemo(() => tab !== 'messages' && messages.some(m =>
    (m.text.includes('te propose un lieu') || m.text.includes('propose')) &&
    !m.text.includes('Tu as refusé') &&
    !m.text.startsWith('❌') &&
    !m.text.includes('Date confirmé') &&
    !seenProposals.has(m.profile_name || m.text)
  ), [messages, tab, seenProposals]);

  if (!user) return <LoginScreen />;

  if (showOnboarding) {
    return <WelcomeOnboarding onDone={async () => {
      setShowOnboarding(false);
      try { await base44.auth.updateMe({ has_seen_onboarding: true }); } catch {}
    }} />;
  }

  // user_id du/de la partenaire du date accepté aujourd'hui (pour afficher sa photo dans l'onglet cœur)
  const acceptedCounterpartUserId = (!userProfile?.accepted_date_key || isCancelledBlock)
    ? null
    : ((messages || []).find(m => m.text?.includes('Date confirmé'))?.profile_id || null);

  return (
    <div style={{
      position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
      maxWidth: '480px', margin: '0 auto',
      color: bgTheme === 'white' ? '#111' : '#fff',
      fontFamily: "'Poppins', sans-serif",
      background: bgTheme === 'white'
        ? '#f0e6d3'
        : bgTheme === 'pink'
        ? 'radial-gradient(circle at 16% 16%, rgba(255,51,102,0.45) 0%, transparent 40%), radial-gradient(circle at 80% 20%, rgba(255,105,180,0.35) 0%, transparent 40%), linear-gradient(180deg, #1a0010 0%, #0d0008 100%)'
        : 'radial-gradient(circle at 16% 16%, rgba(255,51,102,0.22) 0%, transparent 24%), radial-gradient(circle at 86% 18%, rgba(255,105,180,0.14) 0%, transparent 22%), linear-gradient(180deg, #070709 0%, #040405 42%, #030304 100%)',
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
    }}>
      <style>{`
        * { overflow-x: hidden !important; }
        .heart-3d {
          transform: perspective(1000px) rotateZ(0deg);
          filter: drop-shadow(0 10px 20px rgba(255,51,102,0.4)) drop-shadow(0 0 30px rgba(255,105,180,0.3));
        }
        .blink-day { animation: blinkDay 13s ease-in-out infinite; }
        @keyframes blinkDay {
          0%    { opacity: 1; }
          3.85% { opacity: 0.12; }
          7.7%  { opacity: 1; }
          11.55% { opacity: 0.12; }
          15.4% { opacity: 1; }
          19.25% { opacity: 0.12; }
          23.1%, 100% { opacity: 1; }
        }
      `}</style>
      <div style={{ position: 'sticky', top: 0, flexShrink: 0, zIndex: 50, paddingTop: 'env(safe-area-inset-top)', background: bgTheme === 'white' ? 'rgba(240,230,211,0.92)' : 'rgba(7,7,9,0.92)', backdropFilter: 'blur(16px)', borderBottom: bgTheme === 'white' ? '1px solid rgba(0,0,0,0.1)' : '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <HeaderMenu
              isWhite={bgTheme === 'white'}
              isAdmin={user?.role === 'admin'}
              onManual={() => setShowRules(true)}
              onDeleteAccount={async () => {
                if (!window.confirm(translate('Veux-tu vraiment supprimer ton compte ? Cette action est irréversible et toutes tes données seront effacées.'))) return;
                try {
                  await base44.functions.invoke('deleteUserAccount', {});
                  await base44.auth.logout('/');
                } catch (e) {
                  alert(translate('Erreur lors de la suppression du compte : ') + (e.message || e));
                }
              }}
              onLogout={() => { try { localStorage.removeItem('base44_access_token'); localStorage.removeItem('token'); } catch {} window.location.href = '/login'; }}
            />
            <img src="https://media.base44.com/images/public/69b91874189d1f38a8e07d5f/13012b7bc_image_19ee64c32.jpg" alt="ToDay" fetchPriority="high" loading="eager" style={{ height: '52px', objectFit: 'contain', mixBlendMode: bgTheme === 'white' ? 'multiply' : 'screen', filter: bgTheme === 'white' ? 'invert(1) hue-rotate(180deg)' : 'none' }} />
          </div>
        </div>
      </div>
      {/* Le conteneur partagé ne défile plus : chaque onglet gère son propre défilement
          (position conservée d'un onglet à l'autre, pas de rubber-banding iOS). */}
      <div ref={contentRef} style={{ flex: 1, minHeight: 0, position: 'relative', overflow: 'hidden' }}>
        <div className="h-full overflow-y-auto overscroll-y-contain" style={{ display: tab === 'home' ? 'block' : 'none' }}>
          <HomeTab user={user} userProfile={userProfile} isOnline={isOnline} hasAccepted={sessionState.hasAccepted} isLoading={isLoadingData} onGoCreate={() => handleTabChange('create')} onGoCard={() => handleTabChange('card')} onToggleOnline={handleToggleOnline} bgTheme={bgTheme} onBgTheme={handleBgTheme} autoLight={autoLight}           onToggleAutoLight={handleToggleAutoLight} onShowRules={() => setShowRules(true)} onLogout={() => { try { localStorage.removeItem('base44_access_token'); localStorage.removeItem('token'); } catch {} window.location.href = '/login'; }} onAstroSave={async (sign, ascendant) => {
            try {
              if (userProfile?.id) {
                const update = { astro_sign: sign };
                if (ascendant) update.astro_ascendant = ascendant;
                await base44.entities.Profile.update(userProfile.id, update);
                setUserProfile(prev => prev ? { ...prev, ...update } : prev);
              }
            } catch (e) { console.error('astro save failed', e); }
          }}
          onPersonalitySave={handlePersonalitySave}
        />
        </div>
        <div className="h-full overflow-y-auto overscroll-y-contain" style={{ display: tab === 'card' ? 'block' : 'none' }}>
          <CardSetupTab user={user} existingProfile={userProfile} isActive={tab === 'card'} onSaved={handleProfileSaved} onBack={() => handleTabChange('home')} onSeekingChanged={() => setPrefs(null)} bgTheme={bgTheme} />
        </div>
        <div className="h-full overflow-y-auto overscroll-y-contain" style={{ display: tab === 'create' ? 'block' : 'none' }}>
          <CreateDateTab user={user} userProfile={userProfile} isOnline={isOnline} onPublished={handlePublished} onToggleOnline={handleToggleOnline} onGoHome={() => handleTabChange('home')} bgTheme={bgTheme} />
        </div>
        <div className="h-full overflow-y-auto overscroll-y-contain" style={{ display: tab === 'browse' ? 'block' : 'none' }}>
          {isOnline ? (
          <BrowseTab
            userId={user.id}
            resetToken={tabResetTokens.browse}
            isAdmin={user?.role === 'admin'}
            userProfile={userProfile}
            isVisible={tab === 'browse'}
            isCancelledBlock={isCancelledBlock}
            acceptedCounterpartUserId={acceptedCounterpartUserId}
            candidates={deckCandidates}
            prefs={prefs ? { ...prefs, physicalAffinityMap: sessionState.physicalAffinityMap || {} } : prefs}
            sessionState={sessionState}
            incomingFromMessages={incomingFromMessages}
            activeDateInteractionUserIds={activeDateInteractionUserIds}
            onAddMessage={(text) => pushMessage('Système', text, true)}
            onRefresh={reloadDeck}
            onRpsBackground={(type, profile, data) => handleRpsBackground(type, profile, data)}
            onChallengeSend={handleChallengeSend}
            onPersonalitySave={handlePersonalitySave}
            onUnblock={async (profileId) => {
              if (!userProfile?.id) return;
              try {
                const blocked = Array.isArray(userProfile.blocked_profile_ids) ? userProfile.blocked_profile_ids : [];
                const updated = blocked.filter(id => String(id) !== String(profileId));
                await base44.entities.Profile.update(userProfile.id, { blocked_profile_ids: updated });
                setUserProfile(prev => prev ? { ...prev, blocked_profile_ids: updated } : prev);
                reloadDeck();
                toast.success('Profil débloqué');
              } catch (e) {
                console.error('unblock failed', e);
                toast.error('Déblocage impossible');
              }
            }}
          />
          ) : (
            <OfflineDeckGuard bgTheme={bgTheme} onGoOnline={handleGoOnline} />
          )}
        </div>
        <div className="h-full overflow-y-auto overscroll-y-contain" style={{ display: tab === 'messages' ? 'block' : 'none' }}>
          <MessagesTab
            userId={user.id}
            resetToken={tabResetTokens.messages}
            messages={messages}
            setMessagesOptimistic={setMessages}
            sessionState={sessionState}
            myProfile={userProfile}
            prefs={prefs ? { ...prefs, physicalAffinityMap: sessionState.physicalAffinityMap || {} } : prefs}
            bgTheme={bgTheme}
            onGoCreate={() => handleTabChange('create')}
            onAction={handleRpsAction}
            onBlock={async (profileId, profileName) => {
              if (!userProfile?.id || !profileId) return;
              try {
                const blocked = Array.isArray(userProfile.blocked_profile_ids) ? userProfile.blocked_profile_ids : [];
                if (blocked.includes(String(profileId))) return;
                const updated = [...blocked, String(profileId)];
                await Promise.all([
                  base44.entities.Profile.update(userProfile.id, { blocked_profile_ids: updated }),
                  base44.entities.UserMessage.deleteMany({ user_id: user.id, profile_name: profileName }),
                ]);
                setUserProfile(prev => prev ? { ...prev, blocked_profile_ids: updated } : prev);
                setDeckCandidates(prev => prev.filter(c => String(c.id) !== String(profileId)));
                await refreshMessages();
                toast.success(`${profileName} bloqué`);
              } catch (e) {
                console.error('block failed', e);
                toast.error('Blocage impossible');
              }
            }}
            onRefresh={refreshMessages}
            onCancelDate={async (otherUserId, profileName) => {
              try {
                const res = await base44.functions.invoke('cancelDate', { otherUserId });
                invalidateCache(user.id);
                // Si le date n'était PAS confirmé (proposition en attente) → personne bloqué.
                // Reset local pour refléter que le canceller est libéré.
                // Reset local si le canceller est libéré : date non confirmé OU renégociation annulée (règle 04/10).
                if (!res.data?.wasConfirmed || res.data?.isRenegotiationCancel) {
                  setUserProfile(prev => prev ? { ...prev, accepted_date_key: null } : prev);
                  setSessionState(prev => ({ ...prev, hasAccepted: false }));
                }
                await Promise.all([refreshMessages(), reloadDeck()]);
                toast.success(res.data?.wasConfirmed ? 'Date annulé' : 'Pas de match');
              } catch (e) {
                console.error('cancelDate failed', e);
                toast.error('Annulation impossible');
              }
            }}
            onChangePlace={async (otherUserId, profileName, otherProfile) => {
              const loserProfile = {
                ...otherProfile,
                user_id: otherUserId,
                name: otherProfile?.name || otherProfile?.display_name || profileName,
              };
              setRpsOverlay({ profile: loserProfile, initialStep: 'winnerPlace', isPlaceChange: true });
            }}
            onMarkAccepted={async (details) => {
              setSessionState(prev => ({ ...prev, hasAccepted: true })); // optimistic
              try {
                const updatedProfile = await markDateAccepted(user.id, details);
                if (updatedProfile) setUserProfile(prev => prev ? { ...prev, accepted_date_key: updatedProfile.accepted_date_key } : prev);
              } catch {}
            }}
            onMarkPassed={async (profileId) => {
              markPassed(user.id, profileId).catch(e => console.error('markPassed failed:', e));
            }}
            onAddMessage={async (msg) => {
              // Optimistic update
              const optimisticMsg = { ...msg, id: `optimistic_${Date.now()}`, created_date: new Date().toISOString(), timerStartTime: msg.timer_start_time || null, display_time: new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' }) };
              setMessages(prev => [...prev, optimisticMsg]);
              // Attendre la persistance DB — garantit que le message est écrit avant
              // toute action dépendante (ex: cancelDate cherche "Date confirmé" dans le fil).
              try {
                await addMessageForToday(user.id, msg);
              } catch (e) {
                console.error('addMessageForToday failed:', e);
              }
            }}
            onClearMessages={async () => {
              await clearMessagesForToday(user.id);
              await refreshMessages();
            }}
            onDateCancelled={async () => {
              invalidateCache(user.id);
              setSessionState(prev => ({ ...prev, hasAccepted: false }));
              setUserProfile(prev => prev ? { ...prev, accepted_date_key: null } : prev);
              await reloadDeck();
            }}
          />
        </div>
        <div className="h-full overflow-y-auto overscroll-y-contain" style={{ display: tab === 'quiz' ? 'block' : 'none' }}>
          <QuizTab
            userId={user.id}
            resetToken={tabResetTokens.quiz}
            messages={messages}
            isActive={tab === 'quiz'}
            bgTheme={bgTheme}
            onRefresh={refreshMessages}
            onProfileRefresh={refreshProfile}
            myProfile={userProfile}
            prefs={prefs ? { ...prefs, physicalAffinityMap: sessionState.physicalAffinityMap || {} } : prefs}
            onBlock={async (profileId, profileName) => {
              if (!userProfile?.id || !profileId) return;
              try {
                const blocked = Array.isArray(userProfile.blocked_profile_ids) ? userProfile.blocked_profile_ids : [];
                if (blocked.includes(String(profileId))) return;
                const updated = [...blocked, String(profileId)];
                await Promise.all([
                  base44.entities.Profile.update(userProfile.id, { blocked_profile_ids: updated }),
                  base44.entities.UserMessage.deleteMany({ user_id: user.id, profile_name: profileName }),
                ]);
                setUserProfile(prev => prev ? { ...prev, blocked_profile_ids: updated } : prev);
                setDeckCandidates(prev => prev.filter(c => String(c.id) !== String(profileId)));
                await refreshMessages();
                toast.success(`${profileName} bloqué`);
              } catch (e) {
                console.error('block failed', e);
                toast.error('Blocage impossible');
              }
            }}
          />
        </div>
      </div>

      <BottomTabBar
        tabs={TABS}
        tab={tab}
        bgTheme={bgTheme}
        hasNewMessage={hasNewMessage}
        hasPendingQuiz={memoHasPendingQuiz}
        hasPlayerTurn={memoHasPlayerTurn}
        onTabChange={handleTabChange}
      />

      {rpsOverlay && (
        <RpsFlow
          profile={rpsOverlay.profile}
          userId={user.id}
          initialStep={rpsOverlay.initialStep}
          initialOpponentChoice={rpsOverlay.initialOpponentChoice}
          isPlaceChange={rpsOverlay.isPlaceChange}
          winnerCity={userProfile?.city}
          addMessage={(text, isSystem, profileName, action, profileId) => 
            pushMessage('Système', text, isSystem || true, profileName || rpsOverlay.profile.name, action, profileId || rpsOverlay.profile.user_id)
          }
          onBackground={(type, data) => handleRpsBackground(type, rpsOverlay.profile, data)}
          onDone={() => setRpsOverlay(null)}
          onResolve={(playerChoice, opponentChoice) => handleRpsResolve(rpsOverlay.profile, playerChoice, opponentChoice)}
        />
      )}
      <Toaster position="top-center" toastOptions={{ duration: 4000 }} />

      {showRules && (
        <ToDayInBrief onClose={() => setShowRules(false)} />
      )}
    </div>
  );
}