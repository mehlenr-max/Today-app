import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus } from 'lucide-react';
import toast from 'react-hot-toast';
import { base44 } from '../api/base44Client';
import SponsorCarousel from '../components/today/SponsorCarousel';
import RestaurantSearchBar from '../components/today/RestaurantSearchBar';
import SponsorAddModal from '../components/today/SponsorAddModal';

export default function SponsorsPage() {
  const navigate = useNavigate();
  const [sponsors, setSponsors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdd, setShowAdd] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await base44.entities.Sponsor.list({ sort: '-created_date' });
      setSponsors(res?.items ?? res ?? []);
    } catch (e) {
      console.error('load sponsors failed', e);
      toast.error('Impossible de charger les partenaires');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    base44.auth.me().then(u => setIsAdmin(u?.role === 'admin')).catch(() => {});
  }, [load]);

  return (
    <div style={{
      position: 'fixed', inset: 0, maxWidth: '480px', margin: '0 auto',
      background: 'radial-gradient(circle at 16% 16%, rgba(255,51,102,0.22) 0%, transparent 24%), radial-gradient(circle at 86% 18%, rgba(255,105,180,0.14) 0%, transparent 22%), linear-gradient(180deg, #070709 0%, #040405 42%, #030304 100%)',
      color: '#fff', fontFamily: "'Poppins', sans-serif", display: 'flex', flexDirection: 'column', overflow: 'hidden',
    }}>
      <div style={{
        flexShrink: 0, display: 'flex', alignItems: 'center', gap: '12px',
        padding: 'calc(env(safe-area-inset-top) + 12px) 16px 12px',
        background: 'rgba(7,7,9,0.92)', backdropFilter: 'blur(16px)',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
      }}>
        <button onClick={() => navigate(-1)} aria-label="Retour" style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          width: '38px', height: '38px', borderRadius: '999px', flexShrink: 0, cursor: 'pointer',
          background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', color: '#fff',
        }}>
          <ArrowLeft size={18} />
        </button>
        <div style={{ minWidth: 0 }}>
          <h1 style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 900, fontSize: '1.45rem', margin: 0, lineHeight: 1.1 }}>
            Restaurants &amp; bars
          </h1>
          <p style={{ margin: '3px 0 0', color: '#9f9fae', fontSize: '0.75rem' }}>
            Nos adresses partenaires
          </p>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 120px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
        {loading && (
          <p style={{ textAlign: 'center', color: '#9f9fae', fontSize: '0.85rem', padding: '48px 0' }}>Chargement…</p>
        )}
        {!loading && sponsors.length === 0 && (
          <p style={{ textAlign: 'center', color: '#9f9fae', fontSize: '0.85rem', padding: '48px 12px', lineHeight: 1.6 }}>
            Aucun partenaire pour le moment.
          </p>
        )}
        {!loading && sponsors.length > 0 && <SponsorCarousel sponsors={sponsors} />}
        {!loading && <RestaurantSearchBar />}
      </div>

      {isAdmin && (
        <button
          onClick={() => setShowAdd(true)}
          title="Ajouter un partenaire"
          style={{
            position: 'absolute', bottom: 'calc(env(safe-area-inset-bottom) + 22px)', right: '20px',
            width: '58px', height: '58px', borderRadius: '999px', border: 'none', cursor: 'pointer',
            background: 'linear-gradient(135deg, #ff3366, #ff69b4)', color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 12px 28px rgba(255,51,102,0.35)',
          }}
        >
          <Plus size={26} />
        </button>
      )}

      {showAdd && (
        <SponsorAddModal onClose={() => setShowAdd(false)} onSaved={load} />
      )}
    </div>
  );
}