import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import DarkAuthLayout, {
  darkInputStyle,
  darkPrimaryBtnStyle,
  darkLinkBtnStyle,
  DarkDivider,
  DarkError,
} from "@/components/DarkAuthLayout";
import { safeReturnTo } from "@/lib/authReturnTo";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const returnTo = safeReturnTo();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await base44.auth.loginViaEmailPassword(email, password);
      window.location.href = returnTo;
    } catch (err) {
      setError(err.message || "Email ou mot de passe incorrect");
    } finally {
      setLoading(false);
    }
  };

  const registerLink = "/register" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "");

  return (
    <DarkAuthLayout title="Se connecter" subtitle="Accède à ton compte ToDay." showLegal>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        <DarkError>{error}</DarkError>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoComplete="email"
          autoFocus
          required
          style={darkInputStyle}
        />
        <input
          type="password"
          placeholder="Mot de passe"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
          required
          minLength={6}
          style={darkInputStyle}
        />
        <button type="submit" disabled={loading} style={darkPrimaryBtnStyle(loading)}>
          {loading ? "⏳" : "Se connecter"}
        </button>
      </form>

      <Link to="/forgot-password" style={{ ...darkLinkBtnStyle, textAlign: "center" }}>
        Mot de passe oublié ?
      </Link>

      <button
        onClick={() => (window.location.href = registerLink)}
        style={darkLinkBtnStyle}
      >
        Pas de compte ? Crée-en un
      </button>

    </DarkAuthLayout>
  );
}