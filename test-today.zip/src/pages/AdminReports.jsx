import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ShieldAlert, Lock } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { base44 } from '@/api/base44Client';
import ReportCard from '@/components/admin/ReportCard';
import ReportDetail from '@/components/admin/ReportDetail';
import WarningEmailModal from '@/components/admin/WarningEmailModal';
import AdminConfirmModal from '@/components/admin/AdminConfirmModal';
import ThresholdAlert from '@/components/admin/ThresholdAlert';


const pageStyle = {
  position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
  overflowY: 'auto', overflowX: 'hidden',
  fontFamily: "'Poppins', sans-serif",
  background:
    "radial-gradient(circle at 12% 8%, rgba(255,51,102,0.2) 0%, transparent 32%), radial-gradient(circle at 88% 12%, rgba(255,105,180,0.14) 0%, transparent 30%), linear-gradient(180deg, #070709 0%, #040405 45%, #030304 100%)",
  color: '#fff',
};

function FilterPill({ active, label, count, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '9px 16px', borderRadius: '999px', cursor: 'pointer', fontFamily: 'inherit',
        fontSize: '0.8rem', fontWeight: 700, whiteSpace: 'nowrap',
        color: active ? '#fff' : '#9f9fae',
        background: active ? 'rgba(255,51,102,0.16)' : 'rgba(255,255,255,0.05)',
        border: `1px solid ${active ? 'rgba(255,51,102,0.5)' : 'rgba(255,255,255,0.1)'}`,
        transition: 'all 0.15s ease',
      }}
    >
      {label} · {count}
    </button>
  );
}

export default function AdminReports() {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(null);
  const [reports, setReports] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState('pending');
  const [selectedId, setSelectedId] = useState(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [warningReport, setWarningReport] = useState(null);
  const [blockTarget, setBlockTarget] = useState(null);
  const [isModerating, setIsModerating] = useState(false);

  useEffect(() => {
    base44.auth.me()
      .then(u => setIsAdmin(u?.role === 'admin'))
      .catch(() => setIsAdmin(false));
  }, []);

  useEffect(() => {
    if (!isAdmin) return;
    loadReports();
  }, [isAdmin]);

  async function loadReports() {
    setIsLoading(true);
    try {
      const res = await base44.functions.invoke('getAdminReports', {});
      setReports(res?.data?.reports || []);
    } catch (e) {
      console.error('getAdminReports failed:', e);
      setReports([]);
    }
    setIsLoading(false);
  }

  const pending = useMemo(() => reports.filter(r => r.status === 'pending'), [reports]);
  const reviewed = useMemo(() => reports.filter(r => r.status === 'reviewed'), [reports]);
  const visible = filter === 'pending' ? pending : reviewed;
  const selected = useMemo(() => reports.find(r => r.id === selectedId) || null, [reports, selectedId]);
  const history = useMemo(
    () => (selected ? reports.filter(r => r.reported_profile_id === selected.reported_profile_id) : []),
    [reports, selected]
  );

  // Profils ayant atteint 2 signalements en attente : masquage à confirmer par le modérateur
  const thresholdProfiles = useMemo(() => {
    const seen = new Set();
    const list = [];
    pending.forEach(r => {
      if ((r.pending_count || 0) < 2) return;
      if (!r.profile?.id || r.profile.is_hidden) return;
      if (seen.has(r.profile.id)) return;
      seen.add(r.profile.id);
      list.push({
        profileId: r.profile.id,
        display_name: r.profile.display_name,
        pending_count: r.pending_count,
        reportId: r.id,
      });
    });
    return list;
  }, [pending]);

  function handleInspect(reportId) {
    setFilter('pending');
    setSelectedId(reportId);
  }

  async function handleMarkReviewed(reportId) {
    const target = reports.find(r => r.id === reportId);
    if (!target || target.status === 'reviewed') return;
    setIsUpdating(true);
    try {
      await base44.entities.Report.update(reportId, { status: 'reviewed' });
      setReports(prev => prev.map(r => (r.id === reportId ? { ...r, status: 'reviewed' } : r)));
    } finally {
      setIsUpdating(false);
    }
  }

  async function handleToggleBlock(report) {
    const profileId = report?.profile?.id;
    if (!profileId) return;
    const hidden = report.profile.is_hidden === true;
    setIsModerating(true);
    try {
      await base44.functions.invoke('adminModerateProfile', { action: 'set_hidden', profileId, hidden: !hidden });
      setReports(prev => prev.map(r => (
        r.profile && r.profile.id === profileId ? { ...r, profile: { ...r.profile, is_hidden: !hidden } } : r
      )));
      toast.success(hidden ? 'Profil réaffiché dans le deck.' : 'Profil masqué du deck.');
      setBlockTarget(null);
    } catch (e) {
      toast.error("L'action a échoué. Réessaie.");
    } finally {
      setIsModerating(false);
    }
  }

  function handleWarningSent(email) {
    setWarningReport(null);
    toast.success(`Avertissement envoyé à ${email}.`);
  }

  if (isAdmin === null) {
    return (
      <div style={{ ...pageStyle, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: 30, height: 30, borderRadius: '50%', border: '3px solid rgba(255,255,255,0.12)', borderTopColor: '#ff3366', animation: 'spin 0.8s linear infinite' }} />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div style={{ ...pageStyle, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
        <div style={{ maxWidth: 420, textAlign: 'center', background: 'rgba(15,15,19,0.72)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '20px', padding: '32px 24px' }}>
          <Lock size={26} color="#ff69b4" style={{ margin: '0 auto 14px' }} />
          <h1 style={{ fontFamily: "'EB Garamond', serif", fontSize: '1.6rem', margin: '0 0 8px', fontWeight: 700 }}>Accès réservé</h1>
          <p style={{ color: '#9f9fae', fontSize: '0.86rem', margin: '0 0 20px' }}>
            Cette page de modération est réservée aux administrateurs.
          </p>
          <button onClick={() => navigate(-1)} style={{ padding: '11px 20px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.16)', background: 'rgba(255,255,255,0.06)', color: '#fff', fontFamily: 'inherit', fontWeight: 700, cursor: 'pointer' }}>
            Retour à l'app
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={pageStyle}>
      <div className="mx-auto w-full max-w-5xl px-4 pb-20 pt-6 lg:px-8">
        <button
          onClick={() => navigate(-1)}
          style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'none', border: 'none', color: '#ff69b4', fontFamily: 'inherit', fontWeight: 700, fontSize: '0.82rem', cursor: 'pointer', padding: 0, marginBottom: '18px' }}
        >
          <ArrowLeft size={16} /> Retour à l'app
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '6px' }}>
          <ShieldAlert size={24} color="#ff3366" />
          <h1 style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontSize: '1.9rem', fontWeight: 800, margin: 0, lineHeight: 1.1 }}>
            Modération
          </h1>
        </div>
        <p style={{ color: '#9f9fae', fontSize: '0.82rem', margin: '0 0 22px' }}>
          Signalements reçus, profils concernés et historique.
        </p>

        <ThresholdAlert profiles={thresholdProfiles} onInspect={handleInspect} />

        <div style={{ display: 'flex', gap: '8px', marginBottom: '18px', flexWrap: 'wrap' }}>
          <FilterPill active={filter === 'pending'} label="En attente" count={pending.length} onClick={() => setFilter('pending')} />
          <FilterPill active={filter === 'reviewed'} label="Traités" count={reviewed.length} onClick={() => setFilter('reviewed')} />
        </div>

        <div className="grid gap-4 lg:grid-cols-[350px_minmax(0,1fr)]">
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {isLoading ? (
              <div style={{ padding: '32px 0', textAlign: 'center', color: '#9f9fae', fontSize: '0.82rem' }}>Chargement…</div>
            ) : visible.length === 0 ? (
              <div style={{ padding: '32px 18px', textAlign: 'center', background: 'rgba(15,15,19,0.72)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '20px', color: '#9f9fae', fontSize: '0.82rem' }}>
                {filter === 'pending' ? 'Aucun signalement en attente.' : 'Aucun signalement traité.'}
              </div>
            ) : (
              visible.map(report => (
                <ReportCard
                  key={report.id}
                  report={report}
                  isSelected={report.id === selectedId}
                  onSelect={setSelectedId}
                />
              ))
            )}
          </div>

          <div className="lg:sticky lg:top-6">
            {selected ? (
              <ReportDetail
                report={selected}
                history={history}
                onMarkReviewed={handleMarkReviewed}
                isUpdating={isUpdating}
                onSendWarning={setWarningReport}
                onOpenProfile={r => navigate(`/admin/profile/${r.profile.id}`)}
                onToggleBlock={setBlockTarget}
              />
            ) : visible.length > 0 ? (
              <div style={{ padding: '48px 20px', textAlign: 'center', background: 'rgba(15,15,19,0.5)', border: '1px dashed rgba(255,255,255,0.14)', borderRadius: '20px', color: '#9f9fae', fontSize: '0.84rem' }}>
                Sélectionne un signalement pour voir le détail et l'historique du profil.
              </div>
            ) : null}
          </div>
        </div>
      </div>

      {warningReport && (
        <WarningEmailModal
          reportId={warningReport.id}
          onClose={() => setWarningReport(null)}
          onSent={handleWarningSent}
        />
      )}

      {blockTarget && (
        <AdminConfirmModal
          emoji={blockTarget.profile?.is_hidden ? '👁️' : '🚫'}
          title={blockTarget.profile?.is_hidden ? 'Réafficher ce profil ?' : 'Bloquer ce profil ?'}
          description={blockTarget.profile?.is_hidden
            ? `${blockTarget.profile?.display_name || 'Ce profil'} réapparaîtra dans le deck des membres.`
            : `${(blockTarget.pending_count || 0) >= 2 ? 'Seuil de 2 signalements atteint. ' : ''}${blockTarget.profile?.display_name || 'Ce profil'} sera masqué du deck pour tous les membres. L'action reste réversible.`}
          confirmLabel={blockTarget.profile?.is_hidden ? 'Réafficher' : 'Bloquer'}
          tone={blockTarget.profile?.is_hidden ? 'safe' : 'danger'}
          isBusy={isModerating}
          onConfirm={() => handleToggleBlock(blockTarget)}
          onClose={() => setBlockTarget(null)}
        />
      )}
    </div>
  );
}