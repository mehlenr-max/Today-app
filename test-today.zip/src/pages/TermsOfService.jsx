import React from 'react';

export default function TermsOfService() {
  return (
    <div style={{ minHeight: '100dvh', background: '#070709', color: '#e5e5ea', fontFamily: "'Poppins', sans-serif", padding: 'calc(env(safe-area-inset-top) + 24px) 20px 60px' }}>
      <div style={{ maxWidth: 720, margin: '0 auto' }}>
        <a href="/" style={{ color: '#ff69b4', fontSize: '0.85rem', textDecoration: 'none', fontWeight: 600 }}>← Retour</a>
        <h1 style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontSize: '2.2rem', fontWeight: 800, color: '#fff', margin: '16px 0 24px' }}>
          Conditions d'utilisation
        </h1>
        <p style={{ color: '#9f9fae', fontSize: '0.82rem', marginBottom: 24 }}>Dernière mise à jour : 17 août 2026</p>

        <Section title="1. Acceptation">
          En créant un compte ou en utilisant ToDay (« l'Application »), vous acceptez les présentes
          Conditions d'utilisation. Si vous n'êtes pas d'accord, n'utilisez pas l'Application.
        </Section>

        <Section title="2. Éligibilité">
          ToDay est réservé aux personnes âgées d'au moins 18 ans. En vous inscrivant, vous déclarez
          avoir 18 ans révolus et que les informations fournies sont exactes.
        </Section>

        <Section title="3. Service">
          ToDay est une application de rencontre gratuite permettant d'organiser un date le soir même.
          Un seul date par jour peut être confirmé. Le service est fourni « tel quel », sans garantie
          de résultat ni de disponibilité continue.
        </Section>

        <Section title="4. Compte et profil">
          Vous êtes responsable des informations et photos que vous publiez. Les contenus
          illicites, trompeurs, ou non conformes (nudité, mineurs, incitation à la haine) sont interdits
          et entraînent le retrait immédiat du profil, sans préavis.
        </Section>

        <Section title="5. Conduite">
          Vous vous engagez à traiter les autres utilisateurs avec respect, à ne pas harceler,
          à ne pas solliciter d'argent, et à ne pas utiliser l'Application à des fins commerciales
          ou publicitaires.
        </Section>

        <Section title="6. Modération">
          Les signalements sont traités sous 48 h. Un profil recevant deux signalements est
          automatiquement masqué en attendant vérification. Les décisions de modération sont définitives.
        </Section>

        <Section title="7. Suppression du compte">
          Vous pouvez supprimer votre compte à tout moment depuis Profil → Supprimer mon compte.
          Cette action efface immédiatement et définitivement votre profil, vos messages et vos sessions.
        </Section>

        <Section title="8. Propriété">
          Vous conservez la propriété de vos photos. En les publiant, vous autorisez ToDay à les
          afficher aux autres utilisateurs dans le cadre du service.
        </Section>

        <Section title="9. Responsabilité">
          ToDay ne saurait être tenu responsable des rencontres issues de l'Application. Vous
          restez seul responsable de vos interactions et de votre sécurité lors des rendez-vous.
        </Section>

        <Section title="10. Modifications">
          Les présentes conditions peuvent évoluer. Les modifications significatives vous seront
          notifiées dans l'Application.
        </Section>

        <Section title="11. Droit applicable">
          Les présentes conditions sont régies par le droit belge. En cas de litige, les tribunaux
          belges seront seuls compétents.
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <section style={{ marginBottom: 24 }}>
      <h2 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#fff', margin: '0 0 8px' }}>{title}</h2>
      <div style={{ fontSize: '0.88rem', lineHeight: 1.6, color: '#cfcfda' }}>
        {children}
      </div>
    </section>
  );
}