import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Ban, Lock, ShieldAlert, Trash2 } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { base44 } from '@/api/base44Client';
import AdminConfirmModal from '@/components/admin/AdminConfirmModal';

const PHOTO_FIELDS = { 1: 'photo_url', 2: 'photo_url_2', 3: 'photo_url_3' };
const SLOTS = [1, 2, 3];

const pageStyle = {
  position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
  overflowY: 'auto', overflowX: 'hidden',
  fontFamily: "'Poppins', sans-serif",
  background:
    "radial-gradient(circle at 12% 8%, rgba(255,51,102,0.2) 0%, transparent 32%), radial-gradient(circle at 88% 12%, rgba(255,105,180,0.14) 0%, transparent 30%), linear-gradient(180deg, #070709 0%, #040405 45%, #030304 100%)",
  color: '#fff',
};

const card = {
  background: 'rgba(15,15,19,0.72)',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: '20px',
  padding: '18px',
};

const sectionTitle = {
  fontSize: '0.68rem', fontWeight: 800, letterSpacing: '0.1em',
  textTransform: 'uppercase', color: '#ff69b4', margin: '0 0 10px',
};

const badge = (color, background, border) => ({
  fontSize: '0.62rem', fontWeight: 800, letterSpacing: '0.05em',
  borderRadius: '999px', padding: '4px 9px', color, background, border,
});

function InfoRow({ label, value }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: '14px', padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
      <span style={{ fontSize: '0.74rem', color: '#9f9fae' }}>{label}</span>
      <span style={{ fontSize: '0.78rem', color: '#fff', fontWeight: 600, textAlign: 'right' }}>{value || '—'}</span>
    </div>
  );
}

export default function AdminProfileView() {
  const { profileId } = useParams();
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(null);
  const [profile, setProfile] = useState(null);
  const [counts, setCounts] = useState({ total: 0, pending: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);
  const [confirmSlot, setConfirmSlot] = useState(null);

  useEffect(() => {
    base44.auth.me()
      .then(u => setIsAdmin(u?.role === 'admin'))
      .catch(() => setIsAdmin(false));
  }, []);

  useEffect(() => {
    if (!isAdmin || !profileId) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await base44.functions.invoke('adminModerateProfile', { action: 'get_profile', profileId });
        const data = res?.data || {};
        if (cancelled) return;
        setProfile(data.profile || null);
        setCounts({ total: data.reportCount || 0, pending: data.pendingCount || 0 });
      } catch (e) {
        if (!cancelled) toast.error('Profil introuvable.');
      }
      if (!cancelled) setIsLoading(false);
    })();
    return () => { cancelled = true; };
  }, [isAdmin, profileId]);

  async function handleDeletePhoto() {
    const slot = confirmSlot;
    if (!slot) return;
    setIsDeleting(true);
    try {
      await base44.functions.invoke('adminModerateProfile', { action: 'delete_photo', profileId, slot });
      setProfile(prev => prev
        ? { ...prev, [PHOTO_FIELDS[slot]]: '', ...(slot === 1 ? { photo1_verified: false } : {}) }
        : prev);
      toast.success(`Photo ${slot} supprimée.`);
      setConfirmSlot(null);
    } catch (e) {
      toast.error('La suppression a échoué. Réessaie.');
    } finally {
      setIsDeleting(false);
    }
  }

  if (isAdmin === null) {
    return (
      <div style={{ ...pageStyle, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: 30, height: 30, borderRadius: '50%', border: '3px solid rgba(255,255,255,0.12)', borderTopColor: '#ff3366', animation: 'spin 0.8s linear infinite' }} />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div style={{ ...pageStyle, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
        <div style={{ maxWidth: 420, textAlign: 'center', background: 'rgba(15,15,19,0.72)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '20px', padding: '32px 24px' }}>
          <Lock size={26} color="#ff69b4" style={{ margin: '0 auto 14px' }} />
          <h1 style={{ fontFamily: "'EB Garamond', serif", fontSize: '1.6rem', margin: '0 0 8px', fontWeight: 700 }}>Accès réservé</h1>
          <p style={{ color: '#9f9fae', fontSize: '0.86rem', margin: '0 0 20px' }}>
            Cette fiche est réservée aux administrateurs.
          </p>
          <button onClick={() => navigate('/home')} style={{ padding: '11px 20px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.16)', background: 'rgba(255,255,255,0.06)', color: '#fff', fontFamily: 'inherit', fontWeight: 700, cursor: 'pointer' }}>
            Retour à l'app
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={pageStyle}>
      <div className="mx-auto w-full max-w-3xl px-4 pb-20 pt-6 lg:px-8">
        <button
          onClick={() => navigate('/admin/reports')}
          style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'none', border: 'none', color: '#ff69b4', fontFamily: 'inherit', fontWeight: 700, fontSize: '0.82rem', cursor: 'pointer', padding: 0, marginBottom: '18px' }}
        >
          <ArrowLeft size={16} /> Retour à la modération
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '6px' }}>
          <ShieldAlert size={24} color="#ff3366" />
          <h1 style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontSize: '1.9rem', fontWeight: 800, margin: 0, lineHeight: 1.1 }}>
            Profil du membre
          </h1>
        </div>
        <p style={{ color: '#9f9fae', fontSize: '0.82rem', margin: '0 0 22px' }}>
          Fiche en contexte d'administration : consulte et retire une photo si nécessaire.
        </p>

        {isLoading ? (
          <div style={{ padding: '40px 0', textAlign: 'center', color: '#9f9fae', fontSize: '0.82rem' }}>Chargement…</div>
        ) : !profile ? (
          <div style={{ ...card, textAlign: 'center', color: '#9f9fae', fontSize: '0.82rem' }}>
            Ce profil n'existe plus.
          </div>
        ) : (
          <>
            <div style={{ ...card, display: 'flex', gap: '16px', alignItems: 'center', marginBottom: '16px' }}>
              <img
                src={profile.photo_url || 'https://media.base44.com/images/public/69b91874189d1f38a8e07d5f/13012b7bc_image_19ee64c32.jpg'}
                alt=""
                style={{ width: 80, height: 80, borderRadius: '22px', objectFit: 'cover', flexShrink: 0, background: 'rgba(255,255,255,0.06)' }}
              />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontFamily: "'EB Garamond', serif", fontSize: '1.5rem', fontWeight: 700, lineHeight: 1.15 }}>
                  {profile.display_name || 'Profil inconnu'}
                </div>
                <div style={{ fontSize: '0.8rem', color: '#9f9fae', marginTop: 3 }}>
                  {[profile.age ? `${profile.age} ans` : null, profile.city].filter(Boolean).join(' · ') || 'Informations incomplètes'}
                </div>
                <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '10px' }}>
                  {profile.is_hidden && (
                    <span style={badge('#ff3366', 'rgba(255,51,102,0.12)', '1px solid rgba(255,51,102,0.45)')}>MASQUÉ DU DECK</span>
                  )}
                  <span style={badge(
                    profile.is_online ? '#4ade80' : '#9f9fae',
                    profile.is_online ? 'rgba(74,222,128,0.12)' : 'rgba(255,255,255,0.05)',
                    profile.is_online ? '1px solid rgba(74,222,128,0.35)' : '1px solid rgba(255,255,255,0.12)'
                  )}>
                    {profile.is_online ? 'EN LIGNE' : 'HORS LIGNE'}
                  </span>
                </div>
              </div>
            </div>

            <div style={{ ...card, marginBottom: '16px' }}>
              <p style={sectionTitle}>Photos du profil</p>
              <div style={{ display: 'grid', gap: '12px', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))' }}>
                {SLOTS.map(slot => {
                  const url = profile[PHOTO_FIELDS[slot]];
                  return (
                    <div key={slot} style={{ border: '1px solid rgba(255,255,255,0.08)', borderRadius: '16px', overflow: 'hidden', background: 'rgba(255,255,255,0.03)' }}>
                      <div style={{ height: 150, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.35)' }}>
                        {url ? (
                          <img src={url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        ) : (
                          <span style={{ fontSize: '0.72rem', color: '#6f6f80' }}>Aucune photo</span>
                        )}
                      </div>
                      <div style={{ padding: '10px 10px 12px' }}>
                        <div style={{ fontSize: '0.68rem', color: '#9f9fae', marginBottom: '8px' }}>
                          Photo {slot}
                          {slot === 1 && profile.photo1_verified ? ' · vérifiée' : ''}
                        </div>
                        <button
                          onClick={() => setConfirmSlot(slot)}
                          disabled={!url}
                          style={{
                            width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px',
                            padding: '10px', borderRadius: '12px', fontFamily: 'inherit', fontSize: '0.78rem', fontWeight: 700,
                            border: '1px solid rgba(255,51,102,0.4)', background: 'rgba(255,51,102,0.12)', color: '#ff8aa8',
                            cursor: url ? 'pointer' : 'default', opacity: url ? 1 : 0.4,
                          }}
                        >
                          <Trash2 size={14} /> Supprimer
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
              <p style={{ margin: '12px 0 0', fontSize: '0.72rem', color: '#9f9fae', lineHeight: 1.5 }}>
                La suppression est immédiate : la photo disparaît du profil du membre.
              </p>
            </div>

            <div style={card}>
              <p style={sectionTitle}>Suivi de modération</p>
              <InfoRow label="Signalements reçus" value={String(counts.total)} />
              <InfoRow label="En attente" value={String(counts.pending)} />
              <InfoRow
                label="Dernière connexion"
                value={profile.last_online_date ? new Date(profile.last_online_date).toLocaleString('fr-FR', { timeZone: 'Europe/Brussels', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—'}
              />
              <InfoRow label="Statut du profil" value={profile.is_hidden ? 'Masqué du deck' : 'Visible dans le deck'} />
              {profile.is_hidden && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '14px', padding: '10px 12px', borderRadius: '12px', background: 'rgba(255,51,102,0.1)', border: '1px solid rgba(255,51,102,0.35)', color: '#ff8aa8', fontSize: '0.76rem', fontWeight: 600 }}>
                  <Ban size={15} /> Ce profil est actuellement masqué pour tous les membres.
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {confirmSlot && (
        <AdminConfirmModal
          emoji="🗑️"
          title={`Supprimer la photo ${confirmSlot} ?`}
          description={`La photo ${confirmSlot} de ${profile?.display_name || 'ce membre'} sera retirée immédiatement. Cette action est définitive.`}
          confirmLabel="Supprimer"
          tone="danger"
          isBusy={isDeleting}
          onConfirm={handleDeletePhoto}
          onClose={() => setConfirmSlot(null)}
        />
      )}
    </div>
  );
}