import React, { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import DarkAuthLayout, {
  darkInputStyle,
  darkPrimaryBtnStyle,
  darkLinkBtnStyle,
  DarkError,
} from "@/components/DarkAuthLayout";

export default function ResetPassword() {
  const [searchParams] = useSearchParams();
  const resetToken = searchParams.get("token");

  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (newPassword !== confirmPassword) {
      setError("Les mots de passe ne correspondent pas");
      return;
    }
    setLoading(true);
    try {
      await base44.auth.resetPassword({ resetToken, newPassword });
      window.location.href = "/login";
    } catch (err) {
      setError(err.message || "Échec de la réinitialisation");
    } finally {
      setLoading(false);
    }
  };

  if (!resetToken) {
    return (
      <DarkAuthLayout title="Lien invalide" subtitle="Ce lien de réinitialisation est manquant ou invalide.">
        <p style={{ color: "#9f9fae", fontSize: "0.88rem", lineHeight: 1.5, textAlign: "center", margin: 0 }}>
          Le lien que tu as utilisé semble incomplet. Demande un nouvel email de réinitialisation.
        </p>
        <Link to="/forgot-password" style={{ ...darkLinkBtnStyle, textAlign: "center", fontWeight: 600 }}>
          Demander un nouveau lien
        </Link>
      </DarkAuthLayout>
    );
  }

  return (
    <DarkAuthLayout title="Nouveau mot de passe" subtitle="Entre ton nouveau mot de passe.">
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        <DarkError>{error}</DarkError>
        <input
          type="password"
          placeholder="Nouveau mot de passe"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          autoComplete="new-password"
          autoFocus
          required
          minLength={6}
          style={darkInputStyle}
        />
        <input
          type="password"
          placeholder="Confirme le mot de passe"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          autoComplete="new-password"
          required
          style={darkInputStyle}
        />
        <button type="submit" disabled={loading} style={darkPrimaryBtnStyle(loading)}>
          {loading ? "⏳" : "Réinitialiser"}
        </button>
      </form>
      <Link to="/login" style={{ ...darkLinkBtnStyle, textAlign: "center" }}>
        ← Retour à la connexion
      </Link>
    </DarkAuthLayout>
  );
}