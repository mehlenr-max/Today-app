import React from 'react';

export default function PrivacyPolicy() {
  return (
    <div style={{ minHeight: '100dvh', background: '#070709', color: '#e5e5ea', fontFamily: "'Poppins', sans-serif", padding: 'calc(env(safe-area-inset-top) + 24px) 20px 60px' }}>
      <div style={{ maxWidth: 720, margin: '0 auto' }}>
        <a href="/" style={{ color: '#ff69b4', fontSize: '0.85rem', textDecoration: 'none', fontWeight: 600 }}>← Retour</a>
        <h1 style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontSize: '2.2rem', fontWeight: 800, color: '#fff', margin: '16px 0 24px' }}>
          Politique de confidentialité
        </h1>
        <p style={{ color: '#9f9fae', fontSize: '0.82rem', marginBottom: 24 }}>Dernière mise à jour : 17 août 2026</p>

        <Section title="1. Présentation de ToDay">
          ToDay (« l'Application ») est une application de rencontre gratuite, disponible en Belgique,
          qui vous aide à organiser un vrai date le soir même. Nous ne collectionnons pas de matchs :
          un seul date par jour, confirmé avant minuit.
          L'éditeur de l'Application est responsable du traitement des données décrit ci-dessous.
        </Section>

        <Section title="2. Données que nous collectons">
          <ul>
            <li><strong>Compte :</strong> adresse e-mail, nom affiché (prénom/pseudo), âge, genre, ville.</li>
            <li><strong>Profil :</strong> photos, morphologie, traits de personnalité, défauts, études, profession, taille, signe astrologique, préférences de recherche.</li>
            <li><strong>Activité :</strong> messages échangés, défis lancés, dates confirmés, signalements.</li>
            <li><strong>Techniques :</strong> identifiant de session, date de dernière connexion.</li>
          </ul>
          Nous ne demandons ni ne stockons votre numéro de téléphone, ni votre localisation GPS précise.
        </Section>

        <Section title="3. Utilisation des données">
          Les données servent uniquement à : faire fonctionner le matching, afficher les profils,
          organiser les dates, sécuriser la communauté (modération, signalements) et respecter
          nos obligations légales. Aucune donnée n'est vendue ni partagée à des fins publicitaires.
        </Section>

        <Section title="4. Base légale">
          Le traitement repose sur l'exécution du contrat (fournir le service de rencontre),
          votre consentement (photos, profil astrologique) et notre intérêt légitime
          (sécurité et modération de la communauté).
        </Section>

        <Section title="5. Conservation">
          Les sessions et messages quotidiens sont automatiquement effacés après 7 jours.
          Votre profil est conservé tant que votre compte est actif. La suppression de votre compte
          entraîne l'effacement immédiat de l'ensemble de vos données (profil, messages, sessions).
        </Section>

        <Section title="6. Vos droits (RGPD)">
          Vous disposez d'un droit d'accès, de rectification, d'effacement, d'opposition et
          de portabilité. Pour exercer ces droits, écrivez-nous depuis l'Application
          (onglet Profil → Supprimer mon compte) ou contactez-nous.
          Vous pouvez introduire une réclamation auprès de l'Autorité de protection des données
          belge (autoriteprotectiondonnees.be).
        </Section>

        <Section title="7. Modération et sécurité">
          Les photos sont analysées côté appareil (détection de visage et de contenu inapproprié)
          avant envoi. Les profils recevant deux signalements sont automatiquement masqués
          et examinés par un modérateur.
        </Section>

        <Section title="8. Mineurs">
          ToDay est réservé aux personnes de 18 ans et plus. Tout profil mineur signalé est
          immédiatement supprimé.
        </Section>

        <Section title="9. Transferts hors UE">
          Les photos sont stockées via Cloudinary (États-Unis) dans le cadre des garanties
          appropriées. Les autres données restent hébergées au sein de l'UE.
        </Section>

        <Section title="10. Contact">
          Pour toute question relative à vos données, contactez-nous via l'Application
          ou à l'adresse e-mail associée à votre compte.
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <section style={{ marginBottom: 24 }}>
      <h2 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#fff', margin: '0 0 8px' }}>{title}</h2>
      <div style={{ fontSize: '0.88rem', lineHeight: 1.6, color: '#cfcfda' }}>
        {children}
      </div>
    </section>
  );
}