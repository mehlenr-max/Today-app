import { QueryClientProvider } from '@tanstack/react-query'
import { Toaster } from "@/components/ui/toaster"
import { Toaster as HotToaster } from 'react-hot-toast';
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation, useNavigationType } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import ProtectedRoute from '@/components/ProtectedRoute';
import SitePauseGate from '@/components/SitePauseGate';
import { LanguageProvider } from '@/lib/i18n/LanguageContext';
// Add page imports here
import ToDay4 from './pages/ToDay4';
import AdminReports from './pages/AdminReports';
import AdminProfileView from './pages/AdminProfileView';
import SponsorsPage from './pages/SponsorsPage';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';

// Transitions de page natives : une page poussée (push) arrive par la droite,
// un retour (pop) arrive par la gauche.
const pageVariants = {
  enter: (dir) => ({ x: dir === 'pop' ? '-8%' : '8%', opacity: 0.65 }),
  center: { x: 0, opacity: 1 },
  exit: (dir) => ({ x: dir === 'pop' ? '8%' : '-8%', opacity: 0.65 }),
};

const PAGE_TRANSITION = { duration: 0.26, ease: [0.32, 0.72, 0, 1] };

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings } = useAuth();
  const location = useLocation();
  // POP = retour (bouton retour natif ou navigate(-1)) → glissement inverse
  const direction = useNavigationType() === 'POP' ? 'pop' : 'push';

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <AnimatePresence mode="sync" initial={false} custom={direction}>
      {/* Conteneur plein écran : les pages utilisent position:fixed, il sert de
          référentiel pendant la translation et gère le défilement des pages simples. */}
      <motion.div
        key={location.pathname}
        custom={direction}
        variants={pageVariants}
        initial="enter"
        animate="center"
        exit="exit"
        transition={PAGE_TRANSITION}
        style={{ position: 'fixed', inset: 0, overflowY: 'auto', overflowX: 'hidden', overscrollBehaviorY: 'contain' }}
      >
        <Routes location={location}>
      {/* Public auth routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      {/* Public legal pages (linked from login/register) */}
      <Route path="/privacy" element={<PrivacyPolicy />} />
      <Route path="/terms" element={<TermsOfService />} />
      {/* Protected app routes — unauthenticated users land on /login */}
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        {/* Écran de maintenance quand l'admin met le site en pause */}
        <Route element={<SitePauseGate />}>
          <Route path="/" element={<Navigate to="/home" replace />} />
          <Route path="/home" element={<ToDay4 />} />
          <Route path="/today4" element={<ToDay4 />} />
          <Route path="/sponsors" element={<SponsorsPage />} />
          <Route path="/admin/reports" element={<AdminReports />} />
          <Route path="/admin/profile/:profileId" element={<AdminProfileView />} />

        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
};


function App() {

  return (
    <LanguageProvider>
      <AuthProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <AuthenticatedApp />
          </Router>
          <Toaster />
          <HotToaster position="top-center" toastOptions={{ duration: 4000 }} />
        </QueryClientProvider>
      </AuthProvider>
    </LanguageProvider>
  )
}

export default App