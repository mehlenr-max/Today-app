import React, { useEffect, useState } from 'react';
import { Mail, Send, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function WarningEmailModal({ reportId, onClose, onSent }) {
  const [isLoading, setIsLoading] = useState(true);
  const [to, setTo] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await base44.functions.invoke('adminModerateProfile', { action: 'warning_preview', reportId });
        const data = res?.data || {};
        if (cancelled) return;
        setTo(data.to || '');
        setRecipientName(data.recipientName || '');
        setSubject(data.subject || '');
        setMessage(data.message || '');
        if (!data.to) setError("Ce membre n'a pas d'adresse email enregistrée.");
      } catch (e) {
        if (!cancelled) setError("Impossible de préparer l'avertissement.");
      }
      if (!cancelled) setIsLoading(false);
    })();
    return () => { cancelled = true; };
  }, [reportId]);

  async function handleSend() {
    if (!to || !message.trim()) return;
    setIsSending(true);
    setError('');
    try {
      await base44.functions.invoke('adminModerateProfile', { action: 'send_warning', reportId, message });
      onSent(to);
    } catch (e) {
      setError("L'envoi a échoué. Réessaie dans un instant.");
      setIsSending(false);
    }
  }

  const canSend = Boolean(to) && message.trim().length > 0 && !isSending;

  return (
    <div
      onClick={isSending ? undefined : onClose}
      style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{ width: '100%', maxWidth: '460px', maxHeight: '90vh', overflowY: 'auto', background: 'rgba(15,15,19,0.98)', border: '1px solid rgba(255,105,180,0.3)', borderRadius: '20px', padding: '22px 20px', boxShadow: '0 0 40px rgba(255,51,102,0.18)' }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
          <Mail size={18} color="#ff69b4" />
          <h3 style={{ margin: 0, fontSize: '1.05rem', fontWeight: 800, color: '#fff', flex: 1 }}>
            Avertissement au membre
          </h3>
          <button onClick={onClose} disabled={isSending} style={{ background: 'none', border: 'none', color: '#9f9fae', cursor: isSending ? 'default' : 'pointer', padding: 0, display: 'flex' }}>
            <X size={18} />
          </button>
        </div>
        <p style={{ margin: '0 0 16px', color: '#9f9fae', fontSize: '0.8rem', lineHeight: 1.5 }}>
          Vérifie le message avant l'envoi. Tu peux le personnaliser.
        </p>

        {isLoading ? (
          <div style={{ padding: '28px 0', textAlign: 'center', color: '#9f9fae', fontSize: '0.82rem' }}>Préparation du message…</div>
        ) : (
          <>
            <div style={{ marginBottom: '14px' }}>
              <p style={labelStyle}>Destinataire</p>
              <div style={{ fontSize: '0.86rem', color: '#fff', fontWeight: 600 }}>
                {recipientName || 'Membre signalé'}
              </div>
              <div style={{ fontSize: '0.76rem', color: '#9f9fae', marginTop: 2 }}>{to || 'Adresse email indisponible'}</div>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <p style={labelStyle}>Objet</p>
              <div style={{ fontSize: '0.86rem', color: '#fff' }}>{subject || 'ToDay — Avertissement de modération'}</div>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <p style={labelStyle}>Message</p>
              <textarea
                value={message}
                onChange={e => setMessage(e.target.value)}
                disabled={isSending || !to}
                rows={6}
                style={{
                  width: '100%', resize: 'vertical', borderRadius: '14px',
                  border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.05)',
                  color: '#fff', padding: '12px 14px', fontFamily: 'inherit', fontSize: '0.86rem',
                  lineHeight: 1.55, outline: 0, boxSizing: 'border-box',
                }}
              />
              <p style={{ margin: '6px 0 0', fontSize: '0.68rem', color: '#6f6f80' }}>
                Envoyé depuis ToDay à l'adresse du membre.
              </p>
            </div>
          </>
        )}

        {error && (
          <div style={{ marginBottom: '14px', padding: '10px 12px', borderRadius: '12px', background: 'rgba(255,51,102,0.12)', border: '1px solid rgba(255,51,102,0.35)', color: '#ff8aa8', fontSize: '0.78rem' }}>
            {error}
          </div>
        )}

        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={onClose}
            disabled={isSending}
            style={{ flex: 1, padding: '12px', borderRadius: '12px', fontWeight: 600, fontSize: '0.86rem', border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.05)', color: '#9f9fae', cursor: isSending ? 'default' : 'pointer', fontFamily: 'inherit' }}
          >
            Annuler
          </button>
          <button
            onClick={handleSend}
            disabled={!canSend}
            style={{
              flex: 1.3, padding: '12px', borderRadius: '12px', fontWeight: 800, fontSize: '0.86rem',
              border: 'none', background: 'linear-gradient(135deg, #ff3366, #ff69b4)', color: '#fff',
              cursor: canSend ? 'pointer' : 'default', opacity: canSend ? 1 : 0.5,
              fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
            }}
          >
            <Send size={15} />
            {isSending ? 'Envoi…' : "Envoyer l'avertissement"}
          </button>
        </div>
      </div>
    </div>
  );
}

const labelStyle = {
  fontSize: '0.68rem', fontWeight: 800, letterSpacing: '0.1em',
  textTransform: 'uppercase', color: '#ff69b4', margin: '0 0 5px',
};