import React from 'react';
import { Check, ChevronRight } from 'lucide-react';
import { reasonIcon, reasonLabel, formatShortDate } from '@/lib/report-labels';

export default function ReportCard({ report, isSelected, onSelect }) {
  const profile = report.profile || {};
  return (
    <button
      onClick={() => onSelect(report.id)}
      style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: '12px',
        padding: '12px 14px', borderRadius: '16px', cursor: 'pointer',
        textAlign: 'left', fontFamily: 'inherit',
        background: isSelected ? 'rgba(255,51,102,0.12)' : 'rgba(15,15,19,0.72)',
        border: `1px solid ${isSelected ? 'rgba(255,51,102,0.45)' : 'rgba(255,255,255,0.1)'}`,
        transition: 'background 0.15s ease, border-color 0.15s ease',
      }}
    >
      <img
        src={profile.photo_url || 'https://media.base44.com/images/public/69b91874189d1f38a8e07d5f/13012b7bc_image_19ee64c32.jpg'}
        alt=""
        style={{ width: 46, height: 46, borderRadius: '13px', objectFit: 'cover', flexShrink: 0, background: 'rgba(255,255,255,0.06)' }}
      />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <span style={{ fontWeight: 700, fontSize: '0.9rem', color: '#fff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {profile.display_name || 'Profil inconnu'}
          </span>
          {profile.is_hidden && (
            <span style={{
              fontSize: '0.6rem', fontWeight: 800, letterSpacing: '0.04em',
              color: '#ff3366', border: '1px solid rgba(255,51,102,0.45)',
              background: 'rgba(255,51,102,0.12)', borderRadius: '999px', padding: '2px 7px',
              whiteSpace: 'nowrap',
            }}>MASQUÉ</span>
          )}
        </div>
        <div style={{ fontSize: '0.76rem', color: '#9f9fae', marginTop: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {reasonIcon(report.reason)} {reasonLabel(report.reason)} · {formatShortDate(report.created_date)}
        </div>
      </div>
      {report.status === 'reviewed'
        ? <Check size={17} color="#4ade80" style={{ flexShrink: 0 }} />
        : <ChevronRight size={17} color="#ff69b4" style={{ flexShrink: 0 }} />}
    </button>
  );
}