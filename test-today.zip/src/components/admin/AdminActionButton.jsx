import React from 'react';

const TONES = {
  neutral: { color: '#ffffff', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.14)' },
  pink: { color: '#ff8ab0', background: 'rgba(255,105,180,0.1)', border: '1px solid rgba(255,105,180,0.35)' },
  danger: { color: '#ff8aa8', background: 'rgba(255,51,102,0.12)', border: '1px solid rgba(255,51,102,0.4)' },
  safe: { color: '#4ade80', background: 'rgba(74,222,128,0.1)', border: '1px solid rgba(74,222,128,0.35)' },
};

export default function AdminActionButton({ icon: Icon, label, onClick, disabled, tone = 'neutral', full }) {
  const palette = TONES[tone] || TONES.neutral;
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
        padding: '12px 14px', borderRadius: '14px', fontFamily: 'inherit',
        fontSize: '0.82rem', fontWeight: 700, textAlign: 'center',
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.45 : 1,
        gridColumn: full ? '1 / -1' : undefined,
        transition: 'background 0.15s ease, border-color 0.15s ease',
        ...palette,
      }}
    >
      {Icon ? <Icon size={15} style={{ flexShrink: 0 }} /> : null}
      <span style={{ minWidth: 0 }}>{label}</span>
    </button>
  );
}