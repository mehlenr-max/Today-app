import React from 'react';
import { AlertTriangle, Ban, Check, Eye, Mail, ShieldAlert, UserRound } from 'lucide-react';
import { reasonIcon, reasonLabel, formatReportDate } from '@/lib/report-labels';
import AdminActionButton from '@/components/admin/AdminActionButton';

const card = {
  background: 'rgba(15,15,19,0.72)',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: '20px',
  padding: '18px',
};

const sectionTitle = {
  fontSize: '0.68rem', fontWeight: 800, letterSpacing: '0.1em',
  textTransform: 'uppercase', color: '#ff69b4', margin: '0 0 6px',
};

function HistoryRow({ item }) {
  const isPending = item.status === 'pending';
  return (
    <div style={{ display: 'flex', gap: '10px', alignItems: 'flex-start', padding: '9px 0', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
      <span style={{
        fontSize: '0.62rem', fontWeight: 800, borderRadius: '999px', padding: '3px 8px',
        whiteSpace: 'nowrap', marginTop: 1,
        color: isPending ? '#ff69b4' : '#4ade80',
        background: isPending ? 'rgba(255,105,180,0.12)' : 'rgba(74,222,128,0.12)',
        border: `1px solid ${isPending ? 'rgba(255,105,180,0.4)' : 'rgba(74,222,128,0.35)'}`,
      }}>{isPending ? 'EN ATTENTE' : 'TRAITÉ'}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: '0.8rem', color: '#fff', fontWeight: 600 }}>
          {reasonIcon(item.reason)} {reasonLabel(item.reason)}
        </div>
        {item.detail && <div style={{ fontSize: '0.75rem', color: '#cfcfda', marginTop: 2 }}>{item.detail}</div>}
        <div style={{ fontSize: '0.68rem', color: '#6f6f80', marginTop: 3 }}>{formatReportDate(item.created_date)}</div>
      </div>
    </div>
  );
}

export default function ReportDetail({ report, history, onMarkReviewed, isUpdating, onSendWarning, onOpenProfile, onToggleBlock }) {
  const profile = report.profile || {};
  const isReviewed = report.status === 'reviewed';
  const pendingCount = history.filter(r => r.status === 'pending').length;
  const hasProfile = Boolean(profile.id);
  const thresholdReached = (report.pending_count || 0) >= 2 && !profile.is_hidden;

  return (
    <div style={card}>
      <div style={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
        <img
          src={profile.photo_url || 'https://media.base44.com/images/public/69b91874189d1f38a8e07d5f/13012b7bc_image_19ee64c32.jpg'}
          alt=""
          style={{ width: 64, height: 64, borderRadius: '18px', objectFit: 'cover', flexShrink: 0, background: 'rgba(255,255,255,0.06)' }}
        />
        <div style={{ minWidth: 0 }}>
          <div style={{ fontFamily: "'EB Garamond', serif", fontSize: '1.35rem', fontWeight: 700, color: '#fff', lineHeight: 1.15 }}>
            {profile.display_name || 'Profil inconnu'}
          </div>
          <div style={{ fontSize: '0.78rem', color: '#9f9fae', marginTop: 3 }}>
            {[profile.age ? `${profile.age} ans` : null, profile.city].filter(Boolean).join(' · ') || 'Informations incomplètes'}
          </div>
        </div>
      </div>

      {profile.is_hidden && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: '8px', marginTop: '14px',
          padding: '9px 12px', borderRadius: '12px',
          background: 'rgba(255,51,102,0.12)', border: '1px solid rgba(255,51,102,0.4)',
          color: '#ff8aa8', fontSize: '0.78rem', fontWeight: 600,
        }}>
          <ShieldAlert size={15} style={{ flexShrink: 0 }} />
          Profil masqué du deck par la modération
        </div>
      )}

      <div style={{ marginTop: '18px' }}>
        <p style={sectionTitle}>Motif</p>
        <div style={{ fontSize: '0.92rem', color: '#fff', fontWeight: 600 }}>
          {reasonIcon(report.reason)} {reasonLabel(report.reason)}
        </div>
        <div style={{ fontSize: '0.8rem', color: '#cfcfda', marginTop: 6, lineHeight: 1.6 }}>
          {report.detail || 'Aucun détail fourni.'}
        </div>
        <div style={{ fontSize: '0.68rem', color: '#6f6f80', marginTop: 8 }}>
          Reçu le {formatReportDate(report.created_date)}
        </div>
      </div>

      <div style={{ marginTop: '20px' }}>
        <p style={sectionTitle}>Historique du profil · {history.length} signalement{history.length > 1 ? 's' : ''}</p>
        {history.map(item => <HistoryRow key={item.id} item={item} />)}
      </div>

      {thresholdReached && (
        <div style={{
          marginTop: '20px', padding: '14px 16px', borderRadius: '16px',
          background: 'rgba(255,51,102,0.1)', border: '1px solid rgba(255,51,102,0.4)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <AlertTriangle size={16} color="#ff3366" style={{ flexShrink: 0 }} />
            <span style={{ fontSize: '0.82rem', fontWeight: 800, color: '#fff' }}>Seuil de 2 signalements atteint</span>
          </div>
          <p style={{ margin: '6px 0 12px', fontSize: '0.76rem', color: '#cfcfda', lineHeight: 1.55 }}>
            Le masquage n'est plus automatique : le profil reste visible jusqu'à ta confirmation.
          </p>
          <button
            onClick={() => onToggleBlock(report)}
            style={{
              width: '100%', padding: '11px', borderRadius: '12px', cursor: 'pointer', fontFamily: 'inherit',
              border: '1px solid rgba(255,51,102,0.5)', background: 'rgba(255,51,102,0.18)',
              color: '#ff8aa8', fontSize: '0.82rem', fontWeight: 800,
            }}
          >
            Confirmer le masquage
          </button>
        </div>
      )}

      <div style={{ marginTop: '20px' }}>
        <p style={sectionTitle}>Actions de modération</p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
          <AdminActionButton
            icon={Mail}
            label="Envoyer un email"
            tone="pink"
            onClick={() => onSendWarning(report)}
          />
          <AdminActionButton
            icon={UserRound}
            label="Accéder au profil"
            disabled={!hasProfile}
            onClick={() => onOpenProfile(report)}
          />
          <AdminActionButton
            icon={profile.is_hidden ? Eye : Ban}
            label={profile.is_hidden ? 'Réafficher le profil' : 'Bloquer le profil'}
            tone={profile.is_hidden ? 'safe' : 'danger'}
            disabled={!hasProfile}
            full
            onClick={() => onToggleBlock(report)}
          />
        </div>
      </div>

      <button
        onClick={() => onMarkReviewed(report.id)}
        disabled={isReviewed || isUpdating}
        style={{
          width: '100%', marginTop: '20px', padding: '13px 16px', borderRadius: '14px',
          border: isReviewed ? '1px solid rgba(74,222,128,0.4)' : 'none',
          background: isReviewed ? 'rgba(74,222,128,0.12)' : 'linear-gradient(135deg, #ff3366, #ff69b4)',
          color: isReviewed ? '#4ade80' : '#fff',
          fontFamily: 'inherit', fontSize: '0.88rem', fontWeight: 800,
          letterSpacing: '0.02em',
          cursor: isReviewed || isUpdating ? 'default' : 'pointer',
          opacity: isUpdating ? 0.6 : 1,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
          transition: 'opacity 0.15s ease',
        }}
      >
        <Check size={16} />
        {isReviewed ? 'Signalement traité' : isUpdating ? 'Enregistrement…' : 'Marquer comme traité'}
      </button>

      {pendingCount > 1 && !isReviewed && (
        <p style={{ fontSize: '0.72rem', color: '#9f9fae', textAlign: 'center', margin: '10px 0 0' }}>
          {pendingCount} signalements en attente sur ce profil
        </p>
      )}
    </div>
  );
}