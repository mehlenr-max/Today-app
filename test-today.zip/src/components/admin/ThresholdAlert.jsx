import React from 'react';
import { AlertTriangle } from 'lucide-react';

export default function ThresholdAlert({ profiles, onInspect }) {
  if (!profiles || profiles.length === 0) return null;

  return (
    <div style={{
      display: 'flex', gap: '12px', alignItems: 'flex-start',
      padding: '14px 16px', borderRadius: '18px', marginBottom: '18px',
      background: 'rgba(255,51,102,0.1)', border: '1px solid rgba(255,51,102,0.4)',
    }}>
      <AlertTriangle size={18} color="#ff3366" style={{ flexShrink: 0, marginTop: 2 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: '0.88rem', fontWeight: 800, color: '#fff' }}>
          Seuil de 2 signalements atteint
        </div>
        <p style={{ margin: '4px 0 12px', fontSize: '0.78rem', color: '#cfcfda', lineHeight: 1.55 }}>
          {profiles.length === 1
            ? 'Un profil a atteint 2 signalements en attente. Il reste visible : le masquage doit être confirmé après examen.'
            : `${profiles.length} profils ont atteint 2 signalements en attente. Ils restent visibles : le masquage doit être confirmé après examen.`}
        </p>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          {profiles.map(item => (
            <button
              key={item.profileId}
              onClick={() => onInspect(item.reportId)}
              style={{
                display: 'flex', alignItems: 'center', gap: '7px',
                padding: '8px 13px', borderRadius: '999px', cursor: 'pointer', fontFamily: 'inherit',
                fontSize: '0.78rem', fontWeight: 700, color: '#fff',
                background: 'rgba(255,51,102,0.16)', border: '1px solid rgba(255,51,102,0.5)',
                transition: 'background 0.15s ease',
              }}
            >
              {item.display_name || 'Profil inconnu'}
              <span style={{ color: '#ff8aa8', fontWeight: 800 }}>· {item.pending_count}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}