import React from 'react';

const TONES = {
  danger: { accent: '#ff3366', buttonBg: 'rgba(255,51,102,0.15)', buttonBorder: 'rgba(255,51,102,0.4)', buttonColor: '#ff6a7c' },
  safe: { accent: '#4ade80', buttonBg: 'rgba(74,222,128,0.12)', buttonBorder: 'rgba(74,222,128,0.35)', buttonColor: '#4ade80' },
  pink: { accent: '#ff69b4', buttonBg: 'linear-gradient(135deg, #ff3366, #ff69b4)', buttonBorder: 'transparent', buttonColor: '#ffffff' },
};

export default function AdminConfirmModal({ emoji, title, description, confirmLabel, tone = 'danger', isBusy, onConfirm, onClose }) {
  const palette = TONES[tone] || TONES.danger;
  return (
    <div
      onClick={isBusy ? undefined : onClose}
      style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{ maxWidth: '340px', width: '100%', background: 'rgba(15,15,19,0.98)', border: `1px solid ${palette.accent}55`, borderRadius: '20px', padding: '24px 20px', textAlign: 'center', boxShadow: `0 0 40px ${palette.accent}33` }}
      >
        {emoji ? <div style={{ fontSize: '2rem', marginBottom: '10px' }}>{emoji}</div> : null}
        <h3 style={{ margin: '0 0 8px', fontSize: '1.05rem', fontWeight: 800, color: '#fff' }}>{title}</h3>
        <p style={{ margin: '0 0 20px', color: '#9f9fae', fontSize: '0.82rem', lineHeight: 1.55 }}>{description}</p>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={onClose}
            disabled={isBusy}
            style={{ flex: 1, padding: '11px', borderRadius: '12px', fontWeight: 600, fontSize: '0.86rem', border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.05)', color: '#9f9fae', cursor: isBusy ? 'default' : 'pointer', fontFamily: 'inherit' }}
          >
            Annuler
          </button>
          <button
            onClick={onConfirm}
            disabled={isBusy}
            style={{ flex: 1, padding: '11px', borderRadius: '12px', fontWeight: 700, fontSize: '0.86rem', border: `1px solid ${palette.buttonBorder}`, background: palette.buttonBg, color: palette.buttonColor, cursor: isBusy ? 'default' : 'pointer', fontFamily: 'inherit', opacity: isBusy ? 0.6 : 1 }}
          >
            {isBusy ? 'En cours…' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}