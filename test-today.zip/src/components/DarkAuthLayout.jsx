import React from "react";

const LOGO_URL = "https://media.base44.com/images/public/69b91874189d1f38a8e07d5f/13012b7bc_image_19ee64c32.jpg";

const pageStyle = {
  minHeight: "100dvh",
  background:
    "radial-gradient(circle at 16% 16%, rgba(255,51,102,0.22) 0%, transparent 24%), radial-gradient(circle at 86% 18%, rgba(255,105,180,0.14) 0%, transparent 22%), linear-gradient(180deg, #070709 0%, #040405 42%, #030304 100%)",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  padding: "32px 20px",
  gap: "20px",
  fontFamily: "'Poppins', sans-serif",
};

const cardStyle = {
  width: "100%",
  maxWidth: "360px",
  background: "rgba(15,15,19,0.92)",
  border: "1px solid rgba(255,255,255,0.14)",
  borderRadius: "24px",
  padding: "24px 20px",
  display: "flex",
  flexDirection: "column",
  gap: "14px",
};

export const darkInputStyle = {
  width: "100%",
  padding: "12px 16px",
  borderRadius: "14px",
  border: "1px solid rgba(255,255,255,0.12)",
  background: "rgba(255,255,255,0.04)",
  color: "#fff",
  fontSize: "0.95rem",
  fontFamily: "inherit",
  outline: 0,
};

export const darkPrimaryBtnStyle = (disabled) => ({
  width: "100%",
  padding: "0 18px",
  minHeight: "52px",
  borderRadius: "999px",
  fontWeight: 700,
  fontSize: "1rem",
  background: disabled
    ? "rgba(255,51,102,0.4)"
    : "linear-gradient(90deg, #ff3366, #ff69b4)",
  color: "#fff",
  boxShadow: "0 12px 24px rgba(255,51,102,0.22)",
  border: "none",
  cursor: disabled ? "default" : "pointer",
  fontFamily: "inherit",
});

export const darkLinkBtnStyle = {
  background: "none",
  border: "none",
  color: "#9f9fae",
  fontSize: "0.82rem",
  cursor: "pointer",
  fontFamily: "inherit",
  padding: 0,
};

export function DarkDivider() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "4px 0" }}>
      <div style={{ flex: 1, height: 1, background: "rgba(255,255,255,0.1)" }} />
      <span style={{ fontSize: "0.72rem", color: "#9f9fae", fontWeight: 600 }}>ou</span>
      <div style={{ flex: 1, height: 1, background: "rgba(255,255,255,0.1)" }} />
    </div>
  );
}

export function DarkError({ children }) {
  if (!children) return null;
  return (
    <div
      style={{
        padding: "10px 14px",
        borderRadius: "12px",
        background: "rgba(255,51,102,0.12)",
        border: "1px solid rgba(255,51,102,0.3)",
        color: "#ff8fa3",
        fontSize: "0.85rem",
      }}
    >
      {children}
    </div>
  );
}

export function DarkOAuthButton({ onClick, icon, label }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        width: "100%",
        padding: "0 18px",
        minHeight: "52px",
        borderRadius: "999px",
        fontWeight: 600,
        fontSize: "1rem",
        background: "#fff",
        color: "#000",
        border: "none",
        cursor: "pointer",
        fontFamily: "inherit",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 10,
      }}
    >
      {icon}
      {label}
    </button>
  );
}

const GoogleSvg = () => (
  <svg width="18" height="18" viewBox="0 0 24 24">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
  </svg>
);

const AppleSvg = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.08 1.85-2.38 5.84.46 7.18-.54 1.4-1.24 2.78-2.51 4.03zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
  </svg>
);

export function DarkGoogleButton({ onClick }) {
  return <DarkOAuthButton onClick={onClick} icon={<GoogleSvg />} label="Continuer avec Google" />;
}

export function DarkAppleButton({ onClick }) {
  return <DarkOAuthButton onClick={onClick} icon={<AppleSvg />} label="Sign in with Apple" />;
}

export default function DarkAuthLayout({ title, subtitle, children, showLegal = false, aboveCard = null }) {
  return (
    <div style={pageStyle}>
      <img
        src={LOGO_URL}
        alt="ToDay"
        style={{ width: "260px", objectFit: "contain", mixBlendMode: "screen" }}
      />
      {aboveCard}
      <div style={cardStyle}>
        <h2
          style={{
            fontFamily: "'EB Garamond', serif",
            fontStyle: "italic",
            fontSize: "1.5rem",
            fontWeight: 700,
            margin: "0 0 4px",
            color: "#fff",
          }}
        >
          {title}
        </h2>
        {subtitle && (
          <p style={{ margin: 0, color: "#9f9fae", fontSize: "0.88rem", lineHeight: 1.5 }}>
            {subtitle}
          </p>
        )}
        {children}
      </div>
      <p style={{ color: "#9f9fae", fontSize: "0.78rem", textAlign: "center", margin: 0 }}>
        100% gratuit · Belgique
      </p>
      {showLegal && (
        <div
          style={{
            display: "flex",
            gap: "16px",
            justifyContent: "center",
            flexWrap: "wrap",
            marginTop: "4px",
          }}
        >
          <a href="/privacy" style={{ color: "#9f9fae", fontSize: "0.72rem", textDecoration: "underline" }}>
            Politique de confidentialité
          </a>
          <a href="/terms" style={{ color: "#9f9fae", fontSize: "0.72rem", textDecoration: "underline" }}>
            Conditions d'utilisation
          </a>
        </div>
      )}
    </div>
  );
}