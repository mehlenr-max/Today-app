export default function TraitSelection({ 
  items, 
  selectedIds, 
  onToggle, 
  minRequired = 1, 
  maxAllowed = 2, 
  title,
  description 
}) {
  const toggleTrait = (id) => {
    const isSelected = selectedIds.includes(id);
    const maxReached = !isSelected && selectedIds.length >= maxAllowed;
    if (!maxReached) onToggle(id);
  };

  return (
    <div style={{
      borderRadius: '22px',
      border: '1px solid rgba(255,255,255,0.06)',
      background: 'rgba(15,15,19,0.72)',
      backdropFilter: 'blur(16px)',
      boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.04)',
      padding: '18px',
    }}>
      <strong style={{ display: 'block', fontSize: '0.95rem', marginBottom: '4px' }}>
        {title}
      </strong>
      {description && (
        <p style={{ margin: '0 0 14px', fontSize: '0.82rem', color: '#9f9fae' }}>
          {description} — {selectedIds.length}/{maxAllowed} sélectionné{selectedIds.length > 1 ? 's' : ''}
        </p>
      )}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {items.map(item => {
          const isSelected = selectedIds.includes(item.id);
          const maxReached = !isSelected && selectedIds.length >= maxAllowed;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => toggleTrait(item.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '14px',
                padding: '14px 16px',
                borderRadius: '16px',
                cursor: maxReached ? 'not-allowed' : 'pointer',
                border: isSelected ? '1px solid rgba(255,51,102,0.5)' : '1px solid rgba(255,255,255,0.07)',
                background: isSelected ? 'rgba(255,51,102,0.12)' : 'rgba(255,255,255,0.02)',
                transition: 'all 0.12s ease',
                fontFamily: 'inherit',
                textAlign: 'left',
                boxShadow: isSelected ? '0 0 16px rgba(255,51,102,0.2)' : 'none',
                opacity: maxReached ? 0.4 : 1,
              }}
              onPointerDown={e => { if (!maxReached) e.currentTarget.style.transform = 'scale(0.98)'; }}
              onPointerUp={e => { e.currentTarget.style.transform = ''; }}
              onPointerLeave={e => { e.currentTarget.style.transform = ''; }}
            >
              <span style={{ fontSize: '1.8rem', flexShrink: 0 }}>{item.emoji}</span>
              <div style={{ flex: 1 }}>
                <div style={{
                  fontWeight: 700,
                  fontSize: '0.95rem',
                  color: isSelected ? '#ff69b4' : '#fff',
                  marginBottom: '2px'
                }}>
                  {item.label}
                </div>
                <div style={{
                  fontSize: '0.75rem',
                  color: '#9f9fae',
                  lineHeight: 1.4
                }}>
                  {item.desc}
                </div>
              </div>
              <div style={{
                width: 20,
                height: 20,
                borderRadius: '5px',
                flexShrink: 0,
                border: isSelected ? '1px solid #ff3366' : '1px solid rgba(255,255,255,0.3)',
                background: isSelected ? '#ff3366' : 'transparent',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
                {isSelected && <span style={{ color: '#fff', fontSize: '0.7rem', fontWeight: 900 }}>✓</span>}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}