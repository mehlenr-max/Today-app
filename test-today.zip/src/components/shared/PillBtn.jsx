// `light` : sur fond blanc, le libellé non sélectionné passe en noir lisible.
export default function PillBtn({ active, onClick, children, light = false }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        minHeight: '44px',
        padding: '0 14px',
        fontSize: '0.84rem',
        fontWeight: 600,
        borderRadius: '999px',
        cursor: 'pointer',
        fontFamily: 'inherit',
        color: active ? '#fff' : (light ? '#000' : '#cfcfda'),
        border: active ? '1px solid rgba(255,51,102,0.85)' : (light ? '1px solid rgba(0,0,0,0.18)' : '1px solid rgba(255,255,255,0.08)'),
        background: active ? 'rgba(255,51,102,0.28)' : (light ? 'rgba(0,0,0,0.02)' : 'rgba(255,255,255,0.03)'),
        transition: 'all 0.08s ease',
        WebkitTapHighlightColor: 'transparent',
      }}
      onPointerDown={e => { e.currentTarget.style.transform = 'scale(0.96)'; }}
      onPointerUp={e => { e.currentTarget.style.transform = ''; }}
      onPointerLeave={e => { e.currentTarget.style.transform = ''; }}
    >
      {children}
    </button>
  );
}