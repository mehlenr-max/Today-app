import { Check } from 'lucide-react';

export default function CheckItem({ label, checked, onToggle }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '8px',
        padding: '8px 12px',
        borderRadius: '12px',
        border: checked ? '1px solid rgba(255,51,102,0.4)' : '1px solid rgba(255,255,255,0.08)',
        background: checked ? 'rgba(255,51,102,0.12)' : 'rgba(255,255,255,0.03)',
        color: checked ? '#ff69b4' : '#cfcfda',
        fontSize: '0.83rem',
        fontWeight: 500,
        cursor: 'pointer',
        fontFamily: 'inherit',
        transition: 'all 0.08s ease',
        WebkitTapHighlightColor: 'transparent',
      }}
      onPointerDown={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.35)'; e.currentTarget.style.transform = 'scale(0.96)'; }}
      onPointerUp={e => { e.currentTarget.style.background = ''; e.currentTarget.style.transform = ''; }}
      onPointerLeave={e => { e.currentTarget.style.background = ''; e.currentTarget.style.transform = ''; }}
    >
      <span style={{
        width: 14,
        height: 14,
        borderRadius: '4px',
        flexShrink: 0,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        border: checked ? '1px solid #ff3366' : '1px solid rgba(255,255,255,0.3)',
        background: checked ? '#ff3366' : 'transparent',
      }}>
        {checked && <Check size={9} color="#fff" />}
      </span>
      {label}
    </button>
  );
}