import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import { Trash2, Ban, ChevronDown } from 'lucide-react';
import { base44 } from '../../api/base44Client';
import { getParisDateKey } from '../../lib/today-data';
import { calculateMatchScore } from '../../lib/today-data';
import { getCosmicScore } from '../../lib/profile-scores';
import { calculatePersonalityCompatibility, parsePersonalityProfile } from '../../lib/scoring';
import { removeMessageActionForToday, addMessageForToday, getQuizMessagesLast7Days } from '../../lib/today-store';
import QuizAnswerModal from './QuizAnswerModal';
import Avatar from './Avatar';
import { GAMES, GAME_LIST } from '../../lib/quiz-questions';
import { getUnavailableGameTypes, markGameProposed } from '../../lib/quiz-usage';
import useQuizUsageVersion from '../../hooks/useQuizUsageVersion';
import QuizModal from './QuizModal';
import ProfileViewModal from './ProfileViewModal';
import BlockProfileConfirmModal from './BlockProfileConfirmModal';
import OptimizedImage from './OptimizedImage';
import SkeletonLoader from './SkeletonLoader';
import toast from 'react-hot-toast';
import useProfilesMap from '../../hooks/useProfilesMap';
import { fetchFullProfile } from '../../lib/profile-fetch';

export default function QuizTab({ userId, messages, bgTheme, onRefresh, onProfileRefresh, myProfile, prefs, onBlock, isActive, resetToken }) {
  const { profilesMap, loading } = useProfilesMap(userId);
  const [activeQuiz, setActiveQuiz] = useState(null);
  const [sending, setSending] = useState(false);
  const [deletingGroup, setDeletingGroup] = useState(null);
  const [quizMessages, setQuizMessages] = useState([]);
  const [loadingMsgs, setLoadingMsgs] = useState(true);
  const [viewProfile, setViewProfile] = useState(null);
  const [viewProfileLoading, setViewProfileLoading] = useState(false);
  const [viewMatchScore, setViewMatchScore] = useState(null);
  const [viewCosmicScore, setViewCosmicScore] = useState(null);
  const [viewPersonalityScore, setViewPersonalityScore] = useState(null);
  const [viewTargetUserId, setViewTargetUserId] = useState(null);
  const [quizProfile, setQuizProfile] = useState(null);
  // Même état partagé que le deck et l'onglet Messages.
  useQuizUsageVersion();
  // Cartes repliées, fil par fil — même comportement que l'onglet Messages.
  const [collapsed, setCollapsed] = useState({});
  const toggleCollapsed = (name) => setCollapsed(prev => ({ ...prev, [name]: !prev[name] }));

  // Re-tap de l'onglet actif → fermeture des vues imbriquées (fiche profil, quiz en cours)
  useEffect(() => {
    setViewProfile(null);
    setViewProfileLoading(false);
    setViewMatchScore(null);
    setViewCosmicScore(null);
    setViewPersonalityScore(null);
    setViewTargetUserId(null);
    setQuizProfile(null);
  }, [resetToken]);

  const [showBlockConfirm, setShowBlockConfirm] = useState(false);
  const [blockTarget, setBlockTarget] = useState(null);

  const normProfile = (p) => ({
    ...p,
    name: p.display_name || p.name || '',
    photo: p.photo_url || '',
    fiveWords: p.five_words || '',
    quizPhrase: p.quiz_phrase || '',
    ownPhysicalTraits: p.own_physical_traits || [],
    ownPersonalityTraits: p.own_personality_traits || [],
    personal_flaws: p.personal_flaws || [],
    desired_physical_traits: p.desired_physical_traits || [],
  });

  async function handleViewProfile(dbProfile, fallbackUserId) {
    if (!dbProfile && !fallbackUserId) return;
    setViewProfileLoading(true);
    const full = await fetchFullProfile(dbProfile, fallbackUserId);
    if (!full) {
      setViewProfileLoading(false);
      return;
    }
    const fullNorm = normProfile(full);
    setViewMatchScore(prefs ? calculateMatchScore(fullNorm, prefs, myProfile) : null);
    setViewCosmicScore(getCosmicScore(myProfile, fullNorm));
    setViewPersonalityScore(calculatePersonalityCompatibility(
      parsePersonalityProfile(myProfile?.personality_profile),
      parsePersonalityProfile(full?.personality_profile),
    ));
    setViewTargetUserId(fullNorm.user_id || fallbackUserId || dbProfile?.user_id || null);
    setViewProfile(fullNorm);
    setViewProfileLoading(false);
  }

  // Jeux de découverte lancés depuis le menu œil du Dé — mêmes règles que Messages/deck
  function getGames() {
    const targetUserId = viewProfile?.user_id || viewTargetUserId;
    if (!targetUserId) return [];
    const usedGameTypes = getUnavailableGameTypes(myProfile, targetUserId);
    const bothUsed = usedGameTypes.length >= 2;
    return GAME_LIST.map(g => {
      const used = usedGameTypes.includes(g.id);
      return {
        key: g.id,
        emoji: g.emoji,
        label: g.label,
        subtitle: g.subtitle,
        disabled: used || bothUsed,
        disabledLabel: used ? 'Déjà envoyé' : 'Game over',
        onSelect: () => {
          setViewProfile(null);
          setQuizProfile({ profile: viewProfile, profileName: viewProfile?.name, usedGameTypes, initialGameType: g.id, targetUserId });
        },
      };
    });
  }

  const loadQuizMessages = useCallback(async () => {
    try {
      const msgs = await getQuizMessagesLast7Days(userId);
      setQuizMessages(msgs);
    } catch (e) {
      console.error('loadQuizMessages failed', e);
    } finally {
      setLoadingMsgs(false);
    }
  }, [userId]);

  useEffect(() => { loadQuizMessages(); }, [loadQuizMessages]);

  // Recharger les quiz quand l'onglet devient actif (évite l'état vide après race condition DB)
  useEffect(() => {
    if (isActive) loadQuizMessages();
  }, [isActive, loadQuizMessages]);

  // Temps réel : recharger les quiz quand un nouveau message arrive
  // (debounce 800 ms — évite les rechargements multiples en rafale)
  const reloadTimerRef = useRef(null);
  useEffect(() => {
    const unsubscribe = base44.entities.UserMessage.subscribe((event) => {
      if (event.data?.user_id === userId) {
        if (reloadTimerRef.current) clearTimeout(reloadTimerRef.current);
        reloadTimerRef.current = setTimeout(() => loadQuizMessages(), 800);
      }
    });
    return () => {
      unsubscribe();
      if (reloadTimerRef.current) clearTimeout(reloadTimerRef.current);
    };
  }, [userId, loadQuizMessages]);

  async function handleDeleteQuizGroup(profileName, msgs) {
    if (deletingGroup) return;
    setDeletingGroup(profileName);
    try {
      for (const m of msgs) {
        if (m.id && !String(m.id).startsWith('optimistic_')) {
          await base44.entities.UserMessage.delete(m.id);
        }
      }
      onRefresh?.();
      loadQuizMessages();
    } catch (e) {
      console.error('delete quiz group failed', e);
    } finally {
      setDeletingGroup(null);
    }
  }

  // quizMessages est chargé depuis le backend (7 derniers jours) via loadQuizMessages

  // Group by profile_name
  const grouped = {};
  quizMessages.forEach(m => {
    const name = m.profile_name || m.thread_key || 'Inconnu';
    if (!grouped[name]) grouped[name] = [];
    grouped[name].push(m);
  });

  const isWhite = bgTheme === 'white';

  if (loading || loadingMsgs) {
    return (
      <div className="flex flex-col min-h-full">
        <div className="px-4 py-3 border-b border-white/6">
          <div className="text-pink-400 uppercase tracking-widest text-xs font-bold mb-2">Jeux</div>
          <div style={{ height: 28, width: '60%', borderRadius: 8, background: 'rgba(255,255,255,0.06)', marginBottom: 6 }} />
        </div>
        <div className="flex-1 p-4 space-y-3.5">
          <SkeletonLoader type="messages" count={3} />
        </div>
      </div>
    );
  }

  if (Object.keys(grouped).length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-6 text-center">
        <div style={{ fontSize: '3rem', marginBottom: '12px' }}>📝</div>
        <h3 className={`text-xl font-black italic font-garamond mb-2 ${isWhite ? 'text-gray-900' : 'text-white'}`}>Pas encore de jeux</h3>
        <p className="text-gray-500 text-sm">Envoie un jeu depuis le deck pour découvrir qui correspond le mieux !</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-full">
      <div className={`px-4 py-3 border-b ${isWhite ? 'border-black/10' : 'border-white/6'}`}>
        <div className="text-pink-500 uppercase tracking-widest text-xs font-bold mb-2">Jeux</div>
        <h2 className={`text-2xl font-black italic font-garamond mb-1 ${isWhite ? 'text-gray-900' : 'text-white'}`}>Tes jeux</h2>
        <p className="text-gray-500 text-sm">Joue et vois les réponses</p>
      </div>

      {/* Flux naturel, aucun défileur interne : le seul défileur est le conteneur
          de l'onglet (même structure que l'onglet Flamme). */}
      <div className="flex-1 p-4 pb-32 space-y-3.5">
        {Object.entries(grouped).map(([profileName, msgs]) => {
          const quizMsgs = msgs.filter(m => m.action?.type === 'quizQuestions');
          const answerMsgs = msgs.filter(m => m.action?.type === 'quizAnswers');
          const answered = msgs.some(m => m.text?.includes('Tu as joué') || m.text?.includes('Tu as répondu au quiz'));
          const fallbackUserId = msgs.find(m => m.profile_id)?.profile_id || msgs.find(m => m.action?.askerUserId)?.action?.askerUserId || null;
          // Résolution photo : (1) profile_photo snapshot dans les messages, (2) deck cache, (3) initiales (Avatar fallback)
          const threadPhoto = msgs.find(m => m.profile_photo)?.profile_photo || '';
          // Lookup par user_id d'abord (stable), fallback par display_name
          const dbProfile = (fallbackUserId && profilesMap[fallbackUserId]) || profilesMap[profileName] || null;
          const photo = threadPhoto || dbProfile?.photo_url || '';

          return (
            <motion.div
              key={profileName}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`rounded-2xl overflow-hidden backdrop-blur-xl border ${
                answered || answerMsgs.length > 0
                  ? isWhite ? 'bg-green-50/80 border-green-200' : 'bg-green-500/8 border-green-500/20'
                  : isWhite ? 'bg-white/80 shadow-sm border-black/10' : 'bg-black/45 border-white/6'
              }`}
            >
              {/* Header */}
              <div className={`px-4 py-3 border-b flex items-center gap-3 ${isWhite ? 'bg-pink-100 border-pink-200' : 'bg-pink-500/8 border-white/6'}`}>
                <Avatar
                  photoUrl={photo}
                  name={profileName}
                  size={40}
                  sizes="40px"
                  style={{ border: '1.5px solid rgba(255,51,102,0.5)' }}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <div style={{ fontWeight: 800, fontSize: '0.95rem', color: '#ff69b4', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{profileName}</div>
                    <button
                      onClick={() => handleViewProfile(dbProfile, fallbackUserId)}
                      style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', fontSize: '1.2rem', lineHeight: 1, flexShrink: 0 }}
                      title="Voir le profil"
                    >
                      👁
                    </button>
                    <button
                      onClick={() => toggleCollapsed(profileName)}
                      style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', lineHeight: 1, flexShrink: 0, marginLeft: 2, opacity: 0.55 }}
                      title={collapsed[profileName] ? 'Déplier' : 'Replier'}
                    >
                      <ChevronDown size={16} className={isWhite ? 'text-gray-500' : 'text-gray-400'} style={{ transform: collapsed[profileName] ? 'rotate(-90deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }} />
                    </button>
                    {dbProfile && (
                      <button
                        onClick={() => { setBlockTarget({ id: dbProfile.id || dbProfile.user_id, name: profileName }); setShowBlockConfirm(true); }}
                        style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', lineHeight: 1, flexShrink: 0, opacity: 0.55 }}
                        title="Bloquer ce profil"
                      >
                        <Ban size={13} className={isWhite ? 'text-gray-500' : 'text-gray-400'} />
                      </button>
                    )}
                  </div>
                  <div className={`text-xs ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>
                    {answered ? '✅ Tu as joué' : answerMsgs.length > 0 ? '✍️ A joué à ton jeu' : '🎮 Jeu en attente'}
                  </div>
                </div>
                <button
                  onClick={() => handleDeleteQuizGroup(profileName, msgs)}
                  disabled={deletingGroup === profileName}
                  className="flex-shrink-0 p-1.5 rounded-lg bg-red-500/10 border border-red-500/20 hover:bg-red-500/20 transition-colors disabled:opacity-50"
                  title="Supprimer ce quiz"
                >
                  <Trash2 size={14} className={isWhite ? 'text-red-500' : 'text-red-400'} />
                </button>
              </div>

              {/* Content — repliable comme dans l'onglet Messages */}
              {collapsed[profileName] ? (
                <div className="p-3">
                  <div className={`rounded-xl border p-2.5 ${isWhite ? 'bg-white/60 border-black/8' : 'bg-black/30 border-white/5'}`}>
                    <p className={`text-sm leading-relaxed whitespace-pre-wrap break-words line-clamp-2 ${isWhite ? 'text-gray-800' : 'text-gray-200'}`}>
                      {msgs[msgs.length - 1]?.text}
                    </p>
                    {msgs[msgs.length - 1]?.created_date && (
                      <div className={`flex items-center gap-1 text-xs mt-1 ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>
                        <span>🕐</span>
                        <span>{msgs[msgs.length - 1].display_time || new Date(msgs[msgs.length - 1].created_date).toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
              <div className="p-4 space-y-4">
                {/* Réponses reçues affichées en premier */}
                {answerMsgs.map((answerMsg, ai) => (
                  <div key={answerMsg.id || `ans-${ai}`} className="space-y-3">
                    {ai > 0 && <div className={`border-t ${isWhite ? 'border-black/10' : 'border-white/6'}`} />}
                    <p className={`text-sm font-semibold ${isWhite ? 'text-gray-700' : 'text-gray-300'}`}>
                      {answerMsg.action.responderName || profileName} a joué{answerMsg.action.gameType ? ` · ${GAMES[answerMsg.action.gameType]?.emoji || ''} ${GAMES[answerMsg.action.gameType]?.label || ''}` : ''}
                    </p>
                    {(() => {
                      const gt = answerMsg.action.gameType;
                      const qs = answerMsg.action.questions;
                      const ans = answerMsg.action.answers;
                      if (gt === 'thisOrThat') {
                        return qs.map((q, i) => {
                          const a = ans[i];
                          if (!a) return null;
                          const choice = a === 'a' ? q.a : q.b;
                          return (
                            <div key={i}>
                              <p className={`text-xs mb-1 ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>⚡ {q.a} ou {q.b} ?</p>
                              <p className={`text-sm leading-relaxed ${isWhite ? 'text-gray-800' : 'text-gray-200'}`}>👉 {choice}</p>
                            </div>
                          );
                        });
                      }
                      if (gt === 'nhie') {
                        return qs.map((q, i) => {
                          const a = ans[i];
                          if (!a) return null;
                          const choice = a === 'deja' ? 'Vrai ✅' : 'Faux 🚫';
                          return (
                            <div key={i}>
                              <p className={`text-xs mb-1 ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>🤫 Je n'ai jamais {q.text}</p>
                              <p className={`text-sm leading-relaxed ${isWhite ? 'text-gray-800' : 'text-gray-200'}`}>👉 {choice}</p>
                            </div>
                          );
                        });
                      }
                      return qs.map((q, i) => {
                        const a = ans[i]?.trim?.() || '';
                        if (!a) return null;
                        const qText = q?.text || q;
                        return (
                          <div key={i}>
                            <p className={`text-xs mb-1 ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>❓ {qText}</p>
                            <p className={`text-sm leading-relaxed ${isWhite ? 'text-gray-800' : 'text-gray-200'}`}>💬 {a}</p>
                          </div>
                        );
                      });
                    })()}
                  </div>
                ))}
              </div>
              )}

              {/* Boutons "Jouer" — toujours visibles, même carte repliée (comme l'onglet Messages) */}
              {quizMsgs.length > 0 && (
              <div className={`px-4 pb-4 space-y-2 ${collapsed[profileName] ? 'pt-3' : 'pt-0'}`}>
                {quizMsgs.map((quizMsg, qi) => (
                  <div key={quizMsg.id || `quiz-${qi}`} className="space-y-2">
                    {(answerMsgs.length > 0 || qi > 0) && <div className={`border-t ${isWhite ? 'border-black/10' : 'border-white/6'}`} />}
                    {(() => {
                      const gt = quizMsg.action.gameType;
                      const g = gt ? GAMES[gt] : null;
                      const gameLabel = g ? `${g.emoji} ${g.label}` : '📝 Quiz';
                      return (
                        <p className={`text-sm ${isWhite ? 'text-gray-700' : 'text-gray-300'}`}>
                          {quizMsg.action.askerName || profileName} t'a défié(e) à <strong style={{ color: '#ff69b4' }}>{gameLabel}</strong>
                        </p>
                      );
                    })()}
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setActiveQuiz({ msg: quizMsg, profileName })}
                      className="w-full py-2.5 rounded-lg bg-gradient-to-r from-pink-500 to-pink-600 text-white text-sm font-bold hover:shadow-lg transition-all"
                    >
                      🎮 Jouer
                    </motion.button>
                  </div>
                ))}
              </div>
              )}
            </motion.div>
          );
        })}
      </div>

      {activeQuiz && (
        <QuizAnswerModal
          questions={activeQuiz.msg.action.questions}
          gameType={activeQuiz.msg.action.gameType}
          askerName={activeQuiz.profileName}
          onClose={() => setActiveQuiz(null)}
          onSend={async (answers) => {
            if (sending) return;
            setSending(true);
            const questions = activeQuiz.msg.action.questions;
            const askerUserId = activeQuiz.msg.action.askerUserId;
            try {
              await base44.functions.invoke('deliverQuizAnswers', {
                recipientUserId: askerUserId,
                questions,
                answers,
                gameType: activeQuiz.msg.action.gameType,
                dateKey: getParisDateKey(),
              });
              if (activeQuiz.msg?.id && !String(activeQuiz.msg.id).startsWith('optimistic_')) {
                await base44.entities.UserMessage.update(activeQuiz.msg.id, { action_json: null }).catch(e => console.error('UserMessage.update failed:', e));
              }
              await addMessageForToday(userId, {
                sender: 'Vous',
                text: `✅ Tu as joué avec ${activeQuiz.profileName}.`,
                is_system: true,
                profile_name: activeQuiz.profileName,
                profile_id: askerUserId || '',
                thread_key: activeQuiz.profileName,
                action: { type: 'quizPlayed' },
              });
              setActiveQuiz(null);
              onRefresh?.();
              loadQuizMessages();
              // Le jeu répondu compte comme joué pour la paire → quota à jour
              onProfileRefresh?.();
            } catch (e) {
              console.error('deliverQuizAnswers failed:', e);
              toast.error('Envoi impossible');
              setActiveQuiz(null);
            } finally {
              setSending(false);
            }
          }}
        />
      )}

      {viewProfileLoading && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 9999, backgroundColor: 'rgba(0,0,0,0.92)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: 40, height: 40, border: '3px solid rgba(255,255,255,0.1)', borderTopColor: '#ff3366', borderRadius: '50%', animation: 'spin 0.6s linear infinite' }} />
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      )}
      {viewProfile && !viewProfileLoading && (
        <ProfileViewModal
          profile={viewProfile}
          myProfile={myProfile}
          matchScore={viewMatchScore}
          cosmicScore={viewCosmicScore}
          personalityScore={viewPersonalityScore}
          games={getGames()}
          onClose={() => setViewProfile(null)}
        />
      )}

      {/* Jeux de découverte lancés depuis le menu œil — mêmes règles que l'onglet Messages */}
      {quizProfile && (
        <QuizModal
          profile={quizProfile.profile}
          usedGameTypes={quizProfile.usedGameTypes || []}
          initialGameType={quizProfile.initialGameType || null}
          onClose={() => setQuizProfile(null)}
          onSend={async (gameType, items) => {
            const targetUserId = quizProfile.targetUserId;
            const name = quizProfile.profileName || 'ce profil';
            try {
              const res = await base44.functions.invoke('deliverQuiz', {
                recipientUserId: targetUserId,
                questions: items,
                gameType,
                dateKey: getParisDateKey(),
              });
              if (res.data?.alreadySent) {
                toast.error(`Tu as déjà proposé ce jeu à ${name} ce mois-ci.`);
                return;
              }
              markGameProposed(targetUserId, gameType);
              toast.success('Jeu envoyé !');
            } catch (e) {
              const errData = e?.data?.data || e?.data || {};
              if (errData?.blocked && errData?.reason === 'already_sent') {
                toast.error(errData?.message || `Tu as déjà proposé ce jeu à ${name} ce mois-ci.`);
                return;
              }
              console.error('deliverQuiz failed:', e);
              toast.error('Envoi impossible');
            } finally {
              setQuizProfile(null);
            }
          }}
        />
      )}

      {showBlockConfirm && blockTarget && (
        <BlockProfileConfirmModal
          profileName={blockTarget.name}
          onClose={() => { setShowBlockConfirm(false); setBlockTarget(null); }}
          onConfirm={() => {
            setShowBlockConfirm(false);
            onBlock?.(blockTarget.id, blockTarget.name);
            setBlockTarget(null);
          }}
        />
      )}
    </div>
  );
}