import React, { useState } from 'react';

const REASONS = [
  { key: 'place', label: "L'endroit ne me plaît pas" },
  { key: 'food', label: "La nourriture ne me plaît pas" },
  { key: 'personal', label: "Je refuse pour une ou des raisons personnelles, mais peut-être une prochaine fois" },
];

export default function RefusalReasonsModal({ profileName, onClose, onConfirm }) {
  const [selected, setSelected] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  function toggle(key) {
    setSelected(prev => prev === key ? null : key);
  }

  const canSubmit = !!selected && !submitting;

  async function handleConfirm() {
    if (!canSubmit) return;
    setSubmitting(true);
    try {
      await onConfirm([selected]);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 300, padding: '20px' }}>
      <div style={{ width: '100%', maxWidth: '460px', background: 'rgba(12,12,16,0.98)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '28px', padding: '32px 28px', backdropFilter: 'blur(18px)' }}>
        <h3 style={{ color: '#ff3366', fontSize: '1.35rem', margin: '0 0 8px', fontWeight: 700, textAlign: 'center' }}>
          Refuser la proposition
        </h3>
        <p style={{ color: '#9f9fae', fontSize: '0.95rem', margin: '0 0 24px', textAlign: 'center' }}>
          Indique la raison de ton refus à {profileName}
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginBottom: '28px' }}>
          {REASONS.map(({ key, label }) => {
            const isChecked = selected === key;
            return (
              <div
                key={key}
                role="checkbox"
                aria-checked={isChecked}
                tabIndex={0}
                onClick={() => toggle(key)}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(key); } }}
                style={{
                  display: 'flex', alignItems: 'flex-start', gap: '14px',
                  padding: '18px 18px', borderRadius: '16px',
                  background: isChecked ? 'rgba(255,51,102,0.12)' : 'rgba(255,255,255,0.04)',
                  border: isChecked ? '1px solid rgba(255,51,102,0.4)' : '1px solid rgba(255,255,255,0.08)',
                  cursor: 'pointer', textAlign: 'left', fontFamily: 'inherit',
                  transition: 'all 0.15s ease',
                }}
              >
                <div style={{
                  width: 26, height: 26, borderRadius: '7px', flexShrink: 0, marginTop: 1,
                  border: isChecked ? '2px solid #ff3366' : '2px solid rgba(255,255,255,0.2)',
                  background: isChecked ? '#ff3366' : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'all 0.15s ease',
                }}>
                  {isChecked && <span style={{ color: '#fff', fontSize: '0.95rem', fontWeight: 800, lineHeight: 1 }}>✓</span>}
                </div>
                <span style={{ color: isChecked ? '#fff' : '#cfcfda', fontSize: '1.05rem', lineHeight: 1.45, fontWeight: 500 }}>
                  {label}
                </span>
              </div>
            );
          })}
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button
            type="button"
            onClick={onClose}
            disabled={submitting}
            style={{
              flex: 1, minHeight: '48px', borderRadius: '999px',
              fontWeight: 600, fontSize: '0.9rem', fontFamily: 'inherit',
              background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.12)',
              color: '#fff', cursor: 'pointer',
            }}
          >
            Annuler
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            disabled={!canSubmit}
            style={{
              flex: 1, minHeight: '48px', borderRadius: '999px',
              fontWeight: 700, fontSize: '0.9rem', fontFamily: 'inherit',
              background: canSubmit ? 'linear-gradient(90deg, #ff3366, #ff69b4)' : 'rgba(255,255,255,0.08)',
              border: 'none', color: '#fff',
              cursor: canSubmit ? 'pointer' : 'not-allowed',
              opacity: canSubmit ? 1 : 0.4,
              transition: 'all 0.15s ease',
            }}
          >
            {submitting ? 'Envoi...' : 'Envoyer le refus'}
          </button>
        </div>
      </div>
    </div>
  );
}