import React, { useState } from 'react';

/**
 * Converts a Cloudinary URL to serve WebP at a given width with quality compression.
 * Works with any URL format; falls back to original URL for non-Cloudinary sources.
 */
function cloudinaryTransform(url, width, quality = 75) {
  if (!url) return url;
  // Match Cloudinary upload URL pattern
  const match = url.match(/^(https?:\/\/res\.cloudinary\.com\/[^/]+\/image\/upload\/)(.+)$/);
  if (!match) return url;
  const [, base, path] = match;
  // Remove existing transformations to avoid chaining issues
  const cleanPath = path.replace(/^v\d+\//, '');
  return `${base}c_limit,w_${width},q_${quality},f_webp/v1/${cleanPath}`;
}

/**
 * Optimized image component:
 * - Generates WebP srcset from Cloudinary URLs (320w, 640w, 960w)
 * - lazy loading by default, fetchpriority="high" for LCP images
 * - Falls back gracefully for non-Cloudinary URLs
 */
export default function OptimizedImage({
  src,
  alt = '',
  className,
  style,
  priority = false,    // true → fetchpriority="high" (LCP image)
  sizes = '100vw',
  draggable,
  onClick,
  onError,
  fallbackName,        // si fourni, rend un placeholder initiales sur erreur
}) {
  const [errored, setErrored] = useState(false);

  // Placeholder initiales quand l'image casse (404, etc.) et fallbackName est fourni
  if (errored && fallbackName) {
    const initial = (fallbackName || '?').charAt(0).toUpperCase() || '?';
    return (
      <div
        className={className}
        onClick={onClick}
        style={{
          ...style,
          background: 'linear-gradient(135deg, #1a0010, #0d0018)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '4rem',
          fontWeight: 800,
          color: '#ff69b4',
        }}
      >
        {initial}
      </div>
    );
  }

  if (!src) return null;

  const isCloudinary = src.includes('res.cloudinary.com');

  const imgProps = {
    alt,
    className,
    style,
    draggable,
    onClick,
    onError: onError || (() => setErrored(true)),
    loading: priority ? 'eager' : 'lazy',
    decoding: priority ? 'sync' : 'async',
    ...(priority && { fetchPriority: 'high' }),
  };

  if (isCloudinary) {
    const srcSet = [
      `${cloudinaryTransform(src, 320)} 320w`,
      `${cloudinaryTransform(src, 640)} 640w`,
      `${cloudinaryTransform(src, 960)} 960w`,
    ].join(', ');

    return (
      <img
        {...imgProps}
        src={cloudinaryTransform(src, 640)}
        srcSet={srcSet}
        sizes={sizes}
      />
    );
  }

  // Non-Cloudinary: just add lazy/priority attributes
  return <img {...imgProps} src={src} />;
}