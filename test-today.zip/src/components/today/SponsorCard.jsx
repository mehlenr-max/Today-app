import React from 'react';

export default function SponsorCard({ sponsor }) {
  const cities = Array.isArray(sponsor.cities) ? sponsor.cities : [];
  return (
    <div style={{ borderRadius: '20px', overflow: 'hidden', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
      {sponsor.photo_url && (
        <img
          src={sponsor.photo_url}
          alt={sponsor.name}
          loading="lazy"
          style={{ width: '100%', aspectRatio: '16 / 10', objectFit: 'cover', display: 'block', background: 'rgba(255,255,255,0.05)' }}
        />
      )}
      <div style={{ padding: '14px 16px 16px', display: 'flex', flexDirection: 'column', gap: '7px' }}>
        <div style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, fontSize: '1.15rem', color: '#fff' }}>
          {sponsor.name}
        </div>
        {sponsor.description && (
          <div style={{ fontSize: '0.82rem', color: '#9f9fae', lineHeight: 1.5 }}>{sponsor.description}</div>
        )}
        {sponsor.address && (
          <div style={{ fontSize: '0.74rem', color: '#6f6f7e' }}>📍 {sponsor.address}</div>
        )}
        {cities.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '2px' }}>
            {cities.map(c => (
              <span key={c} style={{ padding: '3px 9px', borderRadius: '999px', background: 'rgba(255,51,102,0.1)', border: '1px solid rgba(255,51,102,0.22)', color: '#ff9ec1', fontSize: '0.66rem', fontWeight: 700 }}>
                {c}
              </span>
            ))}
          </div>
        )}
        {sponsor.resa_url && (
          <a
            href={sponsor.resa_url}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              marginTop: '8px', textAlign: 'center', padding: '11px 16px', borderRadius: '999px',
              background: 'linear-gradient(135deg, #ff3366, #ff69b4)', color: '#fff',
              fontSize: '0.85rem', fontWeight: 700, textDecoration: 'none',
              boxShadow: '0 8px 20px rgba(255,51,102,0.25)',
            }}
          >
            Réserver
          </a>
        )}
      </div>
    </div>
  );
}