import React from 'react';

function Bone({ width = '100%', height = 16, radius = 8, style = {} }) {
  return (
    <div style={{
      width, height, borderRadius: radius,
      background: 'linear-gradient(90deg, rgba(255,255,255,0.05) 25%, rgba(255,255,255,0.1) 50%, rgba(255,255,255,0.05) 75%)',
      backgroundSize: '200% 100%',
      animation: 'shimmer 1.4s infinite',
      flexShrink: 0,
      ...style,
    }} />
  );
}

export function ProfileCardSkeleton() {
  return (
    <div style={{ borderRadius: 28, overflow: 'hidden', background: 'rgba(15,15,19,0.92)', border: '1px solid rgba(255,255,255,0.06)', width: '100%' }}>
      <Bone height={300} radius={0} />
      <div style={{ display: 'flex', gap: 12, padding: 16 }}>
        <Bone height={54} radius={16} />
        <Bone height={54} radius={16} />
      </div>
    </div>
  );
}

export function MessageCardSkeleton() {
  return (
    <div style={{ borderRadius: 18, border: '1px solid rgba(255,255,255,0.06)', background: 'rgba(0,0,0,0.3)', overflow: 'hidden' }}>
      <div style={{ padding: '12px 16px', borderBottom: '1px solid rgba(255,255,255,0.05)', display: 'flex', alignItems: 'center', gap: 10 }}>
        <Bone width={28} height={28} radius={14} />
        <Bone width={120} height={14} />
      </div>
      <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Bone width="90%" height={12} />
        <Bone width="70%" height={12} />
      </div>
    </div>
  );
}

export function ProfileHeroSkeleton() {
  return (
    <div style={{ borderRadius: 24, border: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.02)', overflow: 'hidden' }}>
      <div style={{ padding: 16, display: 'flex', gap: 14, alignItems: 'center' }}>
        <Bone width={80} height={80} radius={16} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
          <Bone width="60%" height={20} />
          <Bone width="40%" height={12} />
          <Bone width={80} height={22} radius={999} />
        </div>
      </div>
      <div style={{ padding: '0 16px 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        <Bone width="80%" height={12} />
        <Bone width="50%" height={12} />
      </div>
    </div>
  );
}

export default function SkeletonLoader({ type = 'browse', count = 3 }) {
  return (
    <>
      <style>{`
        @keyframes shimmer {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
      `}</style>
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} style={{ opacity: 1 - i * 0.2 }}>
          {type === 'browse' && <ProfileCardSkeleton />}
          {type === 'messages' && <MessageCardSkeleton />}
          {type === 'home' && <ProfileHeroSkeleton />}
        </div>
      ))}
    </>
  );
}