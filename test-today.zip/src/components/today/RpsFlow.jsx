import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import useOverlayBack from '../../hooks/useOverlayBack';

const RPS_CHOICES = ['✊', '✋', '✌️'];

const flashHandlers = {
  onPointerDown: e => { e.currentTarget.style.transform = 'scale(0.96)'; e.currentTarget.style.filter = 'brightness(2)'; e.currentTarget.style.boxShadow = '0 0 40px 10px rgba(255,255,255,0.5)'; },
  onPointerUp: e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; e.currentTarget.style.boxShadow = ''; },
  onPointerLeave: e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; e.currentTarget.style.boxShadow = ''; },
};

function didPlayerWin(player, opponent) {
  return (player === '✊' && opponent === '✌️')
    || (player === '✋' && opponent === '✊')
    || (player === '✌️' && opponent === '✋');
}

function randomChoice(exclude = '') {
  const choices = RPS_CHOICES.filter(c => c !== exclude);
  return choices[Math.floor(Math.random() * choices.length)];
}

// Modal: défi envoyé, en attente que le profil joue en premier
function WaitModal({ profile, onClose }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: '20px' }}>
      <div style={{ width: '100%', maxWidth: '400px', background: 'rgba(12,12,16,0.98)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '28px', padding: '32px 24px', backdropFilter: 'blur(18px)', textAlign: 'center' }}>
        <div style={{ fontSize: '3rem', marginBottom: '12px' }}>⏳</div>
        <h3 style={{ color: '#ff3366', fontSize: '1.28rem', margin: '0 0 8px' }}>Défi envoyé !</h3>
        <p style={{ color: '#cfcfda', fontSize: '0.88rem', margin: '0 0 6px' }}>
          En attente que <strong style={{ color: '#ff69b4' }}>{profile.name}</strong> joue.
        </p>
        <p style={{ color: '#9f9fae', fontSize: '0.78rem', margin: '0 0 24px' }}>La réponse arrivera dans tes messages ✉️</p>
        <button onClick={onClose} {...flashHandlers} style={{ width: '100%', minHeight: '48px', borderRadius: '999px', fontWeight: 600, fontSize: '0.9rem', fontFamily: 'inherit', background: 'linear-gradient(90deg, #ff3366, #ff69b4)', border: 'none', color: '#fff', cursor: 'pointer', transition: 'transform 0.1s ease, filter 0.1s ease' }}>
          Continuer à naviguer →
        </button>
      </div>
    </div>
  );
}

// Modal: le profil a joué, c'est au tour de l'utilisateur
function PlayerTurnModal({ profile, onChoose }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: '20px' }}>
      <div style={{ width: '100%', maxWidth: '380px', background: 'rgba(12,12,16,0.98)', borderRadius: '28px', border: '1px solid rgba(89,211,154,0.3)', padding: '28px 24px', textAlign: 'center' }}>
        <h2 style={{ fontSize: '2.2rem', fontWeight: 900, color: '#59d39a', margin: '0 0 12px', lineHeight: 1 }}>MATCH !</h2>
        <p style={{ color: '#cfcfda', fontSize: '0.88rem', margin: '0 0 4px' }}>
          <strong style={{ color: '#ff69b4' }}>{profile.name}</strong> a joué en premier.
        </p>
        <p style={{ color: '#9f9fae', fontSize: '0.82rem', margin: '0 0 24px' }}>C'est ton tour — le gagnant choisit le lieu !</p>
        <div style={{ display: 'flex', justifyContent: 'center', gap: '24px', marginBottom: '8px' }}>
          {RPS_CHOICES.map(c => (
            <button key={c} onClick={() => onChoose(c)} style={{
              fontSize: '3rem', background: 'none', border: '2px solid rgba(255,255,255,0.1)',
              borderRadius: '18px', padding: '12px 16px', cursor: 'pointer',
              transition: 'all 0.15s ease',
            }}
              onMouseEnter={e => e.currentTarget.style.borderColor = '#ff3366'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'}
            >{c}</button>
          ))}
        </div>
        <p style={{ color: '#9f9fae', fontSize: '0.75rem', margin: '12px 0 0' }}>Pierre · Papier · Ciseaux</p>
      </div>
    </div>
  );
}

// Modal: résultat RPS
function ResultModal({ profile, playerChoice, opponentChoice, playerWins, isDraw, onContinue, busy }) {
  const result = isDraw ? 'ÉGALITÉ !' : playerWins ? 'TU GAGNES ! 🎉' : `${profile.name} gagne…`;
  const emoji = isDraw ? '🤝' : playerWins ? '🎯' : '😔';
  const borderColor = isDraw ? 'rgba(244,193,98,0.4)' : playerWins ? 'rgba(255,51,102,0.4)' : 'rgba(255,255,255,0.1)';
  const titleColor = isDraw ? '#f4c162' : playerWins ? '#ff3366' : '#9f9fae';
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: '20px' }}>
      <div style={{ width: '100%', maxWidth: '380px', background: 'rgba(12,12,16,0.98)', borderRadius: '28px', border: `1px solid ${borderColor}`, padding: '28px 24px', textAlign: 'center' }}>
        <div style={{ fontSize: '2.8rem', marginBottom: '12px' }}>{emoji}</div>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 900, color: titleColor, margin: '0 0 16px' }}>{result}</h2>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', fontSize: '2.8rem', margin: '0 0 16px' }}>
          <span>{playerChoice}</span>
          <span style={{ fontSize: '1.2rem', color: '#9f9fae' }}>vs</span>
          <span>{opponentChoice}</span>
        </div>
        <p style={{ color: '#cfcfda', fontSize: '0.88rem', margin: '0 0 4px' }}>
          {profile.name} : <strong>{opponentChoice}</strong> · Toi : <strong>{playerChoice}</strong>
        </p>
        {isDraw ? (
          <div style={{ background: 'rgba(244,193,98,0.08)', border: '1px solid rgba(244,193,98,0.25)', borderRadius: '12px', padding: '10px 14px', margin: '0 0 24px' }}>
            <p style={{ margin: 0, color: '#f4c162', fontSize: '0.82rem', fontWeight: 600 }}>
              🏆 Règle : en cas d'égalité, le challengeur gagne.
            </p>
            <p style={{ margin: '4px 0 0', color: '#9f9fae', fontSize: '0.78rem' }}>
              {profile.name} va te proposer un lieu.
            </p>
          </div>
        ) : (
          <p style={{ color: '#9f9fae', fontSize: '0.82rem', margin: '0 0 24px' }}>
            {playerWins ? 'Tu choisis le lieu du date !' : `${profile.name} va te proposer un lieu.`}
          </p>
        )}
        <button onClick={onContinue} disabled={busy} {...flashHandlers} style={{ width: '100%', minHeight: '52px', borderRadius: '999px', fontWeight: 700, fontSize: '1rem', fontFamily: 'inherit', background: 'linear-gradient(90deg, #ff3366, #ff69b4)', color: '#fff', border: 'none', cursor: busy ? 'default' : 'pointer', opacity: busy ? 0.6 : 1, boxShadow: '0 12px 24px rgba(255,51,102,0.22)', transition: 'transform 0.1s ease, filter 0.1s ease' }}>
          {busy ? 'Validation…' : 'Continuer →'}
        </button>
      </div>
    </div>
  );
}

// Modal: gagnant choisit le lieu
function WinnerPlaceModal({ profile, onSend, onSkip, isPlaceChange }) {
  const navigate = useNavigate();
  const [showSponsorReminder, setShowSponsorReminder] = useState(false);
   const [place, setPlace] = useState('');
  const getMinTime = () => { const d = new Date(Date.now() + 30 * 60 * 1000); return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`; };
  const [time, setTime] = useState(() => { const minTime = getMinTime(); return '20:00' > minTime ? '20:00' : minTime; });
  const [adresse, setAdresse] = useState('');
  const [numero, setNumero] = useState('');
  const [codePostal, setCodePostal] = useState('');
  const [ville, setVille] = useState('');
  const isTimeTooSoon = time < getMinTime();
  const canSend = place.trim() && adresse.trim() && numero.trim() && codePostal.trim() && ville.trim() && time && !isTimeTooSoon;
  function handleSkip() { onSkip(); }
  function handleSend() { if (canSend) { const address = `${adresse} ${numero}, ${codePostal} ${ville}`; onSend(place, time, address); } }
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: '20px', paddingTop: 'calc(env(safe-area-inset-top) + 20px)', paddingBottom: 'calc(env(safe-area-inset-bottom) + 20px)' }}>
      <div style={{ width: '100%', maxWidth: '420px', background: 'rgba(12,12,16,0.98)', border: '1px solid rgba(255,51,102,0.3)', borderRadius: '28px', padding: '16px 20px 120px', backdropFilter: 'blur(18px)', maxHeight: '100dvh', overflowY: 'auto', WebkitOverflowScrolling: 'touch' }}>
        <div style={{ width: 44, height: 5, borderRadius: '999px', background: 'rgba(255,255,255,0.18)', margin: '0 auto 14px' }} />
        <h3 style={{ textAlign: 'center', color: '#ff3366', fontSize: '1.1rem', margin: '0 0 6px', fontWeight: 700 }}>{isPlaceChange ? '🔄 Changer le lieu' : '📍 Choisir le lieu'}</h3>
        <p style={{ textAlign: 'center', color: '#9f9fae', fontSize: '0.8rem', margin: '0 0 14px' }}>{isPlaceChange ? 'Propose un nouveau lieu pour le date.' : 'Propose un lieu pour le date.'}</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '12px' }}>
          <div>
            <label style={{ display: 'block', fontSize: '0.7rem', fontWeight: 600, color: '#cfcfda', marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.07em' }}>Nom du lieu <span style={{ color: '#ff3366' }}>*</span></label>
            <input value={place} onChange={e => setPlace(e.target.value)} placeholder="ex: Le Botaniste" style={{ width: '100%', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px', background: 'rgba(255,255,255,0.04)', color: '#fff', padding: '10px 12px', outline: 0, fontFamily: 'inherit', fontSize: '16px' }} />
          </div>
          <div>
            <label style={{ display: 'block', fontSize: '0.7rem', fontWeight: 600, color: '#cfcfda', marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.07em' }}>Heure</label>
            <input type="time" value={time} min={getMinTime()} onChange={e => setTime(e.target.value)} style={{ width: '100%', border: `1px solid ${isTimeTooSoon ? 'rgba(255,51,102,0.5)' : 'rgba(255,255,255,0.08)'}`, borderRadius: '12px', background: 'rgba(255,255,255,0.04)', color: isTimeTooSoon ? '#ff6b6b' : '#fff', padding: '10px 12px', outline: 0, fontFamily: 'inherit', fontSize: '16px' }} />
            {isTimeTooSoon && <p style={{ margin: '4px 0 0', fontSize: '0.75rem', color: '#ff6b6b' }}>⚠️ Au moins 30 minutes à l'avance</p>}
          </div>
          <div>
            <label style={{ display: 'block', fontSize: '0.7rem', fontWeight: 600, color: '#cfcfda', marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.07em' }}>Adresse <span style={{ color: '#ff3366' }}>*</span></label>
            <input value={adresse} onChange={e => setAdresse(e.target.value.replace(/[0-9]/g, ''))} placeholder="ex: Rue de Rivoli" style={{ width: '100%', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px', background: 'rgba(255,255,255,0.04)', color: '#fff', padding: '10px 12px', outline: 0, fontFamily: 'inherit', fontSize: '16px' }} />
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            <div style={{ flex: 1 }}>
              <label style={{ display: 'block', fontSize: '0.7rem', fontWeight: 600, color: '#cfcfda', marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.07em' }}>Numéro <span style={{ color: '#ff3366' }}>*</span></label>
              <input value={numero} onChange={e => setNumero(e.target.value.replace(/[^0-9]/g, ''))} inputMode="numeric" placeholder="ex: 15" style={{ width: '100%', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px', background: 'rgba(255,255,255,0.04)', color: '#fff', padding: '10px 12px', outline: 0, fontFamily: 'inherit', fontSize: '16px' }} />
            </div>
            <div style={{ flex: 1 }}>
              <label style={{ display: 'block', fontSize: '0.7rem', fontWeight: 600, color: '#cfcfda', marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.07em' }}>Code postal <span style={{ color: '#ff3366' }}>*</span></label>
              <input value={codePostal} onChange={e => setCodePostal(e.target.value.replace(/[^0-9]/g, ''))} inputMode="numeric" placeholder="ex: 75001" style={{ width: '100%', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px', background: 'rgba(255,255,255,0.04)', color: '#fff', padding: '10px 12px', outline: 0, fontFamily: 'inherit', fontSize: '16px' }} />
            </div>
          </div>
          <div>
            <label style={{ display: 'block', fontSize: '0.7rem', fontWeight: 600, color: '#cfcfda', marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.07em' }}>Ville <span style={{ color: '#ff3366' }}>*</span></label>
            <input value={ville} onChange={e => setVille(e.target.value.replace(/[0-9]/g, ''))} placeholder="ex: Paris" style={{ width: '100%', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px', background: 'rgba(255,255,255,0.04)', color: '#fff', padding: '10px 12px', outline: 0, fontFamily: 'inherit', fontSize: '16px' }} />
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'center', gap: '32px', marginTop: '8px' }}>
          {/* Bouton Attendre — rouge */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
            <button onClick={handleSkip} style={{
              width: 72, height: 72, borderRadius: '50%',
              background: 'radial-gradient(circle at 35% 35%, #ff5555, #cc1111)',
              border: '3px solid rgba(255,255,255,0.15)',
              boxShadow: '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(255,30,30,0.35)',
              cursor: 'pointer', fontSize: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'transform 0.1s ease, box-shadow 0.1s ease',
            }}
              onPointerDown={e => { e.currentTarget.style.transform = 'translateY(3px) scale(0.93)'; e.currentTarget.style.filter = 'brightness(2.2) saturate(0.5)'; e.currentTarget.style.boxShadow = '0 2px 0 rgba(0,0,0,0.4), 0 0 40px 10px rgba(255,255,255,0.5)'; }}
              onPointerUp={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; e.currentTarget.style.boxShadow = '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(255,30,30,0.35)'; }}
              onPointerLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; e.currentTarget.style.boxShadow = '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(255,30,30,0.35)'; }}
            >⏸</button>
            <span style={{ fontSize: '0.72rem', color: '#ff6b6b', fontWeight: 600, textAlign: 'center', lineHeight: 1.3 }}>Attendre<br/>et choisir plus tard</span>
          </div>
          {/* Bouton Accepter — vert */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
            <button onClick={handleSend} disabled={!canSend} style={{
              width: 72, height: 72, borderRadius: '50%',
              background: canSend ? 'radial-gradient(circle at 35% 35%, #55e87a, #1a9c3e)' : 'radial-gradient(circle at 35% 35%, #3a3a3a, #222)',
              border: '3px solid rgba(255,255,255,0.15)',
              boxShadow: canSend ? '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(30,200,80,0.35)' : '0 6px 0 rgba(0,0,0,0.4)',
              cursor: canSend ? 'pointer' : 'default', fontSize: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center',
              opacity: canSend ? 1 : 0.45,
              transition: 'transform 0.1s ease, box-shadow 0.1s ease',
            }}
              onPointerDown={e => { if (canSend) { e.currentTarget.style.transform = 'translateY(3px) scale(0.93)'; e.currentTarget.style.filter = 'brightness(2.2) saturate(0.5)'; e.currentTarget.style.boxShadow = '0 2px 0 rgba(0,0,0,0.4), 0 0 40px 10px rgba(255,255,255,0.5)'; }}}
              onPointerUp={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; e.currentTarget.style.boxShadow = canSend ? '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(30,200,80,0.35)' : '0 6px 0 rgba(0,0,0,0.4)'; }}
              onPointerLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; e.currentTarget.style.boxShadow = canSend ? '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(30,200,80,0.35)' : '0 6px 0 rgba(0,0,0,0.4)'; }}
            >✅</button>
            <span style={{ fontSize: '0.72rem', color: canSend ? '#59d39a' : '#555', fontWeight: 600, textAlign: 'center', lineHeight: 1.3 }}>Proposer<br/>ce lieu</span>
          </div>
        </div>

        <button
          onClick={() => setShowSponsorReminder(true)}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px',
            marginTop: '22px', padding: '12px 16px', borderRadius: '999px',
            border: '1px solid rgba(255,51,102,0.35)',
            background: 'linear-gradient(135deg, rgba(255,51,102,0.18), rgba(255,105,180,0.12))',
            color: '#fff', fontSize: '0.8rem', fontWeight: 700, fontFamily: 'inherit',
            cursor: 'pointer', width: '100%', textAlign: 'center',
          }}
        >
          🍽️ Restaurants &amp; bars
        </button>
      </div>

      {showSponsorReminder && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.88)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 300, padding: '20px' }}>
          <div style={{ width: '100%', maxWidth: '360px', background: 'rgba(12,12,16,0.98)', border: '1px solid rgba(255,51,102,0.3)', borderRadius: '28px', padding: '26px 22px', textAlign: 'center' }}>
            <div style={{ fontSize: '2.4rem', marginBottom: '10px' }}>🍽️</div>
            <h3 style={{ color: '#ff3366', fontSize: '1.15rem', fontWeight: 800, margin: '0 0 10px' }}>Restaurants &amp; bars</h3>
            <p style={{ color: '#cfcfda', fontSize: '0.9rem', lineHeight: 1.45, margin: '0 0 22px' }}>
              N'oublie pas d'envoyer ta proposition à <strong style={{ color: '#ff69b4' }}>« {profile.name} »</strong> après ta recherche.
            </p>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={() => setShowSponsorReminder(false)} style={{ flex: 1, minHeight: '48px', borderRadius: '999px', fontFamily: 'inherit', fontWeight: 600, fontSize: '0.88rem', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.12)', color: '#fff', cursor: 'pointer' }}>
                Rester ici
              </button>
              <button onClick={() => navigate('/sponsors')} style={{ flex: 1, minHeight: '48px', borderRadius: '999px', fontFamily: 'inherit', fontWeight: 700, fontSize: '0.88rem', background: 'linear-gradient(90deg, #ff3366, #ff69b4)', border: 'none', color: '#fff', cursor: 'pointer' }}>
                Voir les restos →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Modal: pas de réponse
function NoResponseModal({ profile, onClose }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: '20px' }}>
      <div style={{ width: '100%', maxWidth: '360px', background: 'rgba(12,12,16,0.98)', borderRadius: '28px', border: '1px solid rgba(255,255,255,0.08)', padding: '32px 24px', textAlign: 'center' }}>
        <div style={{ fontSize: '3rem', marginBottom: '16px' }}>😔</div>
        <h3 style={{ color: '#9f9fae', fontSize: '1.2rem', margin: '0 0 8px' }}>Pas de réponse</h3>
        <p style={{ color: '#9f9fae', fontSize: '0.85rem', margin: '0 0 24px' }}>{profile.name} n'a pas joué à temps.</p>
        <button onClick={onClose} style={{ width: '100%', minHeight: '48px', borderRadius: '999px', fontWeight: 600, fontSize: '0.9rem', fontFamily: 'inherit', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.12)', color: '#fff', cursor: 'pointer' }}>
          OK
        </button>
      </div>
    </div>
  );
}

// Modal: l'envoyeur choisit sa main en premier
function SenderChooseModal({ profile, onChoose }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: '20px' }}>
      <div style={{ width: '100%', maxWidth: '380px', background: 'rgba(12,12,16,0.98)', borderRadius: '28px', border: '1px solid rgba(255,51,102,0.3)', padding: '28px 24px', textAlign: 'center' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 900, color: '#ff3366', margin: '0 0 8px' }}>✊ Joue en premier !</h2>
        <p style={{ color: '#cfcfda', fontSize: '0.88rem', margin: '0 0 4px' }}>
          Choisis ta main — <strong style={{ color: '#ff69b4' }}>{profile.name}</strong> jouera ensuite.
        </p>
        <p style={{ color: '#9f9fae', fontSize: '0.82rem', margin: '0 0 24px' }}>Le gagnant choisit le lieu du date !</p>
        <div style={{ display: 'flex', justifyContent: 'center', gap: '24px', marginBottom: '8px' }}>
          {RPS_CHOICES.map(c => (
            <button key={c} onClick={() => onChoose(c)} style={{
              fontSize: '3rem', background: 'none', border: '2px solid rgba(255,255,255,0.1)',
              borderRadius: '18px', padding: '12px 16px', cursor: 'pointer',
              transition: 'all 0.15s ease',
            }}
              onMouseEnter={e => e.currentTarget.style.borderColor = '#ff3366'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'}
            >{c}</button>
          ))}
        </div>
        <p style={{ color: '#9f9fae', fontSize: '0.75rem', margin: '12px 0 0' }}>Pierre · Papier · Ciseaux</p>
      </div>
    </div>
  );
}

// Orchestrateur principal du flow RPS
export default function RpsFlow({ profile, userId, onDone, addMessage, onBackground, initialStep, initialOpponentChoice, onResolve, onSenderChose, isPlaceChange, winnerCity }) {
  useOverlayBack(true, () => onDone?.());
  const profileName = profile?.name || 'Profil';
  const [step, setStep] = useState(initialStep || 'waiting');
  const [hidden, setHidden] = useState(initialStep === 'winnerPlace');
  const [opponentFirstChoice, setOpponentFirstChoice] = useState(initialOpponentChoice || null);
  const [playerChoice, setPlayerChoice] = useState(null);
  const [opponentChoice, setOpponentChoice] = useState(null);
  const [playerWins, setPlayerWins] = useState(false);
  const [isDraw, setIsDraw] = useState(false);
  const [proposedPlace, setProposedPlace] = useState('');
  const [resolving, setResolving] = useState(false);



  function handleProfilePlayed(firstChoice) {
    setOpponentFirstChoice(firstChoice);
    onBackground?.('playerTurn', { opponentChoice: firstChoice });
    addMessage?.(`🔥 ${profileName} a joué ! À toi de jouer en premier.`, true, profileName,
      { type: 'playerTurn', profile, opponentChoice: firstChoice });
    onDone?.('background');
  }

  function handleTimeout() {
    if (hidden) {
      onBackground?.('timeout', {});
      onDone?.('background');
      return;
    }
    setStep('noResponse');
    addMessage?.(`${profileName} n'a pas répondu au défi. Pas de match.`, true, profileName);
  }

  function handlePlayerChoose(choice) {
    const oChoice = opponentFirstChoice;
    const isDraw = choice === oChoice;
    // En cas d'égalité, le challengeur (profile) gagne → le joueur perd
    const wins = !isDraw && didPlayerWin(choice, oChoice);
    setPlayerChoice(choice);
    setOpponentChoice(oChoice);
    setPlayerWins(wins);
    setIsDraw(isDraw);
    setStep('result');
    // AUCUNE écriture client : les deux mains sont remontées à l'orchestrateur, qui les
    // résout côté serveur (resolveRps) au moment de valider le modal.
  }

  async function handleResultContinue() {
    if (resolving) return;
    // UN SEUL appel serveur (resolveRps) : il transitionne le fil, écrit les messages des
    // deux boîtes et incrémente le compteur de match du gagnant. En cas d'échec on reste sur
    // le résultat (toast côté orchestrateur) : le défi n'est pas consommé, donc rejouable.
    setResolving(true);
    let resolved = true;
    try {
      resolved = await (onResolve ? onResolve(playerChoice, opponentChoice) : true);
    } finally {
      setResolving(false);
    }
    if (!resolved) return;
    if (playerWins) {
      // Le serveur a déjà notifié le challenger (perdant) — il ne reste qu'à choisir le lieu
      setStep('winnerPlace');
    } else {
      onDone?.('background');
    }
  }

  function handleSendPlace(place, time, address) {
    if (!place.trim()) return;
    const addressMsg = address ? `\n📍 ${address}` : '';
    // En cas de changement de lieu, le message "Nouveau lieu proposé" est déjà créé
    // par le handler changePlaceSent côté ToDay4 — éviter le doublon.
    if (!isPlaceChange) {
      addMessage?.(`Tu as proposé : "${place}" à ${profileName} à ${time}${addressMsg}.`, true, profileName);
    }
    onBackground?.(isPlaceChange ? 'changePlaceSent' : 'winnerSent', { place, time, address, profileId: profile.id });
    onDone?.('background');
  }

  function handleSkipPlace() {
    const timerStartTime = Date.now();
    addMessage?.(`Tu peux choisir le lieu plus tard via tes messages.`, true, profileName, { type: 'reopenWinnerPlace', profileId: profile.id, profileName, timerStartTime });
    onDone?.('skipped');
  }

  // Rendre le modal approprié selon le step
  if (step === 'senderChoose') {
    return <SenderChooseModal profile={profile} onChoose={(choice) => {
      onSenderChose?.(choice);
      setStep('waiting');
    }} />;
  }
  if (step === 'waiting') {
    return <WaitModal profile={profile} onClose={() => onDone?.()} />;
  }
  if (step === 'playerTurn') {
    return <PlayerTurnModal profile={profile} onChoose={handlePlayerChoose} />;
  }
  if (step === 'result') {
    return <ResultModal profile={profile} playerChoice={playerChoice} opponentChoice={opponentChoice} playerWins={playerWins} isDraw={isDraw} onContinue={handleResultContinue} busy={resolving} />;
  }
  if (step === 'winnerPlace') {
    return <WinnerPlaceModal profile={profile} onSend={handleSendPlace} onSkip={handleSkipPlace} isPlaceChange={isPlaceChange} winnerCity={winnerCity} />;
  }
  if (step === 'noResponse') {
    return <NoResponseModal profile={profile} onClose={() => onDone?.()} />;
  }
  
  return null;
}