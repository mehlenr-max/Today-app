import React, { useState, useEffect } from 'react';
import { Clock, Ban, Trash2, ChevronDown } from 'lucide-react';
import Avatar from './Avatar';
import { motion } from 'framer-motion';
import ProfileViewModal from './ProfileViewModal';
import QuizModal from './QuizModal';
import { GAME_LIST } from '../../lib/quiz-questions';
import { getUnavailableGameTypes, markGameProposed } from '../../lib/quiz-usage';
import useQuizUsageVersion from '../../hooks/useQuizUsageVersion';
import toast from 'react-hot-toast';
import CancelDateConfirmModal from './CancelDateConfirmModal';
import BlockProfileConfirmModal from './BlockProfileConfirmModal';
import RefusalReasonsModal from './RefusalReasonsModal';
import { calculateMatchScore, getParisDateKey } from '../../lib/today-data';
import { getCosmicScore } from '../../lib/profile-scores';
import { calculatePersonalityCompatibility, parsePersonalityProfile } from '../../lib/scoring';
import { base44 } from '../../api/base44Client';
import { fetchFullProfile } from '../../lib/profile-fetch';

function formatTime(seconds) {
  if (seconds <= 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export default function MessageGroupCard({ profileName, messages, threadProfile, onChoosePlace, showEditButton, timeRemaining: initialTimeRemaining, onAction, hasAccepted, myProfile, prefs, bgTheme, onBlock, otherUserId: otherUserIdProp, isWinner: isWinnerProp, onCancelDate, onChangePlace, onRefresh, onDeleteThread, willBlock, isNew, onMarkSeen, resetToken }) {
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const [showRefusalModal, setShowRefusalModal] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(!!isNew);

  useEffect(() => {
    if (isNew) setIsCollapsed(true);
  }, [isNew]);

  const toggleCollapse = () => {
    if (isCollapsed && isNew) onMarkSeen?.();
    setIsCollapsed(c => !c);
  };
  // Masquer les boutons d'action dès le clic pour éviter les double-clicks.
  // Reset quand les messages changent (refresh après action) ou quand un modal est annulé.
  const [hideButtons, setHideButtons] = useState(false);

  // Fallback : si threadProfile absent (profil hors-ligne non chargé), récupérer l'otherUserId
  // depuis le message de confirmation (profile_id stocke le user_id du perdant côté gagnant)
  const confirmedMsg = messages.find((m) => m.text.includes('Date confirmé') && m.action?.state !== 'closed');
  const refusalReasonsMsg = messages.find(m => m.action?.type === 'refusalWithReasons' && m.action?.state !== 'closed');
  const otherUserId = otherUserIdProp || confirmedMsg?.profile_id || refusalReasonsMsg?.action?.loserProfile?.user_id || messages.find(m => m.profile_id)?.profile_id || null;

  const [showBlockConfirm, setShowBlockConfirm] = useState(false);
  const [drawingCard, setDrawingCard] = useState(false);
  const [actionInProgress, setActionInProgress] = React.useState(false);
  const timeRemaining = initialTimeRemaining;
  const [lightning, setLightning] = useState(false);
  const [viewProfile, setViewProfile] = useState(null);
  const [viewProfileLoading, setViewProfileLoading] = useState(false);
  const [viewMatchScore, setViewMatchScore] = useState(null);
  const [viewCosmicScore, setViewCosmicScore] = useState(null);
  const [viewPersonalityScore, setViewPersonalityScore] = useState(null);
  const [quizProfile, setQuizProfile] = useState(null);
  // Même état partagé que le deck : un jeu envoyé ici est marqué utilisé partout.
  useQuizUsageVersion();

  // Re-tap de l'onglet Messages → fermeture des vues imbriquées (fiche profil, quiz en cours)
  useEffect(() => {
    setViewProfile(null);
    setViewProfileLoading(false);
    setViewMatchScore(null);
    setViewCosmicScore(null);
    setViewPersonalityScore(null);
    setQuizProfile(null);
  }, [resetToken]);


  useEffect(() => {
    setHideButtons(false);
  }, [messages]);

  // Plus de chrono : l'auto-annulation à l'expiration du délai est supprimée.
  // L'annulation après un date confirmé reste possible à tout moment (règle 1h retirée).

  const hasGameResult = messages.some(m => m.text.includes('Résultat PPC'));
  const hasResponded = messages.some(m =>
    m.action?.state !== 'closed' &&
    (m.text.includes('Tu as refusé') ||
     m.text.includes('Date confirmé') ||
     (m.text.startsWith('❌') && m.sender === 'Vous') ||
     (m.text.startsWith('✅') && m.sender === 'Vous'))
  );
  const hasRefusedThisPlace = messages.some(m => m.text.includes('Tu as refusé') && m.sender === 'Vous');
  const isValidated = messages.some(m => m.text.includes('Date confirmé') && m.action?.state !== 'closed');
  // Seul le refus DÉFINITIF ("Pas de match") élimine le thread.
  // Le refus cas A (lieu/nourriture) garde le thread ouvert pour re-proposition.
  const isEliminated = messages.some(m => m.text.includes('Pas de match'));
  // Un date annulé par l'un des deux profils → plus aucun bouton d'action (même en attente d'acceptation)
  const isCancelled = messages.some(m => m.text.includes('Date annulé'));

  React.useEffect(() => {
    if (hasRefusedThisPlace && actionInProgress) setActionInProgress(false);
  }, [hasRefusedThisPlace]);

  React.useEffect(() => {
    if (actionInProgress) {
      const timer = setTimeout(() => setActionInProgress(false), 1000);
      return () => clearTimeout(timer);
    }
  }, [actionInProgress]);

  const threadPhoto = messages.find(m => m.profile_photo)?.profile_photo || '';
  const challengeMsg = messages.find(m => m.action?.type === 'incomingChallenge');
  const rawChallenger = challengeMsg?.action?.profile || threadProfile;
  // Normaliser tous les champs pour ProfileViewModal (même format que BrowseTab)
  const challengerProfile = rawChallenger ? {
    ...rawChallenger,
    name: rawChallenger.name || rawChallenger.display_name || threadProfile?.display_name || '',
    photo: rawChallenger.photo || rawChallenger.photo_url || threadProfile?.photo_url || '',
    photo_url_2: rawChallenger.photo_url_2 || threadProfile?.photo_url_2 || '',
    photo_url_3: rawChallenger.photo_url_3 || threadProfile?.photo_url_3 || '',
    city: rawChallenger.city || threadProfile?.city || '',
    age: rawChallenger.age || threadProfile?.age || '',
    height: rawChallenger.height || threadProfile?.height || null,
    education: rawChallenger.education || threadProfile?.education || '',
    job: rawChallenger.job || threadProfile?.job || '',
    fiveWords: rawChallenger.fiveWords || rawChallenger.five_words || threadProfile?.five_words || '',
    quizPhrase: rawChallenger.quizPhrase || rawChallenger.quiz_phrase || threadProfile?.quiz_phrase || '',
    astro_sign: rawChallenger.astro_sign || threadProfile?.astro_sign || '',
    astro_ascendant: rawChallenger.astro_ascendant || threadProfile?.astro_ascendant || '',
    ownPhysicalTraits: rawChallenger.ownPhysicalTraits || rawChallenger.own_physical_traits || threadProfile?.own_physical_traits || [],
    ownPersonalityTraits: rawChallenger.ownPersonalityTraits || rawChallenger.own_personality_traits || threadProfile?.own_personality_traits || [],
    personal_flaws: rawChallenger.personal_flaws || threadProfile?.personal_flaws || [],
    desired_physical_traits: rawChallenger.desired_physical_traits || threadProfile?.desired_physical_traits || [],
    time_slot: rawChallenger.time_slot || threadProfile?.time_slot || '',
  } : null;

  const normProfile = (p) => ({
    ...p,
    name: p.display_name || p.name || '',
    photo: p.photo_url || p.photo || '',
    photo_url_2: p.photo_url_2 || '',
    photo_url_3: p.photo_url_3 || '',
    fiveWords: p.five_words || p.fiveWords || '',
    quizPhrase: p.quiz_phrase || p.quizPhrase || '',
    ownPhysicalTraits: p.own_physical_traits || p.ownPhysicalTraits || [],
    ownPersonalityTraits: p.own_personality_traits || p.ownPersonalityTraits || [],
    personal_flaws: p.personal_flaws || [],
    desired_physical_traits: p.desired_physical_traits || p.desired_physical_traits || [],
  });

  async function handleViewProfile() {
    const lean = challengerProfile || threadProfile;
    if (!lean && !otherUserId) return;
    setViewProfileLoading(true);
    const full = await fetchFullProfile(lean, otherUserId);
    if (!full) {
      setViewProfileLoading(false);
      return;
    }
    const fullNorm = normProfile(full);
    setViewMatchScore(prefs ? calculateMatchScore(fullNorm, prefs, myProfile) : null);
    setViewCosmicScore(getCosmicScore(myProfile, fullNorm));
    // Même score de personnalité que le deck et l'onglet Jeux.
    setViewPersonalityScore(calculatePersonalityCompatibility(
      parsePersonalityProfile(myProfile?.personality_profile),
      parsePersonalityProfile(full?.personality_profile),
    ));
    setViewProfile(fullNorm);
    setViewProfileLoading(false);
  }

  // Jeux de découverte jouables depuis la fiche profil (menu œil) — mêmes règles que sur le deck
  function getGames() {
    const targetUserId = viewProfile?.user_id || otherUserId;
    if (!targetUserId) return [];
    const usedGameTypes = getUnavailableGameTypes(myProfile, targetUserId);
    const bothUsed = usedGameTypes.length >= 2;
    return GAME_LIST.map(g => {
      const used = usedGameTypes.includes(g.id);
      return {
        key: g.id,
        emoji: g.emoji,
        label: g.label,
        subtitle: g.subtitle,
        disabled: used || bothUsed,
        disabledLabel: used ? 'Déjà envoyé' : 'Game over',
        onSelect: () => {
          setViewProfile(null);
          setQuizProfile({ profile: viewProfile, usedGameTypes, initialGameType: g.id, targetUserId });
        },
      };
    });
  }

  const isWhite = bgTheme === 'white';
  // L'annulation prend la priorité sur les autres états (validé/éliminé/en attente)
  const borderClass = isCancelled
    ? 'bg-red-500/10 border-red-500/30'
    : isValidated
    ? 'bg-green-500/10 border-green-500/30'
    : isEliminated
    ? 'bg-red-500/10 border-red-500/30'
    : isWhite ? 'bg-white/80 shadow-sm border-black/10' : 'bg-black/45 border-white/6';

  const headerClass = isCancelled
    ? 'bg-red-500/15 border-red-500/30'
    : isValidated
    ? 'bg-green-500/15 border-green-500/30'
    : isEliminated
    ? 'bg-red-500/15 border-red-500/30'
    : isWhite ? 'bg-pink-100 border-pink-200' : 'bg-pink-500/8 border-white/6';

  const nameClass = isCancelled ? 'text-red-400' : isValidated ? 'text-green-400' : isEliminated ? 'text-red-400' : 'text-pink-400';

  return (
    <>
    <motion.div
      data-card=""
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className={`rounded-2xl overflow-hidden backdrop-blur-xl border ${borderClass}`}
    >
      {/* Header */}
      <div className={`px-4 py-3 border-b flex items-start justify-between gap-2 ${headerClass}`}>
        <div className={`text-sm font-bold ${nameClass} flex items-center gap-2 min-w-0 flex-1`}>
          <Avatar
            photoUrl={threadPhoto || threadProfile?.photo || challengerProfile?.photo}
            name={profileName}
            size={28}
            sizes="28px"
            style={{ border: '1.5px solid rgba(255,51,102,0.5)' }}
          />
          <span style={{
            background: 'linear-gradient(90deg, #ff69b4, #e879f9, #ff69b4)',
            backgroundSize: '200% auto',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            fontWeight: 800,
            letterSpacing: '0.03em',
            fontSize: '0.95rem',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            minWidth: 0,
          }}>{profileName}</span>
          <button
            onClick={handleViewProfile}
            style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', fontSize: '1.2rem', lineHeight: 1, flexShrink: 0 }}
            title="Voir le profil"
          >
            👁
          </button>
          <button
            onClick={toggleCollapse}
            style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', lineHeight: 1, flexShrink: 0, marginLeft: 2, opacity: 0.55, transition: 'transform 0.2s' }}
            title={isCollapsed ? 'Déplier' : 'Replier'}
          >
            <ChevronDown size={16} className={isWhite ? 'text-gray-500' : 'text-gray-400'} style={{ transform: isCollapsed ? 'rotate(-90deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }} />
          </button>
          {isValidated && <span style={{ WebkitTextFillColor: 'initial' }}> ✅</span>}
          {(isEliminated || isCancelled) && <span style={{ WebkitTextFillColor: 'initial' }}> ❌</span>}
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          {(hasGameResult || hasResponded || messages.some(m => m.action?.type === 'winnerChoosePlace' || m.action?.type === 'loserAccept') || messages.some(m => m.timerStartTime || m.timer_start_time)) && !isValidated && !isEliminated && !isCancelled && (
            <div className="flex flex-col items-end gap-0.5">
              {timeRemaining !== null && (
                <div className="flex items-center gap-1.5">
                  <Clock size={12} className="text-pink-400" />
                  <span className={`text-xs font-bold ${timeRemaining > 300 ? 'text-pink-400' : 'text-orange-400'}`}>
                    {timeRemaining > 0 ? formatTime(timeRemaining) : 'Expiré'}
                  </span>
                  {timeRemaining > 0 && (() => {
                    const playerWon = messages.some(m => m.text.includes('Tu gagnes') || m.text.includes('Tu as gagné'));
                    const hasLoserAccept = messages.some(m => m.action?.type === 'loserAccept');
                    const hasRefusalReasons = messages.some(m => m.action?.type === 'refusalWithReasons');
                    const alreadyProposed = messages.some(m => m.text.includes('Tu as proposé') || m.text.includes("En attente d'acceptation"));
                    const viewerMustAct = hasRefusalReasons || (hasLoserAccept && !hasResponded) || (playerWon && !alreadyProposed);
                    return <span className={`text-[0.6rem] font-semibold ${isWhite ? 'text-gray-500' : 'text-gray-400'}`}>· {viewerMustAct ? 'à toi' : `à ${profileName}`}</span>;
                  })()}
                </div>
              )}
            </div>
          )}
          {!isValidated && (challengerProfile?.id || threadProfile?.id) && (
            <button
              onClick={() => setShowBlockConfirm(true)}
              style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', lineHeight: 1, flexShrink: 0, opacity: 0.55 }}
              title="Bloquer ce profil"
            >
              <Ban size={13} className={isWhite ? 'text-gray-500' : 'text-gray-400'} />
            </button>
          )}
          <button
            onClick={() => onDeleteThread?.(profileName, messages)}
            style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', lineHeight: 1, flexShrink: 0, opacity: 0.55 }}
            title="Supprimer la conversation"
          >
            <Trash2 size={13} className={isWhite ? 'text-red-500' : 'text-red-400'} />
          </button>
        </div>
      </div>
      {/* Messages */}
      <div className="p-3 space-y-2.5">
        {isCollapsed && messages.length > 0 && (() => {
          if (isNew) {
            return (
              <button
                onClick={toggleCollapse}
                className={`w-full text-left rounded-xl border p-2.5 flex items-center gap-2 ${isWhite ? 'bg-pink-50 border-pink-200' : 'bg-pink-500/10 border-pink-500/25'}`}
              >
                <span className="text-sm">📥</span>
                <span className={`text-xs font-bold ${isWhite ? 'text-pink-600' : 'text-pink-400'}`}>Nouveau message de {profileName}</span>
              </button>
            );
          }
          const last = messages[messages.length - 1];
          return (
            <div className={`rounded-xl border p-2.5 ${isWhite ? 'bg-white/60 border-black/8' : 'bg-black/30 border-white/5'}`}>
              <div className="flex justify-between items-start gap-2">
                <div className="flex-1 min-w-0">
                  <p className={`text-sm leading-relaxed whitespace-pre-wrap break-words line-clamp-2 ${isWhite ? 'text-gray-800' : 'text-gray-200'}`}>
                    {last.text}
                  </p>
                  {last.created_date && (
                    <div className={`flex items-center gap-1 text-xs mt-1 ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>
                      <span>🕐</span>
                      <span>{last.display_time || new Date(last.created_date).toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })()}
        {!isCollapsed && messages.map((msg, i) => {
          return (
            <div key={i} className={`rounded-xl border p-2.5 ${isWhite ? 'bg-white/60 border-black/8' : 'bg-black/30 border-white/5'}`}>
              <div className="flex justify-between items-start gap-2">
                <div className="flex-1 min-w-0">
                  <p className={`text-sm leading-relaxed whitespace-pre-wrap break-words ${isWhite ? 'text-gray-800' : 'text-gray-200'}`}>
                    {msg.text}
                  </p>
                  {msg.created_date && (
                    <div className={`flex items-center gap-1 text-xs mt-1 ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>
                      <span>🕐</span>
                      <span>{msg.display_time || new Date(msg.created_date).toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  )}
                </div>

              </div>
            </div>
          );
        })}

        {/* Action buttons */}
        {(() => {
          // Boutons masqués après un clic (anti-double-click) — reset au refresh ou annulation modal.
          if (hideButtons) return null;
          // Date annulé par l'un des deux → plus aucun bouton (même si lieu en attente d'acceptation)
          if (isCancelled) return null;
          // Un changement de lieu (isPlaceChange) est une renégociation DANS le fil confirmé :
          // ne pas bloquer avec "déjà un date confirmé" — c'est CE fil qui est confirmé.
          const hasPlaceChange = messages.some(m => m.action?.type === 'loserAccept' && m.action?.isPlaceChange && m.action?.state !== 'closed');
          // Côté proposant : le message "Tu as changé le lieu" indique qu'une renégociation
          // est en cours — ne pas afficher "🔒 déjà un date" mais "En attente d'acceptation".
          const hasPlaceChangeSent = messages.some(m =>
            m.action?.state !== 'closed' &&
            (m.text?.includes('Tu as changé le lieu') || m.text?.includes('Nouveau lieu proposé'))
          );
          if (hasAccepted && !isValidated && !hasPlaceChange && !hasPlaceChangeSent) {
            return (
              <p className={`text-xs text-center w-full mt-2 ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>
                🔒 Tu as déjà un date confirmé
              </p>
            );
          }
          // Proposant d'un changement de lieu → en attente d'acceptation du destinataire
          if (hasPlaceChangeSent && !isValidated && !hasPlaceChange && !refusalReasonsMsg) {
            const expired = timeRemaining !== null && timeRemaining <= 0;
            return (
              <p className={`text-xs text-center w-full mt-2 ${isWhite ? 'text-gray-500' : 'text-gray-400'}`}>
                {expired ? '⏰ Délai expiré — annulation…' : `⏳ En attente d'acceptation de ${profileName}…`}
              </p>
            );
          }
          const loserMsg = messages.find(m => m.action?.type === 'loserAccept');
          const incomingMsg = messages.find(m => m.action?.type === 'incomingChallenge');
          const winnerChooseMsg = messages.find(m => m.action?.type === 'winnerChoosePlace');
          const isPlaceChangeInProgress = messages.some(m =>
            m.text?.includes('a changé le lieu') ||
            m.text?.includes('Nouveau lieu proposé') ||
            m.text?.includes("attente d'acceptation") ||
            m.text?.includes('Tu as proposé')
          );
          const placeProposalRefused = messages.some(m =>
            m.text?.includes('a refusé ta proposition') ||
            m.text?.includes('a refusé le lieu')
          );

          // Bouton d'annulation d'un date confirmé — annulable à tout moment
          // (la règle des 1h avant le rendez-vous est retirée : l'annulation
          // après confirmation reste bloquante pour l'annulateur, c'est suffisant).
          if (isValidated && otherUserId && onCancelDate) {
            // Seul le gagnant du défi peut changer le lieu
            const isWinner = isWinnerProp || messages.some(m => m.text.includes('Tu as gagné') || m.text.includes('Tu gagnes') || m.action?.type === 'winnerChoosePlace' || m.text.includes('Tu as proposé'));
            const alreadyDrew = messages.some(m => m.action?.type === 'dateCardDrawn');
            const drawBtn = alreadyDrew ? (
              <div className="flex-1 py-2 rounded-lg bg-purple-500/10 border border-purple-500/25 text-purple-400 text-xs font-bold text-center opacity-80">
                🃏 Gage pioché
              </div>
            ) : (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={drawingCard}
                onClick={async () => {
                  if (drawingCard) return;
                  setDrawingCard(true);
                  try {
                    await base44.functions.invoke('drawDateCard', { otherUserId });
                    await onRefresh?.();
                  } catch (e) {
                    console.error('drawDateCard failed:', e);
                  } finally {
                    setDrawingCard(false);
                  }
                }}
                className="flex-1 py-2 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold hover:shadow-lg transition-all disabled:opacity-50"
              >
                {drawingCard ? '⏳ Pioche...' : '🃏 Piocher un gage'}
              </motion.button>
            );
               return (
                 <div className="flex gap-2 mt-2">
                   {drawBtn}
                   <motion.button
                     whileHover={{ scale: 1.02 }}
                     whileTap={{ scale: 0.98 }}
                     onClick={() => { setHideButtons(true); setShowCancelConfirm(true); }}
                     className="flex-1 py-2 rounded-lg bg-red-500/15 border border-red-500/30 text-red-400 text-xs font-bold hover:bg-red-500/25 transition-all"
                   >
                     ✗ Annuler
                   </motion.button>
                   {isWinner && (
                   <motion.button
                     whileHover={{ scale: 1.02 }}
                     whileTap={{ scale: 0.98 }}
                     onClick={() => { setHideButtons(true); onChangePlace?.(otherUserId, profileName, challengerProfile || threadProfile); }}
                     className="flex-1 py-2 rounded-lg bg-pink-500/15 border border-pink-500/30 text-pink-400 text-xs font-bold hover:bg-pink-500/25 transition-all"
                   >
                     📍 Changer le lieu
                   </motion.button>
                   )}
                 </div>
               );
          }

          if (loserMsg && !hasResponded && !isValidated && !isEliminated) {
            const expired = timeRemaining !== null && timeRemaining <= 0;
            return (
              <div className="flex gap-2 mt-2">
                {expired ? (
                  <p className={`text-xs text-center w-full ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>⏰ Délai expiré</p>
                ) : (
                  <>
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => { setHideButtons(true); setShowRefusalModal(true); }}
                      className="flex-1 py-2 rounded-lg bg-red-500/15 border border-red-500/30 text-red-400 text-xs font-bold hover:bg-red-500/25 transition-all"
                    >
                      ✗ Refuser
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      disabled={actionInProgress}
                      onClick={async () => {
                        if (actionInProgress) return;
                        setActionInProgress(true);
                        setHideButtons(true);
                        try {
                          await onAction?.({ ...loserMsg.action, type: 'acceptPlace' });
                        } catch (e) {
                          setHideButtons(false);
                        } finally {
                          setActionInProgress(false);
                        }
                      }}
                      className="flex-1 py-2 rounded-lg bg-gradient-to-r from-green-500 to-green-600 text-white text-xs font-bold hover:shadow-lg transition-all disabled:opacity-50"
                    >
                      {actionInProgress ? 'Envoi...' : '✅ Accepter'}
                    </motion.button>
                  </>
                )}
              </div>
            );
          }

          const hasAlreadyProposedPlace = messages.some(m => m.text.includes('Tu as proposé'));

          // Cas A : le perdant a refusé avec raisons lieu/nourriture → le gagnant peut re-proposer ou annuler
          if (refusalReasonsMsg && !hasResponded && !isValidated && !isEliminated) {
            const expired = timeRemaining !== null && timeRemaining <= 0;
            if (expired) {
              return (
                <p className={`text-xs text-center w-full mt-2 ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>⏰ Délai expiré</p>
              );
            }
            // Si le date était déjà confirmé (message "Date confirmé" fermé par changeDatePlace),
            // utiliser changeDatePlace (pas deliverResult notifyLoser qui serait bloqué par le lock).
            const wasConfirmedBefore = messages.some(m => m.text.includes('Date confirmé'));
            return (
              <div className="flex gap-2 mt-2">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setHideButtons(true);
                    if (wasConfirmedBefore && otherUserId && onChangePlace) {
                      onChangePlace(otherUserId, profileName, challengerProfile || threadProfile);
                    } else {
                      onAction?.({ type: 'winnerChoosePlace', loserProfile: refusalReasonsMsg.action.loserProfile });
                    }
                  }}
                  className="flex-1 py-2 rounded-lg bg-gradient-to-r from-pink-500 to-pink-600 text-white text-xs font-bold hover:shadow-lg transition-all"
                >
                  📍 Choisir un autre lieu
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => { setHideButtons(true); setShowCancelConfirm(true); }}
                  className="flex-1 py-2 rounded-lg bg-red-500/15 border border-red-500/30 text-red-400 text-xs font-bold hover:bg-red-500/25 transition-all"
                >
                  ✗ Annuler
                </motion.button>
              </div>
            );
          }

          if (winnerChooseMsg && !hasResponded && !isValidated && !isEliminated) {
            const expired = timeRemaining !== null && timeRemaining <= 0;
            if (hasAlreadyProposedPlace) {
              return (
                <p className={`text-xs text-center w-full mt-2 ${isWhite ? 'text-gray-500' : 'text-gray-400'}`}>⏳ En attente de la réponse…</p>
              );
            }
            return (
              <div className="flex flex-col gap-2 mt-2">
                {expired ? (
                  <p className={`text-xs text-center w-full ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>⏰ Délai expiré</p>
                ) : (
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => { setHideButtons(true); onAction?.(winnerChooseMsg.action); }}
                    className="w-full py-2 rounded-lg bg-gradient-to-r from-pink-500 to-pink-600 text-white text-xs font-bold hover:shadow-lg transition-all"
                  >
                    🏆 Choisir le lieu du date
                  </motion.button>
                )}
              </div>
            );
          }

          const playerTurnMsg = messages.find(m => m.action?.type === 'playerTurn');
          if (playerTurnMsg && !hasResponded && !isValidated && !isEliminated && (timeRemaining === null || timeRemaining > 0)) {
            const expired = timeRemaining !== null && timeRemaining <= 0;
            return (
              <div className="flex flex-col gap-2 mt-2">
                {expired ? (
                  <p className={`text-xs text-center w-full ${isWhite ? 'text-gray-500' : 'text-gray-500'}`}>⏰ Délai expiré</p>
                ) : (
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => { setHideButtons(true); onAction?.(playerTurnMsg.action); }}
                    className="w-full py-2 rounded-lg bg-gradient-to-r from-pink-500 to-pink-600 text-white text-xs font-bold hover:shadow-lg transition-all"
                  >
                    🎮 À toi de jouer
                  </motion.button>
                )}
              </div>
            );
          }

          if (incomingMsg && !hasResponded && !isValidated && !isEliminated && (timeRemaining === null || timeRemaining > 0)) {
            const action = incomingMsg.action;
            const isDisabled = hasAccepted;
            const showViewProfile = challengerProfile && (
              challengerProfile.fiveWords ||
              challengerProfile.ownPhysicalTraits?.length > 0 ||
              challengerProfile.ownPersonalityTraits?.length > 0
            );
            return (
              <div className="flex flex-col gap-2 mt-2">
                <style>{`@keyframes flashOut { 0% { opacity: 1; } 100% { opacity: 0; } }`}</style>
                {lightning && (
                  <div style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'white', animation: 'flashOut 0.35s ease-out forwards', pointerEvents: 'none' }} />
                )}

                <motion.button
                  whileHover={!isDisabled ? { scale: 1.02 } : {}}
                  whileTap={!isDisabled ? { scale: 0.98 } : {}}
                  onClick={() => {
                    if (!isDisabled) {
                      setHideButtons(true);
                      setLightning(true);
                      setTimeout(() => setLightning(false), 420);
                      onAction?.(action);
                    }
                  }}
                  disabled={isDisabled}
                  className={`w-full py-2 rounded-lg text-xs font-bold transition-all ${
                    isDisabled
                      ? 'bg-gray-600/40 border border-gray-500/40 text-gray-400 cursor-not-allowed opacity-50'
                      : 'bg-gradient-to-r from-pink-500 to-pink-600 text-white hover:shadow-lg'
                  }`}
                >
                  🎮 Relever le défi
                </motion.button>
              </div>
            );
          }

          return null;
        })()}
      </div>
    </motion.div>

      {/* Modal profil complet (identique au deck : bouton œil + scores complets) */}
      {viewProfileLoading && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 9999, backgroundColor: 'rgba(0,0,0,0.92)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: 40, height: 40, border: '3px solid rgba(255,255,255,0.1)', borderTopColor: '#ff3366', borderRadius: '50%', animation: 'spin 0.6s linear infinite' }} />
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      )}
      {viewProfile && !viewProfileLoading && (
        <ProfileViewModal
          profile={viewProfile}
          myProfile={myProfile}
          matchScore={viewMatchScore}
          cosmicScore={viewCosmicScore}
          personalityScore={viewPersonalityScore}
          games={getGames()}
          onClose={() => setViewProfile(null)}
        />
      )}

      {/* Jeux de découverte lancés depuis le menu œil de la conversation */}
      {quizProfile && (
        <QuizModal
          profile={quizProfile.profile}
          usedGameTypes={quizProfile.usedGameTypes || []}
          initialGameType={quizProfile.initialGameType || null}
          onClose={() => setQuizProfile(null)}
          onSend={async (gameType, items) => {
            const targetUserId = quizProfile.targetUserId;
            try {
              const res = await base44.functions.invoke('deliverQuiz', {
                recipientUserId: targetUserId,
                questions: items,
                gameType,
                dateKey: getParisDateKey(),
              });
              if (res.data?.alreadySent) {
                toast.error(`Tu as déjà proposé ce jeu à ${profileName} ce mois-ci.`);
                return;
              }
              markGameProposed(targetUserId, gameType);
              toast.success('Jeu envoyé !');
            } catch (e) {
              const errData = e?.data?.data || e?.data || {};
              if (errData?.blocked && errData?.reason === 'already_sent') {
                toast.error(errData?.message || `Tu as déjà proposé ce jeu à ${profileName} ce mois-ci.`);
                return;
              }
              console.error('deliverQuiz failed:', e);
              toast.error('Envoi impossible');
            } finally {
              setQuizProfile(null);
            }
          }}
        />
      )}

      {/* Modale de confirmation annulation du date */}
      {showCancelConfirm && (
        <CancelDateConfirmModal
          profileName={profileName}
          willBlock={willBlock}
          onClose={() => { setShowCancelConfirm(false); setHideButtons(false); }}
          onConfirm={async () => {
            await onCancelDate(otherUserId, profileName);
            setShowCancelConfirm(false);
          }}
        />
      )}

      {/* Modale des raisons de refus */}
      {showRefusalModal && (
        <RefusalReasonsModal
          profileName={profileName}
          onClose={() => { setShowRefusalModal(false); setHideButtons(false); }}
          onConfirm={async (reasons) => {
            const loserMsg = messages.find(m => m.action?.type === 'loserAccept');
            if (loserMsg) {
              await onAction?.({ ...loserMsg.action, type: 'passPlaceWithReasons', reasons });
            }
            setShowRefusalModal(false);
          }}
        />
      )}

      {/* Modale de confirmation blocage */}
      {showBlockConfirm && (
        <BlockProfileConfirmModal
          profileName={profileName}
          onClose={() => { setShowBlockConfirm(false); }}
          onConfirm={() => {
            setShowBlockConfirm(false);
            onBlock?.(challengerProfile?.id || threadProfile?.id, profileName);
          }}
        />
      )}
    </>
  );
}