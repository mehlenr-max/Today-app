import React from 'react';

// Section « jeux » de la fiche profil (menu œil) : liste les jeux disponibles
// pour ce profil et lance directement celui qui est choisi.
export default function ProfileGamesSection({ profileName, games }) {
  if (!games?.length) return null;
  return (
    <div style={{ borderRadius: '18px', background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,51,102,0.25)', overflow: 'hidden' }}>
      <div style={{ padding: '14px 18px 10px' }}>
        <div style={{ fontSize: '0.62rem', color: '#9f9fae', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700 }}>Jouer</div>
        <div style={{ fontSize: '0.78rem', color: '#cfcfda', marginTop: 3 }}>
          Lance un jeu avec {profileName} pour briser la glace.
        </div>
      </div>
      {games.map(g => (
        <button
          key={g.key}
          onClick={g.disabled ? undefined : g.onSelect}
          disabled={g.disabled}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '13px 18px',
            background: 'transparent', border: 'none', borderTop: '1px solid rgba(255,255,255,0.06)',
            fontFamily: 'inherit', textAlign: 'left', cursor: g.disabled ? 'default' : 'pointer',
            opacity: g.disabled ? 0.45 : 1,
          }}
        >
          <span style={{ fontSize: '1.5rem', flexShrink: 0 }}>{g.emoji}</span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: '0.9rem', fontWeight: 700, color: g.disabled ? '#9f9fae' : '#ff69b4' }}>{g.label}</div>
            <div style={{ fontSize: '0.7rem', color: '#9f9fae', marginTop: 1 }}>{g.subtitle}</div>
          </div>
          <span style={{
            fontSize: '0.68rem', fontWeight: 700, flexShrink: 0, padding: '5px 11px', borderRadius: '999px',
            color: g.disabled ? '#6b6b7b' : '#fff',
            background: g.disabled ? 'rgba(255,255,255,0.06)' : 'linear-gradient(90deg, #ff3366, #ff69b4)',
          }}>
            {g.disabled ? g.disabledLabel : 'Jouer'}
          </span>
        </button>
      ))}
    </div>
  );
}