import React, { useState } from 'react';
import { base44 } from '../../api/base44Client';
import toast from 'react-hot-toast';

const inputStyle = {
  width: '100%', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px',
  background: 'rgba(255,255,255,0.04)', color: '#fff', padding: '10px 12px',
  outline: 0, fontFamily: 'inherit', fontSize: '16px',
};

const labelStyle = {
  display: 'block', fontSize: '0.7rem', fontWeight: 600, color: '#cfcfda',
  marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.07em',
};

function isValidUrl(value) {
  if (!value) return false;
  try {
    const url = new URL(value);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch { return false; }
}

export default function SponsorAddModal({ onClose, onSaved }) {
  const [name, setName] = useState('');
  const [cities, setCities] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [address, setAddress] = useState('');
  const [description, setDescription] = useState('');
  const [resaUrl, setResaUrl] = useState('');
  const [saving, setSaving] = useState(false);

  const resaTrimmed = resaUrl.trim();
  const photoTrimmed = photoUrl.trim();
  const resaInvalid = resaTrimmed.length > 0 && !isValidUrl(resaTrimmed);
  const photoInvalid = photoTrimmed.length > 0 && !isValidUrl(photoTrimmed);
  const canSave = name.trim().length > 0 && isValidUrl(resaTrimmed) && !photoInvalid && !saving;

  async function handleSave() {
    if (!canSave) return;
    setSaving(true);
    try {
      await base44.entities.Sponsor.create({
        name: name.trim(),
        cities: cities.split(',').map(c => c.trim()).filter(Boolean),
        photo_url: photoTrimmed,
        address: address.trim(),
        description: description.trim(),
        resa_url: resaTrimmed,
      });
      toast.success('Partenaire ajouté');
      onSaved?.();
      onClose();
    } catch (e) {
      console.error('create sponsor failed', e);
      toast.error('Ajout impossible');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 300, padding: '20px' }}>
      <div style={{ width: '100%', maxWidth: '420px', background: 'rgba(12,12,16,0.98)', border: '1px solid rgba(255,51,102,0.3)', borderRadius: '28px', padding: '18px 20px 20px', backdropFilter: 'blur(18px)', maxHeight: '100dvh', overflowY: 'auto' }}>
        <h3 style={{ textAlign: 'center', color: '#ff3366', fontSize: '1.1rem', margin: '0 0 14px', fontWeight: 700 }}>➕ Ajouter un partenaire</h3>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '16px' }}>
          <div>
            <label style={labelStyle}>Nom <span style={{ color: '#ff3366' }}>*</span></label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="ex: 36 Baronomie" style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>Villes <span style={{ color: '#6f6f7e', textTransform: 'none', letterSpacing: 0 }}>(séparées par des virgules)</span></label>
            <input value={cities} onChange={e => setCities(e.target.value)} placeholder="ex: Bruxelles, Tervuren" style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>URL de la photo</label>
            <input value={photoUrl} onChange={e => setPhotoUrl(e.target.value)} placeholder="https://…" style={{ ...inputStyle, borderColor: photoInvalid ? 'rgba(255,51,102,0.5)' : 'rgba(255,255,255,0.08)' }} />
            {photoInvalid && <p style={{ margin: '4px 0 0', fontSize: '0.72rem', color: '#ff6b6b' }}>⚠️ URL invalide</p>}
          </div>
          <div>
            <label style={labelStyle}>Adresse</label>
            <input value={address} onChange={e => setAddress(e.target.value)} placeholder="ex: Av. de Woluwe-Saint-Lambert 36, 1200 Bruxelles" style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>Description</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} placeholder="ex: Bar à vins & petite cuisine de partage." style={{ ...inputStyle, resize: 'vertical' }} />
          </div>
          <div>
            <label style={labelStyle}>URL de réservation <span style={{ color: '#ff3366' }}>*</span></label>
            <input value={resaUrl} onChange={e => setResaUrl(e.target.value)} placeholder="https://…" style={{ ...inputStyle, borderColor: resaInvalid ? 'rgba(255,51,102,0.5)' : 'rgba(255,255,255,0.08)' }} />
            {resaInvalid && <p style={{ margin: '4px 0 0', fontSize: '0.72rem', color: '#ff6b6b' }}>⚠️ URL invalide (http:// ou https://)</p>}
          </div>
        </div>

        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={onClose}
            style={{ flex: 1, minHeight: '48px', borderRadius: '999px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', color: '#cfcfda', fontWeight: 700, fontSize: '0.88rem', fontFamily: 'inherit', cursor: 'pointer' }}
          >
            Annuler
          </button>
          <button
            onClick={handleSave}
            disabled={!canSave}
            style={{
              flex: 1, minHeight: '48px', borderRadius: '999px', border: 'none', fontFamily: 'inherit',
              background: canSave ? 'linear-gradient(90deg, #ff3366, #ff69b4)' : 'rgba(255,51,102,0.3)',
              color: '#fff', fontWeight: 700, fontSize: '0.88rem',
              cursor: canSave ? 'pointer' : 'default',
            }}
          >
            {saving ? '⏳' : 'Ajouter'}
          </button>
        </div>
      </div>
    </div>
  );
}