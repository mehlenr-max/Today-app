import React, { useState } from 'react';
import OptimizedImage from './OptimizedImage';

/**
 * Avatar partagé : rend une photo circulaire avec fallback automatique vers
 * les initiales (première lettre du nom) si l'URL est absente ou cassée (404, etc.).
 *
 * Props :
 *  - photoUrl : URL de la photo (peut être null/undefined/vide)
 *  - name     : display_name utilisé pour l'initiale
 *  - size     : taille en px (défaut 40)
 *  - shape    : 'circle' (défaut) | 'rounded' | 'square'
 *  - style / className / sizes / priority / draggable / onClick : passés au rendu
 */
export default function Avatar({ photoUrl, name, size = 40, shape = 'circle', style, className, sizes, priority, draggable, onClick }) {
  const [errored, setErrored] = useState(false);
  const initial = (name || '?').charAt(0).toUpperCase() || '?';
  const borderRadius = shape === 'circle' ? '50%' : shape === 'rounded' ? '14px' : '0';

  const baseStyle = {
    width: size,
    height: size,
    borderRadius,
    flexShrink: 0,
    ...style,
  };

  // Pas de photo OU image en erreur → placeholder initiales
  if (!photoUrl || errored) {
    return (
      <div
        className={className}
        onClick={onClick}
        style={{
          ...baseStyle,
          background: 'rgba(255,51,102,0.15)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: `${Math.round(size * 0.42)}px`,
          fontWeight: 800,
          color: '#ff69b4',
          border: '1.5px solid rgba(255,51,102,0.35)',
        }}
      >
        {initial}
      </div>
    );
  }

  return (
    <OptimizedImage
      src={photoUrl}
      alt={name || ''}
      sizes={sizes || `${size}px`}
      priority={priority}
      draggable={draggable}
      onClick={onClick}
      className={className}
      style={{ ...baseStyle, objectFit: 'cover' }}
      onError={() => setErrored(true)}
    />
  );
}