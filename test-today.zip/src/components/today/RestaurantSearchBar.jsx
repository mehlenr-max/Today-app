import React, { useState } from 'react';
import { Search } from 'lucide-react';

export default function RestaurantSearchBar() {
  const [query, setQuery] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const value = query.trim();
    if (!value) return;
    window.open(`https://www.google.com/search?q=${encodeURIComponent(value)}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        display: 'flex', alignItems: 'center', gap: '8px',
        padding: '6px 8px 6px 14px', borderRadius: '999px',
        background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.12)',
      }}
    >
      <Search size={17} color="#9f9fae" style={{ flexShrink: 0 }} />
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Chercher un autre restaurant sur Google…"
        aria-label="Rechercher un autre restaurant sur Google"
        style={{
          flex: 1, minWidth: 0, background: 'transparent', border: 'none', outline: 'none',
          color: '#fff', fontFamily: 'inherit', fontSize: '16px', padding: '9px 0',
        }}
      />
      <button
        type="submit"
        disabled={!query.trim()}
        style={{
          flexShrink: 0, border: 'none', cursor: query.trim() ? 'pointer' : 'default',
          padding: '9px 16px', borderRadius: '999px',
          background: query.trim() ? 'linear-gradient(135deg, #ff3366, #ff69b4)' : 'rgba(255,255,255,0.08)',
          color: query.trim() ? '#fff' : '#6f6f7e',
          fontSize: '0.78rem', fontWeight: 700, fontFamily: 'inherit',
          boxShadow: query.trim() ? '0 8px 20px rgba(255,51,102,0.25)' : 'none',
          transition: 'all 0.2s ease',
        }}
      >
        Google
      </button>
    </form>
  );
}