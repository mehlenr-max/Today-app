import React, { useState, useEffect } from 'react';
import { getMidnightCountdown } from '../../lib/today-data';

export default function CountdownBanner() {
  const [time, setTime] = useState(getMidnightCountdown());

  useEffect(() => {
    const id = setInterval(() => setTime(getMidnightCountdown()), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      borderRadius: '999px',
      padding: '8px 14px',
      background: 'rgba(15,15,19,0.78)',
      border: '1px solid rgba(255,51,102,0.18)',
      backdropFilter: 'blur(16px)',
      boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.04)',
    }}>
      <span style={{
        width: 8, height: 8, borderRadius: '50%',
        background: 'linear-gradient(180deg, #ff69b4, #ff3366)',
        boxShadow: '0 0 0 6px rgba(255,51,102,0.12)',
        animation: 'pulse 1.8s infinite',
        flexShrink: 0,
        display: 'inline-block',
      }} />
      <span style={{ fontSize: '0.9rem', fontWeight: 800, letterSpacing: '0.04em', color: '#fff', fontVariantNumeric: 'tabular-nums' }}>
        {time}
      </span>
    </div>
  );
}