import React, { useState } from 'react';

/**
 * Modale de confirmation pour annuler un date confirmé.
 */
export default function CancelDateConfirmModal({ profileName, willBlock = false, onConfirm, onClose }) {
  const [cancelling, setCancelling] = useState(false);

  async function handleConfirm() {
    if (cancelling) return;
    setCancelling(true);
    try {
      await onConfirm();
    } finally {
      setCancelling(false);
    }
  }

  return (
    <div
      onClick={() => !cancelling && onClose()}
      style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}
    >
      <div onClick={e => e.stopPropagation()} style={{ maxWidth: '320px', width: '100%', background: 'rgba(15,15,19,0.98)', border: '1px solid rgba(255,51,102,0.3)', borderRadius: '20px', padding: '24px 20px', textAlign: 'center', boxShadow: '0 0 40px rgba(255,51,102,0.2)' }}>
        <div style={{ fontSize: '2.2rem', marginBottom: '10px' }}>💔</div>
        <h3 style={{ margin: '0 0 8px', fontSize: '1.05rem', fontWeight: 800, color: '#fff' }}>Annuler le date avec {profileName} ?</h3>
        <p style={{ margin: `0 0 ${willBlock ? '12px' : '20px'}`, color: '#9f9fae', fontSize: '0.82rem', lineHeight: 1.5 }}>
          Cette action est définitive. {profileName} en sera informé(e) et le rendez-vous sera annulé pour vous deux.
        </p>
        {willBlock && (
          <p style={{ margin: '0 0 20px', color: '#ff6a7c', fontSize: '0.82rem', fontWeight: 700, lineHeight: 1.5 }}>
            ⚠️ Tu ne pourras plus dater jusqu'à minuit si tu annules.
          </p>
        )}
        <div style={{ display: 'flex', gap: '10px' }}>
          <button onClick={onClose} disabled={cancelling} style={{ flex: 1, padding: '11px', borderRadius: '12px', fontWeight: 600, fontSize: '0.88rem', border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.05)', color: '#9f9fae', cursor: 'pointer', fontFamily: 'inherit' }}>
            Garder le date
          </button>
          <button
            disabled={cancelling}
            onClick={handleConfirm}
            style={{ flex: 1, padding: '11px', borderRadius: '12px', fontWeight: 700, fontSize: '0.88rem', border: '1px solid rgba(255,51,102,0.4)', background: 'rgba(255,51,102,0.15)', color: '#ff6a7c', cursor: 'pointer', fontFamily: 'inherit' }}
          >
            {cancelling ? '⏳…' : 'Oui, annuler'}
          </button>
        </div>
      </div>
    </div>
  );
}