import React from 'react';

/**
 * Modale de confirmation pour bloquer un profil.
 */
export default function BlockProfileConfirmModal({ profileName, onConfirm, onClose }) {
  return (
    <div
      onClick={onClose}
      style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}
    >
      <div onClick={e => e.stopPropagation()} style={{ maxWidth: '320px', width: '100%', background: 'rgba(15,15,19,0.98)', border: '1px solid rgba(255,51,102,0.3)', borderRadius: '20px', padding: '24px 20px', textAlign: 'center', boxShadow: '0 0 40px rgba(255,51,102,0.2)' }}>
        <div style={{ fontSize: '2.2rem', marginBottom: '10px' }}>🚫</div>
        <h3 style={{ margin: '0 0 8px', fontSize: '1.05rem', fontWeight: 800, color: '#fff' }}>Bloquer {profileName} ?</h3>
        <p style={{ margin: '0 0 20px', color: '#9f9fae', fontSize: '0.82rem', lineHeight: 1.5 }}>
          {profileName} n'apparaîtra plus dans ton deck et ses défis seront ignorés.
        </p>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button onClick={onClose} style={{ flex: 1, padding: '11px', borderRadius: '12px', fontWeight: 600, fontSize: '0.88rem', border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.05)', color: '#9f9fae', cursor: 'pointer', fontFamily: 'inherit' }}>
            Annuler
          </button>
          <button
            onClick={onConfirm}
            style={{ flex: 1, padding: '11px', borderRadius: '12px', fontWeight: 700, fontSize: '0.88rem', border: '1px solid rgba(255,51,102,0.4)', background: 'rgba(255,51,102,0.15)', color: '#ff6a7c', cursor: 'pointer', fontFamily: 'inherit' }}
          >
            Bloquer
          </button>
        </div>
      </div>
    </div>
  );
}