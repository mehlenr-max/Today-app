import React from 'react';
import { motion } from 'framer-motion';

const SECTIONS = [
  {
    icon: '🌅',
    title: 'Le concept',
    text: "Une app de rencontre minimaliste, active uniquement le jeudi et le samedi. L'objectif : organiser un date le soir même, pas accumuler des matchs.",
  },
  {
    icon: '🔥',
    title: 'Le rythme',
    text: "Tu défies les profils qui te plaisent. Si la personne accepte et joue, c'est un match. Le but : se voir le soir même.",
  },
  {
    icon: '📊',
    title: 'Les scores de compatibilité',
    items: [
      '💪 Physique',
      '🌙 Astrologique',
      '✨ Personnalité',
    ],
    note: "L'œil te permet de voir ces scores ainsi que d'autres infos sur le profil.",
  },
  {
    icon: '🎲',
    title: 'Les jeux',
    items: [
      'Pierre-Papier-Ciseaux pour les défis',
      "This or That ou Je n'ai jamais pour mieux se connaître",
      'Le gage : envoyé une fois le date confirmé, à réaliser pendant la rencontre',
    ],
  },
  {
    icon: '🛡️',
    title: 'Sécurité & modération',
    items: [
      'Photos vérifiées (visage détecté + filtre NSFW). Maximum 3 changements de photos tous les 3 jours.',
      'Signalements : masquage automatique dès le 2e signalement.',
      'Blocage de profils possible.',
      'Suppression de compte disponible.',
    ],
  },
  {
    icon: '⭐',
    title: 'Règles d\'or',
    items: [
      'Un seul date accepté par jour',
      'Profil complet obligatoire pour pouvoir proposer ou accepter un date',
      "Tu peux t'inscrire et consulter les profils toute la semaine, mais le bouton Défier ne s'active que le jeudi et le samedi",
    ],
  },
];

export default function WelcomeOnboarding({ onDone }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      background: 'radial-gradient(circle at 16% 16%, rgba(255,51,102,0.22) 0%, transparent 24%), radial-gradient(circle at 86% 18%, rgba(255,105,180,0.14) 0%, transparent 22%), linear-gradient(180deg, #070709 0%, #040405 42%, #030304 100%)',
      color: '#fff', fontFamily: "'Poppins', sans-serif",
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
    }}>
      <div style={{ flexShrink: 0, padding: 'calc(env(safe-area-inset-top) + 16px) 20px 12px', textAlign: 'center' }}>
        <img src="https://media.base44.com/images/public/69b91874189d1f38a8e07d5f/13012b7bc_image_19ee64c32.jpg" alt="ToDay" style={{ height: '48px', objectFit: 'contain', mixBlendMode: 'screen', margin: '0 auto 8px' }} />
        <h1 style={{ fontSize: '1.6rem', fontWeight: 900, fontStyle: 'italic', fontFamily: "'EB Garamond', serif", margin: 0, background: 'linear-gradient(90deg, #ff69b4, #e879f9, #ff69b4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
          Bienvenue sur ToDay
        </h1>
        <p style={{ color: '#9f9fae', fontSize: '0.85rem', margin: '4px 0 0' }}>
          Crée ton profil → Publie ton date → Défie quelqu'un → Accepte un défi reçu
        </p>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', padding: '8px 20px 24px', WebkitOverflowScrolling: 'touch' }}>
        {SECTIONS.map((s, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: i * 0.05 }}
            style={{
              marginBottom: '14px',
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: '16px',
              padding: '14px 16px',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <span style={{ fontSize: '1.3rem' }}>{s.icon}</span>
              <h2 style={{ margin: 0, fontSize: '1rem', fontWeight: 800, color: '#ff69b4' }}>{s.title}</h2>
            </div>
            {s.text && (
              <p style={{ margin: '0 0 6px', color: '#cfcfda', fontSize: '0.84rem', lineHeight: 1.5 }}>{s.text}</p>
            )}
            {s.items && (
              <ul style={{ margin: 0, paddingLeft: '18px', color: '#cfcfda', fontSize: '0.84rem', lineHeight: 1.5 }}>
                {s.items.map((it, j) => <li key={j} style={{ marginBottom: '4px' }}>{it}</li>)}
              </ul>
            )}
            {s.note && (
              <p style={{ margin: '8px 0 0', color: '#9f9fae', fontSize: '0.78rem', fontStyle: 'italic' }}>{s.note}</p>
            )}
          </motion.div>
        ))}
      </div>

      <div style={{ flexShrink: 0, padding: '12px 20px calc(env(safe-area-inset-bottom) + 16px)' }}>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={onDone}
          style={{
            width: '100%', minHeight: '52px', borderRadius: '999px',
            fontWeight: 700, fontSize: '1rem', fontFamily: 'inherit',
            background: 'linear-gradient(90deg, #ff3366, #ff69b4)',
            color: '#fff', border: 'none', cursor: 'pointer',
            boxShadow: '0 12px 24px rgba(255,51,102,0.22)',
          }}
        >
          J'ai compris →
        </motion.button>
      </div>
    </div>
  );
}