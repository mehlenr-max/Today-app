import React, { useState } from 'react';
import { motion } from 'framer-motion';

export default function QuizAnswerModal({ questions, gameType, askerName, onClose, onSend }) {
  const [answers, setAnswers] = useState(questions.map(() => ''));
  const [sending, setSending] = useState(false);

  function setAnswer(idx, val) {
    setAnswers(prev => {
      const next = [...prev];
      next[idx] = next[idx] === val ? '' : val;
      return next;
    });
  }

  function handleSend() {
    const hasAtLeastOne = answers.some(a => a);
    if (!hasAtLeastOne || sending) return;
    setSending(true);
    onSend(answers);
  }

  const hasAtLeastOne = answers.some(a => a);
  const canSend = hasAtLeastOne && !sending;
  const gameLabel = gameType === 'thisOrThat' ? 'This or That ⚡' : gameType === 'nhie' ? "Je n'ai jamais 🤫" : 'Jeu';

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        transition={{ type: 'spring', damping: 28, stiffness: 280 }}
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: '500px',
          background: 'rgba(15,15,19,0.98)',
          border: '1px solid rgba(255,51,102,0.2)',
          borderRadius: '24px 24px 0 0',
          padding: '20px 16px 24px',
          maxHeight: '85vh', overflowY: 'auto',
        }}
      >
        <div style={{ width: 44, height: 5, borderRadius: '999px', background: 'rgba(255,255,255,0.18)', margin: '0 auto 16px' }} />

        <h3 style={{ textAlign: 'center', color: '#ff3366', fontSize: '1.2rem', margin: '0 0 6px', fontWeight: 800 }}>
          {gameLabel}
        </h3>
        <p style={{ textAlign: 'center', color: '#9f9fae', fontSize: '0.82rem', margin: '0 0 18px' }}>
          {askerName || 'Ce profil'} t'a défié(e). Choisis ta réponse (tu peux passer).
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginBottom: 20 }}>
          {questions.map((q, idx) => {
            const val = answers[idx];
            return (
              <div key={idx}>
                {gameType === 'thisOrThat' ? (
                  <>
                    <p style={{ fontSize: '0.82rem', color: '#cfcfda', margin: '0 0 8px', textAlign: 'center' }}>
                      <span style={{ color: '#ff69b4', fontWeight: 700 }}>{idx + 1}.</span> {q.a} ou {q.b} ?
                    </p>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button
                        onClick={() => setAnswer(idx, 'a')}
                        style={{
                          flex: 1, minHeight: 44, borderRadius: '12px',
                          background: val === 'a' ? 'rgba(255,51,102,0.2)' : 'rgba(255,255,255,0.04)',
                          border: `1.5px solid ${val === 'a' ? 'rgba(255,51,102,0.5)' : 'rgba(255,255,255,0.08)'}`,
                          color: val === 'a' ? '#ff69b4' : '#cfcfda', fontSize: '0.88rem', fontWeight: 600,
                          cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.12s ease',
                        }}
                      >{q.a}</button>
                      <button
                        onClick={() => setAnswer(idx, 'b')}
                        style={{
                          flex: 1, minHeight: 44, borderRadius: '12px',
                          background: val === 'b' ? 'rgba(255,51,102,0.2)' : 'rgba(255,255,255,0.04)',
                          border: `1.5px solid ${val === 'b' ? 'rgba(255,51,102,0.5)' : 'rgba(255,255,255,0.08)'}`,
                          color: val === 'b' ? '#ff69b4' : '#cfcfda', fontSize: '0.88rem', fontWeight: 600,
                          cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.12s ease',
                        }}
                      >{q.b}</button>
                    </div>
                  </>
                ) : gameType === 'nhie' ? (
                  <>
                    <p style={{ fontSize: '0.82rem', color: '#cfcfda', margin: '0 0 8px', textAlign: 'center' }}>
                      <span style={{ color: '#ff69b4', fontWeight: 700 }}>{idx + 1}.</span> Je n'ai jamais <strong style={{ color: '#fff' }}>{q.text}</strong>
                    </p>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button
                        onClick={() => setAnswer(idx, 'deja')}
                        style={{
                          flex: 1, minHeight: 44, borderRadius: '12px',
                          background: val === 'deja' ? 'rgba(34,197,94,0.2)' : 'rgba(255,255,255,0.04)',
                          border: `1.5px solid ${val === 'deja' ? 'rgba(34,197,94,0.5)' : 'rgba(255,255,255,0.08)'}`,
                          color: val === 'deja' ? '#22c55e' : '#cfcfda', fontSize: '0.88rem', fontWeight: 600,
                          cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.12s ease',
                        }}
                      >✅ Vrai</button>
                      <button
                        onClick={() => setAnswer(idx, 'jamais')}
                        style={{
                          flex: 1, minHeight: 44, borderRadius: '12px',
                          background: val === 'jamais' ? 'rgba(255,51,102,0.2)' : 'rgba(255,255,255,0.04)',
                          border: `1.5px solid ${val === 'jamais' ? 'rgba(255,51,102,0.5)' : 'rgba(255,255,255,0.08)'}`,
                          color: val === 'jamais' ? '#ff69b4' : '#cfcfda', fontSize: '0.88rem', fontWeight: 600,
                          cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.12s ease',
                        }}
                      >🚫 Faux</button>
                    </div>
                  </>
                ) : (
                  <input
                    type="text"
                    value={val}
                    onChange={e => setAnswer(idx, e.target.value)}
                    placeholder="Ta réponse…"
                    style={{
                      width: '100%', padding: '10px 12px', borderRadius: '10px',
                      background: 'rgba(255,255,255,0.04)',
                      border: '1.5px solid rgba(255,255,255,0.08)',
                      color: '#fff', fontSize: '0.85rem', fontFamily: 'inherit', outline: 0,
                    }}
                  />
                )}
              </div>
            );
          })}
        </div>

        <button
          onClick={handleSend}
          disabled={!canSend}
          style={{
            width: '100%', minHeight: '50px', borderRadius: '999px',
            fontWeight: 700, fontSize: '0.95rem', fontFamily: 'inherit',
            background: canSend ? 'linear-gradient(90deg, #ff3366, #ff69b4)' : 'rgba(255,255,255,0.06)',
            color: canSend ? '#fff' : '#555',
            border: 'none',
            cursor: canSend ? 'pointer' : 'default',
            boxShadow: canSend ? '0 8px 20px rgba(255,51,102,0.22)' : 'none',
            transition: 'all 0.12s ease',
          }}
        >
          {sending ? '⏳ Envoi…' : 'Envoyer mes réponses ✉️'}
        </button>
        <button
          onClick={onClose}
          disabled={sending}
          style={{ width: '100%', marginTop: 8, background: 'none', border: 'none', color: '#9f9fae', fontSize: '0.88rem', cursor: 'pointer', fontFamily: 'inherit', padding: '10px' }}
        >
          Annuler
        </button>
      </motion.div>
    </div>
  );
}