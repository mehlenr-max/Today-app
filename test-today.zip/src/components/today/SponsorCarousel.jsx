import React, { useEffect, useRef, useState } from 'react';

const AUTO_MS = 3000;

export default function SponsorCarousel({ sponsors }) {
  const scrollerRef = useRef(null);
  const animatingRef = useRef(false);
  const pausedRef = useRef(false);
  const [index, setIndex] = useState(0);
  const count = sponsors.length;

  useEffect(() => {
    if (count <= 1) return;
    const id = setInterval(() => {
      if (pausedRef.current) return;
      setIndex(prev => (prev + 1) % count);
    }, AUTO_MS);
    return () => clearInterval(id);
  }, [count]);

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    animatingRef.current = true;
    el.scrollTo({ left: index * el.clientWidth, behavior: 'smooth' });
    const t = setTimeout(() => { animatingRef.current = false; }, 700);
    return () => clearTimeout(t);
  }, [index, count]);

  const handleScroll = () => {
    if (animatingRef.current) return;
    const el = scrollerRef.current;
    if (!el) return;
    const i = Math.round(el.scrollLeft / Math.max(1, el.clientWidth));
    if (i !== index && i >= 0 && i < count) setIndex(i);
  };

  const openSponsor = (sponsor) => {
    if (!sponsor.resa_url) return;
    window.open(sponsor.resa_url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <div
        ref={scrollerRef}
        onScroll={handleScroll}
        onTouchStart={() => { pausedRef.current = true; }}
        onTouchEnd={() => { setTimeout(() => { pausedRef.current = false; }, 4000); }}
        onMouseEnter={() => { pausedRef.current = true; }}
        onMouseLeave={() => { pausedRef.current = false; }}
        style={{
          display: 'flex', overflowX: 'auto', scrollSnapType: 'x mandatory',
          scrollbarWidth: 'none', msOverflowStyle: 'none', WebkitOverflowScrolling: 'touch',
        }}
      >
        {sponsors.map(s => (
          <div key={s.id} style={{ flex: '0 0 100%', scrollSnapAlign: 'center', padding: '0 1px' }}>
            <div
              role={s.resa_url ? 'link' : undefined}
              onClick={() => openSponsor(s)}
              style={{
                borderRadius: '22px', overflow: 'hidden', position: 'relative',
                background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
                cursor: s.resa_url ? 'pointer' : 'default',
              }}
            >
              {s.photo_url && (
                <img
                  src={s.photo_url}
                  alt={s.name}
                  loading="lazy"
                  style={{ width: '100%', aspectRatio: '16 / 10', objectFit: 'cover', display: 'block', background: 'rgba(255,255,255,0.05)' }}
                />
              )}
              <div style={{ padding: '14px 16px 16px', display: 'flex', flexDirection: 'column', gap: '7px' }}>
                <div style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, fontSize: '1.2rem', color: '#fff' }}>
                  {s.name}
                </div>
                {s.description && (
                  <div style={{ fontSize: '0.82rem', color: '#9f9fae', lineHeight: 1.5 }}>{s.description}</div>
                )}
                {s.address && (
                  <div style={{ fontSize: '0.74rem', color: '#6f6f7e' }}>📍 {s.address}</div>
                )}
                {Array.isArray(s.cities) && s.cities.length > 0 && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '2px' }}>
                    {s.cities.map(c => (
                      <span key={c} style={{ padding: '3px 9px', borderRadius: '999px', background: 'rgba(255,51,102,0.1)', border: '1px solid rgba(255,51,102,0.22)', color: '#ff9ec1', fontSize: '0.66rem', fontWeight: 700 }}>
                        {c}
                      </span>
                    ))}
                  </div>
                )}
                {s.resa_url && (
                  <div style={{
                    marginTop: '8px', textAlign: 'center', padding: '11px 16px', borderRadius: '999px',
                    background: 'linear-gradient(135deg, #ff3366, #ff69b4)', color: '#fff',
                    fontSize: '0.85rem', fontWeight: 700,
                    boxShadow: '0 8px 20px rgba(255,51,102,0.25)',
                  }}>
                    Réserver
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {count > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: '5px' }}>
          {sponsors.map((s, i) => (
            <button
              key={s.id}
              onClick={() => setIndex(i)}
              aria-label={`Voir ${s.name}`}
              style={{
                width: i === index ? '18px' : '6px', height: '6px', borderRadius: '999px', border: 'none',
                padding: 0, cursor: 'pointer', transition: 'all 0.25s ease',
                background: i === index ? '#ff3366' : 'rgba(255,255,255,0.22)',
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}