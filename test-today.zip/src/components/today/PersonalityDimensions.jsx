import React from 'react';

// Affichage seul : les compatibilités par dimension sont calculées une fois
// par getPersonalityCompatibility (src/lib/scoring.js) et passées ici.
function compatColor(value) {
  if (value >= 70) return '#34d399';
  if (value >= 45) return '#f4c162';
  return '#ff6a7c';
}

export default function PersonalityDimensions({ dimensions }) {
  if (!Array.isArray(dimensions) || dimensions.length === 0) return null;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      {dimensions.map(({ key, label, value }) => {
        const color = compatColor(value);
        return (
          <div key={key}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
              <span style={{ color: '#ff69b4', fontSize: '0.78rem', fontWeight: 700 }}>{label}</span>
              <span style={{ color, fontSize: '0.72rem', fontWeight: 800 }}>{value}%</span>
            </div>
            <div style={{ height: 6, borderRadius: '999px', background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
              <div
                style={{
                  width: `${value}%`,
                  height: '100%',
                  borderRadius: '999px',
                  background: `linear-gradient(90deg, ${color}88, ${color})`,
                  transition: 'width 0.3s ease',
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}