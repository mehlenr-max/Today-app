import React, { useState, useCallback, useEffect } from 'react';
import SkeletonLoader from './SkeletonLoader';
import { getDistanceKm, getParisDateKey, getParisDateKeyFromDate } from '../../lib/today-data';
import RpsFlow from './RpsFlow';
import BlockedProfilesModal from './BlockedProfilesModal';
import { MapPin, Ban } from 'lucide-react';
import { fetchFullProfile } from '../../lib/profile-fetch';

const EDUCATION_LABELS = {
  lycee: 'Secondaire', bts: 'École supérieure / Technique', licence: 'Licence / Bachelor',
  master: 'Master / Grande école', doctorat: 'Doctorat', autodidacte: 'Autodidacte'
};
const JOB_LABELS = {
  etudiant: '🎒 Étudiant·e', salarie: '💼 Salarié·e', entrepreneur: '🚀 Entrepreneur·e',
  freelance: '💻 Freelance', artistique: '🎨 Artiste / Créatif·ve', sante: '🏥 Santé',
  enseignement: '📖 Enseignement', tech: '⚙️ Ingénieur·e / Tech',
  commerce: '📈 Commerce / Finance', sans_emploi: '🌿 Sans emploi', horeca: '🍽️ Horeca'
};
import OptimizedImage from './OptimizedImage';
import Avatar from './Avatar';
import { base44 } from '../../api/base44Client';
import { translate } from '@/lib/i18n/engine';
import ProfileViewModal from './ProfileViewModal';
import QuizModal from './QuizModal';
import { GAME_LIST } from '../../lib/quiz-questions';
import { getUnavailableGameTypes, markGameProposed } from '../../lib/quiz-usage';
import useQuizUsageVersion from '../../hooks/useQuizUsageVersion';
import useProfilesMap from '../../hooks/useProfilesMap';
import useOverlayBack from '../../hooks/useOverlayBack';
import PullToRefresh from './PullToRefresh';
import toast from 'react-hot-toast';
import { globalScoreToLabel } from '../../lib/compat-labels';
import { getMidnightCountdown } from '../../lib/today-data';
import useChallengeWindow from '../../hooks/useChallengeWindow';
import ChallengeWindowBanner from './ChallengeWindowBanner';
import PersonalityGate from './PersonalityGate';

function CountdownUntilMidnight() {
  const [t, setT] = useState(getMidnightCountdown());
  useEffect(() => {
    const id = setInterval(() => setT(getMidnightCountdown()), 1000);
    return () => clearInterval(id);
  }, []);
  return <strong style={{ color: '#ff69b4' }}>{t}</strong>;
}

function formatDisplayName(name) {
  if (!name) return '';
  return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
}

// Date du dernier défi pierre-papier-ciseaux envoyé à ce profil.
// Uniquement les défis RPS — pas les jeux/quiz (PRD : "Défié le" = défi envoyé).
function getLastChallengeDate(challengeDates, profileId) {
  if (!challengeDates || !profileId) return null;
  return challengeDates[String(profileId)] || null;
}

function formatChallengeDate(isoDate) {
  if (!isoDate) return '';
  const d = new Date(isoDate);
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yy = String(d.getFullYear()).slice(-2);
  return `${dd}/${mm}/${yy}`;
}

function ageMatchesRange(age, ageRange) {
  const ranges = Array.isArray(ageRange) ? ageRange : (typeof ageRange === 'string' ? ageRange.split('|').filter(Boolean) : []);
  if (!ranges.length) return true;
  return ranges.some(r => {
    if (r === '18-25') return age >= 18 && age <= 25;
    if (r === '25-35') return age >= 25 && age <= 35;
    if (r === '35-45') return age >= 35 && age <= 45;
    if (r === '45+') return age >= 45;
    return false;
  });
}

function distanceMatchesRange(distKm, range) {
  if (distKm === null) return false;
  if (range === '0-5') return distKm <= 5;
  if (range === '0-10') return distKm <= 10;
  if (range === '0-20') return distKm <= 20;
  if (range === '20+') return true; // toute distance acceptée
  return true;
}

function formatLastSeen(isoDate) {
  if (!isoDate) return '';
  const diff = Date.now() - new Date(isoDate).getTime();
  if (diff < 0) return "à l'instant";
  const min = Math.floor(diff / 60000);
  if (min < 1) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `il y a ${h}h`;
  const d = Math.floor(h / 24);
  if (d < 7) return `il y a ${d}j`;
  return new Date(isoDate).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' });
}

function FlashOverlay({ flash }) {
  if (!flash) return null;
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      background: 'white',
      animation: 'flashOut 0.35s ease-out forwards',
      pointerEvents: 'none',
    }} />
  );
}

function ProfileCard({ profile, globalScore, matchScore, cosmicScore, distance, challenged, isIncoming, hasActiveInteraction, challengeBlocked, onChallenge, onFlash, onViewProfile, onTakeQuiz, usedGameTypes, lastChallengeDate }) {
  // Seuls les jeux ENVOYÉS comptent (1 proposition par jeu et par paire sur 30 jours)
  const bothUsed = usedGameTypes.length >= GAME_LIST.length;

  // Hors jeudi/samedi, le bouton Défier reste visible mais non cliquable.
  const challengeDisabled = challenged || isIncoming || hasActiveInteraction || challengeBlocked;

  // Pastille tricolore : calculée sur LE score global unique (physique 50, personnalité 25, astral 25)
  const dotColor = globalScore == null ? null : globalScore >= 70 ? '#22c55e' : globalScore >= 50 ? '#f59e0b' : '#ef4444';

  return (
    <div data-card="" style={{
      borderRadius: '28px', overflow: 'hidden',
      background: 'rgba(15,15,19,0.92)',
      border: '1px solid rgba(255,255,255,0.08)',
      boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
      width: '100%',
    }}>
      {/* Photo */}
      <div style={{ position: 'relative', width: '100%', aspectRatio: '3/4' }}>
        <OptimizedImage
          src={profile.photo}
          alt={profile.name}
          draggable={false}
          priority={false}
          sizes="(max-width: 600px) 100vw, 600px"
          fallbackName={profile.name}
          style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
        />
        {/* Gradient */}
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.1) 0%, transparent 35%, transparent 55%, rgba(0,0,0,0.85) 100%)' }} />

        {/* Score global */}
        {(() => {
          const lbl = globalScoreToLabel(globalScore);
          if (!lbl) return null;
          return (
            <div style={{ position: 'absolute', top: 14, left: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
              {dotColor && (
                <div title={`Score global : ${globalScore}%`} style={{ width: 14, height: 14, borderRadius: '50%', background: dotColor, border: '2px solid rgba(255,255,255,0.9)', boxShadow: '0 2px 8px rgba(0,0,0,0.35)', flexShrink: 0 }} />
              )}
              <div style={{ padding: '4px 10px', borderRadius: '999px', background: 'rgba(0,0,0,0.25)', backdropFilter: 'blur(8px)', color: 'rgba(255,255,255,0.7)', fontWeight: 600, fontSize: '0.72rem', border: '1px solid rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', gap: 3, whiteSpace: 'nowrap' }}>
                <span>{lbl.emoji}</span> {lbl.label}
              </div>
            </div>
          );
        })()}
        {/* Badges haut droite : admin + défi reçu + dernière connexion */}
        <div style={{ position: 'absolute', top: 14, right: 14, display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-end', zIndex: 4 }}>
          {profile.is_admin && (
            <div style={{ padding: '4px 11px', borderRadius: '999px', background: 'rgba(0,0,0,0.8)', color: '#ff2d2d', fontWeight: 800, fontSize: '0.68rem', letterSpacing: '0.12em', textTransform: 'uppercase', border: '1px solid #ff2d2d', whiteSpace: 'nowrap' }}>
              admin
            </div>
          )}
          {isIncoming && (
            <div style={{ padding: '5px 13px', borderRadius: '999px', background: 'rgba(244,193,98,0.92)', color: '#1a1a1a', fontWeight: 700, fontSize: '0.78rem' }}>
              🎮 Défi reçu
            </div>
          )}
          {profile.last_online_date && (
            <div style={{ padding: '4px 11px', borderRadius: '999px', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', color: '#d4d4d8', fontWeight: 600, fontSize: '0.68rem', border: '1px solid rgba(255,255,255,0.12)', whiteSpace: 'nowrap' }}>
              🕐 {formatLastSeen(profile.last_online_date)}
            </div>
          )}
          {profile.is_vegetarian && (
            <div style={{ padding: '4px 11px', borderRadius: '999px', background: 'rgba(34,197,94,0.85)', color: '#fff', fontWeight: 700, fontSize: '0.68rem', border: '1px solid rgba(255,255,255,0.2)', whiteSpace: 'nowrap' }}>
              🥬 Végétarien
            </div>
          )}
        </div>

        {/* Info sur photo */}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '16px 18px 18px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <h3
              style={{ margin: 0, fontSize: '2rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, lineHeight: 1.1, color: '#fff', minWidth: 0, flex: '1 1 auto', wordBreak: 'break-word' }}
            >
              {formatDisplayName(profile.name)}, {profile.age}
            </h3>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'rgba(255,255,255,0.8)', fontSize: '0.78rem', textTransform: 'uppercase', letterSpacing: '0.09em' }}>
            <MapPin size={10} />
            {profile.city}{distance !== null ? ` · ${Math.round(distance)} km` : ''}
          </div>
          {(profile.education || profile.job) && (
             <div style={{ display: 'flex', gap: 8, marginTop: 4, flexWrap: 'wrap' }}>
               {profile.education && (
                 <span style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.6)', fontWeight: 500 }}>
                   🎓 {EDUCATION_LABELS[profile.education] || profile.education}
                 </span>
               )}
               {profile.job && (
                 <span style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.6)', fontWeight: 500 }}>
                   💼 {JOB_LABELS[profile.job] || profile.job}
                 </span>
               )}
             </div>
           )}

           <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 8 }}>
           <button
             onClick={onViewProfile}
             style={{ background: 'rgba(0,0,0,0.45)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.18)', borderRadius: '999px', width: 30, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: '0.95rem', lineHeight: 1, padding: 0, color: '#fff', flexShrink: 0 }}
             title="Voir le profil"
           >
             👁
           </button>
           <button
             onClick={() => {
               if (isIncoming) { alert(translate(`${profile.name} t'a déjà envoyé un défi ! Réponds dans tes messages.`)); return; }
               if (!bothUsed) onTakeQuiz(profile, usedGameTypes);
             }}
             disabled={bothUsed || isIncoming}
             style={{
               padding: '7px 14px', borderRadius: '999px',
               background: (bothUsed || isIncoming) ? 'rgba(255,255,255,0.06)' : 'rgba(255,51,102,0.18)',
               border: `1px solid ${(bothUsed || isIncoming) ? 'rgba(255,255,255,0.1)' : 'rgba(255,51,102,0.35)'}`,
               color: (bothUsed || isIncoming) ? '#6b6b7b' : '#ff69b4', fontSize: '0.72rem', fontWeight: 600,
               cursor: (bothUsed || isIncoming) ? 'default' : 'pointer', fontFamily: 'inherit',
               display: 'inline-flex', alignItems: 'center', gap: 5,
               opacity: (bothUsed || isIncoming) ? 0.5 : 1,
             }}
           >
             {isIncoming ? '🎮 Défi reçu' : bothUsed ? 'Game over' : usedGameTypes.length === 1 ? '1/2 jeux envoyés' : '🎮 Jouer'}
           </button>
             {lastChallengeDate && (
             <div style={{ marginLeft: 'auto', padding: '4px 11px', borderRadius: '999px', background: 'rgba(255,51,102,0.15)', backdropFilter: 'blur(6px)', color: 'rgba(255,209,222,0.85)', fontWeight: 600, fontSize: '0.68rem', border: '1px solid rgba(255,51,102,0.15)', whiteSpace: 'nowrap' }}>
               🎮 Défié le {formatChallengeDate(lastChallengeDate)}
             </div>
             )}
             </div>
           </div>
           </div>

      {/* Bouton */}
      <div style={{ display: 'flex', gap: 12, padding: '16px' }}>
        <button
          onClick={() => { if (!challengeDisabled) { onFlash(); onChallenge(profile); } }}
          disabled={challengeDisabled}
          style={{
            flex: 1, minHeight: 54, borderRadius: '16px', fontWeight: 700, fontSize: '1rem',
            fontFamily: 'inherit', cursor: challengeDisabled ? 'default' : 'pointer', border: 'none',
            background: challengeDisabled ? 'rgba(255,255,255,0.05)' : 'linear-gradient(90deg, #ff3366, #ff69b4)',
            color: challengeDisabled ? '#9f9fae' : '#fff',
            opacity: challengeDisabled ? 0.6 : 1,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            boxShadow: challengeDisabled ? 'none' : '0 8px 20px rgba(255,51,102,0.25)',
            transition: 'all 0.1s ease',
          }}
          onPointerDown={e => { if (!challengeDisabled) { e.currentTarget.style.transform = 'scale(0.96)'; e.currentTarget.style.filter = 'brightness(1.2)'; }}}
          onPointerUp={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; }}
          onPointerLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; }}
        >
          {isIncoming ? '🎮 Défi reçu' : (challenged || hasActiveInteraction) ? 'Défi envoyé' : '✊ Défier'}
        </button>
      </div>


    </div>
  );
}

function RpsModal({ profile, onClose, onSend }) {
  useOverlayBack(true, onClose);
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'flex-end', zIndex: 100 }} onClick={onClose}>
      <div style={{ width: '100%', background: 'rgba(12,12,16,0.96)', borderTop: '1px solid rgba(255,255,255,0.08)', borderRadius: '28px 28px 0 0', padding: '20px', backdropFilter: 'blur(18px)' }} onClick={e => e.stopPropagation()}>
        <div style={{ width: 44, height: 5, borderRadius: '999px', background: 'rgba(255,255,255,0.18)', margin: '0 auto 16px' }} />
        <h3 style={{ textAlign: 'center', color: '#ff3366', fontSize: '1.28rem', margin: '0 0 8px' }}>Défier {profile.name}</h3>
        <p style={{ textAlign: 'center', color: '#9f9fae', fontSize: '0.88rem', margin: '0 0 16px', lineHeight: 1.5 }}>
          Envoie un défi pierre-papier-ciseaux. Si {profile.name} joue, c'est un match.
        </p>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', background: 'rgba(255,255,255,0.03)', borderRadius: '18px', padding: '14px', marginBottom: '16px', border: '1px solid rgba(255,255,255,0.06)' }}>
          <Avatar photoUrl={profile.photo} name={profile.name} size={52} shape="rounded" sizes="52px" />
          <div>
            <div style={{ fontWeight: 700, fontSize: '0.95rem' }}>{profile.name}, {profile.age} ans</div>
            <div style={{ fontSize: '0.8rem', color: '#9f9fae' }}>{profile.city}</div>
          </div>
        </div>
        <p style={{ textAlign: 'center', fontSize: '0.8rem', color: '#9f9fae', marginBottom: '16px' }}>🏆 Le gagnant choisit l'endroit du date.</p>
        <button onClick={onSend} style={{ width: '100%', minHeight: '52px', borderRadius: '999px', fontWeight: 700, fontSize: '1rem', fontFamily: 'inherit', background: 'linear-gradient(90deg, #ff3366, #ff69b4)', color: '#fff', border: 'none', cursor: 'pointer', boxShadow: '0 12px 24px rgba(255,51,102,0.22)' }}>
          Envoyer le défi ✊
        </button>
        <button onClick={onClose} style={{ width: '100%', marginTop: '10px', background: 'none', border: 'none', color: '#9f9fae', fontSize: '0.9rem', cursor: 'pointer', fontFamily: 'inherit', padding: '10px' }}>
          Annuler
        </button>
      </div>
    </div>
  );
}

export default function BrowseTab({ userId, userProfile, prefs, sessionState, isVisible, isCancelledBlock, acceptedCounterpartUserId, candidates, onAddMessage, onRefresh, onRpsBackground, onChallengeSend, onUnblock, incomingFromMessages, activeDateInteractionUserIds, resetToken, isAdmin, onPersonalitySave }) {
  const { profilesMap } = useProfilesMap(userId);
  // L'administrateur peut défier toute la semaine, sans restriction de jour ni d'heure.
  const challengeWindow = useChallengeWindow(isAdmin === true);
  const counterpart = acceptedCounterpartUserId ? profilesMap[acceptedCounterpartUserId] : null;
  const [challengeProfile, setChallengeProfile] = useState(null);
  const [rpsProfile, setRpsProfile] = useState(null);
  const [flash, setFlash] = useState(false);
  const [viewProfile, setViewProfile] = useState(null);
  const [viewProfileLoading, setViewProfileLoading] = useState(false);
  const [viewMatchScore, setViewMatchScore] = useState(null);
  const [viewCosmicScore, setViewCosmicScore] = useState(null);
  const [viewPersonalityScore, setViewPersonalityScore] = useState(null);

  const [localChallengedId, setLocalChallengedId] = useState(null);
  const [showBlockedModal, setShowBlockedModal] = useState(false);
  const [quizProfile, setQuizProfile] = useState(null);
  // Rend ce menu œil immédiatement cohérent quand un jeu est envoyé ailleurs (messages, jeux).
  useQuizUsageVersion();
  const [justSentDates, setJustSentDates] = useState({});

  // Re-tap de l'onglet actif → fermeture des vues imbriquées (fiche profil, quiz en cours)
  useEffect(() => {
    setViewProfile(null);
    setViewProfileLoading(false);
    setViewMatchScore(null);
    setViewCosmicScore(null);
    setViewPersonalityScore(null);
    setQuizProfile(null);
  }, [resetToken]);

  // Les candidats sont désormais fournis pré-scorés par le backend (getBrowseDeck)
  // — personality_profile n'est plus jamais envoyé au client.
  const dbProfiles = candidates || [];

  const triggerFlash = useCallback(() => {
    setFlash(false);
    requestAnimationFrame(() => requestAnimationFrame(() => setFlash(true)));
    setTimeout(() => setFlash(false), 400);
  }, []);

  const isProfileComplete = userProfile && userProfile.display_name && userProfile.age && userProfile.gender && userProfile.photo_url;

  if (!isProfileComplete) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', padding: '24px 24px 30vh', textAlign: 'center' }}>
        <div style={{ fontSize: '3rem', marginBottom: '16px' }}>👤</div>
        <h3 style={{ fontSize: '1.28rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, margin: '0 0 8px' }}>Remplis ta carte d'abord</h3>
        <p style={{ color: '#9f9fae', fontSize: '0.88rem', margin: 0 }}>Configure ton profil dans l'onglet <strong style={{ color: '#ff69b4' }}>Ma carte</strong> pour voir les autres profils.</p>
      </div>
    );
  }

  // Le test de personnalité conditionne l'accès aux profils.
  if (!userProfile?.personality_profile) {
    return <PersonalityGate onSave={onPersonalitySave} />;
  }

  if (userProfile?.accepted_date_key) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', padding: '24px 24px 30vh', textAlign: 'center' }}>
        <div style={{ fontSize: '3rem', marginBottom: '16px' }}>{isCancelledBlock ? '🔒' : '✅'}</div>
        <h3 style={{ fontSize: '1.28rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, margin: '0 0 8px' }}>
          {isCancelledBlock ? 'Tu es bloqué·e' : 'Date acceptée !'}
        </h3>
        {isCancelledBlock ? (
          <p style={{ color: '#9f9fae', fontSize: '0.88rem', margin: 0, lineHeight: 1.5 }}>
            Tu as annulé un date déjà confirmé. Pour éviter les désistements de dernière minute, tu ne peux plus proposer ni accepter de nouveau date aujourd'hui.
            <br /><br />
            ⏳ Blocage jusqu'à minuit <CountdownUntilMidnight />.
          </p>
        ) : (
          <>
            {counterpart?.photo_url && (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: 14 }}>
                <div style={{ position: 'relative', width: 116, height: 116, borderRadius: '999px', overflow: 'hidden', border: '3px solid rgba(255,105,180,0.55)', boxShadow: '0 8px 28px rgba(255,51,102,0.28)' }}>
                  <OptimizedImage
                    src={counterpart.photo_url}
                    alt={counterpart.display_name || 'Date'}
                    priority={false}
                    sizes="116px"
                    fallbackName={counterpart.display_name || ''}
                    style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
                  />
                </div>
                <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 6, color: '#ff69b4', fontWeight: 700, fontSize: '0.92rem' }}>
                  <span style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic' }}>
                    {formatDisplayName(counterpart.display_name)}{counterpart.age ? `, ${counterpart.age}` : ''}
                  </span>
                </div>
                {counterpart.city && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#9f9fae', fontSize: '0.74rem', textTransform: 'uppercase', letterSpacing: '0.08em', marginTop: 2 }}>
                    <MapPin size={10} />{counterpart.city}
                  </div>
                )}
              </div>
            )}
            <p style={{ color: '#9f9fae', fontSize: '0.88rem', margin: 0 }}>Tu ne peux plus accepter de nouveau date avant demain.</p>
          </>
        )}
      </div>
    );
  }

  if (!prefs) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', padding: '24px 24px 30vh', textAlign: 'center' }}>
        <div style={{ fontSize: '3rem', marginBottom: '16px' }}>🔍</div>
        <h3 style={{ fontSize: '1.28rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, margin: '0 0 8px' }}>Publie d'abord ton date</h3>
        <p style={{ color: '#9f9fae', fontSize: '0.88rem', margin: 0 }}>Crée ton date pour voir les profils compatibles.</p>
      </div>
    );
  }

  // Normaliser les profils DB pour être compatibles avec le reste du code
  const normalizedDbProfiles = dbProfiles.map(p => ({
    ...p,
    id: p.id,
    name: p.display_name || p.full_name || 'Profil',
    photo: p.photo_url || '',
    fiveWords: p.five_words || '',
    quizPhrase: p.quiz_phrase || '',
    ownPhysicalTraits: p.own_physical_traits || [],
    ownPersonalityTraits: p.own_personality_traits || [],
    personal_flaws: p.personal_flaws || [],
    likes: p.likes || [],
    desired_physical_traits: p.desired_physical_traits || [],
    education: p.education || '',
    job: p.job || '',
    height: p.height || null,
    astro_sign: p.astro_sign || '',
    astro_ascendant: p.astro_ascendant || '',
    photo_url_2: p.photo_url_2 || '',
    photo_url_3: p.photo_url_3 || '',
  }));

  const todayKey = getParisDateKey();
  const profiles = normalizedDbProfiles.filter(p => {
    if (p.gender !== prefs.seeking) return false;
    if (prefs.myGender && p.seeking && p.seeking !== prefs.myGender) return false;
    if (!ageMatchesRange(p.age, prefs.ageRange)) return false;
    const dist = getDistanceKm(prefs.myCity, p.city);
    if (!distanceMatchesRange(dist, prefs.distance)) return false;
    if (prefs.minHeight && p.height < prefs.minHeight) return false;
    // Un profil est visible s'il est en ligne maintenant, ou s'il s'est connecté
    // dans les 7 derniers jours (fenêtre glissante)
    const ONLINE_WINDOW_MS = 7 * 24 * 60 * 60 * 1000;
    if (!p.is_online && p.last_online_date && (Date.now() - new Date(p.last_online_date).getTime()) > ONLINE_WINDOW_MS) return false;
    if (p.accepted_date_key === todayKey) return false;
    return true;
  });

  // Retourne true si l'ouverture du défi a été effectivement lancée
  function handleChallenge(p) {
    // Hors fenêtre (jeudis et samedis, 6 h – 23 h heure belge) l'envoi est refusé.
    if (!challengeWindow.isOpen) { if (challengeWindow.notice) alert(translate(challengeWindow.notice)); return false; }
    if (sessionState?.hasAccepted) { alert(translate("Tu as déjà accepté un lieu aujourd'hui.")); return false; }
    // Règle béton : ne jamais défier un profil avec qui on est en interaction active
    if (activeDateInteractionUserIds?.has(String(p.user_id))) { alert(translate(`Tu es déjà en interaction avec ${p.name}. Réponds dans tes messages.`)); return false; }
    const state = sessionState?.challengedProfiles?.[String(p.id)];
    const incomingFromMsg = incomingFromMessages?.has(String(p.id));
    if (state === 'incoming' || incomingFromMsg) { alert(translate(`${p.name} t'a déjà envoyé un défi ! Réponds dans tes messages.`)); return false; }
    if (state === true) { alert(translate(`Tu as déjà défiée ${p.name} aujourd'hui.`)); return false; }
    setLocalChallengedId(p.id);
    setChallengeProfile(p);
    return true;
  }

  // Jeux jouables depuis la fiche profil (menu œil) — mêmes règles que la carte du deck
  function getViewGames() {
    if (!viewProfile) return [];
    const usedGameTypes = getUnavailableGameTypes(userProfile, viewProfile.user_id);
    const state = sessionState?.challengedProfiles?.[String(viewProfile.id)];
    const isIncoming = state === 'incoming' || incomingFromMessages?.has(String(viewProfile.id));
    const bothUsed = usedGameTypes.length >= 2;

    const quizGames = GAME_LIST.map(g => {
      const used = usedGameTypes.includes(g.id);
      return {
        key: g.id,
        emoji: g.emoji,
        label: g.label,
        subtitle: g.subtitle,
        disabled: used || bothUsed || isIncoming,
        disabledLabel: used ? 'Déjà envoyé' : isIncoming ? 'Défi reçu' : 'Game over',
        onSelect: () => { setViewProfile(null); setQuizProfile({ profile: viewProfile, usedGameTypes, initialGameType: g.id }); },
      };
    });

    return quizGames;
  }

  async function sendChallenge() {
    const profile = challengeProfile;
    setChallengeProfile(null);
    // L'envoyeur joue en premier
    setRpsProfile(profile);
  }

  async function handleSenderChose(profile, senderChoice) {
    setRpsProfile(null);
    await onChallengeSend?.(profile, senderChoice);
  }

  function addMsg(text, isSystem = true, profileName = '') {
    onAddMessage?.(text, isSystem, profileName);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100%' }}>
      <style>{`@keyframes flashOut { 0% { opacity: 1; } 100% { opacity: 0; } }`}</style>
      <FlashOverlay flash={flash} />
      {/* Header */}
      <div style={{ padding: '16px 16px 12px', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ color: '#ff69b4', textTransform: 'uppercase', letterSpacing: '0.14em', fontSize: '0.72rem', fontWeight: 700 }}>Deck</div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h2 style={{ margin: '4px 0 0', fontSize: '1.4rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800 }}>Profils du jour</h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            {(() => {
              const available = profiles.filter(p => !sessionState?.challengedProfiles?.[String(p.id)] && !sessionState?.passedProfiles?.[String(p.id)]);
              return available.length > 0 ? <span style={{ fontSize: '0.78rem', color: '#9f9fae' }}>{available.length} profil{available.length > 1 ? 's' : ''}</span> : null;
            })()}
            {(() => {
              const blockedCount = Array.isArray(userProfile?.blocked_profile_ids) ? userProfile.blocked_profile_ids.length : 0;
              return (
                <button
                  onClick={() => setShowBlockedModal(true)}
                  style={{ position: 'relative', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px', padding: '7px 9px', cursor: 'pointer', color: '#cfcfda', display: 'flex', alignItems: 'center', fontFamily: 'inherit', flexShrink: 0 }}
                  title="Profils bloqués"
                >
                  <Ban size={17} style={{ color: '#ff69b4' }} />
                  {blockedCount > 0 && (
                    <span style={{ position: 'absolute', top: 1, right: 1, minWidth: 15, height: 15, borderRadius: '999px', background: '#ff3366', color: '#fff', fontSize: '0.58rem', fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 3px', lineHeight: 1, border: '1.5px solid #0e0e0e', boxShadow: '0 0 4px rgba(255,51,102,0.6)' }}>
                      {blockedCount}
                    </span>
                  )}
                </button>
              );
            })()}
          </div>
        </div>
      </div>

      <ChallengeWindowBanner notice={challengeWindow.notice} parts={challengeWindow.parts} />

      {/* Liste en flux naturel — le seul défileur est le conteneur de l'onglet
          (même structure que l'onglet Flamme). Tirer vers le bas recharge toujours. */}
      <PullToRefresh inline onRefresh={onRefresh}>
      <div style={{ padding: '16px', paddingBottom: '100px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {profiles.length === 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '48px 16px 30vh', textAlign: 'center' }}>
                  <div style={{ fontSize: '3rem', marginBottom: '12px' }}>😕</div>
                  <p style={{ fontSize: '1.2rem', fontWeight: 700, margin: '0 0 8px' }}>Aucun profil compatible</p>
            <p style={{ color: '#9f9fae', fontSize: '0.88rem', margin: 0 }}>Essaie d'ajuster tes critères.</p>
          </div>
        ) : profiles
          .filter(p => !sessionState?.passedProfiles?.[String(p.id)])
          .map(p => {
            const isChallenged = Boolean(sessionState?.challengedProfiles?.[String(p.id)]);
            const isLocalChallenged = localChallengedId === p.id;
            return (
            <ProfileCard
              key={p.id}
              profile={p}
              globalScore={p.globalScore}
              matchScore={p.matchScore}
              cosmicScore={p.cosmicScore}
              distance={getDistanceKm(prefs.myCity, p.city)}
              challenged={isChallenged === true || isLocalChallenged}
              isIncoming={sessionState?.challengedProfiles?.[String(p.id)] === 'incoming' || incomingFromMessages?.has(String(p.id))}
              hasActiveInteraction={activeDateInteractionUserIds?.has(String(p.user_id)) || false}
              challengeBlocked={!challengeWindow.isOpen}
              onChallenge={handleChallenge}
              onFlash={triggerFlash}
              onTakeQuiz={(profile, usedGameTypes) => setQuizProfile({ profile, usedGameTypes })}
              usedGameTypes={getUnavailableGameTypes(userProfile, p.user_id)}
              lastChallengeDate={getLastChallengeDate(sessionState?.challengeDates, p.id)}
              onViewProfile={() => {
                setViewMatchScore(p.matchScore);
                setViewCosmicScore(p.cosmicScore);
                setViewPersonalityScore(p.personalityScore ?? null);
                setViewProfileLoading(true);
                fetchFullProfile(p, p.user_id).then(full => {
                  if (!full) { setViewProfile(p); setViewProfileLoading(false); return; }
                  setViewProfile({
                    ...full,
                    photo: full.photo_url || '',
                    name: full.display_name || '',
                    fiveWords: full.five_words || '',
                    quizPhrase: full.quiz_phrase || '',
                    ownPhysicalTraits: full.own_physical_traits || [],
                    ownPersonalityTraits: full.own_personality_traits || [],
                    personal_flaws: full.personal_flaws || [],
                    desired_physical_traits: full.desired_physical_traits || [],
                  });
                  setViewProfileLoading(false);
                }).catch(() => {
                  setViewProfile(p); // fallback au profil léger
                  setViewProfileLoading(false);
                });
              }}
            />
          );
          })}
      </div>
      </PullToRefresh>

      {viewProfileLoading && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 9999, backgroundColor: 'rgba(0,0,0,0.92)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: 40, height: 40, border: '3px solid rgba(255,255,255,0.1)', borderTopColor: '#ff3366', borderRadius: '50%', animation: 'spin 0.6s linear infinite' }} />
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      )}
      {viewProfile && !viewProfileLoading && (
        <ProfileViewModal
          profile={viewProfile}
          myProfile={userProfile}
          matchScore={viewMatchScore}
          cosmicScore={viewCosmicScore}
          personalityScore={viewPersonalityScore}
          games={getViewGames()}
          onClose={() => setViewProfile(null)}
        />
      )}
      {showBlockedModal && (
        <BlockedProfilesModal
          userProfile={userProfile}
          onClose={() => setShowBlockedModal(false)}
          onUnblock={onUnblock}
        />
      )}
      {quizProfile && (
        <QuizModal
          profile={quizProfile.profile}
          usedGameTypes={quizProfile.usedGameTypes || []}
          initialGameType={quizProfile.initialGameType || null}
          onClose={() => setQuizProfile(null)}
          onSend={async (gameType, items) => {
            const p = quizProfile.profile;
            try {
              const res = await base44.functions.invoke('deliverQuiz', {
                recipientUserId: p.user_id,
                questions: items,
                gameType,
                dateKey: getParisDateKey(),
              });
              if (res.data?.alreadySent) {
                toast.error(`Tu as déjà proposé ce jeu à ${p.name} ce mois-ci.`);
                return;
              }
              markGameProposed(p.user_id, gameType);
              setJustSentDates(prev => ({ ...prev, [p.user_id]: new Date().toISOString() }));
              toast.success('Jeu envoyé !');
            } catch (e) {
              const errData = e?.data?.data || e?.data || {};
              if (errData?.blocked && errData?.reason === 'already_sent') {
                toast.error(errData?.message || `Tu as déjà proposé ce jeu à ${p.name} ce mois-ci.`);
                return;
              }
              console.error('deliverQuiz failed:', e);
              toast.error('Envoi impossible');
            } finally {
              setQuizProfile(null);
            }
          }}
        />
      )}
      {challengeProfile && <RpsModal profile={challengeProfile} onClose={() => { setChallengeProfile(null); setLocalChallengedId(null); }} onSend={sendChallenge} />}
      {rpsProfile && (
        <RpsFlow
          profile={rpsProfile}
          userId={userId}
          initialStep="senderChoose"
          addMessage={addMsg}
          onDone={() => setRpsProfile(null)}
          onBackground={(type, data) => onRpsBackground?.(type, rpsProfile, data)}
          onSenderChose={(choice) => handleSenderChose(rpsProfile, choice)}
        />
      )}
    </div>
  );
}