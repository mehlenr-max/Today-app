import React from 'react';
import { Check } from 'lucide-react';
import { useLanguage } from '../../lib/i18n/LanguageContext';

// Choix de la langue (français / néerlandais / anglais) depuis le menu burger.
export default function LanguageMenu({ isWhite, itemBase, onPicked }) {
  const { lang, setLang, languages } = useLanguage();

  return (
    <>
      <div style={{ padding: '10px 16px 4px', fontSize: '0.68rem', fontWeight: 700, letterSpacing: '0.1em', color: isWhite ? '#666' : '#8e8e9c', textTransform: 'uppercase' }}>
        Langue
      </div>
      {languages.map(({ code, label, flag }) => {
        const active = code === lang;
        return (
          <button
            key={code}
            onClick={() => { setLang(code); onPicked?.(); }}
            style={{ ...itemBase, color: active ? '#ff3366' : (isWhite ? '#111' : '#fff') }}
          >
            <span style={{ fontSize: '1rem' }}>{flag}</span>
            {label}
            {active && <Check size={15} style={{ marginLeft: 'auto' }} />}
          </button>
        );
      })}
      <div style={{ height: 1, background: isWhite ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.06)', margin: '0 8px' }} />
    </>
  );
}