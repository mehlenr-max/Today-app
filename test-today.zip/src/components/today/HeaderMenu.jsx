import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Menu, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { base44 } from '../../api/base44Client';
import { useSitePause } from '../SitePauseGate';
import LanguageMenu from './LanguageMenu';
import { translate } from '../../lib/i18n/engine';

export default function HeaderMenu({ isWhite, isAdmin, onManual, onDeleteAccount, onLogout }) {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ top: 0, left: 0 });
  const [busy, setBusy] = useState(false);
  const { paused, apply } = useSitePause();
  const ref = useRef(null);
  const menuRef = useRef(null);

  const togglePause = async () => {
    const next = !paused;
    setBusy(true);
    try {
      const res = await base44.functions.invoke('toggleSitePause', { paused: next });
      if (res?.data?.paused !== next) throw new Error(res?.data?.error || 'Action impossible');
      apply(next);
      setOpen(false);
      toast.success(next ? 'Site en pause pour les membres' : 'Site de nouveau accessible');
    } catch (e) {
      alert(translate('Erreur') + ' : ' + (e?.response?.data?.error || e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (!ref.current?.contains(e.target) && !menuRef.current?.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    document.addEventListener('touchstart', handler);
    return () => {
      document.removeEventListener('mousedown', handler);
      document.removeEventListener('touchstart', handler);
    };
  }, [open]);

  const openMenu = () => {
    if (ref.current) {
      const r = ref.current.getBoundingClientRect();
      setPos({ top: r.bottom + 6, left: r.left });
    }
    setOpen(v => !v);
  };

  const itemBase = {
    display: 'flex', alignItems: 'center', gap: '10px',
    width: '100%', padding: '12px 16px',
    background: 'none', border: 'none',
    fontFamily: 'inherit', fontSize: '0.88rem', fontWeight: 600,
    cursor: 'pointer', textAlign: 'left',
  };

  return (
    <>
      <button
        ref={ref}
        onClick={openMenu}
        style={{
          width: 44, height: 44, borderRadius: '12px', border: 'none',
          background: isWhite ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.06)',
          color: isWhite ? '#333' : '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', transition: 'all 0.15s ease', flexShrink: 0,
        }}
      >
        {open ? <X size={20} /> : <Menu size={20} />}
      </button>
      {open && createPortal(
        <div ref={menuRef} style={{
          position: 'fixed', top: pos.top, left: pos.left, zIndex: 99999,
          minWidth: 200, borderRadius: '16px',
          background: isWhite ? 'rgba(255,255,255,0.98)' : 'rgba(18,18,24,0.98)',
          backdropFilter: 'blur(16px)',
          border: isWhite ? '1px solid rgba(0,0,0,0.1)' : '1px solid rgba(255,255,255,0.1)',
          boxShadow: '0 12px 40px rgba(0,0,0,0.4)',
          overflow: 'visible', padding: '6px',
        }}>
          {isAdmin && (
            <>
              <button
                onClick={() => { setOpen(false); navigate('/admin/reports'); }}
                style={{ ...itemBase, color: isWhite ? '#111' : '#fff' }}
              >
                🛡️ Modération
              </button>
              <button
                onClick={togglePause}
                disabled={busy}
                style={{ ...itemBase, color: paused ? '#ff3366' : (isWhite ? '#111' : '#fff'), opacity: busy ? 0.6 : 1 }}
              >
                {paused ? '▶️ Reprendre le site' : '⏸️ Mettre le site en pause'}
                {paused && (
                  <span style={{
                    marginLeft: 'auto', fontSize: '0.58rem', fontWeight: 800, letterSpacing: '0.08em',
                    color: '#ff3366', border: '1px solid rgba(255,51,102,0.45)', borderRadius: '999px', padding: '2px 7px',
                  }}>
                    EN PAUSE
                  </span>
                )}
              </button>
              <div style={{ height: 1, background: isWhite ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.06)', margin: '0 8px' }} />
            </>
          )}
          <button
            onClick={() => { setOpen(false); onManual(); }}
            style={{ ...itemBase, color: isWhite ? '#111' : '#fff' }}
          >
            📖 Manuel
          </button>
          <div style={{ height: 1, background: isWhite ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.06)', margin: '0 8px' }} />
          <LanguageMenu isWhite={isWhite} itemBase={itemBase} onPicked={() => setOpen(false)} />
          <button
            onClick={() => { setOpen(false); onDeleteAccount(); }}
            style={{ ...itemBase, color: '#ff3366' }}
          >
            🗑️ Supprimer mon compte
          </button>
          <div style={{ height: 1, background: isWhite ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.06)', margin: '0 8px' }} />
          <button
            onClick={() => { setOpen(false); onLogout(); }}
            style={{ ...itemBase, color: isWhite ? '#555' : '#9f9fae' }}
          >
            🚪 Se déconnecter
          </button>
        </div>,
        document.body
      )}
    </>
  );
}