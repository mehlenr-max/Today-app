import { CalendarDays } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/LanguageContext';

// Bandeau d'information sur la fenêtre des défis (jeudis et samedis, 6 h – 23 h).
// Mise en page : icône centrée, une ligne blanche, une ligne rose en italique,
// puis le compte à rebours avec le nombre surligné.
export default function ChallengeWindowBanner({ notice, parts }) {
  const { t, lang } = useLanguage();
  if (!notice && !parts) return null;
  // « DONDERDAGEN en ZATERDAGEN » est bien plus long que « JEUDIS et SAMEDIS » :
  // en néerlandais on réduit la taille des deux lignes pour rester sur une seule ligne.
  const nl = lang === 'nl';

  return (
    <div style={{
      margin: '12px 16px 0',
      padding: '18px 18px 16px',
      borderRadius: '20px',
      background: 'rgba(255,255,255,0.04)',
      border: '1px solid rgba(255,255,255,0.08)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
    }}>
      <CalendarDays size={22} strokeWidth={1.5} style={{ color: '#e56488', marginBottom: 10 }} />

      {parts ? (
        <>
          <p style={{ margin: 0, color: '#fff', fontSize: nl ? '0.78rem' : '0.92rem', fontWeight: 500, lineHeight: 1.45 }}>
            {t(parts.line1)}
          </p>
          <p style={{ margin: '2px 0 0', color: '#e56488', fontSize: nl ? '0.8rem' : '0.98rem', fontWeight: 800, fontStyle: 'italic', lineHeight: 1.35 }}>
            {t(parts.line2)}
          </p>
          <p style={{ margin: '10px 0 0', color: '#d8d8e2', fontSize: '0.8rem', fontWeight: 500, lineHeight: 1.5 }}>
            {t('Il reste')}{' '}
            <span style={{ color: '#e56488', fontWeight: 700 }}>{parts.daysUntil}</span>{' '}
            {t(parts.daysUntil > 1 ? 'jours' : 'jour')}{t(', sois prêt pour dater !')}
          </p>
        </>
      ) : (
        <p style={{ margin: 0, color: '#d8d8e2', fontSize: '0.82rem', fontWeight: 500, lineHeight: 1.5 }}>
          {notice}
        </p>
      )}
    </div>
  );
}