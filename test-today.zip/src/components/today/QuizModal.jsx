import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Shuffle, ArrowLeft } from 'lucide-react';
import { GAMES, GAME_LIST, pickRandomItems } from '../../lib/quiz-questions';
import useOverlayBack from '../../hooks/useOverlayBack';

export default function QuizModal({ profile, onClose, onSend, usedGameTypes = [], initialGameType = null }) {
  useOverlayBack(true, onClose);
  const startGame = initialGameType && GAMES[initialGameType] ? initialGameType : null;
  const [gameType, setGameType] = useState(startGame);
  const [items, setItems] = useState(() => startGame ? pickRandomItems(GAMES[startGame].items, GAMES[startGame].pickCount) : []);
  const [sending, setSending] = useState(false);

  const game = gameType ? GAMES[gameType] : null;

  function chooseGame(type) {
    setGameType(type);
    setItems(pickRandomItems(GAMES[type].items, GAMES[type].pickCount));
  }

  function shuffle() {
    if (!gameType) return;
    setItems(pickRandomItems(GAMES[gameType].items, GAMES[gameType].pickCount));
  }

  function handleSend() {
    if (!gameType || items.length === 0 || sending) return;
    setSending(true);
    onSend(gameType, items);
  }

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        transition={{ type: 'spring', damping: 28, stiffness: 280 }}
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: '500px',
          background: 'rgba(15,15,19,0.98)',
          border: '1px solid rgba(255,51,102,0.2)',
          borderRadius: '24px 24px 0 0',
          padding: '20px 16px 24px',
          maxHeight: '85vh', overflowY: 'auto',
        }}
      >
        <div style={{ width: 44, height: 5, borderRadius: '999px', background: 'rgba(255,255,255,0.18)', margin: '0 auto 16px' }} />

        {!game ? (
          <>
            <h3 style={{ textAlign: 'center', color: '#ff3366', fontSize: '1.2rem', margin: '0 0 6px', fontWeight: 800 }}>
              Jouer avec {profile?.name || 'ce profil'} 🎮
            </h3>
            <p style={{ textAlign: 'center', color: '#9f9fae', fontSize: '0.82rem', margin: '0 0 20px' }}>
              Choisis un jeu pour apprendre à le/la connaître.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 20 }}>
              {GAME_LIST.map(g => {
                const isUsed = usedGameTypes.includes(g.id);
                return (
                <button
                  key={g.id}
                  onClick={() => !isUsed && chooseGame(g.id)}
                  disabled={isUsed}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 14,
                    padding: '18px 16px', borderRadius: '16px',
                    background: isUsed ? 'rgba(255,255,255,0.02)' : 'rgba(255,255,255,0.03)',
                    border: '1.5px solid rgba(255,255,255,0.08)',
                    cursor: isUsed ? 'not-allowed' : 'pointer', fontFamily: 'inherit', textAlign: 'left',
                    opacity: isUsed ? 0.45 : 1,
                    transition: 'all 0.12s ease',
                  }}
                  onMouseEnter={e => { if (!isUsed) { e.currentTarget.style.borderColor = 'rgba(255,51,102,0.4)'; e.currentTarget.style.background = 'rgba(255,51,102,0.06)'; }}}
                  onMouseLeave={e => { if (!isUsed) { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'; e.currentTarget.style.background = 'rgba(255,255,255,0.03)'; }}}
                >
                  <span style={{ fontSize: '2rem', flexShrink: 0 }}>{g.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: '1rem', fontWeight: 700, color: '#fff' }}>{g.label}</div>
                    <div style={{ fontSize: '0.78rem', color: '#9f9fae' }}>{g.subtitle} · {g.pickCount} questions</div>
                  </div>
                  {isUsed ? (
                    <span style={{ fontSize: '0.72rem', color: '#9f9fae', fontWeight: 600 }}>✓ Déjà proposé</span>
                  ) : (
                    <span style={{ color: '#ff3366', fontSize: '1.2rem' }}>→</span>
                  )}
                </button>
                );
              })}
            </div>
          </>
        ) : (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <button onClick={() => setGameType(null)} style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: '#9f9fae', display: 'flex', alignItems: 'center' }}>
                <ArrowLeft size={20} />
              </button>
              <span style={{ fontSize: '1.6rem' }}>{game.emoji}</span>
              <div>
                <h3 style={{ margin: 0, color: '#ff3366', fontSize: '1.1rem', fontWeight: 800 }}>{game.label}</h3>
                <p style={{ margin: 0, color: '#9f9fae', fontSize: '0.75rem' }}>{game.subtitle}</p>
              </div>
            </div>

            <p style={{ textAlign: 'center', color: '#cfcfda', fontSize: '0.82rem', margin: '0 0 14px' }}>
              Voici {items.length} questions. Tu peux les mélanger.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20 }}>
              {items.map((item, i) => (
                <div key={i} style={{
                  padding: '12px 14px', borderRadius: '12px',
                  background: 'rgba(255,255,255,0.03)',
                  border: '1.5px solid rgba(255,255,255,0.06)',
                }}>
                  {gameType === 'thisOrThat' ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.88rem', color: '#fff' }}>
                      <span style={{ fontWeight: 700, color: '#ff69b4' }}>{item.a}</span>
                      <span style={{ color: '#9f9fae', fontSize: '0.78rem' }}>ou</span>
                      <span style={{ fontWeight: 700, color: '#ff69b4' }}>{item.b}</span>
                      <span style={{ color: '#9f9fae' }}>?</span>
                    </div>
                  ) : (
                    <div style={{ fontSize: '0.88rem', color: '#fff' }}>
                      <span style={{ color: '#9f9fae' }}>Je n'ai jamais </span>
                      <span style={{ fontWeight: 700, color: '#ff69b4' }}>{item.text}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <button
              onClick={shuffle}
              style={{
                width: '100%', minHeight: 42, borderRadius: '999px',
                fontWeight: 600, fontSize: '0.88rem', fontFamily: 'inherit',
                background: 'rgba(255,255,255,0.05)', color: '#cfcfda',
                border: '1px solid rgba(255,255,255,0.1)',
                cursor: 'pointer', marginBottom: 10,
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}
            >
              <Shuffle size={16} /> Mélanger les questions
            </button>

            <button
              onClick={handleSend}
              disabled={sending}
              style={{
                width: '100%', minHeight: 50, borderRadius: '999px',
                fontWeight: 700, fontSize: '0.95rem', fontFamily: 'inherit',
                background: 'linear-gradient(90deg, #ff3366, #ff69b4)', color: '#fff',
                border: 'none', cursor: 'pointer',
                boxShadow: '0 8px 20px rgba(255,51,102,0.22)',
                transition: 'all 0.12s ease',
              }}
            >
              {sending ? '⏳ Envoi…' : `Envoyer le jeu ✉️`}
            </button>
          </>
        )}

        <button
          onClick={onClose}
          disabled={sending}
          style={{ width: '100%', marginTop: 8, background: 'none', border: 'none', color: '#9f9fae', fontSize: '0.88rem', cursor: 'pointer', fontFamily: 'inherit', padding: '10px' }}
        >
          Annuler
        </button>
      </motion.div>
    </div>
  );
}