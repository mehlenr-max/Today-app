import React from 'react';
import { WifiOff } from 'lucide-react';

export default function OfflineDeckGuard({ onGoOnline, bgTheme }) {
  const isWhite = bgTheme === 'white';

  return (
    <div style={{
      minHeight: '60vh', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', textAlign: 'center',
      padding: '40px 28px',
    }}>
      <div style={{
        width: '68px', height: '68px', borderRadius: '999px',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: isWhite ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.06)',
        border: isWhite ? '1px solid rgba(0,0,0,0.1)' : '1px solid rgba(255,255,255,0.12)',
        marginBottom: '18px',
      }}>
        <WifiOff size={30} color="#ff3366" />
      </div>

      <h2 style={{
        margin: '0 0 8px', fontFamily: "'EB Garamond', serif",
        fontSize: '1.6rem', fontWeight: 700,
        color: isWhite ? '#111' : '#fff',
      }}>
        Tu es hors ligne
      </h2>

      <p style={{
        margin: '0 0 22px', maxWidth: '300px', lineHeight: 1.6,
        fontSize: '0.85rem', color: isWhite ? '#555' : '#9f9fae',
      }}>
        Le deck ❤️ est réservé aux membres en ligne. Repasse en ligne pour voir les profils et les défier.
      </p>

      <button
        onClick={onGoOnline}
        style={{
          padding: '13px 26px', borderRadius: '999px', border: 'none', cursor: 'pointer',
          background: 'linear-gradient(135deg, #ff3366, #ff69b4)', color: '#fff',
          fontFamily: 'inherit', fontSize: '0.88rem', fontWeight: 800,
          boxShadow: '0 8px 22px rgba(255,51,102,0.35)',
        }}
      >
        Passer en ligne
      </button>

      <p style={{
        margin: '16px 0 0', fontSize: '0.72rem',
        color: isWhite ? '#777' : '#6f6f7d',
      }}>
        Ton profil redevient visible pour les autres membres.
      </p>
    </div>
  );
}