import React from 'react';

const pageStyle = {
  position: 'fixed',
  top: 0, left: 0, right: 0, bottom: 0,
  zIndex: 9999,
  overflowY: 'auto',
  background:
    "radial-gradient(circle at 16% 16%, rgba(255,51,102,0.22) 0%, transparent 24%), radial-gradient(circle at 86% 18%, rgba(255,105,180,0.14) 0%, transparent 22%), linear-gradient(180deg, #070709 0%, #040405 42%, #030304 100%)",
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  fontFamily: "'Poppins', sans-serif",
  padding: 'calc(env(safe-area-inset-top) + 16px) 20px calc(env(safe-area-inset-bottom) + 24px)',
};

const cardStyle = {
  width: '100%',
  maxWidth: '560px',
  display: 'flex',
  flexDirection: 'column',
};

const closeBtnStyle = {
  position: 'sticky',
  top: 0,
  alignSelf: 'flex-start',
  background: 'none',
  border: 'none',
  color: '#ff69b4',
  fontSize: '1.6rem',
  cursor: 'pointer',
  padding: '0 0 10px',
  fontFamily: 'inherit',
  fontWeight: 700,
  zIndex: 10,
  marginBottom: '8px',
};

const scrollContentStyle = {
  background: 'rgba(15,15,19,0.72)',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: '20px',
  padding: '24px 20px',
  marginBottom: '16px',
  WebkitOverflowScrolling: 'touch',
};

const stickyBtnWrapStyle = {
  position: 'sticky',
  bottom: 0,
  padding: '14px 0 4px',
  marginTop: '-8px',
  background: 'linear-gradient(180deg, rgba(4,4,5,0) 0%, rgba(4,4,5,0.92) 35%, rgba(4,4,5,0.98) 100%)',
};

function Section({ title, children }) {
  return (
    <section style={{ marginBottom: 20 }}>
      <h2 style={{ fontSize: '1rem', fontWeight: 700, color: '#fff', margin: '0 0 6px' }}>{title}</h2>
      <div style={{ fontSize: '0.85rem', lineHeight: 1.6, color: '#cfcfda' }}>{children}</div>
    </section>
  );
}

export default function RulesScreen({ onAccept, loading, onClose, title = 'Règlement ToDay', subtitle = 'Lis et accepte pour finaliser ton inscription' }) {
  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        {onClose && (
          <button
            onClick={onClose}
            style={closeBtnStyle}
            aria-label="Fermer"
          >
            ←
          </button>
        )}
        <div style={{ textAlign: 'center', marginBottom: '16px' }}>
          <h1 style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontSize: '1.7rem', fontWeight: 800, color: '#fff', margin: '0 0 4px' }}>
            {title}
          </h1>
          <p style={{ color: '#9f9fae', fontSize: '0.82rem', margin: 0 }}>{subtitle}</p>
        </div>

        <div style={scrollContentStyle}>
          <Section title="1. Acceptation">
            En créant un compte ou en utilisant ToDay (« l'Application »), vous acceptez les présentes
            Conditions d'utilisation. Si vous n'êtes pas d'accord, n'utilisez pas l'Application.
          </Section>
          <Section title="2. Éligibilité">
            ToDay est réservé aux personnes âgées d'au moins 18 ans. En vous inscrivant, vous déclarez
            avoir 18 ans révolus et que les informations fournies sont exactes.
          </Section>
          <Section title="3. Service">
            ToDay est une application de rencontre gratuite permettant d'organiser un date le soir même.
            Un seul date par jour peut être confirmé. Le service est fourni « tel quel », sans garantie
            de résultat ni de disponibilité continue.
          </Section>
          <Section title="4. Compte et profil">
            Vous êtes responsable des informations et photos que vous publiez. Les contenus
            illicites, trompeurs, ou non conformes (nudité, mineurs, incitation à la haine) sont interdits
            et entraînent le retrait immédiat du profil, sans préavis.
          </Section>
          <Section title="5. Conduite">
            Vous vous engagez à traiter les autres utilisateurs avec respect, à ne pas harceler,
            à ne pas solliciter d'argent, et à ne pas utiliser l'Application à des fins commerciales
            ou publicitaires.
          </Section>
          <Section title="6. Modération">
            Les signalements sont traités sous 48 h. Un profil recevant deux signalements est
            automatiquement masqué en attendant vérification. Les décisions de modération sont définitives.
          </Section>
          <Section title="7. Suppression du compte">
            Vous pouvez supprimer votre compte à tout moment depuis Profil → Supprimer mon compte.
            Cette action efface immédiatement et définitivement votre profil, vos messages et vos sessions.
          </Section>
          <Section title="8. Propriété">
            Vous conservez la propriété de vos photos. En les publiant, vous autorisez ToDay à les
            afficher aux autres utilisateurs dans le cadre du service.
          </Section>
          <Section title="9. Responsabilité">
            ToDay ne saurait être tenu responsable des rencontres issues de l'Application. Vous
            restez seul responsable de vos interactions et de votre sécurité lors des rendez-vous.
          </Section>
          <Section title="10. Modifications">
            Les présentes conditions peuvent évoluer. Les modifications significatives vous seront
            notifiées dans l'Application.
          </Section>
          <Section title="11. Droit applicable">
            Les présentes conditions sont régies par le droit belge. En cas de litige, les tribunaux
            belges seront seuls compétents.
          </Section>
        </div>

        {onAccept && (
          <div style={stickyBtnWrapStyle}>
            <button
              onClick={onAccept}
              disabled={loading}
              style={{
                width: '100%', minHeight: '54px', borderRadius: '999px', fontWeight: 700, fontSize: '1rem',
                background: loading ? 'rgba(255,51,102,0.4)' : 'linear-gradient(90deg, #ff3366, #ff69b4)',
                color: '#fff', border: 'none', cursor: loading ? 'default' : 'pointer', fontFamily: 'inherit',
                boxShadow: '0 12px 24px rgba(255,51,102,0.22)',
              }}
            >
              {loading ? '⏳' : 'J\'accepte et je continue'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}