import React from 'react';
import { useLanguage } from '../../lib/i18n/LanguageContext';

// Choix de la langue (FR / NL / EN) sur les écrans d'authentification, pour que
// le visiteur choisisse sa langue avant même de créer son compte. Les libellés
// sont neutres (drapeau + code) : jamais traduits par le moteur i18n.
export default function LanguageSwitcher() {
  const { lang, setLang, languages } = useLanguage();

  return (
    <div
      style={{
        display: 'flex',
        gap: '4px',
        padding: '4px',
        borderRadius: '999px',
        background: 'rgba(255,255,255,0.05)',
        border: '1px solid rgba(255,255,255,0.12)',
      }}
    >
      {languages.map(({ code, label, flag }) => {
        const active = code === lang;
        return (
          <button
            key={code}
            type="button"
            onClick={() => setLang(code)}
            aria-label={label}
            aria-pressed={active}
            style={{
              minHeight: '44px',
              padding: '0 14px',
              borderRadius: '999px',
              border: 'none',
              cursor: 'pointer',
              fontFamily: 'inherit',
              fontSize: '0.8rem',
              fontWeight: 700,
              letterSpacing: '0.04em',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              background: active ? 'linear-gradient(90deg, #ff3366, #ff69b4)' : 'transparent',
              color: active ? '#fff' : '#9f9fae',
            }}
          >
            <span style={{ fontSize: '1rem' }}>{flag}</span>
            {code.toUpperCase()}
          </button>
        );
      })}
    </div>
  );
}