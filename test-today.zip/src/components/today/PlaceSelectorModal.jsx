import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { findInsult } from '../../lib/insult-filter';
import useOverlayBack from '../../hooks/useOverlayBack';

export default function PlaceSelectorModal({ isOpen, profileName, onConfirm, onClose }) {
  useOverlayBack(isOpen, onClose);
  const [placeName, setPlaceName] = useState('');
  const [street, setStreet] = useState('');
  const [number, setNumber] = useState('');
  const [city, setCity] = useState('');
  const getMinTime = () => { const d = new Date(Date.now() + 30 * 60 * 1000); return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`; };
  const [time, setTime] = useState(() => { const minTime = getMinTime(); return '20:00' > minTime ? '20:00' : minTime; });
  const [error, setError] = useState('');
  const inputRef = useRef(null);
  const isTimeTooSoon = time < getMinTime();

  const handleConfirm = () => {
    if (!placeName.trim() || !time || isTimeTooSoon) return;
    const fullPlace = [placeName.trim(), `${street.trim()} ${number.trim()}`.trim(), city.trim()].filter(Boolean).join(', ');
    const insult = findInsult(fullPlace);
    if (insult) { setError(`Le mot « ${insult} » est interdit.`); return; }
    onConfirm(fullPlace, time);
    setPlaceName(''); setStreet(''); setNumber(''); setCity('');
    setTime(() => { const minTime = getMinTime(); return '20:00' > minTime ? '20:00' : minTime; });
    setError('');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/85 flex items-center justify-center z-50 px-5"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            onAnimationComplete={() => inputRef.current?.focus()}
            onClick={e => e.stopPropagation()}
            className="w-full max-w-[420px] bg-black/98 border border-pink-500/30 rounded-3xl p-5 backdrop-blur-xl max-h-[90vh] overflow-y-auto"
          >
            <div className="w-12 h-1 rounded-full bg-white/18 mx-auto mb-4" />
            
            <h3 className="text-center text-pink-400 text-lg font-bold mb-1">📍 Choisir le lieu</h3>
            <p className="text-center text-gray-400 text-sm mb-4">Propose un lieu pour confirmer votre date !</p>

            {error && (
              <div className="mb-3 px-4 py-2 rounded-xl bg-red-500/15 border border-red-500/40 text-red-300 text-sm text-center font-semibold">
                {error}
              </div>
            )}

            <div className="space-y-3 mb-4">
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1 uppercase tracking-wide">Nom du lieu <span className="text-pink-500">*</span></label>
                <input
                  ref={inputRef}
                  type="text"
                  placeholder="ex: Le Botaniste"
                  value={placeName}
                  onChange={(e) => setPlaceName(e.target.value)}
                  className="w-full border border-white/8 rounded-2xl bg-white/15 text-white px-4 py-3 text-[16px] focus:outline-none focus:border-pink-500/50 focus:ring-2 focus:ring-pink-500/20 transition-all placeholder-gray-400 backdrop-blur"
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-gray-300 mb-1 uppercase tracking-wide">Rue</label>
                  <input
                    type="text"
                    placeholder="ex: Rue Royale"
                    value={street}
                    onChange={(e) => setStreet(e.target.value.replace(/[0-9]/g, ''))}
                    className="w-full border border-white/8 rounded-2xl bg-white/15 text-white px-4 py-3 text-[16px] focus:outline-none focus:border-pink-500/50 focus:ring-2 focus:ring-pink-500/20 transition-all placeholder-gray-400 backdrop-blur"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1 uppercase tracking-wide">N°</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="236"
                    value={number}
                    onChange={(e) => setNumber(e.target.value.replace(/[^0-9]/g, ''))}
                    className="w-full border border-white/8 rounded-2xl bg-white/15 text-white px-4 py-3 text-[16px] focus:outline-none focus:border-pink-500/50 focus:ring-2 focus:ring-pink-500/20 transition-all placeholder-gray-400 backdrop-blur"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1 uppercase tracking-wide">Ville</label>
                <input
                  type="text"
                  placeholder="ex: Bruxelles"
                  value={city}
                  onChange={(e) => setCity(e.target.value.replace(/[0-9]/g, ''))}
                  className="w-full border border-white/8 rounded-2xl bg-white/15 text-white px-4 py-3 text-[16px] focus:outline-none focus:border-pink-500/50 focus:ring-2 focus:ring-pink-500/20 transition-all placeholder-gray-400 backdrop-blur"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-300 mb-1 uppercase tracking-wide">Heure</label>
                <input
                  type="time"
                  value={time}
                  min={getMinTime()}
                  onChange={(e) => setTime(e.target.value)}
                  className={`w-full border rounded-2xl bg-white/15 text-white px-4 py-3 text-[16px] focus:outline-none focus:ring-2 focus:ring-pink-500/20 transition-all backdrop-blur ${isTimeTooSoon ? 'border-red-500/50 text-red-300' : 'border-white/8 focus:border-pink-500/50'}`}
                />
                {isTimeTooSoon && <p className="mt-1 text-xs text-red-400">⚠️ Au moins 30 minutes à l'avance</p>}
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'center', gap: '32px', marginTop: '8px' }}>
              {/* Bouton Attendre — rouge */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                <button onClick={onClose} style={{
                  width: 72, height: 72, borderRadius: '50%',
                  background: 'radial-gradient(circle at 35% 35%, #ff5555, #cc1111)',
                  border: '3px solid rgba(255,255,255,0.15)',
                  boxShadow: '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(255,30,30,0.35)',
                  cursor: 'pointer', fontSize: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'transform 0.1s ease, box-shadow 0.1s ease',
                }}
                  onPointerDown={e => { e.currentTarget.style.transform = 'translateY(3px) scale(0.93)'; e.currentTarget.style.filter = 'brightness(2.5)'; e.currentTarget.style.boxShadow = '0 2px 0 rgba(0,0,0,0.4)'; }}
                  onPointerUp={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; e.currentTarget.style.boxShadow = '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(255,30,30,0.35)'; }}
                  onPointerLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; e.currentTarget.style.boxShadow = '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(255,30,30,0.35)'; }}
                >⏸</button>
                <span style={{ fontSize: '0.72rem', color: '#ff6b6b', fontWeight: 600, textAlign: 'center', lineHeight: 1.3 }}>Attendre<br/>et choisir plus tard</span>
              </div>
              {/* Bouton Accepter — vert */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                <button onClick={handleConfirm} disabled={!placeName.trim() || !time || isTimeTooSoon} style={{
                  width: 72, height: 72, borderRadius: '50%',
                  background: (placeName.trim() && time && !isTimeTooSoon) ? 'radial-gradient(circle at 35% 35%, #55e87a, #1a9c3e)' : 'radial-gradient(circle at 35% 35%, #3a3a3a, #222)',
                  border: '3px solid rgba(255,255,255,0.15)',
                  boxShadow: (placeName.trim() && time && !isTimeTooSoon) ? '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(30,200,80,0.35)' : '0 6px 0 rgba(0,0,0,0.4)',
                  cursor: (placeName.trim() && time && !isTimeTooSoon) ? 'pointer' : 'default', fontSize: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  opacity: (placeName.trim() && time && !isTimeTooSoon) ? 1 : 0.45,
                  transition: 'transform 0.1s ease, box-shadow 0.1s ease',
                }}
                  onPointerDown={e => { if (placeName.trim() && time && !isTimeTooSoon) { e.currentTarget.style.transform = 'translateY(3px) scale(0.93)'; e.currentTarget.style.filter = 'brightness(2.5)'; e.currentTarget.style.boxShadow = '0 2px 0 rgba(0,0,0,0.4)'; }}}
                  onPointerUp={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; e.currentTarget.style.boxShadow = (placeName.trim() && time && !isTimeTooSoon) ? '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(30,200,80,0.35)' : '0 6px 0 rgba(0,0,0,0.4)'; }}
                  onPointerLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.filter = ''; e.currentTarget.style.boxShadow = (placeName.trim() && time && !isTimeTooSoon) ? '0 6px 0 rgba(0,0,0,0.4), 0 0 18px rgba(30,200,80,0.35)' : '0 6px 0 rgba(0,0,0,0.4)'; }}
                >✅</button>
                <span style={{ fontSize: '0.72rem', color: (placeName.trim() && time && !isTimeTooSoon) ? '#59d39a' : '#555', fontWeight: 600, textAlign: 'center', lineHeight: 1.3 }}>Proposer<br/>ce lieu</span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}