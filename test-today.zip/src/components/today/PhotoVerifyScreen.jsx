import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { loadFaceAPI } from '../../lib/face-api-loader';
import useOverlayBack from '../../hooks/useOverlayBack';
import { X, Camera, RefreshCw, Check, AlertCircle } from 'lucide-react';

// Écran de vérification locale de la photo 1 par reconnaissance faciale.
// - Ouvre la caméra avant uniquement (getUserMedia facingMode: 'user').
// - Aucun choix dans la galerie : la selfie est capturée depuis le flux vidéo.
// - Compare le descripteur 128-D de la photo 1 avec celui de la selfie.
// - Distance euclidienne ≤ 0.5 → photo1_verified = true.
// - > 0.5 → « Le visage ne correspond pas », 2ᵉ essai. Deux échecs → bloqué.
// - 0 ou plusieurs visages → refus immédiat, ne compte pas comme un échec.
// - La selfie est jetée après le calcul, jamais envoyée au serveur.

const THRESHOLD = 0.5;
const MAX_FAILURES = 2;

export default function PhotoVerifyScreen({ photoUrl, onSuccess, onBlocked, onClose, bgTheme }) {
  useOverlayBack(true, onClose);
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const faceapiRef = useRef(null);
  const [status, setStatus] = useState('loading'); // loading | camera | analyzing | success | fail | no_face | multi_face | blocked | error
  const [failCount, setFailCount] = useState(0);
  const [message, setMessage] = useState('');

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
  }, []);

  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      setStatus('camera');
    } catch (e) {
      console.error('Camera access failed:', e);
      setMessage(`Accès caméra refusé. Autorise la caméra dans les réglages de ton navigateur.`);
      setStatus('error');
    }
  }, []);

  // Charger face-api + modèles, puis démarrer la caméra
  useEffect(() => {
    let cancelled = false;
    loadFaceAPI()
      .then(api => {
        if (cancelled) return;
        faceapiRef.current = api;
        startCamera();
      })
      .catch(e => {
        if (cancelled) return;
        console.error('face-api load failed:', e);
        setMessage(`Impossible de charger la vérification. Vérifie ta connexion internet.`);
        setStatus('error');
      });
    return () => {
      cancelled = true;
      stopCamera();
    };
  }, []);

  function loadImg(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      if (!src.startsWith('data:')) img.crossOrigin = 'anonymous';
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('Image load failed'));
      img.src = src;
    });
  }

  function euclideanDistance(d1, d2) {
    let sum = 0;
    for (let i = 0; i < d1.length; i++) {
      const diff = d1[i] - d2[i];
      sum += diff * diff;
    }
    return Math.sqrt(sum);
  }

  async function handleCapture() {
    if (!faceapiRef.current || !videoRef.current) return;
    const faceapi = faceapiRef.current;
    const video = videoRef.current;
    setStatus('analyzing');
    setMessage('');

    try {
      // Capture selfie depuis le flux vidéo (canvas en mémoire — jamais affiché ni envoyé)
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const selfieDataUrl = canvas.toDataURL('image/jpeg', 0.8);

      // Charger les deux images
      const [photo1Img, selfieImg] = await Promise.all([
        loadImg(photoUrl),
        loadImg(selfieDataUrl),
      ]);

      const options = new faceapi.SsdMobilenetv1Options({ minConfidence: 0.5 });

      // Détection sur la photo 1
      const photo1Dets = await faceapi
        .detectAllFaces(photo1Img, options)
        .withFaceLandmarks()
        .withFaceDescriptors();

      if (photo1Dets.length === 0) {
        setMessage(`Aucun visage détecté sur ta photo 1. Change ta photo et réessaie.`);
        setStatus('no_face');
        return;
      }
      if (photo1Dets.length > 1) {
        setMessage(`Plusieurs visages sur ta photo 1. Utilise une photo avec un seul visage.`);
        setStatus('multi_face');
        return;
      }

      // Détection sur la selfie
      const selfieDets = await faceapi
        .detectAllFaces(selfieImg, options)
        .withFaceLandmarks()
        .withFaceDescriptors();

      if (selfieDets.length === 0) {
        setMessage(`Aucun visage détecté. Place ton visage bien face à la caméra.`);
        setStatus('no_face');
        return;
      }
      if (selfieDets.length > 1) {
        setMessage(`Plusieurs visages détectés. Assure-toi d\`être seul devant la caméra.`);
        setStatus('multi_face');
        return;
      }

      // Distance euclidienne entre les deux descripteurs 128-D
      const dist = euclideanDistance(photo1Dets[0].descriptor, selfieDets[0].descriptor);

      // Jeter la selfie immédiatement après le calcul
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (dist <= THRESHOLD) {
        setStatus('success');
        stopCamera();
        setTimeout(() => onSuccess(), 1200);
      } else {
        const nf = failCount + 1;
        setFailCount(nf);
        if (nf >= MAX_FAILURES) {
          setStatus('blocked');
          stopCamera();
        } else {
          setMessage(`Le visage ne correspond pas. Il te reste 1 essai.`);
          setStatus('fail');
        }
      }
    } catch (e) {
      console.error('Verification error:', e);
      setMessage(`Erreur lors de l\`analyse. Réessaie.`);
      setStatus('error');
    }
  }

  function handleRetry() {
    setMessage('');
    if (!streamRef.current) {
      startCamera();
    } else {
      setStatus('camera');
    }
  }

  function handleClose() {
    stopCamera();
    onClose?.();
  }

  // ── Rendu ──────────────────────────────────────────────────────────────────
  const overlayStyle = {
    position: 'fixed', inset: 0, zIndex: 10000,
    background: 'rgba(0,0,0,0.96)', backdropFilter: 'blur(16px)',
    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
    padding: '24px',
  };

  const btnPrimary = {
    padding: '14px 32px', borderRadius: '999px', border: 'none',
    background: 'linear-gradient(135deg, #cc1a4d, #ff3366)', color: '#fff',
    fontWeight: 700, fontSize: '1rem', fontFamily: 'inherit', cursor: 'pointer',
    boxShadow: '0 8px 24px rgba(255,51,102,0.4)', display: 'flex', alignItems: 'center', gap: '10px',
  };

  const btnSecondary = {
    ...btnPrimary,
    background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)',
    boxShadow: 'none',
  };

  const spinner = (
    <div style={{ width: 48, height: 48, border: '3px solid rgba(255,255,255,0.15)', borderTopColor: '#ff3366', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
  );

  return createPortal(
    <div style={overlayStyle}>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>

      {/* Close button */}
      {status !== 'analyzing' && status !== 'success' && (
        <button onClick={handleClose} style={{
          position: 'absolute', top: 'calc(env(safe-area-inset-top) + 16px)', right: '20px',
          width: 40, height: 40, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.12)',
          background: 'rgba(255,255,255,0.06)', color: '#fff', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <X size={20} />
        </button>
      )}

      {/* Title */}
      {status !== 'success' && (
        <h2 style={{
          position: 'absolute', top: 'calc(env(safe-area-inset-top) + 20px)', left: 0, right: 0,
          textAlign: 'center', color: '#fff', fontSize: '1.2rem', fontWeight: 800,
          fontFamily: "'EB Garamond', serif", fontStyle: 'italic', margin: 0, pointerEvents: 'none',
        }}>
          Vérifie ta photo
        </h2>
      )}

      {/* Content by status */}
      {status === 'loading' && (
        <div style={{ textAlign: 'center', color: '#9f9fae' }}>
          {spinner}
          <p style={{ marginTop: 16, fontSize: '0.9rem' }}>Chargement de la vérification…</p>
        </div>
      )}

      {(status === 'camera' || status === 'analyzing') && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20, width: '100%', maxWidth: 360 }}>
          <div style={{
            position: 'relative', width: '100%', aspectRatio: '3/4', borderRadius: 24,
            overflow: 'hidden', border: '2px solid rgba(255,51,102,0.3)',
            background: '#0a0a0d',
          }}>
            <video
              ref={node => {
                videoRef.current = node;
                if (node && streamRef.current && node.srcObject !== streamRef.current) {
                  node.srcObject = streamRef.current;
                  node.play().catch(() => {});
                }
              }}
              autoPlay
              playsInline
              muted
              style={{ width: '100%', height: '100%', objectFit: 'cover', transform: 'scaleX(-1)' }}
            />
            {status === 'analyzing' && (
              <div style={{
                position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.7)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12,
              }}>
                {spinner}
                <span style={{ color: '#fff', fontSize: '0.9rem', fontWeight: 600 }}>Analyse en cours…</span>
              </div>
            )}
          </div>

          {status === 'camera' && (
            <>
              <p style={{ color: '#9f9fae', fontSize: '0.85rem', textAlign: 'center', lineHeight: 1.5, margin: 0 }}>
                Regarde la caméra et capture une selfie.<br />On compare ton visage avec ta photo 1.
              </p>
              <button onClick={handleCapture} style={btnPrimary}>
                <Camera size={20} />
                Capturer
              </button>
            </>
          )}
        </div>
      )}

      {status === 'success' && (
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: 80, height: 80, borderRadius: '50%', margin: '0 auto 20px',
            background: 'rgba(89,211,154,0.15)', border: '2px solid #59d39a',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Check size={40} color="#59d39a" strokeWidth={3} />
          </div>
          <h3 style={{ color: '#fff', fontSize: '1.3rem', fontWeight: 800, margin: 0 }}>Photo vérifiée !</h3>
          <p style={{ color: '#9f9fae', fontSize: '0.9rem', marginTop: 8 }}>Tu peux maintenant enregistrer ta carte.</p>
        </div>
      )}

      {(status === 'fail' || status === 'no_face' || status === 'multi_face' || status === 'error') && (
        <div style={{ textAlign: 'center', maxWidth: 320 }}>
          <div style={{
            width: 72, height: 72, borderRadius: '50%', margin: '0 auto 16px',
            background: status === 'fail' ? 'rgba(255,51,102,0.15)' : 'rgba(244,193,98,0.15)',
            border: status === 'fail' ? '2px solid #ff3366' : '2px solid #f4c162',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <AlertCircle size={36} color={status === 'fail' ? '#ff3366' : '#f4c162'} />
          </div>
          <p style={{ color: '#fff', fontSize: '1rem', fontWeight: 600, lineHeight: 1.5, margin: '0 0 24px' }}>
            {message}
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
            <button onClick={handleClose} style={btnSecondary}>Annuler</button>
            <button onClick={handleRetry} style={btnPrimary}>
              <RefreshCw size={18} />
              Réessayer
            </button>
          </div>
        </div>
      )}

      {status === 'blocked' && (
        <div style={{ textAlign: 'center', maxWidth: 320 }}>
          <div style={{
            width: 72, height: 72, borderRadius: '50%', margin: '0 auto 16px',
            background: 'rgba(255,51,102,0.15)', border: '2px solid #ff3366',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <AlertCircle size={36} color="#ff3366" />
          </div>
          <h3 style={{ color: '#fff', fontSize: '1.15rem', fontWeight: 800, margin: '0 0 8px' }}>Photo non vérifiée</h3>
          <p style={{ color: '#9f9fae', fontSize: '0.9rem', lineHeight: 1.5, margin: '0 0 24px' }}>
            Ta photo n'a pas pu être vérifiée après 2 essais.<br />Change ta photo 1 et réessaie.
          </p>
          <button onClick={() => { stopCamera(); onBlocked?.(); }} style={btnPrimary}>
            Fermer
          </button>
        </div>
      )}
    </div>,
    document.body
  );
}