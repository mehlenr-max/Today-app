import React, { useRef, useState } from 'react';
import { RefreshCw } from 'lucide-react';

// Geste « tirer vers le bas » pour recharger une liste.
// L'actualisation se déclenche à la fin du geste (relâchement), une fois la
// liste revenue en haut.
const MIN_PULL = 16;
const MAX_PULL = 70;

function isAtTop(el) {
  let node = el;
  while (node && node !== document.body) {
    if (node.scrollTop > 2) return false;
    node = node.parentElement;
  }
  return window.scrollY <= 2;
}

// `inline` : mode « flux naturel » — le geste fonctionne toujours mais le
// composant n'est plus un conteneur de défilement ni un cadre rognant.
// Le seul défileur reste le conteneur parent (structure de l'onglet Flamme).
export default function PullToRefresh({ onRefresh, children, style, inline = false }) {
  const wrapRef = useRef(null);
  const startYRef = useRef(null);
  const pullRef = useRef(0);
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  function handleTouchStart(e) {
    if (refreshing || !onRefresh) return;
    startYRef.current = isAtTop(wrapRef.current) ? e.touches[0].clientY : null;
  }

  function handleTouchMove(e) {
    if (startYRef.current == null || refreshing) return;
    if (!isAtTop(wrapRef.current)) {
      startYRef.current = null;
      pullRef.current = 0;
      setPull(0);
      return;
    }
    const delta = e.touches[0].clientY - startYRef.current;
    if (delta <= 0) {
      pullRef.current = 0;
      setPull(0);
      return;
    }
    const capped = Math.min(delta * 0.5, MAX_PULL);
    pullRef.current = capped;
    setPull(capped);
  }

  function handleTouchEnd() {
    if (startYRef.current == null) return;
    startYRef.current = null;
    const distance = pullRef.current;
    pullRef.current = 0;
    if (distance <= MIN_PULL) {
      setPull(0);
      return;
    }
    setRefreshing(true);
    setPull(38);
    Promise.resolve(onRefresh?.()).finally(() => {
      setRefreshing(false);
      setPull(0);
    });
  }

  return (
    <div
      ref={wrapRef}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchEnd}
      style={inline
        ? { position: 'relative', touchAction: 'pan-y', ...style }
        : { position: 'relative', overflow: 'hidden', touchAction: 'pan-y', ...style }}
    >
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        height: refreshing ? 38 : Math.max(pull, 0),
        opacity: refreshing || pull > 0 ? 1 : 0,
        transition: 'opacity 0.15s ease',
        pointerEvents: 'none',
      }}>
        <RefreshCw
          size={18}
          className={refreshing ? 'animate-spin' : ''}
          style={{ color: '#ff69b4', opacity: refreshing ? 1 : Math.min(1, pull / MAX_PULL) }}
        />
      </div>
      {/* La translation n'est appliquée que pendant le geste : une transform
          permanente ferait de ce div le bloc de positionnement des fenêtres
          en position fixe rendues plus bas (elles seraient écrasées). */}
      <div style={inline
        ? {
          ...(pull > 0 ? { transform: `translateY(${pull}px)`, willChange: 'transform' } : null),
          transition: pull > 0 && !refreshing ? 'none' : 'transform 0.2s ease',
        }
        : {
          height: '100%',
          display: 'flex', flexDirection: 'column', minHeight: 0,
          ...(pull > 0 ? { transform: `translateY(${pull}px)`, willChange: 'transform' } : null),
          transition: pull > 0 && !refreshing ? 'none' : 'transform 0.2s ease',
        }}>
        {children}
      </div>
    </div>
  );
}