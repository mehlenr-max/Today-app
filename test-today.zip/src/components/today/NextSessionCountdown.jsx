import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../lib/i18n/LanguageContext';

// Renvoie l'état du cycle jeudi/samedi à "maintenant" (Europe/Bruxelles).
// - Jeudi ou samedi → "Ce Soir"
// - Vendredi → compte à rebours vers samedi 00:00
// - Dimanche→mercredi → compte à rebours vers jeudi 00:00
function getScheduleState(now) {
  // Jour de la semaine + heure dans le fuseau Europe/Bruxelles (= Europe/Paris)
  const fmt = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/Brussels',
    weekday: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit',
    hour12: false,
  });
  const parts = fmt.formatToParts(now);
  const get = (type) => parts.find(p => p.type === type)?.value || '';
  const weekday = get('weekday'); // Mon, Tue, Wed, Thu, Fri, Sat, Sun
  const hour = Number(get('hour')) === 24 ? 0 : Number(get('hour'));
  const minute = Number(get('minute'));
  const second = Number(get('second'));

  const isLive = weekday === 'Thu' || weekday === 'Sat';

  // Calcul de la date "aujourd'hui" à minuit dans le fuseau Brussels,
  // pour construire la cible à minuit du jour voulu.
  // On reconstruit un Date local Brussels à partir des composants.
  const partsDate = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/Brussels', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(now);
  const y = Number(partsDate.find(p => p.type === 'year')?.value);
  const m = Number(partsDate.find(p => p.type === 'month')?.value);
  const d = Number(partsDate.find(p => p.type === 'day')?.value);

  // Construit un Date UTC représentant minuit Brussels du jour J (en tenant
  // compte de l'offset DST). Brussels = UTC+1 ou UTC+2.
  function midnightBrussels(daysToAdd) {
    // On prend la date civile Brussels (y,m,d) + daysToAdd, à 00:00 Brussels.
    // Pour obtenir un timestamp UTC correspondant, on calcule d'abord un Date
    // à midi UTC du jour civil (pour éviter les ambiguïtés DST), puis on
    // ajuste à minuit Brussels.
    const base = new Date(Date.UTC(y, m - 1, d + daysToAdd, 12, 0, 0));
    // minuit Brussels = 00:00 locale. On obtient l'offset à cette date en
    // comparant la représentation Brussels à l'UTC.
    const asBrussels = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Europe/Brussels', year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
    }).formatToParts(base);
    const bY = Number(asBrussels.find(p => p.type === 'year')?.value);
    const bM = Number(asBrussels.find(p => p.type === 'month')?.value);
    const bD = Number(asBrussels.find(p => p.type === 'day')?.value);
    const bH = Number(asBrussels.find(p => p.type === 'hour')?.value) === 24 ? 0 : Number(asBrussels.find(p => p.type === 'hour')?.value);
    const bMin = Number(asBrussels.find(p => p.type === 'minute')?.value);
    // Différence entre midi UTC et l'heure Brussels correspondante → offset.
    // On veut minuit Brussels = base - (bH heures + bMin minutes) - 12h? Non.
    // base = midi UTC. L'heure Brussels de base = midi + offset.
    // minuit Brussels du même jour civil Brussels = base - (bH*3600 + bMin*60)*1000.
    return new Date(base.getTime() - (bH * 3600 + bMin * 60) * 1000);
  }

  if (isLive) {
    return { live: true, label: 'Ce Soir', target: null };
  }

  // Sinon : prochaine cible = jeudi 00:00 ou samedi 00:00.
  // weekday index: Sun=0..Sat=6 (JS getDay), mais ici on a les abbr.
  const dayIndex = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[weekday];
  let targetDayIndex; // 4 (jeudi) ou 6 (samedi)
  if (dayIndex === 5) {
    // vendredi → samedi prochain (demain)
    targetDayIndex = 6;
  } else {
    // dimanche..mercredi → jeudi prochain
    targetDayIndex = 4;
  }
  let daysToAdd = (targetDayIndex - dayIndex + 7) % 7;
  const target = midnightBrussels(daysToAdd);

  return { live: false, label: null, target, daysToAdd, targetDayIndex, hour, minute, second };
}

function formatRemaining(ms) {
  if (ms < 0) ms = 0;
  const totalSec = Math.floor(ms / 1000);
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const pad = (n) => String(n).padStart(2, '0');
  if (days > 0) return `${days}j ${pad(hours)}:${pad(mins)}:${pad(secs)}`;
  return `${pad(hours)}:${pad(mins)}:${pad(secs)}`;
}

const DAY_LABELS = { Thu: 'Jeudi', Sat: 'Samedi' };

export default function NextSessionCountdown({ theme, compact = false }) {
  // Le texte du chrono est traduit directement au rendu : le moteur DOM n'a plus à
  // réécrire le nœud chaque seconde (ce qui faisait clignoter le compte à rebours
  // en anglais et en néerlandais).
  const { t: translateText } = useLanguage();
  const [now, setNow] = useState(() => new Date());
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const state = getScheduleState(now);
  const t = theme;

  // Mode compact : statut sous le badge du header (jour exact + chrono)
  if (compact) {
    if (state.live) {
      return (
        <span style={{
          display: 'inline-flex', alignItems: 'center', gap: '7px',
          fontSize: '1.05rem', fontWeight: 700, fontFamily: 'inherit',
          color: '#ff3366', whiteSpace: 'nowrap',
        }}>
          <span style={{
            width: 8, height: 8, borderRadius: '50%', background: '#ff3366',
            boxShadow: '0 0 6px rgba(255,51,102,0.9)', animation: 'pulseDot 1.8s ease-in-out infinite',
          }} />
          Ce Soir
        </span>
      );
    }
    const dayLabel = DAY_LABELS[state.targetDayIndex === 4 ? 'Thu' : 'Sat'] || 'Jeudi';
    const remaining = state.target ? state.target.getTime() - now.getTime() : 0;
    return (
      <span style={{
        display: 'inline-flex', alignItems: 'center', gap: '8px',
        fontSize: '1.05rem', fontWeight: 800, fontFamily: 'inherit',
        color: t?.light ? '#555' : '#cfcfda', whiteSpace: 'nowrap',
      }}>
        <span style={{ color: '#ff3366' }}>{dayLabel}</span>
        <span style={{ fontVariantNumeric: 'tabular-nums', fontSize: '1.15rem', fontWeight: 700 }}>
          {mounted ? translateText(formatRemaining(remaining)) : '⏳'}
        </span>
      </span>
    );
  }

  if (state.live) {
    return (
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px',
        padding: '12px 18px', borderRadius: '16px',
        background: t.light ? 'rgba(255,51,102,0.1)' : 'rgba(255,51,102,0.14)',
        border: `1px solid ${t.light ? 'rgba(255,51,102,0.35)' : 'rgba(255,51,102,0.4)'}`,
        boxShadow: t.light ? '0 4px 18px rgba(255,51,102,0.12)' : '0 0 22px rgba(255,51,102,0.18)',
      }}>
        <span style={{
          width: 8, height: 8, borderRadius: '50%', background: '#ff3366',
          boxShadow: '0 0 10px rgba(255,51,102,0.9)', animation: 'pulseDot 1.8s ease-in-out infinite',
        }} />
        <span style={{
          fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800,
          fontSize: '1.15rem', color: t.light ? t.pinkStrong : '#ff69b4', letterSpacing: '0.02em',
        }}>
          Ce Soir
        </span>
      </div>
    );
  }

  const remaining = state.target ? state.target.getTime() - now.getTime() : 0;
  const label = state.daysToAdd === 1 ? 'Demain · Ce Soir' : null;

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px',
      padding: '12px 18px', borderRadius: '16px',
      background: t.light ? 'rgba(0,0,0,0.04)' : 'rgba(255,255,255,0.05)',
      border: `1px solid ${t.light ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.1)'}`,
    }}>
      <span style={{
        fontSize: '0.62rem', textTransform: 'uppercase', letterSpacing: '0.14em',
        fontWeight: 700, color: t.textMuted,
      }}>
        {label || (state.daysToAdd <= 1 ? 'Prochaine session' : 'Prochain date')}
      </span>
      <span style={{
        fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800,
        fontSize: '1.5rem', color: t.light ? t.pinkStrong : '#ff69b4',
        fontVariantNumeric: 'tabular-nums', letterSpacing: '0.02em',
        lineHeight: 1.1,
      }}>
        {mounted ? translateText(formatRemaining(remaining)) : '⏳'}
      </span>
    </div>
  );
}