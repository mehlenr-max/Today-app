import React, { useState } from 'react';
import { base44 } from '../../api/base44Client';
import toast from 'react-hot-toast';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleEmailSubmit(e) {
    e?.preventDefault?.();
    if (!email || !password) { toast.error('Remplis tous les champs'); return; }
    setSubmitting(true);
    try {
      await base44.auth.loginViaEmailPassword(email, password);
      // Reload to pick up the token and enter the app
      window.location.href = '/home';
    } catch (err) {
      toast.error('Email ou mot de passe incorrect');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div style={{
      minHeight: '100dvh',
      background: 'radial-gradient(circle at 16% 16%, rgba(255,51,102,0.22) 0%, transparent 24%), radial-gradient(circle at 86% 18%, rgba(255,105,180,0.14) 0%, transparent 22%), linear-gradient(180deg, #070709 0%, #040405 42%, #030304 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '32px 20px',
      gap: '20px',
      fontFamily: "'Poppins', sans-serif",
    }}>
      {/* Logo */}
      <img src="https://media.base44.com/images/public/69b91874189d1f38a8e07d5f/13012b7bc_image_19ee64c32.jpg" alt="ToDay" style={{ width: '260px', objectFit: 'contain', mixBlendMode: 'screen' }} />

      {/* Form card */}
      <div style={{
        width: '100%',
        maxWidth: '360px',
        background: 'rgba(15,15,19,0.92)',
        border: '1px solid rgba(255,255,255,0.14)',
        borderRadius: '24px',
        padding: '24px 20px',
        display: 'flex',
        flexDirection: 'column',
        gap: '14px',
      }}>
        <h2 style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontSize: '1.5rem', fontWeight: 700, margin: '0 0 4px', color: '#fff' }}>
          Se connecter
        </h2>
        <p style={{ margin: 0, color: '#9f9fae', fontSize: '0.88rem', lineHeight: 1.5 }}>
          Accède à ton compte ToDay.
        </p>

        {/* Email / password form */}
        <form onSubmit={handleEmailSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            autoComplete="email"
            required
            style={{
              width: '100%', padding: '12px 16px', borderRadius: '14px',
              border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.04)',
              color: '#fff', fontSize: '0.95rem', fontFamily: 'inherit', outline: 0,
            }}
          />
          <input
            type="password"
            placeholder="Mot de passe"
            value={password}
            onChange={e => setPassword(e.target.value)}
            autoComplete="current-password"
            required
            minLength={6}
            style={{
              width: '100%', padding: '12px 16px', borderRadius: '14px',
              border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.04)',
              color: '#fff', fontSize: '0.95rem', fontFamily: 'inherit', outline: 0,
            }}
          />
          <button
            type="submit"
            disabled={submitting}
            style={{
              width: '100%', padding: '0 18px', minHeight: '52px', borderRadius: '999px',
              fontWeight: 700, fontSize: '1rem',
              background: submitting ? 'rgba(255,51,102,0.4)' : 'linear-gradient(90deg, #ff3366, #ff69b4)',
              color: '#fff', boxShadow: '0 12px 24px rgba(255,51,102,0.22)',
              border: 'none', cursor: submitting ? 'default' : 'pointer', fontFamily: 'inherit',
            }}
          >
            {submitting ? '⏳' : 'Se connecter'}
          </button>
        </form>

        {/* Toggle login / register */}
        <button
          onClick={() => window.location.href = '/register'}
          style={{ background: 'none', border: 'none', color: '#9f9fae', fontSize: '0.82rem', cursor: 'pointer', fontFamily: 'inherit', padding: 0 }}
        >
          Pas de compte ? Crée-en un
        </button>


      </div>

      <p style={{ color: '#9f9fae', fontSize: '0.78rem', textAlign: 'center', margin: 0 }}>
        100% gratuit · Belgique
      </p>

      {/* Liens légaux — exigés par l'App Store avant inscription */}
      <div style={{ display: 'flex', gap: '16px', justifyContent: 'center', flexWrap: 'wrap', marginTop: '4px' }}>
        <a href="/privacy" style={{ color: '#9f9fae', fontSize: '0.72rem', textDecoration: 'underline' }}>Politique de confidentialité</a>
        <a href="/terms" style={{ color: '#9f9fae', fontSize: '0.72rem', textDecoration: 'underline' }}>Conditions d'utilisation</a>
      </div>
    </div>
  );
}