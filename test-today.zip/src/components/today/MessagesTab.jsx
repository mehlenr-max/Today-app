import React, { useState, useMemo, useRef, useCallback } from 'react';
import SkeletonLoader from './SkeletonLoader';
import { base44 } from '../../api/base44Client';
import { getParisDateKey } from '../../lib/today-data';
import { clearThreadMessagesExceptConfirmed, invalidateCache, removeMessageActionForToday } from '../../lib/today-store';
import { isQuizMessage } from '../../lib/quiz-messages';
import { motion } from 'framer-motion';
import { RefreshCw } from 'lucide-react';
import MessageGroupCard from './MessageGroupCard';
import PlaceSelectorModal from './PlaceSelectorModal';
import useProfilesMap from '../../hooks/useProfilesMap';
import PullToRefresh from './PullToRefresh';
import { computeWillBlock } from '../../lib/cancel-block';
import toast from 'react-hot-toast';

export default function MessagesTab({ userId, messages, setMessagesOptimistic, sessionState, onAction, onRefresh, onMarkAccepted, onMarkPassed, onAddMessage, onClearMessages, myProfile, prefs, bgTheme, onBlock, onCancelDate, onChangePlace, onDateCancelled, resetToken }) {
  const [choosePlace, setChoosePlace] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const { profilesMap, loading: loadingProfiles } = useProfilesMap(userId);

  async function handleManualRefresh() {
    if (refreshing) return;
    setRefreshing(true);
    try {
      await onRefresh?.();
    } finally {
      setTimeout(() => setRefreshing(false), 600);
    }
  }

  const [deletingThread, setDeletingThread] = useState(null);

  // Suivi des messages entrants non lus, fil par fil : chaque fil garde son propre
  // repère de lecture, indépendamment de l'ordre d'arrivée ou du moment du rafraîchissement.
  const threadSeenKey = `threadSeen:${userId}:${getParisDateKey()}`;
  const baselineSeenRef = useRef(localStorage.getItem(`lastMessageTimestamp:${userId}:${getParisDateKey()}`) || '');
  const [threadSeen, setThreadSeen] = useState(() => {
    try { return JSON.parse(localStorage.getItem(threadSeenKey) || '{}'); } catch { return {}; }
  });
  const [seenVersion, setSeenVersion] = useState(0);

  // Suspension : "suspendue" — Reprise : "à nouveau disponible" ou "reprend"
  const isSystemStatusMsg = (m) => {
    if (!m.is_system) return false;
    const t = m.text || '';
    return t.includes('suspendue') || t.includes('à nouveau disponible') || t.includes('reprend');
  };

  const getAction = (m) => {
    if (m.action) return m.action;
    if (m.action_json) {
      try { return typeof m.action_json === 'string' ? JSON.parse(m.action_json) : m.action_json; } catch { return null; }
    }
    return null;
  };

  const newThreadNames = useMemo(() => {
    const set = new Set();
    // Seule la PREMIÈRE interaction du fil compte : un défi reçu avant toute autre
    // échange. Les interactions suivantes s'affichent normalement, sans indicateur.
    const firstByThread = {};
    messages.forEach(m => {
      // Les jeux (onglet 🎲) ne créent ni thread ni "Nouveau message de X" ici
      if (isQuizMessage(m)) return;
      if (!m.id || String(m.id).startsWith('optimistic_')) return;
      if (isSystemStatusMsg(m)) return; // pas de banner pour les suspensions/reprises
      const name = m.profile_name || m.thread_key;
      if (!name) return;
      const prev = firstByThread[name];
      if (!prev || (m.created_date || '') < (prev.created_date || '')) firstByThread[name] = m;
    });
    Object.entries(firstByThread).forEach(([name, m]) => {
      if (m.sender === 'Vous' || m.sender === 'Système') return; // première interaction = la nôtre
      const action = getAction(m);
      if (action?.type !== 'incomingChallenge') return; // uniquement un défi reçu
      const since = threadSeen[name] ?? baselineSeenRef.current;
      if ((m.created_date || '') > since) set.add(name);
    });
    return set;
  }, [messages, threadSeen, seenVersion]);

  const markThreadSeen = useCallback((profileName) => {
    setThreadSeen(prev => {
      const next = { ...prev, [profileName]: new Date().toISOString() };
      try { localStorage.setItem(threadSeenKey, JSON.stringify(next)); } catch {}
      return next;
    });
    setSeenVersion(v => v + 1);
  }, [threadSeenKey]);

  async function handleDeleteThread(profileName, msgs) {
    if (deletingThread) return;
    setDeletingThread(profileName);
    try {
      // Supprimer TOUS les messages du thread depuis la DB (visibles + masqués par le filtre),
      // pas seulement les messages visibles passés en argument.
      const dk = getParisDateKey();
      const threadMsgs = await base44.entities.UserMessage.filter({ user_id: userId, date_key: dk, $or: [{ profile_name: profileName }, { thread_key: profileName }] });
      const idsToDelete = new Set();
      threadMsgs.forEach(m => { if (m.id) idsToDelete.add(m.id); });
      msgs.forEach(m => { if (m.id && !String(m.id).startsWith('optimistic_')) idsToDelete.add(m.id); });
      await Promise.all([...idsToDelete].map(id => base44.entities.UserMessage.delete(id).catch(e => console.error('UserMessage.delete failed:', e))));
      await onRefresh?.();
    } catch (e) {
      console.error('delete thread failed', e);
    } finally {
      setDeletingThread(null);
    }
  }

  function getTimeRemaining(msgs) {
    // Plus de chrono : on retire la limite de 1h pour proposer un lieu ou répondre.
    return null;
  }

  const dateAlreadyAccepted = sessionState?.hasAccepted;

  const { filtered, winnerThreads } = useMemo(() => {
    const refusedProfiles = new Set();
    messages.forEach(m => {
      if (m.text.includes('Pas de match') && m.action?.state !== 'closed') {
        if (m.profile_name) refusedProfiles.add(m.profile_name);
        const match = m.text.match(/(?:refusé la proposition de|annulé le rendez-vous avec)\s+([^.]+)/);
        if (match) refusedProfiles.add(match[1].trim());
      }
    });

    const confirmedThreads = new Set();
    messages.forEach(m => {
      if ((m.text?.includes('Date confirmé') || m.text?.includes('date confirmé')) && m.action?.state !== 'closed') {
        if (m.profile_name) confirmedThreads.add(m.profile_name);
        if (m.thread_key) confirmedThreads.add(m.thread_key);
      }
    });

    const winnerThreads = new Set();
    messages.forEach(m => {
      if (m.text.includes('Tu as gagné') || m.text.includes('Tu gagnes') || m.action?.type === 'winnerChoosePlace' || m.text.includes('Tu as proposé')) {
        const name = m.profile_name || m.thread_key;
        if (name) winnerThreads.add(name);
      }
    });

    const filtered = messages.filter(m => {
      if (m.text.includes('Tu as refusé la proposition')) return true;
      if (m.text.includes('Pas de match')) return true;
      // Les jeux vivent uniquement dans l'onglet 🎲 — jamais dans la boîte à messages
      if (isQuizMessage(m)) return false;
      if (m.profile_name && refusedProfiles.has(m.profile_name)) return false;
      for (const profileName of refusedProfiles) {
        if (m.text.includes(profileName)) return false;
      }
      if (dateAlreadyAccepted && (m.action?.type === 'incomingChallenge' || m.action?.type === 'winnerChoosePlace')) return false;
      if (dateAlreadyAccepted && m.action?.type === 'loserAccept' && !m.action?.isPlaceChange) return false;
      const threadName = m.profile_name || m.thread_key;
      if (threadName && confirmedThreads.has(threadName)) {
        return m.text?.includes('Date confirmé') || m.text?.includes('date confirmé')
          || m.action?.type === 'dateCardDrawn'
          || m.action?.type === 'dateCardReceived'
          || m.text?.includes('pioché un gage')
          || m.text?.includes('a pioché un gage');
      }
      return m.text.includes('Résultat PPC') || m.text.includes('Date confirmé') || m.text.includes('Date annulé') || m.text.includes('Tu gagnes') || m.text.includes('te propose') || m.text.includes('Tu as perdu') || m.text.includes('En attente') || m.text.includes("attente d'acceptation") || m.text.includes('Tu as changé le lieu') || m.text.includes('Nouveau lieu proposé') || m.text.includes('a refusé ta proposition') || m.text.includes("n'est plus disponible") || m.text.includes("est à nouveau disponible") || m.text.includes("t'envoie un défi") || m.action?.type === 'incomingChallenge' || m.action?.type === 'loserAccept' || m.action?.type === 'playerTurn' || m.action?.type === 'winnerChoosePlace' || m.text.includes('suspendue') || m.text.includes('reprend');
    });

    return { filtered, winnerThreads };
  }, [messages, dateAlreadyAccepted]);

  const willBlockMap = useMemo(() => {
    const map = {};
    messages.forEach(m => {
      const name = m.profile_name || m.thread_key;
      if (name && !(name in map)) {
        const threadMessages = messages.filter(mm => (mm.profile_name || mm.thread_key) === name);
        map[name] = computeWillBlock(threadMessages);
      }
    });
    return map;
  }, [messages]);

  const groupedEntries = useMemo(() => {
    const grouped = {};
    filtered.forEach((msg) => {
      let profileName = msg.profile_name;
      if (!profileName) {
        const m1 = msg.text.match(/avec\s+([^\n!:]+)/);
        const m2 = msg.text.match(/^([^\s:]+)\s+(?:t'envoie|te propose|gagne|gagnes)/);
        profileName = (m1?.[1] || m2?.[1] || 'Inconnu').trim();
      }
      if (!grouped[profileName]) grouped[profileName] = [];
      grouped[profileName].push(msg);
    });
    // Thread prioritaire : contient un "Date confirmé" actif OU un message
    // demandant une action du destinataire (défi, choix de lieu, acceptation).
    // Ces threads restent épinglés en haut, même s'ils ne sont pas les plus récents.
    const isActionMsg = (m) => {
      if (m.text?.includes('Date confirmé') && m.action?.state !== 'closed') return true;
      let action = m.action;
      if (!action && m.action_json) {
        try { action = typeof m.action_json === 'string' ? JSON.parse(m.action_json) : m.action_json; } catch {}
      }
      if (!action || action.state === 'closed') return false;
      return ['incomingChallenge', 'loserAccept', 'playerTurn', 'winnerChoosePlace', 'refusalWithReasons'].includes(action.type);
    };
    const isPriorityThread = (msgs) => msgs.some(isActionMsg);
    // Timestamp du message d'action le plus récent du thread — détermine l'ordre
    // parmi les threads prioritaires : la nouvelle action monte en haut et
    // pousse les anciennes vers le bas, par ordre chronologique.
    const latestActionTs = (msgs) => {
      let ts = '';
      for (const m of msgs) {
        if (isActionMsg(m) && (m.created_date || '') > ts) ts = m.created_date || '';
      }
      return ts;
    };
    // Annulation d'un date confirmé — placée tout au-dessus, au-dessus des autres
    // threads prioritaires. "Date annulé" = annulation après confirmation (vs
    // "Pas de match" = annulation avant confirmation, non prioritaire).
    const isCancelledConfirmed = (m) => m.text?.includes('Date annulé');
    const hasCancel = (msgs) => msgs.some(isCancelledConfirmed);
    const latestCancelTs = (msgs) => {
      let ts = '';
      for (const m of msgs) {
        if (isCancelledConfirmed(m) && (m.created_date || '') > ts) ts = m.created_date || '';
      }
      return ts;
    };

    // ── Thread du date en cours : épinglé tout en haut de la liste ──
    // Le profil avec qui on a un date confirmé passe devant tout le reste. Un date est
    // actif tant que le thread contient un « Date confirmé » et qu'aucune annulation
    // (« Date annulé » / « Pas de match ») ne l'a clôturé — dès l'annulation du date,
    // le thread reprend l'ordre normal.
    const hasLiveDate = (msgs) => {
      if (msgs.some(m => m.text?.includes('Date annulé') || m.text?.includes('Pas de match'))) return false;
      return msgs.some(m => m.text?.includes('Date confirmé'));
    };
    return Object.entries(grouped).sort(([, msgsA], [, msgsB]) => {
      const dateA = hasLiveDate(msgsA);
      const dateB = hasLiveDate(msgsB);
      if (dateA !== dateB) return dateA ? -1 : 1;
      const cancelA = hasCancel(msgsA);
      const cancelB = hasCancel(msgsB);
      if (cancelA && !cancelB) return -1;
      if (!cancelA && cancelB) return 1;
      if (cancelA && cancelB) {
        const ta = latestCancelTs(msgsA);
        const tb = latestCancelTs(msgsB);
        return tb > ta ? 1 : tb < ta ? -1 : 0;
      }
      const prioA = isPriorityThread(msgsA);
      const prioB = isPriorityThread(msgsB);
      if (prioA && !prioB) return -1;
      if (!prioA && prioB) return 1;
      if (prioA && prioB) {
        const ta = latestActionTs(msgsA);
        const tb = latestActionTs(msgsB);
        return tb > ta ? 1 : tb < ta ? -1 : 0;
      }
      const timeA = getTimeRemaining(msgsA);
      const timeB = getTimeRemaining(msgsB);
      const hasTimerA = msgsA.some(m => m.timerStartTime || m.timer_start_time);
      const hasTimerB = msgsB.some(m => m.timerStartTime || m.timer_start_time);
      const expiredA = hasTimerA && timeA <= 0;
      const expiredB = hasTimerB && timeB <= 0;
      if (expiredA && !expiredB) return 1;
      if (!expiredA && expiredB) return -1;
      const lastA = msgsA[msgsA.length - 1]?.created_date || '';
      const lastB = msgsB[msgsB.length - 1]?.created_date || '';
      return lastB > lastA ? 1 : -1;
    });
  }, [filtered]);

  if (loadingProfiles) {
    return (
      <div className="flex flex-col h-full min-h-0">
        <div className="px-4 py-3 border-b border-white/6">
          <div className="text-pink-400 uppercase tracking-widest text-xs font-bold mb-2">Historique</div>
          <div style={{ height: 28, width: '60%', borderRadius: 8, background: 'rgba(255,255,255,0.06)' }} />
        </div>
        <div className="flex-1 min-h-0 overflow-y-auto overscroll-y-contain p-4 space-y-3.5">
          <SkeletonLoader type="messages" count={3} />
        </div>
      </div>
    );
  }

  if (filtered.length === 0) {
    return (
      <PullToRefresh onRefresh={handleManualRefresh} style={{ flex: 1, minHeight: 0 }}>
        <div className="flex flex-col items-center justify-center min-h-full p-6 text-center">
          <h3 className={`text-xl font-black italic font-garamond mb-2 ${bgTheme === 'white' ? 'text-gray-900' : 'text-white'}`}>Pas encore de matches</h3>
          <p className="text-gray-500 text-sm">Va défier des profils pour remporter des matchs !</p>
        </div>
      </PullToRefresh>
    );
  }

  return (
    // Hauteur définie (h-full + min-h-0) : la liste imbriquée dans PullToRefresh
    // obtient une hauteur réelle et devient réellement défilable sur Android.
    <div className="flex flex-col h-full min-h-0">
      <div className={`px-4 py-3 border-b ${bgTheme === 'white' ? 'border-black/10' : 'border-white/6'}`}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="text-pink-500 uppercase tracking-widest text-xs font-bold mb-2">Historique</div>
            <h2 className={`text-2xl font-black italic font-garamond ${bgTheme === 'white' ? 'text-gray-900' : 'text-white'}`}>Matchs {'&'} Résultats</h2>
          </div>
          <button
            onClick={handleManualRefresh}
            disabled={refreshing}
            className={`flex-shrink-0 mt-5 p-2 rounded-full border transition-all ${refreshing ? 'opacity-50' : 'hover:bg-pink-500/10'} ${bgTheme === 'white' ? 'border-black/10 text-gray-600' : 'border-white/10 text-gray-400'}`}
            title="Rafraîchir les messages"
          >
            <RefreshCw size={18} className={refreshing ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      <PullToRefresh onRefresh={handleManualRefresh} style={{ flex: 1, minHeight: 0 }}>
      <div className="flex-1 min-h-0 overflow-y-auto overscroll-y-contain p-4 pb-32 space-y-3.5">
        {groupedEntries.map(([profileName, msgs]) => {
            // Chercher le user_id de l'autre personne dans les messages du thread
            // (profile_id est stable, contrairement au display_name qui peut changer)
            const otherUserId = msgs.find(m => m.profile_id)?.profile_id || null;
            const willBlock = willBlockMap[profileName] || false;
            // Lookup par user_id d'abord, fallback par display_name
            const dbProfile = (otherUserId && profilesMap[otherUserId]) || profilesMap[profileName] || null;
            const threadProfile = dbProfile ? {
              id: dbProfile.id,
              user_id: dbProfile.user_id,
              name: dbProfile.display_name,
              photo: dbProfile.photo_url || '',
              photo_url_2: dbProfile.photo_url_2 || '',
              photo_url_3: dbProfile.photo_url_3 || '',
              age: dbProfile.age,
              city: dbProfile.city,
              fiveWords: dbProfile.five_words || '',
              quizPhrase: dbProfile.quiz_phrase || '',
              ownPhysicalTraits: dbProfile.own_physical_traits || [],
              ownPersonalityTraits: dbProfile.own_personality_traits || [],
              personal_flaws: dbProfile.personal_flaws || [],
              desired_physical_traits: dbProfile.desired_physical_traits || [],
              education: dbProfile.education || '',
              job: dbProfile.job || '',
              height: dbProfile.height || null,
              gender: dbProfile.gender || '',
              astro_sign: dbProfile.astro_sign || '',
              astro_ascendant: dbProfile.astro_ascendant || '',
              time_slot: dbProfile.time_slot || '',
            } : null;

            return (
            <MessageGroupCard
              key={profileName}
              profileName={profileName}
              resetToken={resetToken}
              messages={msgs}
              isNew={newThreadNames.has(profileName)}
              onMarkSeen={() => markThreadSeen(profileName)}
              threadProfile={threadProfile}
              willBlock={willBlock}
              myProfile={myProfile}
              prefs={prefs}
              bgTheme={bgTheme}
              onChoosePlace={(msg) => setChoosePlace({ msg, profileName: profileName.trim() })}
              showEditButton={!dateAlreadyAccepted}
              timeRemaining={getTimeRemaining(msgs)}
              hasAccepted={dateAlreadyAccepted}
              onBlock={onBlock}
              otherUserId={threadProfile?.user_id}
              isWinner={winnerThreads.has(profileName)}
              onCancelDate={onCancelDate}
              onChangePlace={onChangePlace}
              onRefresh={onRefresh}
              onDeleteThread={handleDeleteThread}
              onAction={async (action) => {
                if (action.type === 'incomingChallenge' || action.type === 'playerTurn' || action.type === 'winnerChoosePlace') {
                  onAction?.(action);
                } else if (action.type === 'acceptPlace') {
                  // Optimistic: retirer immédiatement l'action loserAccept pour masquer les boutons
                  setMessagesOptimistic?.(prev => prev.map(m => {
                    if (m.profile_name !== action.profileName || !m.action_json) return m;
                    try {
                      const a = JSON.parse(m.action_json);
                      if (a?.type === 'loserAccept') return { ...m, action_json: null, action: null };
                    } catch {}
                    return m;
                  }));
                  // 1. Tenter le lock atomique côté backend AVANT onMarkAccepted.
                  // Le backend valide qu'un message loserAccept existe encore (d'où l'ordre).
                  if (action.winnerUserId && action.loserName) {
                    try {
                      const res = await base44.functions.invoke('deliverResult', {
                        type: 'notifyWinnerConfirmed',
                        winnerUserId: action.winnerUserId,
                        loserName: action.loserName,
                        loserUserId: userId,
                        place: action.place,
                        dateKey: getParisDateKey(),
                      });
                      if (res.data?.blocked) {
                        // Lock perdu — le gagnant a déjà un date confirmé ailleurs
                        toast.error('Le date a déjà été confirmé avec une autre personne.');
                        await removeMessageActionForToday(userId, 'loserAccept', action.profileName);
                        await onRefresh?.();
                        return;
                      }
                    } catch (e) {
                      console.error('notifyWinnerConfirmed failed:', e);
                      toast.error('Erreur lors de la confirmation. Réessaie.');
                      await onRefresh?.();
                      return;
                    }
                  }
                  // 2. Lock gagné — procéder avec les flags + message local (en parallèle)
                  await Promise.all([
                    onMarkAccepted?.({ profileId: action.profileId, profileName: action.profileName, place: action.place }),
                    onAddMessage?.({
                      user_id: userId,
                      sender: 'Vous',
                      text: `✅ Date confirmé !\n📍 ${action.place}`,
                      is_system: true,
                      profile_name: action.profileName,
                      profile_id: action.winnerUserId || '',
                      thread_key: action.profileName,
                    }),
                    removeMessageActionForToday(userId, 'loserAccept', action.profileName),
                  ]);
                  onRefresh?.(); // fire-and-forget — l'optimistic update affiche déjà le résultat
                } else if (action.type === 'passPlace' || action.type === 'passPlaceWithReasons') {
                  const reasons = action.type === 'passPlaceWithReasons' ? (action.reasons || []) : [];
                  const hasPersonal = reasons.includes('personal');
                  const REASON_LABELS = { place: "L'endroit", food: "La nourriture", personal: "Raisons personnelles" };
                  const reasonsText = reasons.map(r => REASON_LABELS[r] || r).join(', ');
                  const reasonsSuffix = reasonsText ? `\nRaison(s) : ${reasonsText}` : '';

                  // Le backend décide si le refus est DÉFINITIF (raison personnelle OU 3ᵉ proposition refusée)
                  let finalRefusal = hasPersonal;
                  if (action.winnerUserId && action.loserName) {
                    try {
                      const res = await base44.functions.invoke('deliverResult', {
                        type: 'notifyWinnerRefused',
                        winnerUserId: action.winnerUserId,
                        loserName: action.loserName,
                        dateKey: getParisDateKey(),
                        reasons,
                      });
                      finalRefusal = res.data?.finalRefusal ?? hasPersonal;
                    } catch (e) {
                      console.error('notifyWinnerRefused failed:', e);
                      toast.error('Erreur lors du refus. Réessaie.');
                      await onRefresh?.();
                      return;
                    }
                  }

                  // Optimistic: retirer immédiatement l'action loserAccept pour masquer les boutons
                  setMessagesOptimistic?.(prev => prev.map(m => {
                    if (m.profile_name !== action.profileName || !m.action_json) return m;
                    try {
                      const a = JSON.parse(m.action_json);
                      if (a?.type === 'loserAccept') return { ...m, action_json: null, action: null };
                    } catch {}
                    return m;
                  }));

                  if (finalRefusal) {
                    // Refus DÉFINITIF — paralléliser les 3 écritures indépendantes
                    await Promise.all([
                      removeMessageActionForToday(userId, 'loserAccept', action.profileName),
                      onMarkPassed?.(action.profileId),
                      onAddMessage?.({
                        user_id: userId,
                        sender: 'Vous',
                        text: `❌ Tu as refusé la proposition de ${action.profileName}. Pas de match.${reasonsSuffix}\nVous ne pouvez plus vous défier aujourd'hui.`,
                        is_system: true,
                        profile_name: action.profileName,
                        thread_key: action.profileName,
                      }),
                    ]);
                    invalidateCache(userId);
                    onDateCancelled?.(); // fire-and-forget — les mises à jour locales sont instantanées
                  } else {
                    // Cas A : refus NON définitif — paralléliser suppression d'action + message
                    await Promise.all([
                      removeMessageActionForToday(userId, 'loserAccept', action.profileName),
                      onAddMessage?.({
                        user_id: userId,
                        sender: 'Vous',
                        text: `❌ Tu as refusé la proposition de ${action.profileName}.\nRaison(s) : ${reasonsText}\n${action.profileName} peut te proposer un autre lieu.`,
                        is_system: true,
                        profile_name: action.profileName,
                        thread_key: action.profileName,
                      }),
                    ]);
                  }
                  onRefresh?.(); // fire-and-forget — l'optimistic update affiche déjà le résultat
                }
              }}
            />
            );
          })}
      </div>
      </PullToRefresh>

      <PlaceSelectorModal
        isOpen={!!choosePlace}
        profileName={choosePlace?.profileName}
        onConfirm={async (place, time) => {
          if (userId && choosePlace) {
            await onMarkAccepted?.({ profileId: choosePlace.msg.profile_name, profileName: choosePlace.profileName, place, time });
            await clearThreadMessagesExceptConfirmed(userId, choosePlace.profileName);
            await onAddMessage?.({
              user_id: userId,
              sender: 'Vous',
              text: `✅ Date confirmé avec ${choosePlace.profileName} !\n📍 Lieu : ${place}\n⏰ Heure : ${time}`,
              is_system: false,
              profile_name: choosePlace.profileName,
              thread_key: choosePlace.profileName,
            });
            setChoosePlace(null);
          }
        }}
        onClose={() => setChoosePlace(null)}
      />
    </div>
  );
}