import React, { useState, useRef, useEffect, useCallback, useMemo, Suspense } from 'react';
import ReactDOM from 'react-dom';
import { CITIES } from '../../lib/today-data';
import { calcAgeFromDate } from '../../lib/today-data';
import { Camera, Check, ChevronDown } from 'lucide-react';
import { base44 } from '../../api/base44Client';
import { compressImage } from '../../lib/image-utils';
import SelectModal from './SelectModal';
const PhotoVerifyScreen = React.lazy(() => import('@/components/today/PhotoVerifyScreen'));
import { saveCreatePrefs } from '../../lib/today-store';
import { hasFace } from '../../lib/face-detection';
import { isSafePhoto } from '../../lib/nsfw-detection';
import { findInsult } from '../../lib/insult-filter';

// Données statiques à l'extérieur du composant (pas de recréation à chaque render)

const EDUCATION_OPTIONS = [
  { id: 'lycee', label: '🎓 Secondaire' },
  { id: 'bts', label: '📋 École supérieure / Technique' },
  { id: 'licence', label: '📚 Licence / Bachelor' },
  { id: 'master', label: '🏛️ Master / Grande école' },
  { id: 'doctorat', label: '🔬 Doctorat' },
  { id: 'autodidacte', label: '🌱 Autodidacte' },
];

const JOB_OPTIONS = [
  { id: 'etudiant', label: '🎒 Étudiant·e' },
  { id: 'salarie', label: '💼 Salarié·e' },
  { id: 'entrepreneur', label: '🚀 Entrepreneur·e' },
  { id: 'freelance', label: '💻 Freelance' },
  { id: 'artistique', label: '🎨 Artiste / Créatif·ve' },
  { id: 'sante', label: '🏥 Santé' },
  { id: 'enseignement', label: '📖 Enseignement' },
  { id: 'tech', label: '⚙️ Ingénieur·e / Tech' },
  { id: 'commerce', label: '📈 Commerce / Finance' },
  { id: 'sans_emploi', label: '🌿 Sans emploi' },
  { id: 'horeca', label: '🍽️ Horeca' },
];

const MORPHOLOGIES_WOMEN = [
  { id: 'fine', label: 'Fine / Élancée', emoji: '🪶', desc: 'Silhouette mince et longue · Apparence légère · Traits fins' },
  { id: 'sportive', label: 'Sportive / Tonique', emoji: '🏃‍♀️', desc: 'Corps ferme et actif · Silhouette dessinée · Apparence dynamique' },
  { id: 'equilibree', label: 'Équilibrée / Naturelle', emoji: '⚖️', desc: 'Proportions harmonieuses · Morphologie moyenne · Aspect classique équilibré' },
  { id: 'pulpeuse', label: 'Formes douces / Pulpeuse', emoji: '🌸', desc: 'Courbes visibles · Silhouette arrondie · Apparence féminine marquée' },
  { id: 'genereuse', label: 'Généreuse / Forte présence', emoji: '🌺', desc: 'Morphologie plus large · Présence physique assumée · Corps solide et visible' },
  { id: 'peu_importe', label: 'Peu importe', emoji: '🤷', desc: 'Je préfère ne pas préciser ma morphologie' },
];

const MORPHOLOGIES_MEN = [
  { id: 'elance', label: 'Élancé / Fin', emoji: '🪶', desc: 'Silhouette mince · Membres longs · Apparence légère' },
  { id: 'athletique', label: 'Athlétique', emoji: '💪', desc: 'Corps tonique / musclé · Épaules larges · Aspect sportif' },
  { id: 'normal', label: 'Normal / Équilibré', emoji: '⚖️', desc: 'Morphologie moyenne · Proportions harmonieuses' },
  { id: 'rond', label: 'Rond / Doux', emoji: '🌸', desc: 'Formes arrondies · Silhouette généreuse · Traits doux' },
  { id: 'massif', label: 'Massif / Solide', emoji: '🪨', desc: 'Ossature large · Présence physique forte · Corps robuste' },
  { id: 'peu_importe', label: 'Peu importe', emoji: '🤷', desc: 'Je préfère ne pas préciser ma morphologie' },
];

const MAX_PHOTO_FILE_SIZE = 2 * 1024 * 1024; // 2 Mo

async function processPhotoFile(file, quality = 0.6) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = async (ev) => {
      let dataUrl = ev.target.result;
      if (file.size > MAX_PHOTO_FILE_SIZE) {
        dataUrl = await compressImage(dataUrl, 800, 1200, quality);
      }
      resolve(dataUrl);
    };
    reader.readAsDataURL(file);
  });
}

const PHOTO_COOLDOWN_MS = 3 * 24 * 60 * 60 * 1000;

function getPhotoCountdownText(lastUpdate) {
  if (!lastUpdate) return null;
  const elapsed = Date.now() - new Date(lastUpdate).getTime();
  const remaining = PHOTO_COOLDOWN_MS - elapsed;
  if (remaining <= 0) return null;
  const days = Math.floor(remaining / (24 * 60 * 60 * 1000));
  const hours = Math.floor((remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  if (days > 0) return `⏳ Prochain changement de photo dans ${days} jour${days > 1 ? 's' : ''} et ${hours}h`;
  if (hours > 0) return `⏳ Prochain changement de photo dans ${hours}h`;
  return `⏳ Prochain changement de photo bientôt`;
}

function getPhotoCountdownFromMs(remainingMs) {
  const days = Math.floor(remainingMs / (24 * 60 * 60 * 1000));
  const hours = Math.floor((remainingMs % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  if (days > 0) return `⏳ Prochain changement de photo dans ${days} jour${days > 1 ? 's' : ''} et ${hours}h`;
  if (hours > 0) return `⏳ Prochain changement de photo dans ${hours}h`;
  return `⏳ Prochain changement de photo bientôt`;
}

function getPhotoCountdownShort(lastUpdate) {
  if (!lastUpdate) return null;
  const elapsed = Date.now() - new Date(lastUpdate).getTime();
  const remaining = PHOTO_COOLDOWN_MS - elapsed;
  if (remaining <= 0) return null;
  const days = Math.floor(remaining / (24 * 60 * 60 * 1000));
  const hours = Math.floor((remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  if (days > 0) return `⏳ ${days}j ${hours}h`;
  if (hours > 0) return `⏳ ${hours}h`;
  return `⏳ bientôt`;
}

export default function CardSetupTab({ user, existingProfile, isActive, onSaved, onBack, onSeekingChanged, bgTheme }) {
   const isWhite = bgTheme === 'white';

   const inputStyle = {
     width: '100%', border: isWhite ? '1px solid rgba(0,0,0,0.12)' : '1px solid rgba(255,255,255,0.08)', borderRadius: '18px',
     background: isWhite ? 'rgba(0,0,0,0.03)' : 'rgba(255,255,255,0.04)', color: isWhite ? '#111' : '#fff', padding: '14px 16px',
     outline: 0, fontFamily: 'inherit', fontSize: '0.95rem',
   };

   const labelStyle = {
     display: 'block', marginBottom: '6px', color: isWhite ? '#666' : '#9f9fae',
     fontSize: '0.68rem', letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700,
   };

   const card = {
     borderRadius: '22px', border: isWhite ? '1px solid rgba(0,0,0,0.08)' : '1px solid rgba(255,255,255,0.06)',
     background: isWhite ? 'rgba(255,255,255,0.75)' : 'rgba(15,15,19,0.72)', backdropFilter: 'blur(16px)',
     boxShadow: isWhite ? '0 2px 12px rgba(0,0,0,0.06)' : 'inset 0 1px 0 rgba(255,255,255,0.04)',
     padding: '18px',
   };

   const [photo, setPhoto] = useState(null);
   const [photoPreview, setPhotoPreview] = useState(existingProfile?.photo_url || '');
   const [photoPreview2, setPhotoPreview2] = useState(existingProfile?.photo_url_2 || '');
   const [photoPreview3, setPhotoPreview3] = useState(existingProfile?.photo_url_3 || '');
   const [activePhotoSlot, setActivePhotoSlot] = useState(1);
   const [seeking, setSeeking] = useState(existingProfile?.seeking || '');
   const [isVegetarian, setIsVegetarian] = useState(existingProfile?.is_vegetarian || false);
   const [fiveWords, setFiveWords] = useState(existingProfile?.five_words || '');
   const [displayName, setDisplayName] = useState(existingProfile?.display_name || '');
   const [birthDate, setBirthDate] = useState(existingProfile?.birth_date || '');
   const [gender, setGender] = useState(existingProfile?.gender || '');
   const [city, setCity] = useState(existingProfile?.city || 'Bruxelles');
   const [morphology, setMorphology] = useState(existingProfile?.own_physical_traits?.[0] || '');
   const [education, setEducation] = useState(existingProfile?.education || '');
   const [job, setJob] = useState(existingProfile?.job || '');
   const [height, setHeight] = useState(existingProfile?.height || '');
   const [saving, setSaving] = useState(false);
   const [error, setError] = useState('');
   const [faceChecking, setFaceChecking] = useState(false);
   const [faceVerified, setFaceVerified] = useState(!!existingProfile?.photo_url);
   const [pendingVerificationPhoto, setPendingVerificationPhoto] = useState(null);
   const [verifiedPhotoSrc, setVerifiedPhotoSrc] = useState(null);
   const fileRef = useRef();
   const fileRef2 = useRef();
   const fileRef3 = useRef();
   const [showFlash, setShowFlash] = useState(false);
   const [showLovePopup, setShowLovePopup] = useState(false);
   const [showCityPicker, setShowCityPicker] = useState(false);

   // Auto-effacement du message d'erreur après 3 secondes
   useEffect(() => {
     if (!error) return;
     const t = setTimeout(() => setError(''), 3000);
     return () => clearTimeout(t);
   }, [error]);

   const morphologies = useMemo(() => gender === 'fille' ? MORPHOLOGIES_WOMEN : MORPHOLOGIES_MEN, [gender]);

   const computedAge = calcAgeFromDate(birthDate);
   // Date enregistrée, affichée en clair dans son champ (JJ/MM/AAAA)
   const formattedBirthDate = birthDate ? birthDate.split('-').reverse().join('/') : '';
   const isValid = useMemo(() =>
     !!photoPreview && !!displayName.trim() && computedAge != null && computedAge >= 18 && computedAge <= 99 && !!gender && !!seeking &&
     !!morphology &&
     !!height && Number(height) >= 140 && Number(height) <= 230 && !!education && !!job,
     [photoPreview, displayName, birthDate, gender, seeking, morphology, height, education, job]
   );

   // Recharger les données si le profil existant change
   useEffect(() => {
     if (existingProfile) {
       setPhotoPreview(existingProfile.photo_url || '');
       setPhotoPreview2(existingProfile.photo_url_2 || '');
       setPhotoPreview3(existingProfile.photo_url_3 || '');
       setDisplayName(existingProfile.display_name || '');
       setBirthDate(existingProfile.birth_date || '');
       setGender(existingProfile.gender || '');
       setCity(existingProfile.city || 'Bruxelles');
       setFiveWords(existingProfile.five_words || '');
       setMorphology(existingProfile.own_physical_traits?.[0] || '');
       setEducation(existingProfile.education || '');
       setJob(existingProfile.job || '');
       setHeight(existingProfile.height || '');
       setSeeking(existingProfile.seeking || '');
       setIsVegetarian(existingProfile.is_vegetarian || false);
       setFaceVerified(!!existingProfile.photo_url);
       }
       }, [existingProfile?.id]);

  // Photo principale : une fois les contrôles passés, on enchaîne directement sur la
  // vérification faciale (les filtres photo ont été retirés).
  const confirmMainPhoto = useCallback((src) => {
    if (!src) return;
    if (src !== photoPreview && src !== verifiedPhotoSrc) {
      setPendingVerificationPhoto(src);
      return;
    }
    setPhotoPreview(src);
  }, [photoPreview, verifiedPhotoSrc]);

  // Quota global : 3 changements de photos tous les 3 jours, tous slots confondus
  // Un premier upload sur un slot vide ne compte pas comme changement
  const canChangePhoto = useCallback((slot) => {
    const slotHasPhoto = slot === 1 ? !!existingProfile?.photo_url : slot === 2 ? !!existingProfile?.photo_url_2 : !!existingProfile?.photo_url_3;
    if (!slotHasPhoto) return true;
    const WINDOW_MS = 3 * 24 * 60 * 60 * 1000;
    const MAX_CHANGES = 3;
    const history = Array.isArray(existingProfile?.photo_change_history) ? existingProfile.photo_change_history : [];
    const now = Date.now();
    const recent = history.map(ts => new Date(ts).getTime()).filter(t => now - t < WINDOW_MS);
    if (recent.length >= MAX_CHANGES) {
      const oldest = Math.min(...recent);
      const remaining = WINDOW_MS - (now - oldest);
      setError(getPhotoCountdownFromMs(remaining));
      return false;
    }
    return true;
  }, [existingProfile?.photo_change_history, existingProfile?.photo_url, existingProfile?.photo_url_2, existingProfile?.photo_url_3]);

  async function handleSave() {
    if (!photoPreview) { setError('Ajoute une photo 📸'); return; }
    if (photoPreview.startsWith('data:') && verifiedPhotoSrc !== photoPreview) {
      setPendingVerificationPhoto(photoPreview);
      return;
    }
    if (!faceVerified) { setError('📸 Photo non validée — assure-toi qu\'un visage est bien visible.'); return; }
    if (!displayName.trim()) { setError('Entre ton prénom ou pseudo.'); return; }
    const insult = findInsult(displayName);
    if (insult) { setError(`Le mot « ${insult} » est interdit.`); return; }
    // Vérifier l'unicité du pseudo (uniquement à la création — le champ est verrouillé ensuite)
    if (!existingProfile) {
      try {
        const res = await base44.functions.invoke('checkPseudoUnique', { displayName: displayName.trim() });
        if (!res.data?.available) { setError('Ce pseudo est déjà pris. Choisis-en un autre.'); return; }
      } catch (e) {
        console.error('checkPseudoUnique failed:', e);
        setError('Vérification du pseudo impossible. Réessaie.');
        return;
      }
    }
    const computedAgeSave = calcAgeFromDate(birthDate);
    if (!birthDate) { setError('Entre ta date de naissance.'); return; }
    if (computedAgeSave == null) { setError('Date de naissance invalide.'); return; }
    if (computedAgeSave < 18 || computedAgeSave > 99) { setError('Tu dois avoir entre 18 et 99 ans.'); return; }
    if (!gender) { setError('Choisis ton genre.'); return; }
    if (!seeking) { setError('Choisis ce que tu recherches.'); return; }
    if (!morphology) { setError('Choisis ta morphologie.'); return; }
    if (!height || Number(height) < 140 || Number(height) > 230) { setError('Entre ta taille (entre 140 et 230 cm).'); return; }
    if (!education) { setError('Choisis ton niveau d\'études.'); return; }
    if (!job) { setError('Choisis ta profession.'); return; }

    setSaving(true);
    setError('');

    let photoUrl = photoPreview;
    let photoUrl2 = photoPreview2;
    let photoUrl3 = photoPreview3;

    const uploadedSlots = {};

    // Upload photo 1
    if (photoPreview.startsWith('data:')) {
      const compressed = await compressImage(photoPreview);
      const res = await base44.functions.invoke('uploadPhoto', { base64: compressed, userId: user.id, slot: 1 });
      if (res.data?.url) { photoUrl = res.data.url; uploadedSlots[1] = true; }
      else {
        setSaving(false);
        if (res.data?.error === 'cooldown') {
          setError(getPhotoCountdownFromMs(res.data.remaining_ms));
        } else {
          setError('Erreur upload photo 1 : ' + (res.data?.error || 'Réessaie.'));
        }
        return;
      }
    }
    // Upload photo 2
    if (photoPreview2?.startsWith('data:')) {
      const compressed = await compressImage(photoPreview2);
      const res = await base44.functions.invoke('uploadPhoto', { base64: compressed, userId: user.id, slot: 2 });
      if (res.data?.url) { photoUrl2 = res.data.url; uploadedSlots[2] = true; }
      else if (res.data?.error === 'cooldown') {
        setSaving(false);
        setError(getPhotoCountdownFromMs(res.data.remaining_ms));
        return;
      }
    }
    // Upload photo 3
    if (photoPreview3?.startsWith('data:')) {
      const compressed = await compressImage(photoPreview3);
      const res = await base44.functions.invoke('uploadPhoto', { base64: compressed, userId: user.id, slot: 3 });
      if (res.data?.url) { photoUrl3 = res.data.url; uploadedSlots[3] = true; }
      else if (res.data?.error === 'cooldown') {
        setSaving(false);
        setError(getPhotoCountdownFromMs(res.data.remaining_ms));
        return;
      }
    }

    const seekingChanged = !!existingProfile?.seeking && existingProfile.seeking !== seeking;
    const payload = {
      user_id: user.id,
      display_name: displayName.trim(),
      age: computedAgeSave, birth_date: birthDate, gender, city, photo_url: photoUrl, photo_url_2: photoUrl2 || null, photo_url_3: photoUrl3 || null, seeking,
      is_vegetarian: isVegetarian,
      // Statut persistant : une sauvegarde de profil ne réactive pas un compte
      // resté volontairement hors ligne (explicitly_offline).
      is_online: !existingProfile?.explicitly_offline,
      ...(existingProfile?.explicitly_offline ? {} : { last_online_date: new Date().toISOString() }),
      own_physical_traits: morphology ? [morphology] : [],
      education,
      job,
      ...(height ? { height: Number(height) } : {}),
      ...(existingProfile?.quiz_phrase ? { quiz_phrase: existingProfile.quiz_phrase } : {}),
      ...(existingProfile?.five_words ? { five_words: existingProfile.five_words } : {}),
      ...(uploadedSlots[1] ? { last_photo_update_1: new Date().toISOString(), photo1_verified: verifiedPhotoSrc === photoPreview } : {}),
      ...(uploadedSlots[2] ? { last_photo_update_2: new Date().toISOString() } : {}),
      ...(uploadedSlots[3] ? { last_photo_update_3: new Date().toISOString() } : {}),
      ...(seekingChanged ? { create_prefs: null } : {}),
    };

    // Sauvegarde en DB
    try {
      const existing = await base44.entities.Profile.filter({ user_id: user.id });
      let saved;
      if (existing[0]) {
        saved = await base44.entities.Profile.update(existing[0].id, payload);
      } else {
        saved = await base44.entities.Profile.create(payload);
      }

      if (saved) {
        if (seekingChanged) {
          await saveCreatePrefs(user.id, null);
          onSeekingChanged?.();
        }
        setPhotoPreview(photoUrl);
        setPhotoPreview2(photoUrl2 || '');
        setPhotoPreview3(photoUrl3 || '');
        onSaved({ ...existingProfile, ...saved, ...payload });
        // Afficher le popup d'amour uniquement lors de la première création du profil
        if (!existing[0]) {
          setShowLovePopup(true);
          setTimeout(() => setShowLovePopup(false), 3000);
        }
      }
    } catch (err) {
      setError('Erreur sauvegarde : ' + err.message);
    }
    setSaving(false);
  }

  return (
    <>
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100%', paddingBottom: '8px' }}>
      <div style={{ padding: '16px 16px 12px', borderBottom: isWhite ? '1px solid rgba(0,0,0,0.08)' : '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', gap: '12px' }}>
        {onBack && (
          <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#ff69b4', fontSize: '1.4rem', cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            ←
          </button>
        )}
        <div>
          <div style={{ color: '#ff69b4', textTransform: 'uppercase', letterSpacing: '0.14em', fontSize: '0.72rem', fontWeight: 700 }}>Ma carte</div>
          <h2 style={{ margin: '4px 0 2px', fontSize: '1.4rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, color: isWhite ? '#111' : '#fff' }}>Le profil en petits blocs</h2>
          <p style={{ margin: 0, color: isWhite ? '#555' : '#9f9fae', fontSize: '0.82rem' }}>Configure ton profil pour être visible.</p>
        </div>
      </div>

      {/* Flux naturel, aucun défileur interne : le seul défileur est le conteneur
          de l'onglet (même structure que l'onglet Flamme). */}
      <div style={{ flex: 1, padding: '16px 16px 120px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
        {error && ReactDOM.createPortal(
          <div style={{
            position: 'fixed', top: 'calc(env(safe-area-inset-top) + 72px)', left: '50%', transform: 'translateX(-50%)',
            zIndex: 9000, maxWidth: 'calc(100vw - 24px)', width: 'auto',
            background: 'rgba(255,51,102,0.96)', border: '1px solid rgba(255,255,255,0.2)',
            borderRadius: '14px', padding: '10px 16px', color: '#fff', fontSize: '0.85rem', fontWeight: 600,
            boxShadow: '0 8px 24px rgba(255,51,102,0.35)', textAlign: 'center',
          }}>
            {error}
          </div>,
          document.body
        )}

        {/* Photos */}
        <div style={{ marginBottom: '4px', fontSize: '0.68rem', color: isWhite ? '#666' : '#9f9fae', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', flexWrap: 'wrap' }}>
          <span>Photos <span style={{ color: '#ff3366' }}>*</span> <span style={{ color: isWhite ? '#666' : '#9f9fae', fontWeight: 400, textTransform: 'none', letterSpacing: 0, fontSize: '0.75rem' }}>· 1 obligatoire, 2 et 3 optionnelles</span></span>
          {(() => {
            const WINDOW_MS = 3 * 24 * 60 * 60 * 1000;
            const history = Array.isArray(existingProfile?.photo_change_history) ? existingProfile.photo_change_history : [];
            const recent = history.map(ts => new Date(ts).getTime()).filter(t => Date.now() - t < WINDOW_MS);
            const remaining = Math.max(0, 3 - recent.length);
            const color = remaining === 0 ? '#ff4444' : remaining === 1 ? '#f4c162' : '#59d39a';
            return <span style={{ color, fontWeight: 700, fontSize: '0.7rem' }}>{remaining}/3 changements restants</span>;
          })()}
        </div>

        {/* Photo principale (grande) : ouverture native du sélecteur */}
        <label
          htmlFor="today-main-photo"
          style={{ display: 'block', position: 'relative', width: '100%', aspectRatio: '3/4', borderRadius: '20px', overflow: 'hidden', background: 'rgba(255,255,255,0.03)', border: `1px solid ${activePhotoSlot === 1 ? 'rgba(255,51,102,0.4)' : 'rgba(255,51,102,0.2)'}`, cursor: 'pointer', marginBottom: '10px' }}
          onClick={e => { setActivePhotoSlot(1); if (!canChangePhoto(1)) e.preventDefault(); }}
        >
          {photoPreview ? (
            <div style={{ position: 'relative', width: '100%', height: '100%' }}>
              <img src={photoPreview} alt="" style={{ width: '100%', height: '100%', objectFit: 'contain', background: '#0a0a0d' }} />
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', color: isWhite ? '#999' : '#9f9fae', gap: '8px' }}>
              <Camera size={32} />
              <span style={{ fontSize: '0.88rem' }}>{faceChecking ? '🔍 Analyse du visage...' : 'Photo principale'}</span>
            </div>
          )}
          <div style={{ position: 'absolute', top: 8, left: 8, background: 'rgba(255,51,102,0.85)', borderRadius: '8px', padding: '3px 8px', fontSize: '0.7rem', fontWeight: 800, color: '#fff' }}>1</div>

        </label>

        {/* Photos 2 et 3 (petites) */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '14px' }}>
          {[{ slot: 2, preview: photoPreview2, setPreview: setPhotoPreview2, ref: fileRef2 }, { slot: 3, preview: photoPreview3, setPreview: setPhotoPreview3, ref: fileRef3 }].map(({ slot, preview, setPreview, ref: slotRef }) => (
            <div key={slot}
              style={{ position: 'relative', aspectRatio: '3/4', borderRadius: '16px', overflow: 'hidden', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', cursor: 'pointer' }}
              onClick={() => { setActivePhotoSlot(slot); if (canChangePhoto(slot)) slotRef.current?.click(); }}
            >
              {preview ? (
                <>
                  <img src={preview} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', background: '#0a0a0d' }} />
                  <button onClick={e => { e.stopPropagation(); setPreview(''); }} style={{ position: 'absolute', top: 6, right: 6, width: 22, height: 22, borderRadius: '50%', background: 'rgba(0,0,0,0.7)', border: 'none', color: '#fff', fontSize: '0.7rem', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>✕</button>
                </>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', color: isWhite ? '#999' : '#9f9fae', gap: '6px' }}>
                  <Camera size={22} />
                  <span style={{ fontSize: '0.72rem' }}>Photo {slot}</span>
                </div>
              )}
              <div style={{ position: 'absolute', top: 6, left: 6, background: 'rgba(0,0,0,0.65)', borderRadius: '6px', padding: '2px 6px', fontSize: '0.65rem', fontWeight: 800, color: '#9f9fae' }}>{slot}</div>

            </div>
          ))}
        </div>

        <input id="today-main-photo" ref={fileRef} type="file" accept="image/*" className="sr-only" aria-label="Changer la photo principale" onClick={e => { e.currentTarget.value = ''; }} onChange={async e => {
          const f = e.target.files[0];
          if (f) {
            setPhoto(f);
            const src = await processPhotoFile(f, 0.7);
            setFaceChecking(true);
            setError('');
            const found = await hasFace(src);
            setFaceChecking(false);
            if (!found) {
              setError('😕 On ne voit pas de visage sur cette photo. Essaie avec une photo plus claire et de face.');
              return;
            }
            setFaceChecking(true);
            const safety = await isSafePhoto(src);
            setFaceChecking(false);
            if (!safety.safe) {
              setError(safety.error
                ? '⚠️ Analyse de sécurité indisponible. Vérifie ta connexion et réessaie.'
                : '🚫 Photo non conforme (contenu inapproprié détecté). Choisis une photo respectueuse.');
              return;
            }
            confirmMainPhoto(src);
          }
        }} />
        <input ref={fileRef2} type="file" accept="image/*" style={{ display: 'none' }} onChange={async e => {
          const f = e.target.files[0];
          if (f) {
            const src = await processPhotoFile(f, 0.5);
            setFaceChecking(true);
            setError('');
            const found = await hasFace(src);
            setFaceChecking(false);
            if (!found) {
              setError('😕 Pas de visage détecté sur la photo 2. Essaie avec une photo plus claire.');
              return;
            }
            setFaceChecking(true);
            const safety2 = await isSafePhoto(src);
            setFaceChecking(false);
            if (!safety2.safe) {
              setError(safety2.error
                ? '⚠️ Analyse de sécurité indisponible. Vérifie ta connexion et réessaie.'
                : '🚫 Photo 2 non conforme (contenu inapproprié détecté). Choisis une autre photo.');
              return;
            }
            setPhotoPreview2(src);
          }
        }} />
        <input ref={fileRef3} type="file" accept="image/*" style={{ display: 'none' }} onChange={async e => {
          const f = e.target.files[0];
          if (f) {
            const src = await processPhotoFile(f, 0.5);
            setFaceChecking(true);
            setError('');
            const found = await hasFace(src);
            setFaceChecking(false);
            if (!found) {
              setError('😕 Pas de visage détecté sur la photo 3. Essaie avec une photo plus claire.');
              return;
            }
            setFaceChecking(true);
            const safety3 = await isSafePhoto(src);
            setFaceChecking(false);
            if (!safety3.safe) {
              setError(safety3.error
                ? '⚠️ Analyse de sécurité indisponible. Vérifie ta connexion et réessaie.'
                : '🚫 Photo 3 non conforme (contenu inapproprié détecté). Choisis une autre photo.');
              return;
            }
            setPhotoPreview3(src);
          }
        }} />

        {/* Essentiel */}
        <div style={card}>
          <strong style={{ display: 'block', fontSize: '0.95rem', marginBottom: '6px', color: isWhite ? '#111' : '#fff' }}>Essentiel</strong>
          <div style={{ marginBottom: '12px' }}>
            <label style={labelStyle}>Prénom / Pseudo <span style={{ color: '#ff3366' }}>*</span>{existingProfile && <span style={{ marginLeft: 6, color: isWhite ? '#999' : '#9f9fae', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>🔒 verrouillé</span>}</label>
            <input value={displayName} disabled={!!existingProfile} onChange={e => {
              const val = e.target.value;
              const letters = val.replace(/[^a-zA-Z]/g, '').length;
              const digits = val.replace(/[^0-9]/g, '').length;
              if (letters <= 10 && digits <= 2) setDisplayName(val);
            }} placeholder="Ton prénom ou pseudo" style={{ ...inputStyle, ...(existingProfile ? { opacity: 0.65, cursor: 'not-allowed' } : {}) }} maxLength="12" />
          </div>

          <div style={{ marginTop: '10px' }}>
           <label style={labelStyle}>Naissance <span style={{ color: '#ff3366' }}>*</span>{existingProfile?.birth_date && <span style={{ marginLeft: 6, color: isWhite ? '#999' : '#9f9fae', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>🔒</span>}</label>
           {existingProfile?.birth_date ? (
             <div style={{ ...inputStyle, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', opacity: 0.85 }}>
               <span>{formattedBirthDate}</span>
               {computedAge != null && <span style={{ fontSize: '0.82rem', color: isWhite ? '#666' : '#9f9fae' }}>{computedAge} ans</span>}
             </div>
           ) : (
             <input type="date" value={birthDate} max={new Date().toISOString().split('T')[0]} onChange={e => setBirthDate(e.target.value)} style={{ ...inputStyle, boxSizing: 'border-box', maxWidth: '100%', paddingRight: '40px', colorScheme: isWhite ? 'light' : 'dark' }} />
           )}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginTop: '12px' }}>
           <div>
             <label style={labelStyle}>Taille (cm) <span style={{ color: '#ff3366' }}>*</span>{existingProfile && <span style={{ marginLeft: 6, color: isWhite ? '#999' : '#9f9fae', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>🔒</span>}</label>
             <input type="number" value={height} disabled={!!existingProfile} onChange={e => setHeight(e.target.value)} min="140" max="230" placeholder="175" style={{ ...inputStyle, ...(existingProfile ? { opacity: 0.65, cursor: 'not-allowed' } : {}) }} />
           </div>
           <div>
             <label style={labelStyle}>Ville</label>
             <button
               type="button"
               onClick={() => setShowCityPicker(true)}
               style={{ ...inputStyle, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', cursor: 'pointer', textAlign: 'left' }}
             >
               <span>{city}</span>
               <ChevronDown size={18} style={{ color: isWhite ? '#666' : '#9f9fae', flexShrink: 0 }} />
             </button>
             {showCityPicker && (
               <SelectModal
                 title="Ville"
                 options={CITIES}
                 value={city}
                 isWhite={isWhite}
                 onSelect={(c) => { setCity(c); setShowCityPicker(false); }}
                 onClose={() => setShowCityPicker(false)}
               />
             )}
           </div>
          </div>
          <div style={{ marginTop: '12px', marginBottom: '6px', fontSize: '0.68rem', color: isWhite ? '#666' : '#9f9fae', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700 }}>
            Genre <span style={{ color: '#ff3366' }}>*</span>
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            {['garçon', 'fille'].map(g => (
              <label key={g} style={{
                flex: 1, display: 'flex', alignItems: 'center', padding: '10px 14px',
                background: gender === g ? 'rgba(255,51,102,0.22)' : 'rgba(255,255,255,0.02)',
                border: gender === g ? '1px solid rgba(255,51,102,0.85)' : '1px solid rgba(255,255,255,0.08)',
                borderRadius: '16px', cursor: 'pointer', transition: 'all 0.2s ease',
              }}>
                <input type="radio" name="gender" checked={gender === g} onChange={() => { setGender(g); setMorphology(''); }}
                  style={{ appearance: 'none', width: 18, height: 18, borderRadius: '50%', border: '2px solid #cfcfda', marginRight: '8px', cursor: 'pointer',
                    background: gender === g ? '#ff3366' : 'transparent',
                    boxShadow: gender === g ? 'inset 0 0 0 3px rgba(15,18,28,0.8)' : 'none',
                  }} />
                <span style={{ fontSize: '0.95rem', fontWeight: 500, color: gender === g ? '#ff3366' : (isWhite ? '#111' : '#cfcfda') }}>{g === 'garçon' ? 'Garçon' : 'Fille'}</span>
              </label>
            ))}
          </div>

          <div style={{ marginTop: '16px', marginBottom: '6px', fontSize: '0.68rem', color: isWhite ? '#666' : '#9f9fae', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700 }}>
            Je cherche <span style={{ color: '#ff3366' }}>*</span>
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            {['garçon', 'fille'].map(g => (
              <button key={g} type="button" onClick={() => setSeeking(g)} style={{
                flex: 1, minHeight: '44px', borderRadius: '999px',
                border: seeking === g ? '1px solid rgba(255,51,102,0.85)' : '1px solid rgba(255,255,255,0.08)',
                background: seeking === g ? 'rgba(255,51,102,0.22)' : 'rgba(255,255,255,0.03)',
                color: seeking === g ? '#ff3366' : (isWhite ? '#111' : '#cfcfda'), fontWeight: 700, fontSize: '0.95rem',
                cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.08s ease',
              }}>{g === 'garçon' ? 'Un garçon' : 'Une fille'}</button>
            ))}
          </div>

          {/* Végétarien */}
          <div style={{ marginTop: '16px', marginBottom: '6px', fontSize: '0.68rem', color: isWhite ? '#666' : '#9f9fae', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700 }}>
            Végétarien
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            {[{ v: false, label: 'Non' }, { v: true, label: 'Oui' }].map(opt => (
              <button key={String(opt.v)} type="button" onClick={() => setIsVegetarian(opt.v)} style={{
                flex: 1, minHeight: '44px', borderRadius: '999px',
                border: isVegetarian === opt.v ? '1px solid rgba(255,51,102,0.85)' : '1px solid rgba(255,255,255,0.08)',
                background: isVegetarian === opt.v ? 'rgba(255,51,102,0.22)' : 'rgba(255,255,255,0.03)',
                color: isVegetarian === opt.v ? '#ff3366' : (isWhite ? '#111' : '#cfcfda'), fontWeight: 700, fontSize: '0.95rem',
                cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.08s ease',
              }}>{opt.label}</button>
            ))}
          </div>
        </div>

        {/* Morphologie */}
        <div style={card}>
          <strong style={{ display: 'block', fontSize: '0.95rem', marginBottom: '4px', color: isWhite ? '#111' : '#fff' }}>Ma morphologie <span style={{ color: '#ff3366' }}>*</span></strong>
          <p style={{ margin: '0 0 14px', fontSize: '0.82rem', color: isWhite ? '#555' : '#9f9fae' }}>Quel choix te décrit le mieux ?</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {morphologies.map(m => {
              const selected = morphology === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMorphology(m.id)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '14px',
                    padding: '14px 16px', borderRadius: '16px', cursor: 'pointer',
                    border: selected ? '1px solid rgba(255,51,102,0.85)' : '1px solid rgba(255,255,255,0.07)',
                    background: selected ? 'rgba(255,51,102,0.22)' : 'rgba(255,255,255,0.02)',
                    transition: 'all 0.12s ease', fontFamily: 'inherit', textAlign: 'left',
                    boxShadow: selected ? '0 0 20px rgba(255,51,102,0.4)' : 'none',
                  }}
                  onPointerDown={e => { e.currentTarget.style.transform = 'scale(0.98)'; }}
                  onPointerUp={e => { e.currentTarget.style.transform = ''; }}
                  onPointerLeave={e => { e.currentTarget.style.transform = ''; }}
                >
                  <span style={{ fontSize: '1.8rem', flexShrink: 0 }}>{m.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: '0.95rem', color: selected ? '#ff3366' : (isWhite ? '#111' : '#fff'), marginBottom: '2px' }}>{m.label}</div>
                    <div style={{ fontSize: '0.75rem', color: isWhite ? '#555' : '#9f9fae', lineHeight: 1.4 }}>{m.desc}</div>
                  </div>
                  <div style={{
                    width: 20, height: 20, borderRadius: '50%', flexShrink: 0,
                    border: selected ? '1px solid #ff3366' : '1px solid rgba(255,255,255,0.3)',
                    background: selected ? '#ff3366' : 'transparent',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {selected && <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#fff' }} />}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Études & Profession */}
        <div style={card}>
          <strong style={{ display: 'block', fontSize: '0.95rem', marginBottom: '14px', color: isWhite ? '#111' : '#fff' }}>Études & Profession</strong>
          <label style={labelStyle}>Niveau d'études <span style={{ color: '#ff3366' }}>*</span></label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '16px' }}>
            {EDUCATION_OPTIONS.map(o => (
              <button key={o.id} type="button" onClick={() => setEducation(education === o.id ? '' : o.id)}
                style={{
                  padding: '8px 14px', borderRadius: '999px', fontSize: '0.85rem', fontWeight: 600,
                  border: education === o.id ? '1px solid rgba(255,51,102,0.85)' : '1px solid rgba(255,255,255,0.1)',
                  background: education === o.id ? 'rgba(255,51,102,0.22)' : 'rgba(255,255,255,0.03)',
                  color: education === o.id ? '#ff3366' : (isWhite ? '#111' : '#cfcfda'), cursor: 'pointer', fontFamily: 'inherit',
                  transition: 'all 0.12s ease',
                }}>{o.label}</button>
            ))}
          </div>
          <label style={labelStyle}>Profession <span style={{ color: '#ff3366' }}>*</span></label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            {JOB_OPTIONS.map(o => (
              <button key={o.id} type="button" onClick={() => setJob(job === o.id ? '' : o.id)}
                style={{
                  padding: '8px 14px', borderRadius: '999px', fontSize: '0.85rem', fontWeight: 600,
                  border: job === o.id ? '1px solid rgba(255,51,102,0.85)' : '1px solid rgba(255,255,255,0.1)',
                  background: job === o.id ? 'rgba(255,51,102,0.22)' : 'rgba(255,255,255,0.03)',
                  color: job === o.id ? '#ff3366' : (isWhite ? '#111' : '#cfcfda'), cursor: 'pointer', fontFamily: 'inherit',
                  transition: 'all 0.12s ease',
                }}>{o.label}</button>
            ))}
          </div>
        </div>

        {showFlash && (
          <div style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'white', animation: 'flashOut 0.35s ease-out forwards', pointerEvents: 'none' }} />
        )}
        <style>{`
          @keyframes flashOut { 0% { opacity: 1; } 100% { opacity: 0; } }
        `}</style>
      </div>
    </div>

    {pendingVerificationPhoto && (
      <Suspense fallback={null}>
      <PhotoVerifyScreen
        key={pendingVerificationPhoto}
        photoUrl={pendingVerificationPhoto}
        onSuccess={() => {
          setPhotoPreview(pendingVerificationPhoto);
          setVerifiedPhotoSrc(pendingVerificationPhoto);
          setFaceVerified(true);
          setPendingVerificationPhoto(null);
        }}
        onClose={() => setPendingVerificationPhoto(null)}
        onBlocked={() => {
          setPendingVerificationPhoto(null);
          setError('Photo non vérifiée. Choisis une autre photo principale.');
        }}
        bgTheme={bgTheme}
      />
      </Suspense>
    )}

    {isActive && !pendingVerificationPhoto && ReactDOM.createPortal(
      <button
        onClick={(e) => {
          setShowFlash(true);
          setTimeout(() => setShowFlash(false), 420);
          handleSave();
        }}
        disabled={saving || !isValid}
        style={{
          position: 'fixed',
          bottom: 'calc(env(safe-area-inset-bottom) + 88px)',
          right: '20px',
          zIndex: 9000,
          width: 60, height: 60, borderRadius: '50%',
          background: saving || !isValid
            ? 'radial-gradient(circle at 35% 35%, #3a3a3a, #222)'
            : 'linear-gradient(135deg, #cc1a4d, #ff3366, #ff69b4)',
          border: 'none',
          boxShadow: saving || !isValid
            ? '0 4px 12px rgba(0,0,0,0.3)'
            : '0 8px 24px rgba(255,51,102,0.45), inset 0 1px 0 rgba(255,255,255,0.25)',
          color: '#fff', fontSize: '1.6rem', cursor: saving || !isValid ? 'default' : 'pointer',
          opacity: saving || !isValid ? 0.5 : 1,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'transform 0.15s ease, box-shadow 0.15s ease',
          fontFamily: 'inherit',
        }}
        onPointerDown={e => { if (!saving && isValid) e.currentTarget.style.transform = 'scale(0.92)'; }}
        onPointerUp={e => { e.currentTarget.style.transform = ''; }}
        onPointerLeave={e => { e.currentTarget.style.transform = ''; }}
        aria-label="Enregistrer ma carte"
      >
        <Check size={26} strokeWidth={3} />
      </button>,
      document.body
    )}

    {showLovePopup && ReactDOM.createPortal(
      <>
        <style>{`
          @keyframes fadeIn { 0% { opacity: 0; } 100% { opacity: 1; } }
          @keyframes popIn { 0% { opacity: 0; transform: scale(0.9); } 100% { opacity: 1; transform: scale(1); } }
        `}</style>
        <div style={{ position: 'fixed', inset: 0, zIndex: 10000, background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'center', justifyContent: 'center', animation: 'fadeIn 0.5s ease' }} onClick={() => setShowLovePopup(false)}>
          <div onClick={e => e.stopPropagation()} style={{ maxWidth: '300px', textAlign: 'center', padding: '32px 24px', animation: 'popIn 0.5s ease' }}>
            <div style={{ fontSize: '3.5rem', marginBottom: '20px' }}>💕</div>
            <p style={{ color: '#fff', fontSize: '1.15rem', fontWeight: 600, lineHeight: 1.6, margin: 0, fontFamily: "'EB Garamond', serif", fontStyle: 'italic' }}>
              Don't spend too much time on this app,<br/>spend time with your lover
            </p>
          </div>
        </div>
      </>,
      document.body
    )}
    </>
  );
}