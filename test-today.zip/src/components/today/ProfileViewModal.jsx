import React, { useState, useMemo } from 'react';
import ReactDOM from 'react-dom';
import { X, ChevronDown } from 'lucide-react';
import OptimizedImage from './OptimizedImage';
import { getSignEmoji, getElementLabel, getCompatibility, getElement } from '../../lib/astro';
import { scoreToLabel, personalityScoreToLabel } from '../../lib/compat-labels';
import { PUBLICATION_TIME_SLOTS } from '../../lib/today-constants';
import { localizeQuizPhrase } from '../../lib/quiz-data';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { Flag } from 'lucide-react';
import ReportModal from './ReportModal';
import ProfileGamesSection from './ProfileGamesSection';
import PersonalityDimensions from './PersonalityDimensions';
import useOverlayBack from '../../hooks/useOverlayBack';
import { parsePersonalityProfile, getPersonalityCompatibility } from '../../lib/scoring';

const EDUCATION_LABELS = {
  lycee: 'Secondaire', bts: 'École supérieure / Technique', licence: 'Licence / Bachelor',
  master: 'Master / Grande école', doctorat: 'Doctorat', autodidacte: 'Autodidacte'
};
const JOB_LABELS = {
  etudiant: '🎒 Étudiant·e', salarie: '💼 Salarié·e', entrepreneur: '🚀 Entrepreneur·e',
  freelance: '💻 Freelance', artistique: '🎨 Artiste / Créatif·ve', sante: '🏥 Santé',
  enseignement: '📖 Enseignement', tech: '⚙️ Ingénieur·e / Tech',
  commerce: '📈 Commerce / Finance', sans_emploi: '🌿 Sans emploi', horeca: '🍽️ Horeca'
};
function formatLastSeen(isoDate) {
  if (!isoDate) return '';
  const diff = Date.now() - new Date(isoDate).getTime();
  if (diff < 0) return "à l'instant";
  const min = Math.floor(diff / 60000);
  if (min < 1) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `il y a ${h}h`;
  const d = Math.floor(h / 24);
  if (d < 7) return `il y a ${d}j`;
  return new Date(isoDate).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' });
}

// --- Panneau score cliquable ---
function ScorePanel({ emoji, label, score, percent, color, accentColor, expanded, onToggle, children }) {
  const hasContent = !!children;
  return (
    <div style={{
      borderRadius: '18px',
      background: expanded ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.3)',
      border: `1px solid ${expanded ? color + '50' : color + '25'}`,
      boxShadow: expanded ? `0 0 24px ${color}18` : 'none',
      overflow: 'hidden',
      transition: 'all 0.25s ease',
      cursor: hasContent ? 'pointer' : 'default',
    }}>
      <div
        onClick={hasContent ? onToggle : undefined}
        style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', gap: '12px' }}
      >
        <span style={{ fontSize: '1.8rem', flexShrink: 0 }}>{emoji}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: '0.62rem', color: '#9f9fae', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, marginBottom: 2 }}>{label}</div>
          <div style={{ fontSize: '0.92rem', fontWeight: 800, color }}>{score}</div>
        </div>
        {percent != null && (
          <div style={{ fontSize: '1.3rem', fontWeight: 900, color: accentColor }}>{percent}</div>
        )}
        {hasContent && (
          <ChevronDown size={16} style={{ color: '#6b7280', transition: 'transform 0.25s ease', transform: expanded ? 'rotate(180deg)' : 'rotate(0deg)', flexShrink: 0 }} />
        )}
      </div>
      {expanded && children && (
        <div style={{ padding: '0 18px 16px', borderTop: `1px solid ${color}15` }}>
          <div style={{ paddingTop: '14px' }}>
            {children}
          </div>
        </div>
      )}
    </div>
  );
}

export default function ProfileViewModal({ profile, myProfile, matchScore, cosmicScore: cosmicScoreProp, personalityScore, games, onClose }) {
  useOverlayBack(true, onClose);
  const [activePhoto, setActivePhoto] = useState(0);
  const [expandedPanel, setExpandedPanel] = useState(null); // 'match' | 'cosmic' | 'personality' | null
  const [showReport, setShowReport] = useState(false);
  const photos = [profile?.photo, profile?.photo_url_2, profile?.photo_url_3].filter(Boolean);
  // Phrase-résumé du quiz : retraduite à chaque changement de langue.
  const { lang } = useLanguage();
  const quizPhrase = useMemo(() => localizeQuizPhrase(profile?.quizPhrase), [lang, profile?.quizPhrase]);
  if (!profile) return null;

  const cosmicScore = cosmicScoreProp != null ? cosmicScoreProp
    : (myProfile?.astro_sign && profile.astro_sign)
      ? getCompatibility(
          { element: getElement(myProfile.astro_sign), ascendant: myProfile.astro_ascendant },
          { element: getElement(profile.astro_sign), ascendant: profile.astro_ascendant }
        )
      : null;

  const compatLabel = cosmicScore === null ? null
    : cosmicScore >= 90 ? { emoji: '🔥', label: 'Âmes sœurs astrales', color: '#3b82f6' }
    : cosmicScore >= 70 ? { emoji: '✨', label: 'Très bonne harmonie', color: '#60a5fa' }
    : cosmicScore >= 50 ? { emoji: '⚡', label: 'Énergie complémentaire', color: '#93c5fd' }
    : { emoji: '🌊', label: 'Opposés qui s\'attirent', color: '#93c5fd' };

  const togglePanel = (id) => {
    setExpandedPanel(prev => prev === id ? null : id);
  };

  // Pour la section match
  const matchScoreDetails = matchScore;
  const matchLabel = matchScore >= 90 ? 'Match idéal ✨' : matchScore >= 75 ? 'Très compatible' : matchScore >= 55 ? 'Compatible' : matchScore >= 35 ? 'Peu de points communs' : 'Incompatibilité physique';

  // Pour la section cosmique
  const cosmicEffectiveScore = cosmicScore !== null && cosmicScore > 0 ? cosmicScore : null;

  const hasMatchContent = profile.ownPhysicalTraits?.length > 0 || profile.desired_physical_traits?.length > 0 || profile.seeking;
  const hasCosmicContent = profile.astro_sign && cosmicEffectiveScore !== null;
  // Profils de personnalité comparés (aucun score affiché s'ils n'existent pas).
  const theirPersonality = parsePersonalityProfile(profile.personality_profile);
  const myPersonality = parsePersonalityProfile(myProfile?.personality_profile);
  const hasPersonalityContent = !!profile.quizPhrase || !!theirPersonality;

  // CALCUL UNIQUE : dimensions + score général en une passe, sur les deux mêmes profils.
  const personalityCompat = getPersonalityCompatibility(myPersonality, theirPersonality);
  const resolvedPersonalityScore = personalityScore != null ? personalityScore : personalityCompat.score;

  return ReactDOM.createPortal(
    <div
      style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', zIndex: 9999, backgroundColor: 'rgba(0,0,0,0.92)', overflowY: 'auto', paddingBottom: '120px' }}
    >
      {/* Bouton fermer */}
      <button
        onClick={onClose}
        style={{ position: 'fixed', top: 'calc(env(safe-area-inset-top) + 12px)', right: 16, width: 40, height: 40, borderRadius: '50%', background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#fff', zIndex: 10000 }}
      >
        <X size={18} />
      </button>

      {/* Bouton signaler */}
      <button
        onClick={() => setShowReport(true)}
        title="Signaler ce profil"
        style={{ position: 'fixed', top: 'calc(env(safe-area-inset-top) + 16px)', left: 16, height: 32, padding: '0 10px', borderRadius: '999px', background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)', border: '1px solid rgba(255,107,107,0.7)', display: 'flex', alignItems: 'center', gap: 4, cursor: 'pointer', color: 'rgba(255,107,107,0.8)', zIndex: 10000, fontFamily: 'inherit', fontSize: '0.68rem', fontWeight: 700 }}
      >
        <Flag size={12} /> Signaler
      </button>

      {/* Photos */}
      <div style={{ position: 'relative', width: '100%', height: '380px' }}>
        {photos.length > 0 ? (
          <OptimizedImage key={activePhoto} src={photos[activePhoto]} alt={profile.name} priority={true} sizes="100vw" fallbackName={profile.name} style={{ width: '100%', height: '100%', objectFit: 'contain', display: 'block', background: '#0a0a0d' }} />
        ) : (
          <div style={{ width: '100%', height: '100%', background: 'linear-gradient(135deg, #1a0010, #0d0018)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '4rem' }}>👤</div>
        )}
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.1) 0%, transparent 40%, rgba(0,0,0,0.85) 100%)' }} />
        {/* Dernière connexion — identique au deck (photo) */}
        {profile.last_online_date && (
          <div style={{ position: 'absolute', top: 'calc(env(safe-area-inset-top) + 58px)', right: 14, zIndex: 3, padding: '4px 11px', borderRadius: '999px', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', color: '#d4d4d8', fontWeight: 600, fontSize: '0.68rem', border: '1px solid rgba(255,255,255,0.12)', whiteSpace: 'nowrap' }}>
            🕐 {formatLastSeen(profile.last_online_date)}
          </div>
        )}
        {photos.length > 1 && (
          <>
            <div onClick={() => setActivePhoto(i => Math.max(0, i - 1))} style={{ position: 'absolute', top: 0, left: 0, width: '40%', height: '100%', cursor: 'pointer', zIndex: 2 }} />
            <div onClick={() => setActivePhoto(i => Math.min(photos.length - 1, i + 1))} style={{ position: 'absolute', top: 0, right: 0, width: '40%', height: '100%', cursor: 'pointer', zIndex: 2 }} />
          </>
        )}
        {photos.length > 1 && (
          <div style={{ position: 'absolute', top: 12, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: 6, zIndex: 3 }}>
            {photos.map((_, i) => (
              <button key={i} onClick={() => setActivePhoto(i)} style={{
                width: i === activePhoto ? 28 : 8, height: 4, borderRadius: '999px',
                background: i === activePhoto ? '#ff3366' : 'rgba(255,255,255,0.45)',
                border: 'none', cursor: 'pointer', padding: 0, transition: 'all 0.2s ease',
              }} />
            ))}
          </div>
        )}
        {/* Nom + âge + profession sur la photo */}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '16px 18px 18px', zIndex: 3 }}>
          <h3 style={{ margin: 0, fontSize: '2rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, lineHeight: 1.1, color: '#fff' }}>
            {profile.name}{profile.age != null ? `, ${profile.age}` : ''}
          </h3>
          {profile.job && (
            <div style={{ marginTop: 4, fontSize: '0.8rem', color: 'rgba(255,255,255,0.7)', fontWeight: 600 }}>
              {JOB_LABELS[profile.job] || profile.job}
            </div>
          )}
        </div>
      </div>

             {/* Contenu */}
      <div style={{ padding: '16px 22px 80px', display: 'flex', flexDirection: 'column', gap: '14px', background: 'linear-gradient(180deg, #0a0408 0%, #040405 100%)' }}>

        {/* Citation */}
        {profile.fiveWords && (
          <p style={{ margin: '4px 0 0', color: '#ff69b4', fontStyle: 'italic', fontSize: '1.1rem', lineHeight: 1.5, textAlign: 'center', fontFamily: "'EB Garamond', serif" }}>
            « {profile.fiveWords} »
          </p>
        )}



        {/* Heure souhaitée */}
        {profile.time_slot && (
          <div style={{ padding: '12px 16px', borderRadius: '14px', background: 'rgba(255,105,180,0.06)', border: '1px solid rgba(255,105,180,0.15)', textAlign: 'center' }}>
            <div style={{ fontSize: '0.62rem', color: '#9f9fae', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, marginBottom: 3 }}>Heure souhaitée pour le date</div>
            <div style={{ fontSize: '1.1rem', fontWeight: 800, color: '#ff69b4' }}>{(profile.time_slot || '').split('|').filter(Boolean).sort((a, b) => PUBLICATION_TIME_SLOTS.indexOf(a) - PUBLICATION_TIME_SLOTS.indexOf(b)).join(' · ')}</div>
          </div>
        )}

        {/* --- Score Match --- */}
        <ScorePanel
          emoji="💪"
          label="Compatibilité physique"
          score={matchLabel}
          percent={scoreToLabel(matchScore)?.label}
          color="#ff69b4"
          accentColor={scoreToLabel(matchScore)?.color || '#ff3366'}
          expanded={expandedPanel === 'match'}
          onToggle={() => togglePanel('match')}
        >
          {/* Détails : taille, morphologie, ce qu'il/elle cherche */}
          {profile.height && (
            <div style={{ marginBottom: 12 }}>
              <div style={{ color: '#a1a1aa', fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, marginBottom: 8 }}>Taille</div>
              <div style={{ color: '#ff69b4', fontSize: '0.9rem', fontWeight: 600, lineHeight: 1.5 }}>
                📏 {profile.height} cm
              </div>
            </div>
          )}
          {profile.ownPhysicalTraits?.length > 0 && (
            <div style={{ marginBottom: 12 }}>
              <div style={{ color: '#a1a1aa', fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, marginBottom: 8 }}>Morphologie</div>
              <div style={{ color: '#ff69b4', fontSize: '0.9rem', fontWeight: 600, lineHeight: 1.5 }}>
                {profile.ownPhysicalTraits.join(' · ')}
              </div>
            </div>
          )}
          {profile.desired_physical_traits?.length > 0 && (
            <div style={{ marginBottom: 12 }}>
              <div style={{ color: '#a1a1aa', fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, marginBottom: 8 }}>Recherche physiquement</div>
              <div style={{ color: '#ff69b4', fontSize: '0.9rem', fontWeight: 600, lineHeight: 1.5 }}>
                {profile.desired_physical_traits.join(' · ')}
              </div>
            </div>
          )}
        </ScorePanel>

        {/* --- Score Cosmique --- */}
        <ScorePanel
          emoji="🌙"
          label="Compatibilité astrale"
          score={cosmicEffectiveScore ? compatLabel.label : 'Non effectué'}
          percent={scoreToLabel(cosmicEffectiveScore)?.label}
          color={cosmicEffectiveScore ? compatLabel.color : '#9f9fae'}
          accentColor={scoreToLabel(cosmicEffectiveScore)?.color || '#6b7280'}
          expanded={expandedPanel === 'cosmic'}
          onToggle={hasCosmicContent ? () => togglePanel('cosmic') : undefined}
        >
          {compatLabel && cosmicEffectiveScore && (
            <p style={{ margin: '0 0 14px', color: compatLabel.color, fontSize: '0.92rem', fontWeight: 600, lineHeight: 1.5, textAlign: 'center' }}>
              {cosmicEffectiveScore >= 90 ? 'Une alchimie céleste rare — les astres vous sont favorables'
              : cosmicEffectiveScore >= 70 ? 'Les planètes s\'alignent pour créer une belle dynamique'
              : cosmicEffectiveScore >= 50 ? 'Des énergies complémentaires qui peuvent créer l\'étincelle'
              : 'Un défi astral — vos éléments se confrontent mais rien n\'est impossible'}
            </p>
          )}
          {myProfile?.astro_sign && profile.astro_sign && (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'flex-start', gap: 18, marginBottom: 14 }}>
              <div style={{ textAlign: 'center', minWidth: 74 }}>
                <div style={{ fontSize: '1.6rem', lineHeight: 1 }}>{getSignEmoji(myProfile.astro_sign)}</div>
                <div style={{ color: '#9f9fae', fontSize: '0.6rem', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, marginTop: 7 }}>Mon signe</div>
                <div style={{ color: '#ff69b4', fontSize: '0.86rem', fontWeight: 700, marginTop: 2 }}>{myProfile.astro_sign}</div>
              </div>
              <div style={{ color: '#6b7280', fontSize: '0.9rem', paddingTop: 10 }}>×</div>
              <div style={{ textAlign: 'center', minWidth: 74 }}>
                <div style={{ fontSize: '1.6rem', lineHeight: 1 }}>{getSignEmoji(profile.astro_sign)}</div>
                <div style={{ color: '#9f9fae', fontSize: '0.6rem', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, marginTop: 7 }}>Son signe</div>
                <div style={{ color: '#ff69b4', fontSize: '0.86rem', fontWeight: 700, marginTop: 2 }}>{profile.astro_sign}</div>
              </div>
            </div>
          )}
          {profile.astro_sign && (
            <div style={{ marginBottom: 10 }}>
              <div style={{ color: '#a1a1aa', fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, marginBottom: 8 }}>Signe & ascendant</div>
              <div style={{ color: '#ff69b4', fontSize: '0.9rem', fontWeight: 600, lineHeight: 1.5 }}>
                {getSignEmoji(profile.astro_sign)} {profile.astro_sign}
                {profile.astro_ascendant && profile.astro_ascendant !== profile.astro_sign && (
                  <> · Asc. {getSignEmoji(profile.astro_ascendant)} {profile.astro_ascendant}</>
                )}
              </div>
            </div>
          )}
        </ScorePanel>

        {/* --- Personnalité --- */}
        <ScorePanel
          emoji="✨"
          label="Personnalité"
          score={hasPersonalityContent ? (resolvedPersonalityScore ? personalityScoreToLabel(resolvedPersonalityScore)?.label || 'Voir le résumé' : 'Voir le résumé') : 'Non renseigné'}
          percent={resolvedPersonalityScore ? personalityScoreToLabel(resolvedPersonalityScore)?.label : null}
          color={hasPersonalityContent ? '#ff69b4' : '#9f9fae'}
          accentColor={resolvedPersonalityScore ? personalityScoreToLabel(resolvedPersonalityScore)?.color || '#ff3366' : '#6b7280'}
          expanded={expandedPanel === 'personality'}
          onToggle={hasPersonalityContent ? () => togglePanel('personality') : undefined}
        >
          {quizPhrase && (
            <p style={{ margin: '0', fontStyle: 'italic', fontSize: '0.92rem', lineHeight: 1.55, color: '#cfcfda', textAlign: 'center' }}>
              « {quizPhrase} »
            </p>
          )}
          {theirPersonality && myPersonality && (
            <div style={{ marginTop: quizPhrase ? 16 : 0 }}>
              <div style={{ color: '#a1a1aa', fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, marginBottom: 10, textAlign: 'center' }}>
                Compatibilité par dimension
              </div>
              <PersonalityDimensions dimensions={personalityCompat.dimensions} />
            </div>
          )}
        </ScorePanel>

        {/* Jeux disponibles pour ce profil */}
        <ProfileGamesSection profileName={profile.name} games={games} />

        {/* Séparateur */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '4px 0' }}>
          <div style={{ flex: 1, height: 1, background: 'linear-gradient(90deg, transparent, rgba(255,51,102,0.25))' }} />
          <span style={{ color: 'rgba(255,51,102,0.35)', fontSize: '0.65rem' }}>✦</span>
          <div style={{ flex: 1, height: 1, background: 'linear-gradient(90deg, rgba(255,51,102,0.25), transparent)' }} />
        </div>

      </div>

      {showReport && (
        <ReportModal
          profile={profile}
          reporterId={myProfile?.user_id}
          onClose={() => setShowReport(false)}
        />
      )}

    </div>,
    document.body
  );
}