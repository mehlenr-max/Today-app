import React, { useState, useEffect, useMemo } from 'react';
import PersonalityQuizModal from './PersonalityQuizModal';
import { getPersonalityCompatLabel, localizeQuizPhrase } from '../../lib/quiz-data';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { motion } from 'framer-motion';
import OptimizedImage from './OptimizedImage';
import { ProfileHeroSkeleton } from './SkeletonLoader';
import { buildCosmicProfile, getSignEmoji } from '../../lib/astro';
import { base44 } from '../../api/base44Client';
import { translate } from '@/lib/i18n/engine';
import { getHomeTheme } from '../../lib/home-theme';
import NextSessionCountdown from './NextSessionCountdown';
import SelectModal from './SelectModal';
import { ChevronDown } from 'lucide-react';

const BIRTH_COUNTRIES = [
  'France', 'Belgique', 'Suisse', 'Luxembourg', 'Monaco', 'Canada',
  'Maroc', 'Tunisie', 'Algérie', 'Liban', 'Espagne', 'Italie', 'Portugal',
  'Allemagne', 'Royaume-Uni', 'Pays-Bas', 'Irlande', 'Pologne', 'Roumanie',
  'Turquie', 'Russie', 'Suède', 'Norvège', 'Danemark', 'Finlande', 'Autriche',
  'Grèce', 'États-Unis', 'Mexique', 'Brésil', 'Argentine', 'Sénégal',
  'Côte d\'Ivoire', 'Cameroun',
];

export default function HomeTab({ user, onGoCreate, onGoCard, userProfile, onToggleOnline, isOnline, hasAccepted, onLogout, onAstroSave, onPersonalitySave, bgTheme, onBgTheme, autoLight, onToggleAutoLight, isLoading, onShowRules }) {
  const t = getHomeTheme(bgTheme);
  // La phrase-résumé du quiz se retraduit dès que la langue change (dépendance à `lang`).
  const { lang } = useLanguage();
  const quizPhrase = useMemo(() => localizeQuizPhrase(userProfile?.quiz_phrase), [lang, userProfile?.quiz_phrase]);
  const [showThemePicker, setShowThemePicker] = useState(false);
  const [showAstroForm, setShowAstroForm] = useState(false);
  const [showPersonalityQuiz, setShowPersonalityQuiz] = useState(false);
  const [showCountryPicker, setShowCountryPicker] = useState(false);

  useEffect(() => {
    const lockScroll = () => {
      document.body.style.overflowX = 'hidden';
      document.documentElement.style.overflowX = 'hidden';
      document.body.style.maxWidth = '100vw';
      document.documentElement.style.maxWidth = '100vw';
      window.scrollTo(0, window.scrollY);
    };
    lockScroll();
    window.addEventListener('scroll', lockScroll, { passive: true });
    window.addEventListener('touchend', lockScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', lockScroll);
      window.removeEventListener('touchend', lockScroll);
    };
  }, []);

  const [birthDay, setBirthDay] = useState('');
  const [birthMonth, setBirthMonth] = useState('');
  const [birthYear, setBirthYear] = useState('');
  const [birthTime, setBirthTime] = useState('');
  const [birthCountry, setBirthCountry] = useState('France');
  const [birthCity, setBirthCity] = useState('');
  const [preview, setPreview] = useState(null);
  const [loadingPreview, setLoadingPreview] = useState(false);
  const [showFlash, setShowFlash] = useState(false);
  const triggerFlash = () => { setShowFlash(false); requestAnimationFrame(() => requestAnimationFrame(() => setShowFlash(true))); setTimeout(() => setShowFlash(false), 400); };

  // Pré-remplit les champs date de naissance du formulaire astro depuis le profil
  const openAstroForm = () => {
    triggerFlash();
    if (!userProfile) { onGoCard(); return; }
    if (userProfile.birth_date) {
      const [y, m, d] = userProfile.birth_date.split('-');
      setBirthDay(d || '');
      setBirthMonth(m || '');
      setBirthYear(y || '');
    }
    setShowAstroForm(v => !v);
  };
  const astroSign = userProfile?.astro_sign;
  const astroAscendant = userProfile?.astro_ascendant;
  const cosmicDone = !!astroSign;
  const personalityDone = !!userProfile?.personality_profile;
  const profileStepsDone = (cosmicDone ? 1 : 0) + (personalityDone ? 1 : 0);

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-full">
        <div className="px-5 py-7 flex flex-col gap-6">
          <ProfileHeroSkeleton />
          <div style={{ height: 1, background: t.dividerFaint }} />
          <div style={{ height: 44, borderRadius: 999, width: 80, margin: '0 auto', background: t.skeletonBlock }} />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-full" style={{ paddingBottom: '30vh' }}>
      {/* Flash overlay */}
      <style>{`@keyframes homeFlashOut { 0% { opacity: 1; } 100% { opacity: 0; } } @keyframes pulseDot { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.6; transform: scale(0.85); } } @keyframes pulseRing { 0% { transform: scale(1); opacity: 0.7; } 100% { transform: scale(1.35); opacity: 0; } }`}</style>
      {showFlash && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'white', animation: 'homeFlashOut 0.35s ease-out forwards', pointerEvents: 'none' }} />
      )}
      <div className="px-5 py-7 flex flex-col gap-6">

        {/* Profile hero */}
        {userProfile ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-3xl border overflow-hidden"
            style={{ background: t.cardBg, borderColor: t.cardBorder, boxShadow: t.light ? '0 4px 24px rgba(0,0,0,0.06)' : '0 8px 32px rgba(0,0,0,0.4)' }}
          >
            {/* Photo + nom */}
            <div className="p-5 flex flex-col items-center gap-3">
              <NextSessionCountdown theme={t} compact />
              {userProfile.photo_url && (
                <div style={{ position: 'relative', display: 'inline-flex' }}>
                  <div style={{ padding: 3, borderRadius: '50%', background: 'linear-gradient(135deg, #ff3366, #ff69b4, #3b82f6)', boxShadow: '0 8px 24px rgba(255,51,102,0.25)' }}>
                    <OptimizedImage src={userProfile.photo_url} alt="" priority={true} sizes="112px" fallbackName={userProfile.display_name} className="w-28 h-28 rounded-full object-cover flex-shrink-0" style={{ background: 'rgba(0,0,0,0.3)', border: `3px solid ${t.light ? '#f0e6d3' : '#0d0d12'}` }} />
                  </div>
                  {user?.role === 'admin' && (
                    <span className="absolute" style={{ bottom: 0, left: '50%', transform: 'translateX(-50%)', background: 'rgba(0,0,0,0.8)', color: '#ff2d2d', fontSize: '0.68rem', fontWeight: 800, letterSpacing: '0.12em', textTransform: 'uppercase', padding: '2px 10px', borderRadius: 999, border: '1px solid #ff2d2d', lineHeight: 1.3 }}>admin</span>
                  )}
                </div>
              )}
              <div className="flex flex-col items-center gap-0.5">
                <div className="font-garamond italic font-black text-center" style={{ color: t.textPrimary, fontSize: '1.7rem', lineHeight: 1.1, padding: '0 12px' }}>
                  {userProfile.display_name}
                </div>
                {userProfile.city && <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-sm justify-center" style={{ color: t.textSecondary }}>
                  <span>📍 {userProfile.city}</span>
                </div>}
                <div className="flex justify-center mt-1.5">
                  <button onClick={onToggleOnline} className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border transition-all duration-200 cursor-pointer ${isOnline ? (t.light ? 'bg-pink-500/10 border-pink-500/40' : 'bg-emerald-500/10 border-emerald-500/40') : 'bg-pink-500/10 border-pink-500/30'}`}>
                    <span className={`w-2 h-2 rounded-full ${isOnline ? (t.light ? 'bg-pink-500' : 'bg-emerald-400') : 'bg-pink-500'}`} style={isOnline ? { boxShadow: `0 0 8px ${t.light ? '#ff3366' : '#34d399'}`, animation: 'pulseDot 1.8s ease-in-out infinite' } : {}} />
                    <span className={`text-xs font-bold ${isOnline ? (t.light ? 'text-pink-400' : 'text-emerald-400') : 'text-pink-400'}`}>{isOnline ? 'En ligne' : 'Hors ligne'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Séparateur */}
            <div style={{ height: 1, background: t.divider, margin: '0 16px' }} />

            {/* Détails */}
            <div className="p-4 flex flex-col gap-3">

              {/* Phrase / quote */}
              {userProfile.five_words && (
                <p style={{ margin: 0, fontStyle: 'italic', fontSize: '0.9rem', color: t.pink }}>
                  "{userProfile.five_words}"
                </p>
              )}
              {(userProfile.quiz_phrase || astroSign) && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {quizPhrase && (
                    <p style={{ margin: 0, textAlign: 'center', fontSize: '0.88rem', fontStyle: 'italic', color: t.light ? t.pinkStrong : t.emerald, lineHeight: 1.4 }}>
                      "{quizPhrase}"
                    </p>
                  )}
                  {astroSign && (
                    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '8px' }}>
                      <button
                        onClick={openAstroForm}
                        style={{
                          display: 'inline-flex', alignItems: 'center', gap: '6px',
                          padding: '6px 14px', borderRadius: '999px',
                          background: t.light ? 'rgba(59,130,246,0.06)' : 'rgba(255,255,255,0.04)',
                          border: `1px solid ${t.light ? 'rgba(59,130,246,0.25)' : 'rgba(255,255,255,0.12)'}`,
                          color: t.blue, fontSize: '0.82rem', fontWeight: 600,
                          fontFamily: 'inherit', cursor: 'pointer',
                          transition: 'all 0.2s ease',
                        }}
                      >
                        <span style={{ fontSize: '0.95rem' }}>{getSignEmoji(astroSign)}</span>
                        {astroSign}
                      </button>
                      {astroAscendant && astroAscendant !== astroSign && (
                        <button
                          onClick={openAstroForm}
                          style={{
                            display: 'inline-flex', alignItems: 'center', gap: '6px',
                            padding: '6px 14px', borderRadius: '999px',
                            background: t.light ? 'rgba(59,130,246,0.06)' : 'rgba(255,255,255,0.04)',
                            border: `1px solid ${t.light ? 'rgba(59,130,246,0.25)' : 'rgba(255,255,255,0.12)'}`,
                            color: t.blue, fontSize: '0.82rem', fontWeight: 600,
                            fontFamily: 'inherit', cursor: 'pointer',
                            transition: 'all 0.2s ease',
                          }}
                        >
                          <span style={{ fontSize: '0.95rem' }}>{getSignEmoji(astroAscendant)}</span>
                          Asc. {astroAscendant}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}



              {/* Likes */}
              {userProfile.likes?.length > 0 && (
                <div>
                  <div style={{ fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, marginBottom: '6px', color: t.textMuted }}>J'aime</div>
                  <div className="flex flex-wrap gap-1.5">
                    {userProfile.likes.map(item => (
                      <span key={item} style={{ padding: '3px 9px', borderRadius: '999px', fontSize: '0.72rem', background: t.light ? 'rgba(59,130,246,0.1)' : 'rgba(89,211,154,0.1)', border: t.light ? '1px solid rgba(59,130,246,0.25)' : '1px solid rgba(89,211,154,0.25)', color: t.light ? t.blue : t.emeraldSoft }}>{item}</span>
                    ))}
                  </div>
                </div>
              )}

              {/* Dislikes */}
              {userProfile.dislikes?.length > 0 && (
                <div>
                  <div style={{ fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, marginBottom: '6px', color: t.textMuted }}>J'aime pas</div>
                  <div className="flex flex-wrap gap-1.5">
                    {userProfile.dislikes.map(item => (
                      <span key={item} style={{ padding: '3px 9px', borderRadius: '999px', fontSize: '0.72rem', background: 'rgba(255,80,80,0.1)', border: '1px solid rgba(255,80,80,0.25)', color: t.textDanger }}>{item}</span>
                    ))}
                  </div>
                </div>
              )}

            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={onGoCard}
            className="rounded-3xl p-8 text-center cursor-pointer transition-all duration-200"
            style={{ background: t.light ? 'rgba(255,51,102,0.06)' : 'rgba(255,51,102,0.08)', border: `1px solid ${t.light ? 'rgba(255,51,102,0.2)' : 'rgba(255,51,102,0.25)'}` }}
          >
            <div style={{ width: 72, height: 72, borderRadius: '50%', margin: '0 auto 14px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', background: t.light ? 'rgba(255,51,102,0.1)' : 'rgba(255,51,102,0.12)', border: `1px solid ${t.light ? 'rgba(255,51,102,0.25)' : 'rgba(255,51,102,0.3)'}` }}>👤</div>
            <div style={{ fontWeight: 800, fontSize: '1rem', marginBottom: '4px', color: t.textPrimary }}>Crée ta carte</div>
            <div style={{ fontSize: '0.82rem', color: t.textMuted }}>Configure ton profil pour être visible par les autres.</div>
          </motion.div>
        )}

        {/* Badge date confirmé */}
        {hasAccepted && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: '14px',
            padding: '16px 18px', borderRadius: '18px',
            background: t.light ? 'rgba(255,51,102,0.08)' : 'rgba(89,211,154,0.08)', border: t.light ? '1px solid rgba(255,51,102,0.3)' : '1px solid rgba(89,211,154,0.3)',
            boxShadow: t.light ? '0 4px 20px rgba(255,51,102,0.1)' : '0 0 24px rgba(89,211,154,0.12)',
          }}>
            <span style={{ fontSize: '1.8rem' }}>✅</span>
            <div>
              <div style={{ fontWeight: 800, fontSize: '0.92rem', color: t.light ? t.pinkStrong : t.emeraldSoft }}>Date confirmé ce soir !</div>
              <div style={{ fontSize: '0.78rem', color: t.textMuted, marginTop: '2px' }}>Tu ne peux plus accepter de nouveau date avant minuit.</div>
            </div>
          </div>
        )}

        {/* Divider */}
        <div className="flex items-center gap-3">
          <div className="flex-1 h-px" style={{ background: t.light ? 'linear-gradient(90deg, transparent, rgba(0,0,0,0.12))' : 'linear-gradient(90deg, transparent, rgba(255,255,255,0.1))' }} />
          <span className="text-xs uppercase tracking-widest font-bold" style={{ color: t.textMuted }}>Ce soir · Belgique</span>
          <div className="flex-1 h-px" style={{ background: t.light ? 'linear-gradient(90deg, rgba(0,0,0,0.12), transparent)' : 'linear-gradient(90deg, rgba(255,255,255,0.1), transparent)' }} />
        </div>

        {profileStepsDone < 2 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          style={{
            background: t.checklistBg,
            borderRadius: '20px',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <div style={{ padding: '14px 16px 6px', textAlign: 'center' }}>
            <div style={{ fontSize: '0.82rem', fontWeight: 700, color: t.pinkStrong, lineHeight: 1.4 }}>
              Complète pour augmenter la précision de compatibilité
            </div>
          </div>
          {/* Ligne : Test de personnalité */}
          <button
            onClick={() => { if (!personalityDone) { triggerFlash(); if (!userProfile) { onGoCard(); return; } setShowPersonalityQuiz(true); } }}
            disabled={personalityDone}
            style={{
              display: 'flex', alignItems: 'center', gap: '12px',
              width: '100%', padding: '16px',
              cursor: personalityDone ? 'default' : 'pointer',
              background: 'none',
              border: 'none',
              fontFamily: 'inherit', textAlign: 'left',
              opacity: personalityDone ? 0.5 : 1,
            }}
          >
            <div style={{ width: 40, height: 40, borderRadius: '50%', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem', background: t.light ? 'rgba(89,211,154,0.12)' : '#1E2A25', border: `1px solid ${t.light ? 'rgba(89,211,154,0.3)' : 'rgba(89,211,154,0.3)'}` }}>✨</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '0.95rem', fontWeight: 600, color: t.textPrimary }}>
                Test de personnalité
              </div>
              <div style={{ fontSize: '0.78rem', color: t.textMuted, marginTop: '2px' }}>
                {personalityDone ? 'Terminé' : '5 min • 15 questions'}
              </div>
            </div>
            <span style={{ width: 20, height: 20, borderRadius: '50%', border: `2px solid ${personalityDone ? (t.light ? t.pinkStrong : t.emerald) : (t.light ? '#ccc' : '#333')}`, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {personalityDone && <span style={{ width: 10, height: 10, borderRadius: '50%', background: t.light ? t.pinkStrong : t.emerald }} />}
            </span>
          </button>

          {/* Divider */}
          <div style={{ height: 1, background: t.light ? 'rgba(0,0,0,0.08)' : '#333', margin: '0 16px' }} />

          {/* Ligne : Profil astrologique */}
          <button
            onClick={openAstroForm}
            style={{
              display: 'flex', alignItems: 'center', gap: '12px',
              width: '100%', padding: '16px',
              cursor: 'pointer',
              background: 'none',
              border: 'none',
              fontFamily: 'inherit', textAlign: 'left',
            }}
          >
            <div style={{ width: 40, height: 40, borderRadius: '50%', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem', background: t.light ? 'rgba(59,130,246,0.12)' : '#222533', border: `1px solid ${t.light ? 'rgba(59,130,246,0.3)' : 'rgba(59,130,246,0.3)'}` }}>🌙</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '0.95rem', fontWeight: 600, color: t.textPrimary }}>
                Profil astrologique
              </div>
              <div style={{ fontSize: '0.78rem', color: t.textMuted, marginTop: '2px' }}>
                {cosmicDone ? 'Modifier mon signe' : 'Active ton signe'}
              </div>
            </div>
            <span style={{ width: 20, height: 20, borderRadius: '50%', border: `2px solid ${cosmicDone ? (t.light ? t.pinkStrong : t.emerald) : (t.light ? '#ccc' : '#333')}`, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {cosmicDone && <span style={{ width: 10, height: 10, borderRadius: '50%', background: t.light ? t.pinkStrong : t.emerald }} />}
            </span>
          </button>

        </motion.div>
        )}

        {/* Bouton persistant : re-entrée formulaire astrologique quand l'ascendant manque */}
        {profileStepsDone === 2 && !astroAscendant && (
          <motion.button
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={openAstroForm}
            style={{
              display: 'flex', alignItems: 'center', gap: '12px',
              width: '100%', padding: '14px',
              borderRadius: '14px', cursor: 'pointer',
              background: t.light ? 'rgba(59,130,246,0.06)' : 'rgba(59,130,246,0.08)',
              border: `1px solid ${t.light ? 'rgba(59,130,246,0.2)' : 'rgba(59,130,246,0.25)'}`,
              fontFamily: 'inherit', textAlign: 'left',
              transition: 'all 0.2s ease',
            }}
          >
            <div style={{ width: 40, height: 40, borderRadius: '50%', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem', background: t.light ? 'rgba(59,130,246,0.12)' : 'rgba(59,130,246,0.15)', border: `1px solid ${t.light ? 'rgba(59,130,246,0.3)' : 'rgba(59,130,246,0.35)'}` }}>🌙</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '1.02rem', fontWeight: 600, color: t.blue }}>
                Profil astrologique
              </div>
              <div style={{ fontSize: '0.82rem', color: t.textMuted, marginTop: '2px' }}>
                Ascendant manquant · ajoute heure &amp; lieu de naissance
              </div>
            </div>
            <span style={{ fontSize: '0.9rem', fontWeight: 700, color: t.blue }}>→</span>
          </motion.button>
        )}

        {/* Modal test de personnalité */}
        {showPersonalityQuiz && (
          <PersonalityQuizModal
            onClose={() => setShowPersonalityQuiz(false)}
            existingProfile={userProfile?.personality_profile ? JSON.parse(userProfile.personality_profile) : null}
            onSave={async (profile, phrase) => {
              await onPersonalitySave?.(profile, phrase);
            }}
          />
        )}

        {/* Formulaire profil cosmique */}
        {showAstroForm && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            style={{
              padding: '20px', borderRadius: '20px',
              background: 'rgba(15,10,30,0.95)', border: '1px solid rgba(180,80,255,0.3)',
              boxShadow: '0 0 30px rgba(180,0,255,0.15)',
            }}
          >
            {!userProfile && (
              <div style={{ marginBottom: '14px', padding: '14px 16px', borderRadius: '14px', background: 'rgba(255,51,102,0.1)', border: '1px solid rgba(255,51,102,0.3)', color: '#ff6a7c', fontSize: '0.88rem', textAlign: 'center', fontWeight: 600 }}>
                ⚠️ Remplis d'abord ta fiche perso (onglet Ma carte)
              </div>
            )}
            <div style={{ fontSize: '0.75rem', color: t.light ? '#666' : t.textMuted, textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 700, marginBottom: '14px' }}>🌙 Profil astrologique</div>

            {/* Jour + Mois + Année */}
            <div style={{ display: 'flex', gap: '10px', marginBottom: '12px' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '0.65rem', color: t.inputLabel, marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Jour <span style={{ color: t.pinkStrong }}>*</span></div>
                <input
                  type="number" min="1" max="31" placeholder="15"
                  disabled={!userProfile || !!userProfile.birth_date}
                  value={birthDay} onChange={e => { setBirthDay(e.target.value); setPreview(null); }}
                  style={{ width: '100%', padding: '10px 12px', borderRadius: '12px', border: `1px solid ${t.inputBorder}`, background: (!userProfile || userProfile.birth_date) ? t.inputBgDisabled : t.inputBg, color: (!userProfile || userProfile.birth_date) ? t.inputTextDisabled : t.inputText, fontFamily: 'inherit', fontSize: '16px', outline: 0, opacity: (!userProfile || userProfile.birth_date) ? 0.5 : 1, cursor: (!userProfile || userProfile.birth_date) ? 'not-allowed' : 'text' }}
                />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '0.65rem', color: t.inputLabel, marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Mois <span style={{ color: t.pinkStrong }}>*</span></div>
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={2}
                  placeholder="07"
                  disabled={!userProfile || !!userProfile.birth_date}
                  value={birthMonth}
                  onChange={e => {
                    let val = e.target.value.replace(/\D/g, '');
                    if (val.length > 2) val = val.slice(0, 2);
                    if (val && Number(val) > 12) val = '12';
                    setBirthMonth(val);
                    setPreview(null);
                  }}
                  style={{ width: '100%', padding: '10px 12px', borderRadius: '12px', border: `1px solid ${t.inputBorder}`, background: (!userProfile || userProfile.birth_date) ? t.inputBgDisabled : t.inputBg, color: (!userProfile || userProfile.birth_date) ? t.inputTextDisabled : t.inputText, fontFamily: 'inherit', fontSize: '16px', outline: 0, opacity: (!userProfile || userProfile.birth_date) ? 0.5 : 1, cursor: (!userProfile || userProfile.birth_date) ? 'not-allowed' : 'text' }}
                />
              </div>
              <div style={{ flex: 1.4 }}>
                <div style={{ fontSize: '0.65rem', color: t.inputLabel, marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Année <span style={{ color: t.pinkStrong }}>*</span></div>
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={4}
                  placeholder="1998"
                  disabled={!userProfile || !!userProfile.birth_date}
                  value={birthYear}
                  onChange={e => {
                    let val = e.target.value.replace(/\D/g, '');
                    if (val.length > 4) val = val.slice(0, 4);
                    setBirthYear(val);
                    setPreview(null);
                  }}
                  style={{ width: '100%', padding: '10px 12px', borderRadius: '12px', border: `1px solid ${t.inputBorder}`, background: (!userProfile || userProfile.birth_date) ? t.inputBgDisabled : t.inputBg, color: (!userProfile || userProfile.birth_date) ? t.inputTextDisabled : t.inputText, fontFamily: 'inherit', fontSize: '16px', outline: 0, opacity: (!userProfile || userProfile.birth_date) ? 0.5 : 1, cursor: (!userProfile || userProfile.birth_date) ? 'not-allowed' : 'text' }}
                />
              </div>
            </div>

            {/* Heure + Ville (optionnels pour l'ascendant) */}
            <div style={{ fontSize: '0.65rem', color: '#b47fff', marginBottom: '8px', fontWeight: 600 }}>
              ✨ Heure &amp; lieu de naissance <span style={{ color: t.textMuted, fontWeight: 400 }}>(optionnel · pour l'ascendant)</span>
            </div>
            <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '0.65rem', color: t.inputLabel, marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Pays</div>
                <button
                  type="button"
                  disabled={!userProfile}
                  onClick={() => setShowCountryPicker(true)}
                  style={{ width: '100%', padding: '10px 12px', borderRadius: '12px', border: `1px solid ${t.inputBorder}`, background: !userProfile ? t.inputBgDisabled : t.inputBg, color: !userProfile ? t.inputTextDisabled : t.inputText, fontFamily: 'inherit', fontSize: '16px', outline: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', textAlign: 'left', cursor: !userProfile ? 'not-allowed' : 'pointer', opacity: !userProfile ? 0.5 : 1 }}
                >
                  <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{birthCountry}</span>
                  <ChevronDown size={16} style={{ flexShrink: 0, color: t.inputLabel }} />
                </button>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '0.65rem', color: t.inputLabel, marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Ville</div>
                <input
                  type="text" placeholder="Paris"
                  disabled={!userProfile}
                  value={birthCity} onChange={e => { setBirthCity(e.target.value); setPreview(null); }}
                  style={{ width: '100%', padding: '10px 12px', borderRadius: '12px', border: `1px solid ${t.inputBorder}`, background: !userProfile ? t.inputBgDisabled : t.inputBg, color: !userProfile ? t.inputTextDisabled : t.inputText, fontFamily: 'inherit', fontSize: '16px', outline: 0 }}
                />
              </div>
            </div>
            <div style={{ marginBottom: '16px' }}>
              <div style={{ fontSize: '0.65rem', color: t.inputLabel, marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Heure</div>
              <input
                type="time"
                placeholder="14:00"
                disabled={!userProfile}
                value={birthTime}
                onChange={e => { setBirthTime(e.target.value); setPreview(null); }}
                style={{ width: '100%', padding: '10px 8px', borderRadius: '12px', border: `1px solid ${t.inputBorder}`, background: !userProfile ? t.inputBgDisabled : t.inputBg, color: !userProfile ? t.inputTextDisabled : t.inputText, fontFamily: 'inherit', fontSize: '16px', outline: 0, boxSizing: 'border-box', opacity: !userProfile ? 0.5 : 1, cursor: !userProfile ? 'not-allowed' : 'text' }}
              />
            </div>

            <style>{`
              .aurora-btn-astro {
                position: relative;
                padding: 12px 24px;
                border: none;
                border-radius: 999px;
                background: linear-gradient(135deg, #cc1a4d, #ff3366, #ff69b4, #cc1a4d);
                color: #fff;
                font-weight: 700;
                font-size: 0.95rem;
                font-family: inherit;
                letter-spacing: 0.18em;
                text-transform: uppercase;
                box-shadow: inset 0 1px 0 rgba(255,255,255,0.25), 0 12px 35px rgba(0,0,0,0.5), 0 8px 20px rgba(255,51,102,0.55), 0 4px 10px rgba(204,26,77,0.4);
                cursor: pointer;
                transition: all 0.25s ease;
                flex: 2;
              }
              .aurora-btn-astro:hover { transform: translateY(-2px) scale(1.02); box-shadow: inset 0 1px 0 rgba(255,255,255,0.25), 0 14px 40px rgba(0,0,0,0.6), 0 10px 25px rgba(255,51,102,0.65); }
              .aurora-btn-astro:active { transform: scale(0.97); }
            `}</style>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={() => { setShowAstroForm(false); setBirthDay(''); setBirthMonth(''); setBirthYear(''); setBirthTime(''); setBirthCity(''); setBirthCountry('France'); setPreview(null); }}
                style={{ flex: 1, padding: '10px', borderRadius: '12px', border: `1px solid ${t.cancelBorder}`, background: 'transparent', color: t.cancelColor, cursor: 'pointer', fontFamily: 'inherit', fontWeight: 600 }}>
                Annuler
              </button>
              <button
                className="aurora-btn-astro"
                disabled={!userProfile || !birthDay || !birthMonth || !birthYear || Number(birthDay) < 1 || Number(birthDay) > 31 || Number(birthMonth) < 1 || Number(birthMonth) > 12 || birthYear.length < 4 || loadingPreview}
                onClick={async (e) => {
                  if (!userProfile) {
                    alert(translate('Remplis d\'abord ta fiche perso (onglet Ma carte)'));
                    return;
                  }
                  const d = Number(birthDay), m = Number(birthMonth);
                  if (!d || !m) return;
                  triggerFlash();
                  setLoadingPreview(true);
                  const result = await buildCosmicProfile({ day: d, month: m, year: Number(birthYear) || undefined, time: birthTime || undefined, city: birthCity || undefined, country: birthCountry || undefined });
                  setLoadingPreview(false);
                  onAstroSave?.(result.sunSign, result.ascendant);
                  setShowAstroForm(false);
                  setBirthDay(''); setBirthMonth(''); setBirthYear(''); setBirthTime(''); setBirthCity(''); setBirthCountry('France'); setPreview(null);
                }}
                style={{ opacity: loadingPreview ? 0.6 : 1 }}
              >
                {loadingPreview ? '⏳ Calcul...' : '🔭 Calculer'}
              </button>
            </div>
          </motion.div>
        )}

        {/* Bouton admin — reset interactions & matchs (visible pour le rôle admin) */}
        {user?.role === 'admin' && (
          <button
            onClick={async () => {
              if (!window.confirm(translate('Remettre à zéro les interactions et matchs de TOUS les profils ?'))) return;
              try {
                const res = await base44.functions.invoke('resetMyInteractions', {});
                if (res.data?.success) {
                  alert(`✅ Reset global : ${res.data?.sessionReset || 0} sessions, ${res.data?.profileReset || 0} profils, ${res.data?.messageDeleted || 0} messages, ${res.data?.threadDeleted || 0} matchs et ${res.data?.lockDeleted || 0} locks supprimés.`);
                  window.location.reload();
                } else {
                  alert(translate('Erreur : ') + (res.data?.error || translate('réessaie')));
                }
              } catch (e) {
                alert(translate('Erreur : ') + (e.message || e));
              }
            }}
            style={{ background: 'rgba(255,51,102,0.1)', border: '1px solid rgba(255,51,102,0.3)', color: '#ff3366', fontSize: '0.72rem', fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit', width: '100%', padding: '10px', borderRadius: '9999px', letterSpacing: '0.05em' }}
          >
            🛠️ Admin · Reset interactions & matchs
          </button>
        )}

      </div>

      {/* Floating theme button */}
      <button
        onClick={() => setShowThemePicker(v => !v)}
        style={{
          position: 'fixed', bottom: 96, right: 16, zIndex: 200,
          width: 40, height: 40, borderRadius: '50%', border: 'none',
          background: bgTheme === 'dark' ? '#111' : bgTheme === 'white' ? '#f0e6d3' : '#ff3366',
          boxShadow: '0 4px 16px rgba(0,0,0,0.4)',
          cursor: 'pointer', fontSize: '1.1rem',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
      >🎨</button>

      {showThemePicker && (
        <>
          <div onClick={() => setShowThemePicker(false)} style={{ position: 'fixed', inset: 0, zIndex: 199 }} />
          <div style={{
            position: 'fixed', bottom: 148, right: 16, zIndex: 200,
            background: 'rgba(18,18,24,0.96)', backdropFilter: 'blur(16px)',
            border: '1px solid rgba(255,255,255,0.1)', borderRadius: '20px',
            padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: '12px',
            boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
          }}>
            <span style={{ fontSize: '0.62rem', color: t.textMuted, textTransform: 'uppercase', letterSpacing: '0.12em', fontWeight: 700, textAlign: 'center' }}>Couleur de fond</span>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center', justifyContent: 'center' }}>
              {[
                { id: 'dark', color: '#111', label: '⚫' },
                { id: 'white', color: '#f0e6d3', label: '⚪' },
                { id: 'pink', color: '#ff3366', label: '🩷' },
              ].map(({ id, color, label }) => (
                <button
                  key={id}
                  onClick={() => { onBgTheme?.(id); setShowThemePicker(false); }}
                  style={{
                    width: 40, height: 40, borderRadius: '50%', background: color, border: 'none',
                    cursor: 'pointer', fontSize: '1.1rem',
                    boxShadow: bgTheme === id ? '0 0 0 3px #fff, 0 0 0 5px #ff3366' : '0 0 0 2px rgba(255,255,255,0.2)',
                    transition: 'box-shadow 0.2s ease',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}
                >{label}</button>
              ))}
            </div>
            <div style={{ borderTop: '1px solid rgba(255,255,255,0.08)', paddingTop: '12px', marginTop: '4px' }}>
              <button
                onClick={() => onToggleAutoLight?.()}
                style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px',
                  width: '100%', padding: '8px 4px', background: 'none', border: 'none',
                  cursor: 'pointer', fontFamily: 'inherit',
                }}
              >
                <span style={{ fontSize: '0.78rem', color: '#cfcfda', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6 }}>
                  ☀️ Mode auto soleil
                </span>
                <span style={{
                  width: 36, height: 20, borderRadius: '999px', position: 'relative',
                  background: autoLight ? '#ff3366' : 'rgba(255,255,255,0.15)',
                  transition: 'background 0.2s ease', flexShrink: 0,
                }}>
                  <span style={{
                    position: 'absolute', top: 2, left: autoLight ? 18 : 2,
                    width: 16, height: 16, borderRadius: '50%', background: '#fff',
                    transition: 'left 0.2s ease',
                  }} />
                </span>
              </button>
              <p style={{ margin: '6px 4px 0', fontSize: '0.65rem', color: '#9f9fae', lineHeight: 1.4 }}>
                Bascule sur fond clair en pleine lumière.
              </p>
            </div>
          </div>
        </>
      )}

      {showCountryPicker && (
        <SelectModal
          title="Pays de naissance"
          options={BIRTH_COUNTRIES}
          value={birthCountry}
          onSelect={(c) => { setBirthCountry(c); setPreview(null); setShowCountryPicker(false); }}
          onClose={() => setShowCountryPicker(false)}
        />
      )}
    </div>
  );
}