import React from 'react';

const pageStyle = {
  position: 'fixed',
  inset: 0,
  zIndex: 10000,
  background: 'rgba(0,0,0,0.82)',
  backdropFilter: 'blur(8px)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '24px 20px',
  fontFamily: "'Poppins', sans-serif",
};

const cardStyle = {
  width: '100%',
  maxWidth: '340px',
  background: 'rgba(15,15,19,0.96)',
  border: '1px solid rgba(255,255,255,0.14)',
  borderRadius: '24px',
  padding: '28px 24px',
  textAlign: 'center',
  boxShadow: '0 24px 64px rgba(0,0,0,0.6)',
};

export default function AgeConfirmModal({ onConfirm, onCancel }) {
  return (
    <div style={pageStyle} onClick={onCancel}>
      <div style={cardStyle} onClick={e => e.stopPropagation()}>
        <div style={{ fontSize: '2.6rem', marginBottom: '12px' }}>🔞</div>
        <h2 style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontSize: '1.4rem', fontWeight: 700, color: '#fff', margin: '0 0 10px' }}>
          Confirmation d'âge
        </h2>
        <p style={{ color: '#cfcfda', fontSize: '0.9rem', lineHeight: 1.55, margin: '0 0 22px' }}>
          ToDay est réservé aux personnes âgées de <strong style={{ color: '#ff69b4' }}>18 ans ou plus</strong>.
          Confirme que tu remplis cette condition pour continuer.
        </p>
        <button
          onClick={onConfirm}
          style={{
            width: '100%', minHeight: '50px', borderRadius: '999px', fontWeight: 700, fontSize: '0.95rem',
            background: 'linear-gradient(90deg, #ff3366, #ff69b4)', color: '#fff',
            border: 'none', cursor: 'pointer', fontFamily: 'inherit',
            boxShadow: '0 12px 24px rgba(255,51,102,0.22)', marginBottom: '10px',
          }}
        >
          J'ai 18 ans ou plus
        </button>
        <button
          onClick={onCancel}
          style={{
            width: '100%', minHeight: '44px', borderRadius: '999px', fontWeight: 600, fontSize: '0.88rem',
            background: 'transparent', color: '#9f9fae',
            border: '1px solid rgba(255,255,255,0.12)', cursor: 'pointer', fontFamily: 'inherit',
          }}
        >
          Annuler
        </button>
      </div>
    </div>
  );
}