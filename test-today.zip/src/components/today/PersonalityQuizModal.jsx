import React, { useState, useMemo } from 'react';
import ReactDOM from 'react-dom';
import { X } from 'lucide-react';
import { pickRandomQuestions, computePersonalityProfile, generateQuizPhrase, getPersonalityCompatLabel, localizeQuizPhrase } from '../../lib/quiz-data';
import { useLanguage } from '@/lib/i18n/LanguageContext';

const TOTAL = 15;

export default function PersonalityQuizModal({ onClose, onSave, existingProfile }) {
  const questions = useMemo(() => pickRandomQuestions(), []);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({});
  // If already done, show results immediately
  const [result, setResult] = useState(existingProfile ? { profile: existingProfile, phrase: null } : null);
  const [saving, setSaving] = useState(false);
  // Phrase du résultat : retraduite si la langue change pendant l'affichage.
  const { lang, t } = useLanguage();
  const localizedPhrase = useMemo(() => localizeQuizPhrase(result?.phrase), [lang, result?.phrase]);

  const q = questions[current];
  const progress = Object.keys(answers).length;
  const isDone = progress === TOTAL;

  function handleAnswer(choice) {
    const newAnswers = { ...answers, [q.id]: choice };
    setAnswers(newAnswers);
    if (current < TOTAL - 1) {
      setCurrent(c => c + 1);
    } else {
      // Compute result
      const profile = computePersonalityProfile(newAnswers);
      const phrase = generateQuizPhrase(newAnswers);
      setResult({ profile, phrase });
    }
  }

  async function handleSave() {
    setSaving(true);
    await onSave?.(result.profile, result.phrase);
    setSaving(false);
    onClose?.();
  }

  const dimLabels = {
    social: 'Social',
    emotionnel: 'Émotionnel',
    modeVie: 'Mode de vie',
    relationnel: 'Relationnel',
    valeurs: 'Valeurs',
  };

  return ReactDOM.createPortal(
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      background: 'rgba(0,0,0,0.92)',
      display: 'flex', flexDirection: 'column',
      overflowY: 'auto',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px', borderBottom: '1px solid rgba(255,255,255,0.07)', flexShrink: 0 }}>
        <div>
          <div style={{ color: '#ff69b4', fontSize: '0.68rem', textTransform: 'uppercase', letterSpacing: '0.14em', fontWeight: 700 }}>Test de personnalité</div>
          {!result && <div style={{ color: '#9f9fae', fontSize: '0.78rem', marginTop: 2 }}>{current + 1} / {TOTAL}</div>}
        </div>
        <button onClick={onClose} style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#fff' }}>
          <X size={16} />
        </button>
      </div>

      {/* Progress bar */}
      {!result && (
        <div style={{ height: 3, background: 'rgba(255,255,255,0.07)', flexShrink: 0 }}>
          <div style={{ height: '100%', background: 'linear-gradient(90deg, #ff3366, #ff69b4)', width: `${((current + 1) / TOTAL) * 100}%`, transition: 'width 0.3s ease' }} />
        </div>
      )}

      {/* Content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '24px 20px', gap: '20px' }}>
        {!result ? (
          <>
            {/* Question */}
            <div style={{
              padding: '24px 20px', borderRadius: '22px',
              background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
              textAlign: 'center',
            }}>
              <div style={{ fontSize: '0.68rem', color: '#9f9fae', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '14px', fontWeight: 600 }}>
                Question {current + 1}
              </div>
              <p style={{ margin: 0, fontSize: '1.2rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 700, color: '#fff', lineHeight: 1.5 }}>
                {t(q.text)}
              </p>
            </div>

            {/* Réponses */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {['A', 'B', 'C'].map((letter) => (
                <button
                  key={letter}
                  onClick={() => handleAnswer(letter)}
                  style={{
                    width: '100%', padding: '16px 20px', borderRadius: '18px',
                    background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)',
                    color: '#fff', fontFamily: 'inherit', fontSize: '0.95rem', fontWeight: 500,
                    cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: '14px',
                    transition: 'all 0.12s ease',
                  }}
                  onPointerDown={e => { e.currentTarget.style.background = 'rgba(255,51,102,0.14)'; e.currentTarget.style.borderColor = 'rgba(255,51,102,0.5)'; e.currentTarget.style.transform = 'scale(0.98)'; }}
                  onPointerUp={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'; e.currentTarget.style.transform = ''; }}
                  onPointerLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'; e.currentTarget.style.transform = ''; }}
                >
                  <span style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(255,51,102,0.12)', border: '1px solid rgba(255,51,102,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontWeight: 800, fontSize: '0.85rem', color: '#ff69b4' }}>
                    {letter}
                  </span>
                  <span style={{ lineHeight: 1.4 }}>{t(q[letter])}</span>
                </button>
              ))}
            </div>

            {/* Navigation retour */}
            {current > 0 && (
              <button onClick={() => setCurrent(c => c - 1)} style={{ background: 'none', border: 'none', color: '#9f9fae', fontSize: '0.82rem', cursor: 'pointer', fontFamily: 'inherit', textAlign: 'center', padding: '8px' }}>
                ← Question précédente
              </button>
            )}
          </>
        ) : (
          /* Résultat */
          <>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3rem', marginBottom: '8px' }}>✨</div>
              <h2 style={{ margin: '0 0 6px', fontSize: '1.6rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800 }}>Ton profil de personnalité</h2>
              {localizedPhrase && <p style={{ margin: 0, color: '#ff69b4', fontStyle: 'italic', fontSize: '0.9rem' }}>"{localizedPhrase}"</p>}
              {existingProfile && (
                <p style={{ margin: '6px 0 0', color: '#59d39a', fontSize: '0.78rem', fontWeight: 700 }}>✅ Test déjà complété</p>
              )}
            </div>

            {/* Scores par dimension */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {Object.entries(result.profile).map(([dim, score]) => {
                const label = getPersonalityCompatLabel(score);
                return (
                  <div key={dim} style={{ padding: '14px 16px', borderRadius: '16px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                      <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#cfcfda' }}>{t(dimLabels[dim])}</span>
                      <span style={{ fontSize: '0.78rem', fontWeight: 700, color: label.color }}>{score}/100</span>
                    </div>
                    <div style={{ height: 6, borderRadius: '999px', background: 'rgba(255,255,255,0.07)', overflow: 'hidden' }}>
                      <div style={{ height: '100%', borderRadius: '999px', background: `linear-gradient(90deg, #ff3366, #ff69b4)`, width: `${score}%`, transition: 'width 0.8s ease' }} />
                    </div>
                  </div>
                );
              })}
            </div>

            <p style={{ margin: 0, color: '#9f9fae', fontSize: '0.8rem', textAlign: 'center', lineHeight: 1.5 }}>
              Ces scores seront utilisés pour calculer ta compatibilité avec les autres profils.
            </p>

            {/* Boutons */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: 'auto' }}>
              {existingProfile ? (
                <button onClick={onClose} style={{
                  width: '100%', minHeight: '52px', borderRadius: '999px',
                  background: 'linear-gradient(90deg, #ff3366, #ff69b4)',
                  color: '#fff', fontWeight: 800, fontSize: '1rem', fontFamily: 'inherit',
                  border: 'none', cursor: 'pointer',
                }}>
                  ✅ Fermer
                </button>
              ) : (
                <>
                  <button onClick={handleSave} disabled={saving} style={{
                    width: '100%', minHeight: '52px', borderRadius: '999px',
                    background: 'linear-gradient(90deg, #ff3366, #ff69b4)',
                    color: '#fff', fontWeight: 800, fontSize: '1rem', fontFamily: 'inherit',
                    border: 'none', cursor: saving ? 'not-allowed' : 'pointer',
                    opacity: saving ? 0.6 : 1,
                  }}>
                    {saving ? 'Enregistrement...' : '✅ Sauvegarder mon profil'}
                  </button>
                  <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#9f9fae', fontSize: '0.85rem', cursor: 'pointer', fontFamily: 'inherit', padding: '8px' }}>
                    Annuler
                  </button>
                </>
              )}
            </div>
          </>
        )}
      </div>
    </div>,
    document.body
  );
}