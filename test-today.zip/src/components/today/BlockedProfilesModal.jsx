import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import Avatar from './Avatar';
import { base44 } from '../../api/base44Client';
import useOverlayBack from '../../hooks/useOverlayBack';

export default function BlockedProfilesModal({ userProfile, onClose, onUnblock }) {
  useOverlayBack(true, onClose);
  const [blocked, setBlocked] = useState([]);
  const [loading, setLoading] = useState(true);
  const [unblockingId, setUnblockingId] = useState(null);

  useEffect(() => {
    const ids = Array.isArray(userProfile?.blocked_profile_ids) ? userProfile.blocked_profile_ids : [];
    if (ids.length === 0) {
      setBlocked([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    Promise.all(
      ids.map(id => base44.entities.Profile.get(id).catch(() => null))
    ).then(results => {
      setBlocked(results.filter(Boolean));
      setLoading(false);
    });
  }, [userProfile?.blocked_profile_ids]);

  async function handleUnblock(profile) {
    setUnblockingId(profile.id);
    try {
      await onUnblock?.(profile.id);
      setBlocked(prev => prev.filter(p => p.id !== profile.id));
    } finally {
      setUnblockingId(null);
    }
  }

  return (
    <div
      onClick={onClose}
      style={{ position: 'fixed', inset: 0, zIndex: 10000, background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: '440px', maxHeight: '80vh', overflowY: 'auto',
          background: 'rgba(15,15,19,0.98)', border: '1px solid rgba(255,51,102,0.25)',
          borderRadius: '24px 24px 0 0', padding: '20px 16px calc(env(safe-area-inset-bottom) + 20px)',
          boxShadow: '0 -8px 40px rgba(255,51,102,0.15)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
          <div>
            <div style={{ color: '#ff69b4', textTransform: 'uppercase', letterSpacing: '0.14em', fontSize: '0.68rem', fontWeight: 700 }}>Modération</div>
            <h3 style={{ margin: '4px 0 0', fontSize: '1.25rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, color: '#fff' }}>Profils bloqués</h3>
          </div>
          <button onClick={onClose} style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '50%', width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#cfcfda' }}>
            <X size={18} />
          </button>
        </div>

        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '40px 0' }}>
            <div style={{ width: 32, height: 32, border: '3px solid rgba(255,255,255,0.1)', borderTopColor: '#ff3366', borderRadius: '50%', animation: 'spin 0.6s linear infinite' }} />
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          </div>
        ) : blocked.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px 16px', color: '#9f9fae', fontSize: '0.88rem' }}>
            <div style={{ fontSize: '2rem', marginBottom: '8px' }}>🕊️</div>
            Aucun profil bloqué.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {blocked.map(p => (
              <div
                key={p.id}
                style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', borderRadius: '16px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}
              >
                <Avatar
                  photoUrl={p.photo_url}
                  name={p.display_name}
                  size={44}
                  sizes="44px"
                  style={{ border: '1.5px solid rgba(255,51,102,0.3)' }}
                />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: '0.92rem', color: '#fff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {p.display_name || 'Profil'}
                  </div>
                  {p.city && <div style={{ fontSize: '0.75rem', color: '#9f9fae' }}>📍 {p.city}</div>}
                </div>
                <button
                  onClick={() => handleUnblock(p)}
                  disabled={unblockingId === p.id}
                  style={{
                    padding: '8px 14px', borderRadius: '999px', fontSize: '0.78rem', fontWeight: 700,
                    border: '1px solid rgba(89,211,154,0.4)', background: 'rgba(89,211,154,0.12)',
                    color: '#59d39a', cursor: unblockingId === p.id ? 'wait' : 'pointer', fontFamily: 'inherit',
                    opacity: unblockingId === p.id ? 0.5 : 1,
                  }}
                >
                  {unblockingId === p.id ? '…' : 'Débloquer'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}