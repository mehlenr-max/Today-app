import React from 'react';
import { Check, X } from 'lucide-react';
import useOverlayBack from '../../hooks/useOverlayBack';

// Sélecteur unique affiché dans une fenêtre centrée (remplace les <select>
// natifs, peu confortables sur iOS / Android).
export default function SelectModal({ title, options, value, onSelect, onClose, isWhite = false }) {
  useOverlayBack(true, onClose);

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 10000,
        background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '24px',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: '380px', maxHeight: '72vh',
          display: 'flex', flexDirection: 'column',
          borderRadius: '24px', overflow: 'hidden',
          border: isWhite ? '1px solid rgba(0,0,0,0.1)' : '1px solid rgba(255,255,255,0.1)',
          background: isWhite ? '#faf5ec' : '#0f0f13',
          boxShadow: '0 24px 60px rgba(0,0,0,0.55)',
        }}
      >
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '16px 18px',
          borderBottom: isWhite ? '1px solid rgba(0,0,0,0.08)' : '1px solid rgba(255,255,255,0.07)',
        }}>
          <strong style={{ fontSize: '1rem', color: isWhite ? '#111' : '#fff' }}>{title}</strong>
          <button
            onClick={onClose}
            aria-label="Fermer"
            style={{
              width: 32, height: 32, borderRadius: '50%', flexShrink: 0,
              border: isWhite ? '1px solid rgba(0,0,0,0.12)' : '1px solid rgba(255,255,255,0.12)',
              background: isWhite ? 'rgba(0,0,0,0.04)' : 'rgba(255,255,255,0.06)',
              color: isWhite ? '#555' : '#cfcfda', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <X size={16} />
          </button>
        </div>

        <div style={{ overflowY: 'auto', padding: '8px' }}>
          {options.map(option => {
            const selected = option === value;
            return (
              <button
                key={option}
                onClick={() => onSelect(option)}
                style={{
                  width: '100%', minHeight: '52px',
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px',
                  padding: '12px 14px', marginBottom: '4px',
                  borderRadius: '16px', cursor: 'pointer', fontFamily: 'inherit',
                  border: selected ? '1px solid rgba(255,51,102,0.85)' : '1px solid transparent',
                  background: selected ? 'rgba(255,51,102,0.22)' : 'transparent',
                  color: selected ? '#ff3366' : (isWhite ? '#111' : '#cfcfda'),
                  fontSize: '0.95rem', fontWeight: 600, textAlign: 'left',
                }}
              >
                <span>{option}</span>
                {selected && <Check size={18} strokeWidth={3} style={{ flexShrink: 0 }} />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}