import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  LIKE_ITEMS_FOR_WOMEN, LIKE_ITEMS_FOR_MEN, DISLIKE_ITEMS, DISLIKE_ITEMS_FOR_MEN, CITIES
} from '../../lib/today-data';
import {
  PUBLICATION_TIME_SLOTS, AGE_RANGES, DISTANCE_OPTIONS,
  DESIRED_MORPHOLOGIES_WOMEN, DESIRED_MORPHOLOGIES_MEN
} from '../../lib/today-constants';
import { getCreatePrefs } from '../../lib/today-store';
import PillBtn from '../shared/PillBtn';
import { Sparkles, ChevronDown } from 'lucide-react';
import SelectModal from './SelectModal';
import { translate } from '@/lib/i18n/engine';


export default function CreateDateTab({ user, userProfile, isOnline, onPublished, onToggleOnline, onGoHome, bgTheme }) {
  const [timeSlots, setTimeSlots] = useState([]);
  const [seeking, setSeeking] = useState(() => userProfile?.seeking || (userProfile?.gender === 'garçon' ? 'fille' : 'garçon'));
  const [ageRange, setAgeRange] = useState([]);
  const [distance, setDistance] = useState('0-10');
  const [city, setCity] = useState(userProfile?.city || 'Bruxelles');
  const [likes, setLikes] = useState([]);
  const [dislikes, setDislikes] = useState([]);
  const [desiredTraits, setDesiredTraits] = useState([]);
  const [minHeight, setMinHeight] = useState('');
  const [error, setError] = useState('');
  const [showFlash, setShowFlash] = useState(false);
  const [showOfflineModal, setShowOfflineModal] = useState(false);
  const [showCityPicker, setShowCityPicker] = useState(false);

  const isWhite = bgTheme === 'white';

  const inputStyle = useMemo(() => ({
    width: '100%', border: isWhite ? '1px solid rgba(0,0,0,0.12)' : '1px solid rgba(255,255,255,0.08)', borderRadius: '18px',
    background: isWhite ? 'rgba(0,0,0,0.03)' : 'rgba(255,255,255,0.04)', color: isWhite ? '#111' : '#fff', padding: '14px 16px',
    outline: 0, fontFamily: 'inherit', fontSize: '0.95rem',
  }), [isWhite]);

  const labelStyle = useMemo(() => ({
    display: 'block', marginBottom: '6px', color: isWhite ? '#666' : '#9f9fae',
    fontSize: '0.68rem', letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700,
  }), [isWhite]);

  const card = useMemo(() => ({
    borderRadius: '22px', border: isWhite ? '1px solid rgba(0,0,0,0.08)' : '1px solid rgba(255,255,255,0.06)',
    background: isWhite ? 'rgba(255,255,255,0.75)' : 'rgba(15,15,19,0.72)', backdropFilter: 'blur(16px)',
    boxShadow: isWhite ? '0 2px 12px rgba(0,0,0,0.06)' : 'inset 0 1px 0 rgba(255,255,255,0.04)',
    padding: '18px',
  }), [isWhite]);

  // Réinitialiser l'erreur dès que les critères manquants sont remplis
  useEffect(() => {
    if (!error) return;
    if (error.includes('tranche') && ageRange.length >= 1) setError('');
    if (error.includes('morphologie') && desiredTraits.length >= 1 && desiredTraits.length <= 2) setError('');
  }, [ageRange, desiredTraits]);

  // Réinitialiser l'erreur quand le statut online change
  useEffect(() => {
    setError('');
  }, [isOnline]);

  // Mettre à jour seeking depuis le profil
  useEffect(() => {
    if (userProfile?.seeking) {
      setSeeking(userProfile.seeking);
    } else if (userProfile?.gender) {
      setSeeking(userProfile.gender === 'garçon' ? 'fille' : 'garçon');
    }
  }, [userProfile?.seeking, userProfile?.gender]);

  // Filtrer la morphologie recherchée quand le genre recherché change
  // (les morphologies sont spécifiques au genre → on ne conserve que les IDs valides)
  useEffect(() => {
    const validIds = (seeking === 'garçon' ? DESIRED_MORPHOLOGIES_MEN : DESIRED_MORPHOLOGIES_WOMEN).map(m => m.id);
    setDesiredTraits(prev => prev.filter(t => validIds.includes(t)));
  }, [seeking]);

  // Synchroniser la ville depuis le profil dès qu'elle change
  useEffect(() => {
    if (userProfile?.city) {
      setCity(userProfile.city);
    }
  }, [userProfile?.city]);

  // Charger les préférences : session du jour en priorité, sinon profil persisté (survit à la déconnexion)
  useEffect(() => {
    if (!user?.id) return;
    getCreatePrefs(user.id).then(saved => {
      const finalPrefs = saved || (userProfile?.create_prefs ? (() => { try { return JSON.parse(userProfile.create_prefs); } catch { return null; } })() : null);
      if (!finalPrefs) return;
      if (finalPrefs.timeSlot) {
        const ts = finalPrefs.timeSlot;
        setTimeSlots(Array.isArray(ts) ? ts : (typeof ts === 'string' && ts ? ts.split('|').filter(Boolean) : []));
      }
      if (finalPrefs.seeking) setSeeking(finalPrefs.seeking);
      if (finalPrefs.ageRange) setAgeRange(finalPrefs.ageRange);
      if (finalPrefs.distance) setDistance(finalPrefs.distance);
      if (finalPrefs.city) setCity(finalPrefs.city);
      if (finalPrefs.likes) setLikes(finalPrefs.likes);
      if (finalPrefs.dislikes) setDislikes(finalPrefs.dislikes);
      if (finalPrefs.desiredTraits) setDesiredTraits(finalPrefs.desiredTraits);
      else if (finalPrefs.physicalTraits) setDesiredTraits(finalPrefs.physicalTraits);
      if (finalPrefs.minHeight) setMinHeight(finalPrefs.minHeight);
    });
  }, [user?.id, userProfile?.id]);



  const toggleArr = useCallback((arr, setArr, item) => {
    setArr(prev => prev.includes(item) ? prev.filter(i => i !== item) : [...prev, item]);
  }, []);

  function wordCount(s) { return s.trim().split(/\s+/).filter(Boolean).length; }

  const likeItemsMemo = useMemo(() => seeking === 'garçon' ? LIKE_ITEMS_FOR_MEN : LIKE_ITEMS_FOR_WOMEN, [seeking]);
  const morphologyItemsMemo = useMemo(() => seeking === 'garçon' ? DESIRED_MORPHOLOGIES_MEN : DESIRED_MORPHOLOGIES_WOMEN, [seeking]);
  const dislikeItemsMemo = useMemo(() => seeking === 'fille' ? DISLIKE_ITEMS_FOR_MEN : DISLIKE_ITEMS, [seeking]);

  function handlePublish(profile = userProfile) {
    if (!isOnline) { setShowOfflineModal(true); return; }
    if (userProfile?.accepted_date_key) { alert(translate('Tu as déjà accepté un date. Reviens demain !')); return; }
    if (ageRange.length < 1) { setError('Choisis au moins 1 tranche d\'âge.'); return; }
    if (desiredTraits.length < 1) { setError('Choisis au moins 1 morphologie recherchée.'); return; }
    if (desiredTraits.length > 2) { setError('Choisis maximum 2 morphologies recherchées.'); return; }
    const prefs = { seeking, ageRange, distance, myCity: city, likes, dislikes, physicalTraits: desiredTraits, desiredTraits, minHeight: minHeight ? Number(minHeight) : null, timeSlot: timeSlots, myPhysicalTraits: userProfile?.own_physical_traits || [], myGender: userProfile?.gender || '' };
    const updated = {
      user_id: user.id,
      // Préserver TOUS les champs existants du profil
      ...(profile || {}),
      // Écraser seulement les champs du date
      time_slot: timeSlots.join('|'),
      seeking,
      desired_age_range: ageRange.join('|'),
      desired_distance_range: distance,
      city,
      likes,
      dislikes,
      desired_physical_traits: desiredTraits,
    };
    onPublished(prefs, updated);
  }



  // Racine en flux naturel comme l'onglet Flamme : le seul défileur est le
  // conteneur de l'onglet.
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100%' }}>

      {/* Popup offline */}
      {showOfflineModal && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 9999,
          background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px',
        }} onClick={() => setShowOfflineModal(false)}>
          <div onClick={e => e.stopPropagation()} style={{
            background: 'rgba(15,15,19,0.98)', border: '1px solid rgba(255,51,102,0.3)',
            borderRadius: '24px', padding: '32px 24px', textAlign: 'center', maxWidth: '320px', width: '100%',
            boxShadow: '0 0 40px rgba(255,51,102,0.2)',
          }}>
            <div style={{ fontSize: '2.5rem', marginBottom: '12px' }}>🔴</div>
            <h3 style={{ margin: '0 0 8px', fontSize: '1.1rem', fontWeight: 800, color: '#fff' }}>Tu es hors ligne</h3>
            <p style={{ margin: '0 0 24px', color: '#9f9fae', fontSize: '0.88rem', lineHeight: 1.5 }}>
              Active ton statut <strong style={{ color: '#59d39a' }}>En ligne</strong> pour pouvoir publier ton date.
            </p>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={() => setShowOfflineModal(false)} style={{
                flex: 1, padding: '12px', borderRadius: '12px', fontWeight: 600, fontSize: '0.9rem',
                border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.05)',
                color: '#9f9fae', cursor: 'pointer', fontFamily: 'inherit',
              }}>Annuler</button>
              <button onClick={() => { setShowOfflineModal(false); onToggleOnline(); }} style={{
                flex: 1, padding: '12px', borderRadius: '12px', fontWeight: 700, fontSize: '0.9rem',
                border: '1px solid rgba(89,211,154,0.4)', background: 'rgba(89,211,154,0.12)',
                color: '#59d39a', cursor: 'pointer', fontFamily: 'inherit',
              }}>Me mettre en ligne</button>
            </div>
          </div>
        </div>
      )}
      <div style={{ padding: '16px 16px 12px', borderBottom: isWhite ? '1px solid rgba(0,0,0,0.08)' : '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ color: '#ff69b4', textTransform: 'uppercase', letterSpacing: '0.14em', fontSize: '0.72rem', fontWeight: 700 }}>Créer</div>
        <h2 style={{ margin: '4px 0 2px', fontSize: '1.4rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, color: isWhite ? '#111' : '#fff' }}>Ton date ce soir</h2>
        <p style={{ margin: 0, color: isWhite ? '#555' : '#9f9fae', fontSize: '0.82rem' }}>Publie ta demande pour ce soir.</p>
      </div>

      {/* Bouton sticky */}
      <div style={{ position: 'sticky', top: 0, zIndex: 10, padding: '10px 16px', background: isWhite ? 'rgba(240,230,211,0.95)' : 'rgba(7,7,9,0.95)', backdropFilter: 'blur(12px)', borderBottom: isWhite ? '1px solid rgba(0,0,0,0.08)' : '1px solid rgba(255,255,255,0.05)' }}>
        {showFlash && (
          <div style={{ position: 'fixed', inset: 0, zIndex: 9999, background: 'white', animation: 'flashOut 0.35s ease-out forwards', pointerEvents: 'none' }} />
        )}
        <style>{`
          @keyframes flashOut { 0% { opacity: 1; } 100% { opacity: 0; } }
          @keyframes sparkle { 0%, 100% { opacity: 1; transform: scale(1) rotate(0deg); } 50% { opacity: 0.7; transform: scale(1.2) rotate(15deg); } }
          .aurora-btn {
            position: relative;
            padding: 14px 32px;
            border: none;
            border-radius: 999px;
            background: linear-gradient(135deg, #cc1a4d, #ff3366, #ff69b4, #cc1a4d);
            color: #fff;
            font-weight: 700;
            font-size: 1rem;
            font-family: inherit;
            letter-spacing: 0.18em;
            text-transform: uppercase;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.25), 0 12px 35px rgba(0,0,0,0.5), 0 8px 20px rgba(255,51,102,0.55), 0 4px 10px rgba(204,26,77,0.4);
            cursor: pointer;
            transition: all 0.25s ease;
            display: block;
            margin: 0 auto;
          }
          .aurora-btn span {
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
          }
          .aurora-btn:hover {
            transform: translateY(-2px) scale(1.02);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.25), 0 14px 40px rgba(0,0,0,0.6), 0 10px 25px rgba(255,51,102,0.65);
          }
          .aurora-btn:active { transform: scale(0.97); }
          .sparkle-icon { animation: sparkle 1.8s ease-in-out infinite; }
        `}</style>
        <button className="aurora-btn"
          onClick={(e) => {
            const publishButton = e.currentTarget;
            if (!isOnline) { setShowOfflineModal(true); return; }
            if (userProfile?.accepted_date_key) { alert(translate('Tu as déjà accepté un date. Reviens demain !')); return; }
            if (ageRange.length < 1) { setError('Choisis au moins 1 tranche d\'âge.'); return; }
            if (desiredTraits.length < 1) { setError('Choisis au moins 1 morphologie recherchée.'); return; }
            if (desiredTraits.length > 2) { setError('Choisis maximum 2 morphologies recherchées.'); return; }
            // Tout est valide → explosion + publication
            setShowFlash(true);
            setTimeout(() => setShowFlash(false), 420);
            const rect = publishButton.getBoundingClientRect();
            const x = (rect.left + rect.width / 2) / window.innerWidth;
            const y = (rect.top + rect.height / 2) / window.innerHeight;
            confetti({ particleCount: 25, spread: 70, origin: { x, y }, colors: ['#ffffff'], shapes: ['star'], scalar: 0.9, gravity: 0.7, ticks: 140 });
            handlePublish();
          }}
        >
          <span>
            <Sparkles size={18} className="sparkle-icon" />
            DATE TODAY
            <Sparkles size={18} className="sparkle-icon" style={{ animationDelay: '0.9s' }} />
          </span>
          <div className="shine"></div>
        </button>
      </div>

      <div style={{ padding: '16px', paddingBottom: '120px', display: 'flex', flexDirection: 'column', gap: '14px' }}>

        {error && (
          <div style={{ background: 'rgba(255,51,102,0.1)', border: '1px solid rgba(255,51,102,0.3)', borderRadius: '14px', padding: '12px 16px', color: '#ff6a7c', fontSize: '0.88rem' }}>
            {error}
            {(error.includes('test de personnalité') || error.includes('profil cosmique')) && (
              <button onClick={onGoHome} style={{ display: 'block', marginTop: '8px', background: 'rgba(255,51,102,0.2)', border: '1px solid rgba(255,51,102,0.4)', borderRadius: '10px', padding: '8px 16px', color: '#fff', fontWeight: 700, fontSize: '0.85rem', cursor: 'pointer', fontFamily: 'inherit', width: '100%' }}>
                → Aller remplir {error.includes('personnalité') ? 'le test de personnalité' : 'le profil cosmique'}
              </button>
            )}
          </div>
        )}



        {/* Heure */}
        <div style={card}>
          <strong style={{ display: 'block', fontSize: '0.95rem', marginBottom: '4px' }}>Tranches horaires</strong>
          <p style={{ margin: '0 0 12px', fontSize: '0.82rem', color: isWhite ? '#555' : '#9f9fae' }}>Indicatif — choisis une ou plusieurs tranches ({timeSlots.length} sélectionnée{timeSlots.length > 1 ? 's' : ''})</p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            {PUBLICATION_TIME_SLOTS.map(t => <PillBtn key={t} active={timeSlots.includes(t)} onClick={() => toggleArr(timeSlots, setTimeSlots, t)}>{t}</PillBtn>)}
          </div>
        </div>


        {/* Âge + Distance + Ville */}
        <div style={card}>
          <strong style={{ display: 'block', fontSize: '0.95rem', marginBottom: '12px' }}>Critères</strong>
          <label style={labelStyle}>Tranches d'âge <span style={{ color: '#ff3366' }}>*</span></label>
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '14px' }}>
            {AGE_RANGES.map(r => <PillBtn key={r} light={isWhite} active={ageRange.includes(r)} onClick={() => toggleArr(ageRange, setAgeRange, r)}>{r}</PillBtn>)}
          </div>
          <label style={labelStyle}>Distance maximale que tu es prêt à faire</label>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '14px' }}>
            {DISTANCE_OPTIONS.map(d => <PillBtn key={d.value} light={isWhite} active={distance === d.value} onClick={() => setDistance(d.value)}>{d.label}</PillBtn>)}
          </div>
          <label style={labelStyle}>Taille minimum (cm)</label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '14px' }}>
            {['', '150', '155', '160', '165', '170', '175', '180', '185', '190'].map(h => (
              <PillBtn key={h} light={isWhite} active={minHeight === h} onClick={() => setMinHeight(h)}>
                {h === '' ? 'Peu importe' : `${h} cm+`}
              </PillBtn>
            ))}
          </div>
          <label style={labelStyle}>Ma ville</label>
          <button
            type="button"
            onClick={() => setShowCityPicker(true)}
            style={{ ...inputStyle, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', cursor: 'pointer', textAlign: 'left' }}
          >
            <span>{city}</span>
            <ChevronDown size={18} style={{ color: isWhite ? '#666' : '#9f9fae', flexShrink: 0 }} />
          </button>
          {showCityPicker && (
            <SelectModal
              title="Ma ville"
              options={CITIES}
              value={city}
              isWhite={isWhite}
              onSelect={(c) => { setCity(c); setShowCityPicker(false); }}
              onClose={() => setShowCityPicker(false)}
            />
          )}
        </div>

        {/* Morphologie recherchée */}
        <div style={card}>
          <strong style={{ display: 'block', fontSize: '0.95rem', marginBottom: '4px' }}>Morphologie recherchée <span style={{ color: '#ff3366' }}>*</span></strong>
          <p style={{ margin: '0 0 14px', fontSize: '0.82rem', color: isWhite ? '#555' : '#9f9fae' }}>Min. 1 · Max. 2 — {desiredTraits.length}/2 sélectionné{desiredTraits.length > 1 ? 's' : ''}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {morphologyItemsMemo.map(m => {
              const selected = desiredTraits.includes(m.id);
              const maxReached = !selected && desiredTraits.length >= 2;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => { if (!maxReached) toggleArr(desiredTraits, setDesiredTraits, m.id); }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '14px',
                    padding: '14px 16px', borderRadius: '16px', cursor: maxReached ? 'not-allowed' : 'pointer',
                    border: selected ? '1px solid rgba(255,51,102,0.85)' : '1px solid rgba(255,255,255,0.07)',
                    background: selected ? 'rgba(255,51,102,0.22)' : 'rgba(255,255,255,0.02)',
                    transition: 'all 0.12s ease', fontFamily: 'inherit', textAlign: 'left',
                    boxShadow: selected ? '0 0 20px rgba(255,51,102,0.4)' : 'none',
                    opacity: maxReached ? 0.4 : 1,
                  }}
                  onPointerDown={e => { if (!maxReached) e.currentTarget.style.transform = 'scale(0.98)'; }}
                  onPointerUp={e => { e.currentTarget.style.transform = ''; }}
                  onPointerLeave={e => { e.currentTarget.style.transform = ''; }}
                >
                  <span style={{ fontSize: '1.8rem', flexShrink: 0 }}>{m.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: '0.95rem', color: selected ? '#ff3366' : (isWhite ? '#111' : '#fff'), marginBottom: '2px' }}>{m.label}</div>
                    <div style={{ fontSize: '0.75rem', color: isWhite ? '#555' : '#9f9fae', lineHeight: 1.4 }}>{m.desc}</div>
                  </div>
                  <div style={{
                    width: 20, height: 20, borderRadius: '5px', flexShrink: 0,
                    border: selected ? '1px solid #ff3366' : '1px solid rgba(255,255,255,0.3)',
                    background: selected ? '#ff3366' : 'transparent',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {selected && <span style={{ color: '#fff', fontSize: '0.7rem', fontWeight: 900 }}>✓</span>}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

      </div>


    </div>
  );
}