import React from 'react';

// Barre d'onglets principale, fixée en bas de l'écran (iOS / Android friendly).
export default function BottomTabBar({ tabs, tab, bgTheme, hasNewMessage, hasPendingQuiz, hasPlayerTurn, onTabChange }) {
  const isWhite = bgTheme === 'white';

  return (
    <div style={{
      flexShrink: 0,
      // Sous les fenêtres (z-index 300+) : elles doivent passer par-dessus la barre.
      zIndex: 90,
      display: 'flex',
      paddingBottom: 'env(safe-area-inset-bottom)',
      background: isWhite ? 'rgba(240,230,211,0.94)' : 'rgba(7,7,9,0.94)',
      backdropFilter: 'blur(16px)',
      borderTop: isWhite ? '1px solid rgba(0,0,0,0.1)' : '1px solid rgba(255,255,255,0.06)',
    }}>
      {tabs.map(({ id, label }) => {
        const isActive = tab === id;
        const hasUnread = id === 'messages' && hasNewMessage;
        const hasQuiz = id === 'quiz' && hasPendingQuiz;
        return (
          <button
            key={id}
            onClick={() => onTabChange(id)}
            className={id === 'browse' && hasPlayerTurn ? 'heart-3d' : ''}
            style={{
              flex: 1, position: 'relative', padding: '10px 0 12px', fontSize: '1.3rem',
              background: 'none', border: 'none', pointerEvents: 'auto',
              borderTop: isActive ? '2px solid #ff3366' : '2px solid transparent',
              cursor: 'pointer',
              color: isActive ? (isWhite ? '#111' : '#fff') : (isWhite ? '#555' : '#9f9fae'),
              transition: 'all 0.08s ease', willChange: 'transform',
            }}
          >
            {id === 'quiz' ? (
              <span style={{
                fontSize: '1.3rem', lineHeight: 1,
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                padding: '2px 6px', borderRadius: '999px',
                border: `1px solid ${isActive ? 'rgba(255,51,102,0.55)' : (isWhite ? 'rgba(0,0,0,0.14)' : 'rgba(255,255,255,0.16)')}`,
                background: isActive
                  ? 'linear-gradient(135deg, rgba(255,51,102,0.22), rgba(255,105,180,0.14))'
                  : (isWhite ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.05)'),
                boxShadow: isActive ? '0 0 14px rgba(255,51,102,0.35), inset 0 1px 0 rgba(255,255,255,0.12)' : 'inset 0 1px 0 rgba(255,255,255,0.06)',
                backdropFilter: 'blur(8px)',
                transition: 'all 0.2s ease',
              }}>{label}</span>
            ) : label}
            {(hasUnread || hasQuiz) && (
              <span style={{
                position: 'absolute', top: 6, right: '50%', transform: 'translateX(10px)',
                minWidth: 18, height: 18, borderRadius: '999px',
                background: '#ff3366', color: '#fff',
                fontSize: '0.65rem', fontWeight: 800,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                padding: '0 4px',
                boxShadow: '0 0 8px rgba(255,51,102,0.7)',
                lineHeight: 1,
              }}>
                {'●'}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}