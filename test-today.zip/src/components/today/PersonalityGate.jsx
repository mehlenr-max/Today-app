import React, { useState } from 'react';
import { motion } from 'framer-motion';
import PersonalityQuizModal from './PersonalityQuizModal';
import { translate } from '@/lib/i18n/engine';

// Verrou d'accès au deck : sans test de personnalité complété, les profils
// restent invisibles. Le bouton ouvre le test ; une fois sauvegardé, le deck
// se débloque de lui-même (userProfile est mis à jour par onSave).
export default function PersonalityGate({ onSave }) {
  const [open, setOpen] = useState(false);
  const [saved, setSaved] = useState(false);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', padding: '24px 24px 30vh', textAlign: 'center' }}>
      <div style={{ fontSize: '3rem', marginBottom: '16px' }}>✨</div>
      <h3 style={{ fontSize: '1.28rem', fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontWeight: 800, margin: '0 0 8px' }}>
        {translate('Le test de personnalité est obligatoire')}
      </h3>
      <p style={{ color: '#9f9fae', fontSize: '0.88rem', margin: '0 0 22px', lineHeight: 1.55, maxWidth: 320 }}>
        {translate('Réponds à 15 questions pour que l’on puisse calculer ta compatibilité avec les autres profils.')}
      </p>
      <motion.button
        whileTap={{ scale: 0.97 }}
        onClick={() => setOpen(true)}
        style={{
          minWidth: 220, minHeight: 52, borderRadius: '999px',
          background: 'linear-gradient(90deg, #ff3366, #ff69b4)',
          color: '#fff', fontWeight: 800, fontSize: '1rem', fontFamily: 'inherit',
          border: 'none', cursor: 'pointer', boxShadow: '0 12px 24px rgba(255,51,102,0.22)',
        }}
      >
        {saved ? translate('Test enregistré…') : translate('Faire le test')}
      </motion.button>

      {open && (
        <PersonalityQuizModal
          existingProfile={null}
          onClose={() => setOpen(false)}
          onSave={async (profile, phrase) => {
            await onSave?.(profile, phrase);
            setSaved(true);
          }}
        />
      )}
    </div>
  );
}