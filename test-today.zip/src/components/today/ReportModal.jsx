import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '../../api/base44Client';
import toast from 'react-hot-toast';
import useOverlayBack from '../../hooks/useOverlayBack';

const REASONS = [
  { id: 'nudity', label: '🔞 Nudité ou contenu sexuel', emoji: '🔞' },
  { id: 'minor', label: '🧒 Mineur présumé', emoji: '🧒' },
  { id: 'harassment', label: '😠 Harcèlement', emoji: '😠' },
  { id: 'fake', label: '🎭 Faux profil / Usurpation', emoji: '🎭' },
  { id: 'spam', label: '📢 Spam / Arnaque', emoji: '📢' },
  { id: 'other', label: '❓ Autre', emoji: '❓' },
];

export default function ReportModal({ profile, reporterId, onClose, onDone }) {
  useOverlayBack(true, onClose);
  const [reason, setReason] = useState('');
  const [detail, setDetail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit() {
    if (!reason) { setError('Choisis un motif.'); return; }
    setSubmitting(true);
    setError('');
    try {
      await base44.entities.Report.create({
        reporter_id: reporterId,
        reported_profile_id: profile.id,
        reported_user_id: profile.user_id || '',
        reason,
        detail: detail.trim(),
        status: 'pending',
      });
      toast.success('Merci pour votre signalement. Notre équipe va l’examiner rapidement.', {
        duration: 4000,
        style: { background: 'rgba(15,15,19,0.95)', color: '#fff', border: '1px solid rgba(255,51,102,0.4)', borderRadius: '14px', fontSize: '0.88rem' },
        iconTheme: { primary: '#ff3366', secondary: '#fff' },
      });
      setDone(true);
      setTimeout(() => { onDone?.(); onClose?.(); }, 1600);
    } catch (e) {
      setError('Erreur : ' + (e.message || e));
    } finally {
      setSubmitting(false);
    }
  }

  return ReactDOM.createPortal(
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        style={{ position: 'fixed', inset: 0, zIndex: 10001, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}
      >
        <motion.div
          initial={{ y: 60, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 60, opacity: 0 }}
          transition={{ type: 'spring', damping: 28, stiffness: 320 }}
          onClick={e => e.stopPropagation()}
          style={{
            width: '100%', maxWidth: 460, background: 'rgba(15,15,19,0.98)',
            borderTop: '1px solid rgba(255,255,255,0.08)', borderRadius: '28px 28px 0 0',
            padding: '22px 20px calc(env(safe-area-inset-bottom) + 24px)', backdropFilter: 'blur(18px)',
          }}
        >
          <div style={{ width: 44, height: 5, borderRadius: '999px', background: 'rgba(255,255,255,0.18)', margin: '0 auto 16px' }} />

          {done ? (
            <div style={{ textAlign: 'center', padding: '24px 8px' }}>
              <div style={{ fontSize: '2.4rem', marginBottom: 12 }}>✅</div>
              <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#59d39a', marginBottom: 4 }}>Signalement envoyé</div>
              <div style={{ fontSize: '0.85rem', color: '#9f9fae' }}>Merci, notre équipe va examiner ce profil.</div>
            </div>
          ) : (
            <>
              <h3 style={{ margin: '0 0 4px', fontSize: '1.2rem', fontWeight: 800, color: '#fff', textAlign: 'center' }}>
                🚩 Signaler {profile.name || 'ce profil'}
              </h3>
              <p style={{ margin: '0 0 16px', fontSize: '0.82rem', color: '#9f9fae', textAlign: 'center' }}>
                Les signalements sont confidentiels et examinés par un modérateur.
              </p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 14 }}>
                {REASONS.map(r => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setReason(r.id)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 12,
                      padding: '12px 14px', borderRadius: '14px', cursor: 'pointer',
                      fontFamily: 'inherit', textAlign: 'left',
                      border: reason === r.id ? '1px solid rgba(255,51,102,0.5)' : '1px solid rgba(255,255,255,0.07)',
                      background: reason === r.id ? 'rgba(255,51,102,0.12)' : 'rgba(255,255,255,0.02)',
                      color: reason === r.id ? '#ff69b4' : '#cfcfda',
                      fontWeight: 600, fontSize: '0.9rem',
                      transition: 'all 0.12s ease',
                    }}
                  >
                    <span style={{ fontSize: '1.1rem' }}>{r.emoji}</span>
                    <span style={{ flex: 1 }}>{r.label.replace(/^\S+\s/, '')}</span>
                    {reason === r.id && <span style={{ color: '#ff3366', fontWeight: 900 }}>✓</span>}
                  </button>
                ))}
              </div>

              <textarea
                value={detail}
                onChange={e => setDetail(e.target.value)}
                placeholder="Précisions (optionnel)…"
                maxLength={300}
                style={{
                  width: '100%', minHeight: 70, resize: 'none', boxSizing: 'border-box',
                  padding: '12px 14px', borderRadius: '14px', fontFamily: 'inherit', fontSize: '0.88rem',
                  background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)',
                  color: '#fff', outline: 0, marginBottom: 14,
                }}
              />

              {error && (
                <div style={{ textAlign: 'center', color: '#ff6b6b', fontSize: '0.82rem', fontWeight: 600, marginBottom: 12 }}>
                  {error}
                </div>
              )}

              <div style={{ display: 'flex', gap: 10 }}>
                <button
                  onClick={onClose}
                  style={{ flex: 1, padding: '13px', borderRadius: '999px', border: '1px solid rgba(255,255,255,0.1)', background: 'transparent', color: '#9f9fae', cursor: 'pointer', fontFamily: 'inherit', fontWeight: 600, fontSize: '0.92rem' }}
                >
                  Annuler
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={submitting || !reason}
                  style={{
                    flex: 1.4, padding: '13px', borderRadius: '999px', border: 'none',
                    background: submitting || !reason ? 'rgba(255,51,102,0.3)' : 'linear-gradient(90deg, #ff3366, #ff69b4)',
                    color: '#fff', cursor: submitting || !reason ? 'default' : 'pointer', fontFamily: 'inherit',
                    fontWeight: 700, fontSize: '0.92rem', opacity: submitting || !reason ? 0.6 : 1,
                  }}
                >
                  {submitting ? 'Envoi…' : 'Envoyer le signalement'}
                </button>
              </div>
            </>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>,
    document.body
  );
}