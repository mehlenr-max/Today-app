import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import useOverlayBack from '../../hooks/useOverlayBack';

const pageStyle = {
  height: '100dvh',
  background:
    "radial-gradient(circle at 16% 16%, rgba(255,51,102,0.22) 0%, transparent 24%), radial-gradient(circle at 86% 18%, rgba(255,105,180,0.14) 0%, transparent 22%), linear-gradient(180deg, #070709 0%, #040405 42%, #030304 100%)",
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  fontFamily: "'Poppins', sans-serif",
  padding: 'calc(env(safe-area-inset-top) + 16px) 20px calc(env(safe-area-inset-bottom) + 24px)',
  position: 'fixed',
  top: 0, left: 0, right: 0, bottom: 0,
  zIndex: 9999,
  overflowY: 'auto',
  WebkitOverflowScrolling: 'touch',
  overscrollBehavior: 'contain',
  touchAction: 'pan-y',
};

const closeBtnStyle = {
  position: 'sticky',
  top: 0,
  alignSelf: 'flex-start',
  background: 'none',
  border: 'none',
  color: '#ff69b4',
  fontSize: '1.6rem',
  cursor: 'pointer',
  padding: '0 0 10px',
  fontFamily: 'inherit',
  fontWeight: 700,
  zIndex: 10,
  marginBottom: '8px',
};

const cardStyle = {
  width: '100%',
  maxWidth: '560px',
  display: 'flex',
  flexDirection: 'column',
};

const scrollContentStyle = {
  background: 'rgba(15,15,19,0.72)',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: '20px',
  padding: '20px 18px',
  WebkitOverflowScrolling: 'touch',
};

function Accordion({ title, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section style={{ marginBottom: 10, borderBottom: '1px solid rgba(255,255,255,0.06)', paddingBottom: 10 }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit',
          padding: '6px 0', textAlign: 'left',
        }}
      >
        <h2 style={{ fontSize: '0.92rem', fontWeight: 700, color: '#fff', margin: 0 }}>{title}</h2>
        {open ? <ChevronUp size={16} color="#ff69b4" /> : <ChevronDown size={16} color="#ff69b4" />}
      </button>
      {open && (
        <div style={{ fontSize: '0.84rem', lineHeight: 1.65, color: '#cfcfda', marginTop: 8, textAlign: 'justify', textJustify: 'inter-word', hyphens: 'auto', WebkitHyphens: 'auto' }}>
          {children}
        </div>
      )}
    </section>
  );
}

function Li({ children }) {
  return <li style={{ marginBottom: '6px', textAlign: 'justify', textJustify: 'inter-word', hyphens: 'auto', WebkitHyphens: 'auto' }}>{children}</li>;
}

const W = ({ children }) => <strong style={{ color: '#fff' }}>{children}</strong>;

export default function ToDayInBrief({ onClose }) {
  useOverlayBack(!!onClose, onClose);
  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        {onClose && (
          <button onClick={onClose} style={closeBtnStyle} aria-label="Fermer">←</button>
        )}
        <div style={{ textAlign: 'center', marginBottom: '14px' }}>
          <h1 style={{ fontFamily: "'EB Garamond', serif", fontStyle: 'italic', fontSize: '1.7rem', fontWeight: 800, color: '#fff', margin: '0 0 4px' }}>
            Manuel ToDay
          </h1>
          <p style={{ color: '#ff69b4', fontSize: '0.82rem', margin: 0, fontWeight: 600 }}>
            Le guide complet pour maîtriser l'app
          </p>
        </div>

        <div style={scrollContentStyle}>
          <Accordion title="📅 Les jours de rencontre" defaultOpen>
            <p style={{ margin: '0 0 8px' }}>ToDay n'est disponible que <W>les jeudis et samedis</W>. Le reste de la semaine, l'app est en pause — tu peux consulter ton profil et tes paramètres, mais pas publier de date ni défier.</p>
            <p style={{ margin: 0 }}>Ce rythme garantit que tout le monde cherche un date le même soir, au même moment.</p>
          </Accordion>

          <Accordion title="👤 Ton profil & ta carte">
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Photo vérifiée</W> : ta photo principale est vérifiée par reconnaissance faciale (selfie comparé au visage de la photo). Une photo non vérifiée ne peut pas être publiée.</Li>
              <Li><W>Quota de changements</W> : 3 changements de photo tous les 3 jours, tous slots confondus. Le compteur se réinitialise automatiquement.</Li>
              <Li><W>Profil complet requis</W> pour publier un date : photo vérifiée, test de personnalité, profil cosmique (date de naissance).</Li>
              <Li><W>Pseudo unique</W> : un seul profil par personne, vérifié à l'inscription.</Li>
            </ul>
          </Accordion>

          <Accordion title="🔥 Publier ton date">
            <p style={{ margin: '0 0 8px' }}>Avant de parcourir le deck, tu publies ta demande de date :</p>
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Créneau horaire</W> : quand tu es dispo ce soir.</Li>
              <Li><W>Critères</W> : âge, distance, taille, morphologie recherchée, traits de personnalité souhaités.</Li>
            </ul>
            <p style={{ margin: '8px 0 0' }}>Tes critères sont <W>réciproques</W> : tu ne vois que les profils dont l'âge te correspond ET dont tu rentres dans leur tranche d'âge. La compatibilité est mutuelle ou elle n'est pas.</p>
          </Accordion>

          <Accordion title="❤️ Le deck & les défis">
            <p style={{ margin: '0 0 8px' }}>Le deck te montre les profils compatibles du jour, triés par score.</p>
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Défier</W> : envoie un défi Pierre-Papier-Ciseaux. Tu joues en premier. Si l'autre accepte et joue, c'est un match.</Li>
              <Li><W>Passer</W> : le profil disparaît de ton deck pour la journée.</Li>
              <Li><W>Défi reçu</W> : si quelqu'un te défie, tu vois un badge « Défi reçu » sur sa carte. Réponds depuis tes messages.</Li>
              <Li><W>« Défié le »</W> : un badge rose indique la date du dernier défi envoyé à ce profil.</Li>
              <Li><W>Profils visibles</W> : les profils connectés dans les 7 derniers jours apparaissent. Si tu te mets hors-ligne, tu disparais du deck. Un profil qui a déjà un date confirmé n'apparaît plus.</Li>
              <Li><W>Blocage</W> : tu peux bloquer un profil depuis ses messages. Il disparaît de ton deck et ses défis sont ignorés.</Li>
            </ul>
          </Accordion>

          <Accordion title="✊ Le match Pierre-Papier-Ciseaux">
            <p style={{ margin: '0 0 8px' }}>Quand tu défies quelqu'un, le défi se joue en Pierre-Papier-Ciseaux :</p>
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Tu joues en premier</W>, l'autre reçoit le défi et joue à son tour.</Li>
              <Li><W>Le gagnant choisit le lieu</W> du date (restaurant, bar, activité…).</Li>
              <Li><W>Le perdant accepte ou refuse</W> la proposition de lieu.</Li>
              <Li>Si l'autre ne répond pas, pas de match — le défi expire sans pénalité.</Li>
            </ul>
          </Accordion>

          <Accordion title="📍 Proposition de lieu & confirmation">
            <p style={{ margin: '0 0 8px' }}>Le gagnant propose un lieu (nom, adresse, heure). Le perdant a trois choix :</p>
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Accepter</W> → le date est confirmé. Les deux sont verrouillés : plus aucun autre date possible aujourd'hui.</Li>
              <Li><W>Refuser (lieu ou nourriture)</W> → refus <em>non définitif</em>. Le gagnant peut proposer un autre lieu, sans limite.</Li>
              <Li><W>Refuser (raisons personnelles)</W> → refus <em>définitif</em>. « Pas de match ». La paire est bloquée pour la journée.</Li>
            </ul>
            <p style={{ margin: '8px 0 0' }}>Une fois le lieu accepté, tu peux encore <W>changer le lieu</W> en renégociant avec l'autre — tant que personne n'annule, le date reste confirmé.</p>
          </Accordion>

          <Accordion title="❌ Annuler un date">
            <p style={{ margin: '0 0 8px' }}>Il y a deux cas d'annulation, avec des conséquences différentes :</p>
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Avant confirmation</W> (proposition en attente) → « Pas de match ». Personne n'est bloqué. Chacun peut continuer à défier.</Li>
              <Li><W>Après confirmation</W> (date accepté) → « Date annulé ». <strong style={{ color: '#ff3366' }}>L'annulateur est bloqué jusqu'à minuit</strong> : il ne peut plus proposer ni accepter de date aujourd'hui. L'autre personne est libérée et peut dater à nouveau.</Li>
            </ul>
            <p style={{ margin: '8px 0 0' }}>Cette règle protège contre les désistements de dernière minute.</p>
          </Accordion>

          <Accordion title="💬 Messages & historique">
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Onglet Messages 💬</W> : tes matchs, résultats PPC, propositions de lieu, confirmations et annulations.</Li>
              <Li><W>Threads prioritaires</W> : les conversations avec une action en attente (défi à répondre, lieu à accepter) ou un date confirmé sont épinglées en haut. Les annulations de date confirmé passent tout au-dessus.</Li>
              <Li><W>Tri</W> : les threads prioritaires sont ordonnés par l'horodatage de la dernière action, pas du dernier message.</Li>
              <Li><W>Rétention</W> : les messages classiques sont conservés 24h, les messages de jeux 7 jours. À minuit, tout se réinitialise.</Li>
              <Li><W>Supprimer un thread</W> : tu peux effacer une conversation depuis le menu du thread.</Li>
            </ul>
          </Accordion>

          <Accordion title="🎲 Les jeux (This or That, Je n'ai jamais)">
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Objectif</W> : mieux connaître un profil de façon ludique avant de défier.</Li>
              <Li><W>Limite</W> : 2 jeux par paire, sur une fenêtre de 30 jours. Une fois les 2 jeux envoyés, « Game over » s'affiche.</Li>
              <Li><W>Onglet Jeux 🎲</W> : les questions reçues et tes réponses consolidées y apparaissent.</Li>
              <Li>Les jeux sont indépendants des défis date — ils ne bloquent pas le deck.</Li>
            </ul>
          </Accordion>

          <Accordion title="⭐ Les scores de compatibilité">
            <p style={{ margin: '0 0 8px' }}>Trois dimensions, affichées en qualitatif (Excellent / Très bon / OK / Moyen / Mauvais) :</p>
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li>💪 <W>Physique</W> : match morphologique mutuel (ce que tu cherches vs ce qu'il/elle est, et inversement).</Li>
              <Li>🌙 <W>Cosmique</W> : compatibilité astrologique (signes + ascendants).</Li>
              <Li>✨ <W>Personnalité</W> : basée sur le test de personnalité (5 dimensions pondérées).</Li>
            </ul>
            <p style={{ margin: '8px 0 0' }}>Une pastille colorée (vert / orange / rouge) résume la moyenne des trois scores.</p>
          </Accordion>

          <Accordion title="🛡️ Sécurité & modération">
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Vérification faciale</W> : chaque photo est vérifiée localement (reconnaissance faciale + filtre anti-NSFW).</Li>
              <Li><W>Signalements</W> : nudité, mineur, harcèlement, faux profil, spam. Traités sous 48h.</Li>
              <Li><W>Masquage auto</W> : au 2e signalement, le profil est automatiquement masqué du deck en attente de vérification.</Li>
              <Li><W>Blocage</W> : bloque un profil depuis ses messages. Il disparaît de ton deck et ses défis sont ignorés.</Li>
              <Li><W>Suppression du compte</W> : disponible à tout moment depuis Profil → Supprimer mon compte. Efface immédiatement profil, messages et sessions.</Li>
            </ul>
          </Accordion>

          <Accordion title="🌙 Profil cosmique & personnalité">
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Profil cosmique</W> : calcule ton signe astrologique et ton ascendant à partir de ta date (et optionnellement heure + lieu) de naissance. Utilisé pour le score cosmique.</Li>
              <Li><W>Test de personnalité</W> : 5 dimensions (social, émotionnel, mode de vie, relationnel, valeurs). Génère une phrase-résumé affichée sur ta carte. Utilisé pour le score personnalité.</Li>
              <Li>Les deux sont obligatoires pour publier un date.</Li>
            </ul>
          </Accordion>

          <Accordion title="⚙️ Paramètres & thème">
            <ul style={{ margin: 0, paddingLeft: 0, listStylePosition: 'inside' }}>
              <Li><W>Thème</W> : choisis entre sombre, clair et rose via le bouton 🎨 en bas à droite.</Li>
              <Li><W>Mode auto soleil</W> : bascule automatiquement sur fond clair en pleine lumière.</Li>
              <Li><W>Notifications</W> : un point rouge (●) apparaît sur l'onglet Messages ou Jeux quand tu as du nouveau.</Li>
            </ul>
          </Accordion>

          <p style={{ textAlign: 'center', color: '#9f9fae', fontSize: '0.82rem', fontStyle: 'italic', marginTop: '12px', marginBottom: 0 }}>
            Un date par jour. Un seul. Le bon.
          </p>
        </div>
      </div>
    </div>
  );
}