import { createContext, useContext, useEffect, useState } from 'react';
import { Outlet } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

const SitePauseContext = createContext({ paused: false, apply: () => {} });

export const useSitePause = () => useContext(SitePauseContext);

const POLL_MS = 45000;

// Portail global : quand le site est en pause, les membres voient l'écran de maintenance.
// L'administrateur garde l'accès complet pour continuer ses modifications.
export default function SitePauseGate() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const [paused, setPaused] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const res = await base44.entities.AppState.filter({ key: 'site' });
        const record = (res?.items ?? res ?? [])[0] || null;
        if (alive) setPaused(record?.paused === true);
      } catch (e) {
        // État illisible : on ne bloque pas l'app.
      } finally {
        if (alive) setReady(true);
      }
    };
    load();
    const timer = setInterval(load, POLL_MS);
    const onVisible = () => { if (document.visibilityState === 'visible') load(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      alive = false;
      clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, []);

  const apply = (next) => setPaused(next === true);

  if (paused && !isAdmin) {
    return (
      <div style={{
        position: 'fixed', inset: 0, background: '#0b0b0f', color: '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '32px 24px', paddingTop: 'calc(env(safe-area-inset-top) + 32px)',
        fontFamily: 'inherit', textAlign: 'center',
      }}>
        <div style={{ maxWidth: 340, width: '100%' }}>
          <div style={{ fontSize: '3rem', marginBottom: '14px' }}>⏸️</div>
          <h1 style={{ fontSize: '1.35rem', fontWeight: 700, margin: '0 0 10px', letterSpacing: '-0.01em' }}>
            Le site est en pause
          </h1>
          <p style={{ color: '#9f9fae', fontSize: '0.9rem', lineHeight: 1.6, margin: '0 0 26px' }}>
            On peaufine quelques améliorations. Reviens très vite, tout sera de nouveau accessible.
          </p>
          <button
            onClick={() => window.location.reload()}
            style={{
              width: '100%', padding: '13px 18px', borderRadius: '16px', border: 'none',
              background: 'linear-gradient(135deg, #ff3366, #ff6fa0)', color: '#fff',
              fontFamily: 'inherit', fontSize: '0.88rem', fontWeight: 700, cursor: 'pointer',
            }}
          >
            Réessayer
          </button>
          <button
            onClick={() => base44.auth.logout('/')}
            style={{
              width: '100%', marginTop: '10px', padding: '13px 18px', borderRadius: '16px',
              background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)',
              color: '#cfcfda', fontFamily: 'inherit', fontSize: '0.82rem', fontWeight: 600, cursor: 'pointer',
            }}
          >
            Se déconnecter
          </button>
        </div>
      </div>
    );
  }

  if (!ready) {
    return (
      <div style={{ position: 'fixed', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#0b0b0f' }}>
        <div className="animate-spin" style={{ width: 30, height: 30, border: '3px solid rgba(255,255,255,0.15)', borderTopColor: '#ff3366', borderRadius: '50%' }} />
      </div>
    );
  }

  return (
    <SitePauseContext.Provider value={{ paused, apply }}>
      <Outlet />
    </SitePauseContext.Provider>
  );
}