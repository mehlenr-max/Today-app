import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Rétention nocturne des entités de gestion (DateThread, DateLock, UserSession).
// L'historique visible des utilisateurs vit dans UserMessage et n'est PAS touché.
//
// - DateLock et UserSession : supprimés au-delà de 7 jours (plus aucune lecture après J+1).
// - DateThread : supprimé au-delà de 30 jours (conservation pour audit/replay).
//
// Suppression par filtre date_key directement (deleteMany par requête), jamais
// de boucle record-par-record. Si deleteMany a une limite interne, la boucle
// while + has_more gère les chunks restants.
Deno.serve(async (req) => {
  try {
    const body = await req.json().catch(() => ({}));
    const readOnly = body?.readOnly === true;

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const svc = base44.asServiceRole;

    const now = new Date();
    const sevenDaysAgo = new Date(now);
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const sevenDaysAgoKey = sevenDaysAgo.toLocaleDateString('fr-CA', { timeZone: 'Europe/Brussels' });

    const thirtyDaysAgo = new Date(now);
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const thirtyDaysAgoKey = thirtyDaysAgo.toLocaleDateString('fr-CA', { timeZone: 'Europe/Brussels' });

    if (readOnly) {
      return Response.json({
        readOnly: true,
        cutoffLocksSessions: sevenDaysAgoKey,
        cutoffThreads: thirtyDaysAgoKey,
      });
    }

    // DateLock : > 7 jours
    let deletedLocks = 0;
    let hasMoreLocks = true;
    while (hasMoreLocks) {
      const res = await svc.entities.DateLock.deleteMany({ date_key: { $lt: sevenDaysAgoKey } });
      deletedLocks += res?.deleted || 0;
      hasMoreLocks = res?.has_more === true;
    }

    // UserSession : > 7 jours
    let deletedSessions = 0;
    let hasMoreSessions = true;
    while (hasMoreSessions) {
      const res = await svc.entities.UserSession.deleteMany({ date_key: { $lt: sevenDaysAgoKey } });
      deletedSessions += res?.deleted || 0;
      hasMoreSessions = res?.has_more === true;
    }

    // DateThread : > 30 jours
    let deletedThreads = 0;
    let hasMoreThreads = true;
    while (hasMoreThreads) {
      const res = await svc.entities.DateThread.deleteMany({ date_key: { $lt: thirtyDaysAgoKey } });
      deletedThreads += res?.deleted || 0;
      hasMoreThreads = res?.has_more === true;
    }

    // Report : 'reviewed' de plus de 90 jours → suppression (les 'pending' ne sont JAMAIS touchés)
    const ninetyDaysAgoIso = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000).toISOString();
    let deletedReports = 0;
    let hasMoreReports = true;
    while (hasMoreReports) {
      const res = await svc.entities.Report.deleteMany({ status: 'reviewed', created_date: { $lt: ninetyDaysAgoIso } });
      deletedReports += res?.deleted || 0;
      hasMoreReports = res?.has_more === true;
    }

    return Response.json({
      success: true,
      deletedLocks,
      deletedSessions,
      deletedThreads,
      deletedReports,
      cutoffLocksSessions: sevenDaysAgoKey,
      cutoffThreads: thirtyDaysAgoKey,
      cutoffReports: ninetyDaysAgoIso,
    });
  } catch (error) {
    console.error('cleanupOldThreads error:', error?.message || error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});