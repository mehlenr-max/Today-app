import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { msgDateCardDrawn, msgDateCardReceived } from '../../shared/messages.ts';

// Gages pour un date ce soir.
// Le drawer ne connaît pas son gage : il est envoyé à l'autre participant,
// qui le recevra dans ses messages et le lui demandera pendant le date.
const DATE_QUESTIONS = [
  "Dis-moi 3 compliments. Un est faux. Je dois trouver lequel.",
  "Fais-moi une déclaration d'amour qui a l'air fausse. Si j'y crois quand même, tu as perdu.",
  "Commande pour moi. Si ça ne me plaît pas, le date s'arrête au dessert. Ou au café, si tu négocies.",
  "Donne-moi 3 raisons de te revoir. Une est nulle exprès. Je dois la trouver.",
  "Raconte comment on s'est rencontrés, version film. Si c'est trop beau, tu recommences en version nulle.",
  "Fais-moi un compliment précis. Pas le sourire, pas le style. Si tu sèches, tu trinques.",
  "Propose 3 plans pour la suite. Un est une blague. Je choisis sans savoir lequel.",
  "Dis-moi ce que tu as pensé en arrivant, puis la version polie. Je devine laquelle est sortie en premier.",
  "Invente notre dispute la plus bête. Si elle est crédible, on trinque. Si elle est trop mignonne, tu recommences.",
  "Choisis mon prochain verre. Si je fais la grimace, tu le finis.",
  "Dis-moi 3 choses que tu aimes chez quelqu'un en date. Une doit être un red flag que tu assumes.",
  "Fais-moi la scène « je te présente à un ami », en trente secondes. Si c'est gênant, c'est réussi.",
  "Avoue un truc que tu fais pour plaire. Si je le devine avant, tu as perdu.",
  "Donne-moi une note sur dix pour ce date, plus une note fausse. Je dois écarter la fausse.",
  "Écris-moi un texto de demain, à voix haute. S'il est trop sage, tu en envoies un vrai, plus court.",
  "Dis le moment où tu as failli ne pas venir. Vrai ou inventé : j'annonce, tu confirmes.",
  "Dis-moi 3 choses que tu changerais chez moi ce soir. Une est fausse, tu n'y toucherais pas. Je dois trouver laquelle.",
  "Fais-moi deux promesses pour le prochain verre. Une que tu ne tiendras pas. Je parie laquelle.",
  "Décris-moi comme si tu parlais à ton meilleur ami. Sans filtre marketing.",
  "Commande un truc à partager. Si je n'y touche pas, tu le finis, et tu choisis le sujet suivant.",
  "Dis-moi 3 surnoms possibles. Un est interdit. Je dois trouver l'interdit, sinon je le garde.",
  "Fais une déclaration en trois mots. Si elle sonne vrai, tu es en danger. Si elle sonne fausse, tu es sauvé.",
  "Raconte notre fin de soirée idéale, puis la version où ça capote. Je choisis laquelle on vise.",
  "Donne-moi un code pour dire « on s'ennuie ». Si tu l'utilises ce soir, je paye le café. Si c'est moi, c'est l'inverse.",
  "Cite 3 plats que tu m'imagines commander. Le plus faux te coûte la prochaine tournée.",
  "Fais-moi un compliment de dos, comme si je n'entendais pas. Puis assume-le en me regardant.",
  "Dis une qualité que tu me prêtes déjà. Si c'est trop tôt, tu la retires. Si elle est juste, tu la gardes.",
  "Propose de payer quelque chose de petit. Si tu hésites en le disant, ça ne compte pas.",
  "Invente le message que tu enverrais à un ami dans l'heure. Tu le lis. Je dis si tu oserais l'envoyer.",
  "Donne-moi 3 sujets interdits pour ce soir. Un est faux, tu veux en parler. Je dois le débloquer.",
  "Fais le premier pas du deuxième date, maintenant, en une phrase. « Faut qu'on se fasse ça » est interdit.",
  "Dis-moi ce qui te ferait partir avant le dessert. Si c'est déjà arrivé, tu trinques.",
  "Choisis qui parle pendant deux minutes. Si tu me choisis et que je sèche, tu reprends.",
  "Fais-moi une jalousie miniature et absurde, puis retire-la. Si elle sonne vraie, tu as mal joué.",
  "Avoue le détail que tu as remarqué en premier. Si tu changes de version, la première compte.",
  "Donne-moi une règle pour la prochaine fois. Si elle est trop stricte, je la casse tout de suite.",
  "Dis 3 choses que tu ne referais pas ce soir. Une est un mensonge. Je cherche le mensonge.",
  "Commande le truc que tu n'oses pas prendre. Si tu me le refilles, gage raté.",
  "Fais une phrase d'accroche comme sur l'app, mais pour moi, en direct. Si elle est meilleure que ton profil, tu gagnes.",
  "Dis si tu restes pour un dernier verre, avant de regarder l'heure. Changer d'avis coûte un toast.",
  "Raconte ce date à la troisième personne, comme une chronique. Je coupe si ça devient trop gentil.",
  "Donne-moi ton pire conseil de date, puis suis-le pendant cinq minutes.",
  "Choisis un mot que je n'ai pas le droit de dire. Si je le dis, je te dois un vrai compliment.",
  "Fais semblant de me présenter à tes parents, une minute. Le premier cliché te fait recommencer.",
  "Dis le truc que tu espérais que je te demande. Puis pose-le-toi, et réponds.",
  "Parie sur mon prochain choix au menu. Si tu rates, tu commandes le tien les yeux fermés.",
  "Fais-moi une promesse inutile et solennelle. Si tu ris en la disant, elle est validée.",
  "Dis 3 façons de se quitter ce soir. Une est la vraie. Je dois la trouver.",
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { otherUserId } = await req.json();
    if (!otherUserId) return Response.json({ error: 'Missing otherUserId' }, { status: 400 });

    const dk = new Date().toLocaleDateString('fr-CA', { timeZone: 'Europe/Brussels' });
    const displayTime = new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' });

    const myProfiles = await base44.entities.Profile.filter({ user_id: user.id });
    const otherProfiles = await base44.asServiceRole.entities.Profile.filter({ user_id: otherUserId });
    const myName = myProfiles[0]?.display_name || user.full_name || 'Toi';
    const otherName = otherProfiles[0]?.display_name || 'ton date';
    const myPhoto = myProfiles[0]?.photo_url || '';

    // Vérifier qu'un date est confirmé avec ce counterpart aujourd'hui
    const myMsgs = await base44.entities.UserMessage.filter({ user_id: user.id, date_key: dk }, '-created_date', 500);
    const hasConfirmed = myMsgs.some(m => m.text?.includes('Date confirmé') && m.profile_id === otherUserId);
    if (!hasConfirmed) return Response.json({ error: 'No confirmed date with this user' }, { status: 403 });

    // Une seule pioche par thread (évite le spam)
    const alreadyDrew = myMsgs.some(m => {
      if (!m.action_json) return false;
      try { const a = JSON.parse(m.action_json); return a.type === 'dateCardDrawn' && a.toUserId === otherUserId; } catch { return false; }
    });
    if (alreadyDrew) return Response.json({ error: 'already_drew' }, { status: 409 });

    // Piocher un gage aléatoire
    const gage = DATE_QUESTIONS[Math.floor(Math.random() * DATE_QUESTIONS.length)];

    // Message pour le drawer (confirme la pioche sans révéler le gage)
    await base44.entities.UserMessage.create({
      user_id: user.id,
      date_key: dk,
      sender: 'Système',
      text: msgDateCardDrawn(otherName),
      is_system: true,
      profile_name: otherName,
      profile_id: otherUserId,
      profile_photo: otherProfiles[0]?.photo_url || '',
      thread_key: otherName,
      action_json: JSON.stringify({ type: 'dateCardDrawn', toUserId: otherUserId }),
      display_time: displayTime,
    });

    // Message pour le recipient (reçoit le gage à demander au drawer pendant le date)
    await base44.asServiceRole.entities.UserMessage.create({
      user_id: otherUserId,
      date_key: dk,
      sender: myName,
      text: msgDateCardReceived(myName, gage),
      is_system: true,
      profile_name: myName,
      profile_id: String(user.id),
      profile_photo: myPhoto,
      thread_key: myName,
      action_json: JSON.stringify({ type: 'dateCardReceived', fromUserId: user.id }),
      display_time: displayTime,
    });

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});