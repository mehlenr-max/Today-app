import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { cleanChallengeMarkers, markPairLocked } from '../../shared/challenge-cleanup.ts';
import { threadSnapshot, transitionThreadState, computeThreadKey, findThread, updateLockReason, deleteLock } from '../../shared/datethread.ts';
import { resumeSuspendedInteractions, notifyPairAvailableAgain, closePendingActionsBetween } from '../../shared/stale-cleanup.ts';
import { msgDateCancelledSelf, msgNoMatchSelf, msgDateCancelledOther, msgNoMatchOther } from '../../shared/messages.ts';
import { notifyMessagePush, PUSH } from '../../shared/push.ts';

Deno.serve(async (req) => {
  const transitions = [];
  let lock = null;
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { otherUserId } = await req.json();
    if (!otherUserId) {
      return Response.json({ error: 'Missing otherUserId' }, { status: 400 });
    }

    const dk = new Date().toLocaleDateString('fr-CA', { timeZone: 'Europe/Brussels' });
    const displayTime = new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' });

    // Récupérer les profils + sessions pour les noms et la détection d'état
    const myProfiles = await base44.entities.Profile.filter({ user_id: user.id });
    const otherProfiles = await base44.asServiceRole.entities.Profile.filter({ user_id: otherUserId });
    const mySessions = await base44.entities.UserSession.filter({ user_id: user.id, date_key: dk });
    const otherSessions = await base44.asServiceRole.entities.UserSession.filter({ user_id: otherUserId, date_key: dk });
    const myName = myProfiles[0]?.display_name || user.full_name || "Quelqu'un";
    const otherName = otherProfiles[0]?.display_name || 'Date';

    // SOURCE DE VÉRITÉ : le DateThread. wasConfirmed se lit depuis l'état du thread,
    // pas depuis les flags de session (qui peuvent être absents ou en retard —
    // cas réel : frontend n'écrit pas les flags à l'acceptation).
    const threadKey = computeThreadKey(dk, user.id, otherUserId);
    const thread = await findThread(base44, threadKey);

    // Idempotence : un thread déjà clos (cancelled ou no_match) ne doit pas être re-classé.
    // Retour sans rien faire — pas de second message, pas de re-transition, pas de lock change.
    if (thread && (thread.state === 'cancelled' || thread.state === 'no_match')) {
      return Response.json({ success: true, wasConfirmed: thread.state === 'cancelled', idempotent: true, transitions: [], lock: null });
    }

    // wasConfirmed depuis le thread (authoritaire si le thread existe).
    // Si le thread est accepted → annulation TOUJOURS confirmée, quels que soient les flags.
    // Si le thread n'existe pas (edge case) → filet de sécurité sur les flags.
    let wasConfirmed;
    if (thread) {
      // has_been_confirmed est un fait historique (posé à la transition vers accepted, jamais remis à false).
      // Backfill : si le champ est absent (thread antérieur au fix), thread.state === 'accepted' suffit
      // pour les threads actuellement accepted. Les threads antérieurs passés par accepted puis
      // repartis vers place_proposed/place_refused sans le champ sont un cas transitoire (voir doc).
      wasConfirmed = thread.state === 'accepted' || thread.has_been_confirmed === true;
    } else {
      const myHasAccepted = myProfiles[0]?.accepted_date_key === dk && mySessions[0]?.has_accepted_date === true;
      const otherHasAccepted = otherProfiles[0]?.accepted_date_key === dk && otherSessions[0]?.has_accepted_date === true;
      let detailsMatch = false;
      try {
        const myDetails = mySessions[0]?.accepted_date_details ? JSON.parse(mySessions[0].accepted_date_details) : null;
        const otherDetails = otherSessions[0]?.accepted_date_details ? JSON.parse(otherSessions[0].accepted_date_details) : null;
        if (myDetails?.profileId && otherProfiles[0]?.id && String(myDetails.profileId) === String(otherProfiles[0].id)) detailsMatch = true;
        if (otherDetails?.profileId && myProfiles[0]?.id && String(otherDetails.profileId) === String(myProfiles[0].id)) detailsMatch = true;
      } catch {}
      wasConfirmed = myHasAccepted && otherHasAccepted && detailsMatch;
    }

    // Messages nécessaires pour fermer les confirmations résiduelles sans les supprimer
    const myMsgs = await base44.entities.UserMessage.filter({ user_id: user.id, date_key: dk }, '-created_date', 500);
    const otherMsgs = await base44.asServiceRole.entities.UserMessage.filter({ user_id: otherUserId, date_key: dk }, '-created_date', 500);

    // Détecter une renégociation de lieu en attente (isPlaceChange non résolu dans le thread).
    // Règle 04/10 : annulation pendant renégociation → schéma pré-acceptation (personne bloqué).
    const allThreadMsgs = [...myMsgs, ...otherMsgs];
    allThreadMsgs.sort((a, b) => (a.created_date || '').localeCompare(b.created_date || ''));
    let placeChangeIdx = -1;
    for (let i = allThreadMsgs.length - 1; i >= 0; i--) {
      try {
        const action = allThreadMsgs[i].action_json ? JSON.parse(allThreadMsgs[i].action_json) : null;
        if (action?.type === 'loserAccept' && action?.isPlaceChange) { placeChangeIdx = i; break; }
      } catch {}
    }
    let hasPendingRenegotiation = false;
    if (placeChangeIdx >= 0) {
      hasPendingRenegotiation = true;
      for (let i = placeChangeIdx + 1; i < allThreadMsgs.length; i++) {
        const txt = allThreadMsgs[i].text || '';
        let action = null;
        try { action = allThreadMsgs[i].action_json ? JSON.parse(allThreadMsgs[i].action_json) : null; } catch {}
        // Un refus non-final (refusalWithReasons) résout le changement de lieu en attente —
        // sans cette détection, un refus lieu/nourriture laisserait hasPendingRenegotiation=true
        // et l'annulation passerait en schéma pré-acceptation au lieu de confirmé.
        if (txt.includes('Date confirmé') || txt.includes('Pas de match') || txt.includes('Date annulé') || txt.includes('Tu as refusé') || action?.type === 'refusalWithReasons') {
          hasPendingRenegotiation = false;
          break;
        }
      }
    }
    // Schéma pré-acceptation étendu : renégociation ouverte sur un thread accepted → personne bloqué.
    const isRenegotiationCancel = wasConfirmed && hasPendingRenegotiation;

    if (isRenegotiationCancel) {
      // Renégociation ouverte → les locks date_confirmed des DEUX parties sont supprimés.
      // Personne n'est bloqué — chacun peut continuer sa soirée ailleurs.
      await deleteLock(base44, dk, user.id);
      await deleteLock(base44, dk, otherUserId);
      // Réinitialiser les flags des DEUX côtés (schéma pré-acceptation).
      if (mySessions[0]) {
        await base44.entities.UserSession.update(mySessions[0].id, { has_accepted_date: false, accepted_date_details: null });
      }
      if (myProfiles[0]) {
        await base44.entities.Profile.update(myProfiles[0].id, { accepted_date_key: null });
      }
      if (otherSessions[0]) {
        await base44.asServiceRole.entities.UserSession.update(otherSessions[0].id, { has_accepted_date: false, accepted_date_details: null });
      }
      if (otherProfiles[0]) {
        await base44.asServiceRole.entities.Profile.update(otherProfiles[0].id, { accepted_date_key: null });
      }
      // Les DEUX sont libérés → notifier leurs partenaires stale-closed
      await resumeSuspendedInteractions(base44, dk, user.id, displayTime);
      await resumeSuspendedInteractions(base44, dk, otherUserId, displayTime);
      // Les DEUX sont libérés → se notifier mutuellement la disponibilité réciproque
      // et fermer les actions en attente pour débloquer le défi côté frontend.
      await closePendingActionsBetween(base44, dk, user.id, otherUserId);
      await notifyPairAvailableAgain(base44, dk, user.id, otherUserId, myName, otherName, myProfiles[0]?.photo_url || '', otherProfiles[0]?.photo_url || '', displayTime);
    } else if (wasConfirmed) {
      // Date CONFIRMÉ → annulation après acceptation :
      // Addition #1: le lock survit à l'annulation — reason → "cancelled_after_confirm".
      // L'annulateur reste indisponible jusqu'à minuit (règle S10).
      lock = await updateLockReason(base44, dk, user.id, 'cancelled_after_confirm', computeThreadKey(dk, user.id, otherUserId));
      // L'autre personne est libérée : son lock est SUPPRIMé (elle peut dater à nouveau).
      await deleteLock(base44, dk, otherUserId);
      // Le canceller RESTE bloqué (has_accepted_date + accepted_date_key conservés — shadow).
      // L'autre personne est libérée (flags réinitialisés).
      if (otherSessions[0]) {
        await base44.asServiceRole.entities.UserSession.update(otherSessions[0].id, {
          has_accepted_date: false,
          accepted_date_details: null,
        });
      }
      if (otherProfiles[0]) {
        await base44.asServiceRole.entities.Profile.update(otherProfiles[0].id, { accepted_date_key: null });
      }
      // Seul l'autre est libéré → notifier ses partenaires stale-closed
      await resumeSuspendedInteractions(base44, dk, otherUserId, displayTime);
    } else {
      // Date NON confirmé (proposition en attente) → personne n'est bloqué.
      // Réinitialiser les flags des DEUX côtés.
      if (mySessions[0]) {
        await base44.entities.UserSession.update(mySessions[0].id, { has_accepted_date: false, accepted_date_details: null });
      }
      if (myProfiles[0]) {
        await base44.entities.Profile.update(myProfiles[0].id, { accepted_date_key: null });
      }
      if (otherSessions[0]) {
        await base44.asServiceRole.entities.UserSession.update(otherSessions[0].id, {
          has_accepted_date: false,
          accepted_date_details: null,
        });
      }
      if (otherProfiles[0]) {
        await base44.asServiceRole.entities.Profile.update(otherProfiles[0].id, { accepted_date_key: null });
      }
      // Supprimer les locks des deux côtés (no-op pour une proposition simple sans lock ;
      // nécessaire pour une renégociation expirée — le proposant garde son lock pendant l'attente).
      await deleteLock(base44, dk, user.id).catch(e => console.error('cancelDate: deleteLock self failed:', e));
      await deleteLock(base44, dk, otherUserId).catch(e => console.error('cancelDate: deleteLock other failed:', e));
      // Les DEUX sont libérés → notifier leurs partenaires stale-closed
      await resumeSuspendedInteractions(base44, dk, user.id, displayTime);
      await resumeSuspendedInteractions(base44, dk, otherUserId, displayTime);
      // Les DEUX sont libérés → se notifier mutuellement la disponibilité réciproque
      // et fermer les actions en attentes pour débloquer le défi côté frontend.
      await closePendingActionsBetween(base44, dk, user.id, otherUserId);
      await notifyPairAvailableAgain(base44, dk, user.id, otherUserId, myName, otherName, myProfiles[0]?.photo_url || '', otherProfiles[0]?.photo_url || '', displayTime);
    }

    // Annulation → la paire est verrouillée pour la journée (règle : un seul défi par jour
    // entre profils, dans les deux sens). Pour une annulation après confirmation, le
    // canceller est déjà bloqué par le DateLock et l'autre est libéré — on nettoie les
    // marqueurs pour qu'il puisse dater ailleurs (le backend bloquera un re-défi via le
    // thread state 'cancelled').
    if (isRenegotiationCancel || !wasConfirmed) {
      await markPairLocked(base44, user.id, otherUserId, dk);
    } else {
      await cleanChallengeMarkers(base44, user.id, otherUserId, dk);
    }

    // SHADOW: transition vers cancelled (wasConfirmed) ou no_match (proposition en attente)
    transitions.push(threadSnapshot(await transitionThreadState(base44, computeThreadKey(dk, user.id, otherUserId), wasConfirmed ? 'cancelled' : 'no_match')));

    // Journal append-only : fermer les confirmations sans supprimer leur texte ni leur ID.
    await Promise.all(
      myMsgs
        .filter(
          (m) =>
            (m.profile_id === otherUserId || m.profile_name === otherName) &&
            m.text?.includes('Date confirmé')
        )
        .map((m) => base44.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) }))
    );
    await Promise.all(
      otherMsgs
        .filter(
          (m) =>
            (m.profile_id === user.id || m.profile_name === myName) &&
            m.text?.includes('Date confirmé')
        )
        .map((m) => base44.asServiceRole.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) }))
    );

    // Message d'annulation pour le courant
    // Date confirmé (lieu accepté par les 2) → "Date annulé", canceller reste bloqué.
    // Date non confirmé → "Pas de match", pair fermée, chacun peut dater à nouveau.
    const selfText = wasConfirmed
      ? msgDateCancelledSelf(otherName)
      : msgNoMatchSelf(otherName);
    await base44.entities.UserMessage.create({
      user_id: user.id,
      date_key: dk,
      sender: 'Système',
      text: selfText,
      is_system: true,
      profile_name: otherName,
      profile_id: otherUserId,
      profile_photo: otherProfiles[0]?.photo_url || '',
      thread_key: otherName,
      action_json: null,
      display_time: displayTime,
    });

    // Message d'annulation miroir pour l'autre utilisateur
    const otherText = wasConfirmed
      ? msgDateCancelledOther(myName)
      : msgNoMatchOther(myName);
    const cancelMessage = await base44.asServiceRole.entities.UserMessage.create({
      user_id: otherUserId,
      date_key: dk,
      sender: 'Système',
      text: otherText,
      is_system: true,
      profile_name: myName,
      profile_id: user.id,
      profile_photo: myProfiles[0]?.photo_url || '',
      thread_key: myName,
      action_json: null,
      display_time: displayTime,
    });

    notifyMessagePush(base44, {
      message: cancelMessage,
      fromUserId: user.id,
      senderName: myName,
      override: wasConfirmed ? PUSH.dateCancelled(myName) : PUSH.noMatch(myName),
    });

    return Response.json({ success: true, wasConfirmed, isRenegotiationCancel, transitions, lock });
  } catch (error) {
    return Response.json({ success: false, error: error.message, code: error.code || 'WRITE_FAILED', transitions, lock, actualState: error.state ?? null }, { status: error.status || 500 });
  }
});