import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Vérifie qu'un display_name (pseudo) n'est pas déjà utilisé par un autre profil.
// Contourne la RLS (is_online) via service role pour détecter les doublons hors-ligne.
// Comparaison insensible à la casse et aux espaces superflus.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { displayName } = await req.json();
    if (!displayName || !displayName.trim()) {
      return Response.json({ error: 'Missing displayName' }, { status: 400 });
    }

    const normalized = displayName.trim().toLowerCase();
    // Récupère tous les profils en service role (contourne RLS is_online)
    const profiles = await base44.asServiceRole.entities.Profile.filter({});
    const list = Array.isArray(profiles) ? profiles : (profiles.items || []);
    const taken = list.some(
      (p) => p.user_id !== user.id && p.display_name && p.display_name.trim().toLowerCase() === normalized
    );

    return Response.json({ available: !taken });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});