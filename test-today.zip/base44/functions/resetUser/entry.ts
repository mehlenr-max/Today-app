import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    // Seul un admin peut réinitialiser
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { email } = await req.json();
    if (!email) {
      return Response.json({ error: 'Email required' }, { status: 400 });
    }

    // Récupérer l'utilisateur à réinitialiser
    const targetUsers = await base44.asServiceRole.entities.User.filter({ email });
    if (!targetUsers.length) {
      return Response.json({ error: 'User not found' }, { status: 404 });
    }
    const targetUserId = targetUsers[0].id;

    // Supprimer tous les messages
    const messages = await base44.asServiceRole.entities.UserMessage.filter({ user_id: targetUserId });
    for (const msg of messages) {
      await base44.asServiceRole.entities.UserMessage.delete(msg.id);
    }

    // Supprimer toutes les sessions
    const sessions = await base44.asServiceRole.entities.UserSession.filter({ user_id: targetUserId });
    for (const session of sessions) {
      await base44.asServiceRole.entities.UserSession.delete(session.id);
    }

    return Response.json({ success: true, message: `User ${email} reset to zero` });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});