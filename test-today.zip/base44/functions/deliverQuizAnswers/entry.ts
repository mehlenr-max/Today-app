import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { msgQuizAnswers } from '../../shared/messages.ts';
import { notifyMessagePush } from '../../shared/push.ts';

// Envoie les réponses du quiz à l'expéditeur des questions (contourne la RLS en service role)
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { recipientUserId, questions, answers, gameType, dateKey } = await req.json();
    if (!recipientUserId || !dateKey || !Array.isArray(questions) || !Array.isArray(answers)) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Récupérer le profil du répondant
    const myProfiles = await base44.entities.Profile.filter({ user_id: user.id });
    const myProfile = myProfiles[0];
    const responderName = myProfile?.display_name || user.full_name || 'Quelqu\'un';
    const displayTime = new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' });

    // Construire le texte des réponses selon le type de jeu
    let qaText;
    if (gameType === 'thisOrThat') {
      qaText = questions.map((q, i) => {
        const a = answers[i];
        if (!a) return null;
        const choice = a === 'a' ? q.a : q.b;
        return `⚡ ${q.a} ou ${q.b} ?\n👉 ${choice}`;
      }).filter(Boolean).join('\n\n');
    } else if (gameType === 'nhie') {
      qaText = questions.map((q, i) => {
        const a = answers[i];
        if (!a) return null;
        const choice = a === 'deja' ? 'Vrai ✅' : 'Faux 🚫';
        return `🤫 Je n'ai jamais ${q.text}\n👉 ${choice}`;
      }).filter(Boolean).join('\n\n');
    } else {
      qaText = questions.map((q, i) => {
        const a = answers[i]?.trim();
        const qText = q?.text || q;
        return a ? `❓ ${qText}\n💬 ${a}` : null;
      }).filter(Boolean).join('\n\n');
    }

    // ── Le jeu est marqué comme joué (répondre à au moins une question suffit) ──
    // La marque porte sur LE JEU (type de jeu avec cette personne), pas sur la paire :
    // le quota « 2 jeux proposés par paire » n'est pas touché.
    if (gameType && myProfile?.id) {
      const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;
      const nowMs = Date.now();
      let playedMap = {};
      try { playedMap = myProfile.quiz_played_map ? JSON.parse(myProfile.quiz_played_map) : {}; } catch {}

      // Prune des entrées de plus de 30 jours + copie de la map existante
      const cleanedMap = {};
      for (const [uid, data] of Object.entries(playedMap)) {
        if (!data || typeof data !== 'object' || Array.isArray(data)) continue;
        const kept = {};
        for (const [gtype, stamps] of Object.entries(data)) {
          if (!Array.isArray(stamps)) continue;
          const recent = stamps.filter(ts => new Date(ts).getTime() > nowMs - THIRTY_DAYS);
          if (recent.length > 0) kept[gtype] = recent;
        }
        if (Object.keys(kept).length > 0) cleanedMap[uid] = kept;
      }

      const pairKey = String(recipientUserId);
      const pair = cleanedMap[pairKey] || {};
      const alreadyPlayed = Array.isArray(pair[gameType]) && pair[gameType].length > 0;
      if (!alreadyPlayed) {
        // Écriture autoritaire AVANT l'envoi : si elle échoue, aucune réponse n'est envoyée
        cleanedMap[pairKey] = { ...pair, [gameType]: [...(pair[gameType] || []), new Date().toISOString()] };
        await base44.entities.Profile.update(myProfile.id, { quiz_played_map: JSON.stringify(cleanedMap) });
      }
    }

    // Créer le message dans la boîte de l'expéditeur des questions
    const answersMessage = await base44.asServiceRole.entities.UserMessage.create({
      user_id: recipientUserId,
      date_key: dateKey,
      sender: responderName,
      text: msgQuizAnswers(responderName, qaText),
      is_system: false,
      profile_name: responderName,
      profile_id: String(user.id),
      thread_key: responderName,
      action_json: JSON.stringify({
        type: 'quizAnswers',
        gameType: gameType || null,
        questions,
        answers,
        responderName,
      }),
      profile_photo: myProfile?.photo_url || '',
      display_time: displayTime,
    });

    notifyMessagePush(base44, { message: answersMessage, fromUserId: user.id });

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});