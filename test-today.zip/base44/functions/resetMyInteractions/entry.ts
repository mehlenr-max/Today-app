import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Réservé aux administrateurs — contrôle par rôle, plus par adresse email.
    const isAdmin = user?.role === 'admin';
    if (!isAdmin) {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const svc = base44.asServiceRole;

    // Date du jour en Europe/Brussels
    const todayKey = new Date().toLocaleDateString('fr-CA', { timeZone: 'Europe/Brussels' });

    // Compter les enregistrements avant reset pour affichage
    const [msgCount, sessionCount, profileCount, threadCount, lockCount] = await Promise.all([
      svc.entities.UserMessage.count({ date_key: todayKey }),
      svc.entities.UserSession.count({ date_key: todayKey }),
      svc.entities.Profile.count({}),
      svc.entities.DateThread.count({ date_key: todayKey }),
      svc.entities.DateLock.count({ date_key: todayKey }),
    ]);

    // 0. Supprimer TOUS les messages du jour
    let msgHasMore = true;
    while (msgHasMore) {
      const res = await svc.entities.UserMessage.deleteMany({ date_key: todayKey });
      msgHasMore = res.has_more === true;
    }

    // 1. Réinitialiser TOUTES les sessions du jour (interactions + matchs + flags date accepté)
    // updateMany avec $unset garantit que les champs sont VRAIMENT vidés (bulkUpdate avec null peut échouer silencieusement).
    let sessionHasMore = true;
    while (sessionHasMore) {
      const res = await svc.entities.UserSession.updateMany(
        { date_key: todayKey },
        { $set: { challenged_profiles: '{}', passed_profiles: '{}', challenge_dates: '{}', physical_affinity: '{}', match_count: 0, has_accepted_date: false }, $unset: { accepted_date_details: '' } }
      );
      sessionHasMore = res.has_more === true;
    }

    // 2. Réinitialiser les maps persistantes + accepted_date_key sur TOUS les profils
    let profileHasMore = true;
    while (profileHasMore) {
      const res = await svc.entities.Profile.updateMany(
        {},
        { $set: { challenge_dates_map: '{}', quiz_proposed_map: '{}', quiz_played_map: '{}' }, $unset: { accepted_date_key: '' } }
      );
      profileHasMore = res.has_more === true;
    }

    // 3. Supprimer TOUS les DateThread du jour (les matchs eux-mêmes)
    let threadHasMore = true;
    while (threadHasMore) {
      const res = await svc.entities.DateThread.deleteMany({ date_key: todayKey });
      threadHasMore = res.has_more === true;
    }

    // 4. Supprimer TOUS les DateLock du jour (locks de disponibilité)
    let lockHasMore = true;
    while (lockHasMore) {
      const res = await svc.entities.DateLock.deleteMany({ date_key: todayKey });
      lockHasMore = res.has_more === true;
    }

    return Response.json({
      success: true,
      sessionReset: sessionCount,
      profileReset: profileCount,
      messageDeleted: msgCount,
      threadDeleted: threadCount,
      lockDeleted: lockCount,
      message: 'Interactions, matchs, locks et messages remis à zéro pour tous les profils',
    });
  } catch (error) {
    console.error('resetMyInteractions error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});