import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { transitionThreadState, threadSnapshot } from '../../shared/datethread.ts';
import { cleanChallengeMarkers } from '../../shared/challenge-cleanup.ts';
import { msgChallengeWin } from '../../shared/messages.ts';

// ── Réparation ponctuelle (one-shot, approuvée par Romain) ─────────────────────
// Fil PPC Sarah/Michael du 2026-10-21 resté en pending_challenge v1 : le verdict est
// connu (Sarah a perdu — son message « 😔 Tu as perdu contre Michael » id 6ad8e5ecdb71a94a5ee7aaae
// fait foi) mais l'appel deliverResult/notifyWinner du 16:18:52 n'a produit AUCUNE écriture
// serveur (ni 🏆 chez Michael, ni transition de fil, ni nettoyage des marqueurs).
//
// Cette fonction rétablit l'état normal d'une résolution PPC :
//   - transition du fil → ppc_resolved (v2) avec winner_user_id = Michael
//   - UN SEUL message 🏆 chez Michael (même forme que deliverResult/notifyWinner)
//   - nettoyage des marqueurs challenged_profiles des deux côtés
// Elle NE supprime aucun message, NE recrée PAS le lose de Sarah (déjà présent),
// N'INSÈRE PAS de « Résultat PPC » (les choix réels ne sont enregistrés nulle part —
// aucune donnée inventée) et NE TOUCHE À AUCUN AUTRE FIL.
// Idempotente : ré-invocable sans doublon. Ne jamais utiliser resetTodayInteractions/
// resetMyInteractions à la place (elles détruisent tout le jour pour tout le monde).
const REPAIR = {
  dateKey: '2026-10-21',
  threadKey: '2026-10-21_6abcd53aef9c69e1b7b03da5_6ac26902b39617d11bde11b7',
  threadId: '6ad8e5266834d26dd22b111f',
  winnerUserId: '6abcd53aef9c69e1b7b03da5', // Michael (gagnant)
  winnerProfileId: '6abcd5941cc3add091591303', // profil RÉEL de Michael (pas le profil replay)
  loserUserId: '6ac26902b39617d11bde11b7', // Sarah (perdante)
  loserProfileId: '6ac269581c0f2250a018e5d1',
  loserName: 'Sarah',
};

Deno.serve(async (req) => {
  const done: Record<string, any> = { thread: null, message: null, markers: null };
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    // Réservé admin (même garde que resetMyInteractions) — contrôle par rôle.
    if (user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const dryRun = body?.dryRun === true;
    const svc = base44.asServiceRole;
    const { dateKey, threadKey, winnerUserId, winnerProfileId, loserUserId, loserProfileId, loserName } = REPAIR;

    // 1. Le fil attendu
    const threads = await svc.entities.DateThread.filter({ thread_key: threadKey });
    const thread = threads[0];
    if (!thread) return Response.json({ success: false, error: 'THREAD_NOT_FOUND', threadKey }, { status: 404 });
    done.thread = threadSnapshot(thread);
    if (thread.state === 'ppc_resolved') {
      // Idempotence stricte : déjà réparé → succès sans aucune écriture
      return Response.json({ success: true, alreadyResolved: true, dryRun, ...done });
    }
    if (thread.state !== 'pending_challenge') {
      return Response.json({ success: false, error: 'UNEXPECTED_THREAD_STATE', ...done }, { status: 409 });
    }

    // 2. Identités vérifiées contre les ids verrouillés — on n'écrit rien si ça ne correspond pas
    const [winnerProfiles, loserProfiles] = await Promise.all([
      svc.entities.Profile.filter({ user_id: winnerUserId }),
      svc.entities.Profile.filter({ user_id: loserUserId }),
    ]);
    if (winnerProfiles[0]?.id !== winnerProfileId || loserProfiles[0]?.id !== loserProfileId) {
      return Response.json({
        success: false,
        error: 'PROFILE_ID_MISMATCH',
        winnerProfileId: winnerProfiles[0]?.id || null,
        loserProfileId: loserProfiles[0]?.id || null,
      }, { status: 409 });
    }
    const loserPhoto = loserProfiles[0]?.photo_url || '';

    // 3. Idempotence : un 🏆 contre Sarah existe-t-il déjà chez Michael ? (garde par test texte)
    const winText = msgChallengeWin(loserName);
    const winnerMsgs = await svc.entities.UserMessage.filter(
      { user_id: winnerUserId, date_key: dateKey, profile_name: loserName }, '-created_date', 200
    );
    const alreadyNotified = winnerMsgs.some(m => m.text === winText || m.text?.includes(`Tu as gagné le défi contre ${loserName}`));

    const displayTime = new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' });

    if (dryRun) {
      // Aucune écriture — permet de vérifier le plan avant d'appliquer
      return Response.json({
        success: true,
        dryRun: true,
        plan: {
          thread: done.thread,
          willCreateWinnerMessage: !alreadyNotified,
          winnerMessageText: winText,
          willTransitionTo: 'ppc_resolved',
          winnerUserId,
          loserProfileId,
        },
      });
    }

    // 4. Message 🏆 chez Michael — créé EN PREMIER (garde par test texte), même forme que
    //    deliverResult/notifyWinner. Si la transition échoue ensuite, la re-invocation
    //    saute la création (idempotence) et rejoue la transition → convergence.
    let created = null;
    if (!alreadyNotified) {
      created = await svc.entities.UserMessage.create({
        user_id: winnerUserId,
        date_key: dateKey,
        sender: loserName,
        text: winText,
        is_system: false,
        profile_name: loserName,
        profile_id: loserUserId,
        thread_key: loserName,
        action_json: JSON.stringify({
          type: 'winnerChoosePlace',
          loserProfile: { id: loserProfileId, user_id: loserUserId, name: loserName },
        }),
        profile_photo: loserPhoto,
        timer_start_time: Date.now(),
        display_time: displayTime,
      });
    }
    done.message = { created: !alreadyNotified, id: created?.id || null };

    // 5. Transition autoritaire du fil → ppc_resolved (garde de version : v1 → v2)
    const updated = await transitionThreadState(base44, threadKey, 'ppc_resolved', {
      winner_user_id: winnerUserId,
      loser_profile_id: loserProfileId,
    });
    done.thread = threadSnapshot(updated);

    // 6. Marqueurs challenged_profiles des deux côtés : même helper que le flux normal
    //    (comme pour IRENE/TESSA/Amber), puis garantie explicite sur les deux clés
    //    verrouillées si le helper ne les a pas retirées (idempotent).
    await cleanChallengeMarkers(base44, loserUserId, winnerUserId, dateKey);
    for (const [sessionUserId, markerKey] of [[loserUserId, winnerProfileId], [winnerUserId, loserProfileId]]) {
      const sessions = await svc.entities.UserSession.filter({ user_id: sessionUserId, date_key: dateKey });
      if (!sessions[0]) continue;
      let map = {};
      try { map = JSON.parse(sessions[0].challenged_profiles || '{}'); } catch {}
      if (String(markerKey) in map) {
        delete map[String(markerKey)];
        await svc.entities.UserSession.update(sessions[0].id, { challenged_profiles: JSON.stringify(map) });
      }
    }
    const [loserSessions, winnerSessions] = await Promise.all([
      svc.entities.UserSession.filter({ user_id: loserUserId, date_key: dateKey }),
      svc.entities.UserSession.filter({ user_id: winnerUserId, date_key: dateKey }),
    ]);
    done.markers = {
      sarah: loserSessions[0]?.challenged_profiles || null,
      michael: winnerSessions[0]?.challenged_profiles || null,
    };

    return Response.json({ success: true, dryRun: false, alreadyResolved: false, ...done });
  } catch (error) {
    return Response.json({
      success: false,
      error: error.message,
      code: error.code || 'REPAIR_FAILED',
      ...done,
      actualState: error.state ?? null,
    }, { status: error.status || 500 });
  }
});