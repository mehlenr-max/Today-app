import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const PUSH_TITLE = "Ce soir c'est ToDay !";
const PUSH_CONTENT = "N'oublie pas de te connecter.";

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const listed = await base44.asServiceRole.entities.User.list();
    const users = Array.isArray(listed) ? listed : (listed?.items || listed?.data || []);

    let sent = 0;
    const failures = [];

    for (let i = 0; i < users.length; i += 5) {
      const batch = users.slice(i, i + 5);
      const results = await Promise.allSettled(
        batch.map((u) => base44.asServiceRole.integrations.Core.SendPushNotification({
          user_id: u.id,
          title: PUSH_TITLE,
          content: PUSH_CONTENT
        }))
      );
      results.forEach((r, idx) => {
        if (r.status === 'fulfilled') sent += 1;
        else failures.push({ user_id: batch[idx].id, error: r.reason?.message || 'send failed' });
      });
    }

    return Response.json({ total: users.length, sent, failed: failures.length, failures });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}