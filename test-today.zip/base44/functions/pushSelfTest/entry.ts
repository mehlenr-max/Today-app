import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// ─────────────────────────────────────────────────────────────────────────────
// Diagnostic push — RÉSERVÉ À L'ADMIN.
//
// Envoie UNE notification native à l'utilisateur qui appelle la fonction, via
// l'intégration SendPushNotification, et renvoie la réponse BRUTE de
// l'intégration. Aucune erreur n'est avalée : en cas d'échec, le message
// complet est renvoyé dans `error` et l'objet d'erreur dans `raw`.
//
// Réponse : { ok, error, raw }
//   ok    : true si le service push a accepté l'envoi
//   error : message d'erreur complet (null si succès)
//   raw   : réponse brute de l'intégration (ou détail de l'erreur)
// ─────────────────────────────────────────────────────────────────────────────
Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  const user = await base44.auth.me().catch((e: any) => (e?.status === 401 ? null : Promise.reject(e)));
  if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
  if (user.role !== 'admin') {
    return Response.json({ ok: false, error: 'Forbidden: admin only', raw: null }, { status: 403 });
  }

  // Le destinataire est l'utilisateur Base44 qui appelle — jamais un Profile.id.
  const destinataire = String(user.id);

  try {
    console.info('PUSH: tentative ->', destinataire);
    const raw = await base44.asServiceRole.integrations.Core.SendPushNotification({
      user_id: destinataire,
      title: 'Test ToDay',
      content: 'Test push',
    });
    console.info('PUSH: resultat ->', JSON.stringify(raw ?? null));
    return Response.json({ ok: true, error: null, raw });
  } catch (error: any) {
    const message = String(error?.message || error);
    console.info('PUSH: resultat ->', message);
    return Response.json({
      ok: false,
      error: message,
      raw: error?.response?.data ?? { status: error?.status ?? null, detail: message },
    });
  }
});