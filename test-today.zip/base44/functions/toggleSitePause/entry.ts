import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

// Bascule l'état de pause du site (réservé aux administrateurs).
// paused = true → les membres non admin voient l'écran de maintenance.
const KEY = 'site';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Accès réservé aux administrateurs' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const paused = body?.paused === true;
    const svc = base44.asServiceRole;

    const found = await svc.entities.AppState.filter({ key: KEY });
    const record = (Array.isArray(found) ? found : (found?.items || []))[0] || null;

    if (record) {
      if (record.paused !== paused) {
        await svc.entities.AppState.update(record.id, { paused, updated_by_id: user.id });
      }
    } else {
      await svc.entities.AppState.create({ key: KEY, paused, updated_by_id: user.id });
    }

    return Response.json({ ok: true, paused });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}