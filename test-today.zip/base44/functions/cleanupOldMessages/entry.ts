import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

function isQuizMessage(m) {
  if (m.action_json && (m.action_json.includes('"quizQuestions"') || m.action_json.includes('"quizAnswers"'))) return true;
  if (m.text && m.text.includes('Tu as répondu au quiz')) return true;
  return false;
}

Deno.serve(async (req) => {
  try {
    const body = await req.json().catch(() => ({}));
    const readOnly = body?.readOnly === true;

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const svc = base44.asServiceRole;

    const now = new Date();
    // Messages classiques : cutoff à J-3 (rétention glissante de 3 jours)
    const threeDaysAgo = new Date(now);
    threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
    const cutoffKey = threeDaysAgo.toLocaleDateString('fr-CA', { timeZone: 'Europe/Brussels' });

    // Quiz : cutoff à 8 jours (visibilité 7 jours, effacement au 8e)
    const eightDaysAgo = new Date(now);
    eightDaysAgo.setDate(eightDaysAgo.getDate() - 8);
    const eightDaysAgoKey = eightDaysAgo.toLocaleDateString('fr-CA', { timeZone: 'Europe/Brussels' });

    if (readOnly) {
      return Response.json({
        readOnly: true,
        cutoffRegular: cutoffKey,
        cutoffQuiz: eightDaysAgoKey,
      });
    }

    // Phase 1: Suppression directe — TOUS les messages de plus de 8 jours.
    // À cet âge, même les quiz sont expirés. Aucune lecture nécessaire.
    let deletedOld = 0;
    let hasMoreOld = true;
    while (hasMoreOld) {
      const res = await svc.entities.UserMessage.deleteMany({ date_key: { $lt: eightDaysAgoKey } });
      deletedOld += res?.deleted || 0;
      hasMoreOld = res?.has_more === true;
    }

    // Phase 2: Suppression directe — messages NON-quiz entre J-8 et J-3.
    // Les quiz (action_json avec quizQuestions/quizAnswers, ou text 'Tu as répondu au quiz')
    // sont préservés jusqu'à J-8. $not $regex exclut les quiz de cette fenêtre.
    let deletedRegular = 0;
    let hasMoreRegular = true;
    while (hasMoreRegular) {
      const res = await svc.entities.UserMessage.deleteMany({
        date_key: { $lt: cutoffKey },
        action_json: { $not: { $regex: 'quizQuestions|quizAnswers' } },
        text: { $not: { $regex: 'Tu as répondu au quiz' } },
      });
      deletedRegular += res?.deleted || 0;
      hasMoreRegular = res?.has_more === true;
    }

    return Response.json({
      success: true,
      deletedOld,
      deletedRegular,
      total: deletedOld + deletedRegular,
      cutoffRegular: cutoffKey,
      cutoffQuiz: eightDaysAgoKey,
    });
  } catch (error) {
    console.error('cleanupOldMessages error:', error?.message || error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});