import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { buildWarningCopy } from '../../shared/moderation-warning.ts';

// Actions de modération réservées aux administrateurs :
//   get_profile     → fiche complète du profil signalé
//   warning_preview → email d'avertissement prérempli, à valider par l'admin
//   send_warning    → envoi de l'avertissement au membre concerné
//   set_hidden      → masquer / réafficher le profil (global et réversible)
//   delete_photo    → retirer une photo du profil (slot 1, 2 ou 3)

const ACTIONS = ['get_profile', 'warning_preview', 'send_warning', 'set_hidden', 'delete_photo'];

const PHOTO_FIELDS = { 1: 'photo_url', 2: 'photo_url_2', 3: 'photo_url_3' };

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Accès réservé aux administrateurs' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const action = body?.action;
    if (!ACTIONS.includes(action)) {
      return Response.json({ error: 'Action inconnue' }, { status: 400 });
    }

    const svc = base44.asServiceRole;

    async function loadProfile(profileId) {
      if (!profileId) return null;
      const profiles = await svc.entities.Profile.filter({ id: profileId });
      return Array.isArray(profiles) ? (profiles[0] || null) : null;
    }

    async function loadMember(userId) {
      if (!userId) return null;
      const users = await svc.entities.User.filter({ id: userId });
      const list = Array.isArray(users) ? users : (users?.items || []);
      return list[0] || null;
    }

    // Le motif provient toujours du signalement stocké, jamais du client.
    async function loadReportContext(reportId) {
      if (!reportId) return {};
      const reports = await svc.entities.Report.filter({ id: reportId });
      const report = Array.isArray(reports) ? (reports[0] || null) : null;
      if (!report) return {};
      const profile = await loadProfile(report.reported_profile_id);
      const member = await loadMember(profile?.user_id || report.reported_user_id);
      return { report, profile, member };
    }

    if (action === 'get_profile') {
      const profile = await loadProfile(String(body.profileId || ''));
      if (!profile) return Response.json({ error: 'Profil introuvable' }, { status: 404 });
      const reports = await svc.entities.Report.filter({ reported_profile_id: profile.id });
      const list = Array.isArray(reports) ? reports : [];
      return Response.json({
        profile,
        reportCount: list.length,
        pendingCount: list.filter(r => (r.status || 'pending') === 'pending').length,
      });
    }

    if (action === 'warning_preview') {
      const { report, profile, member } = await loadReportContext(String(body.reportId || ''));
      if (!report) return Response.json({ error: 'Signalement introuvable' }, { status: 404 });
      const firstName = String(member?.full_name || profile?.display_name || '').trim().split(' ')[0] || '';
      const copy = buildWarningCopy({ firstName, reason: report.reason, message: '' });
      return Response.json({
        to: member?.email || '',
        recipientName: profile?.display_name || member?.full_name || '',
        subject: copy.subject,
        message: copy.message,
      });
    }

    if (action === 'send_warning') {
      const { report, profile, member } = await loadReportContext(String(body.reportId || ''));
      if (!report) return Response.json({ error: 'Signalement introuvable' }, { status: 404 });
      if (!member?.email) {
        return Response.json({ error: "Ce membre n'a pas d'adresse email enregistrée" }, { status: 400 });
      }
      const firstName = String(member.full_name || profile?.display_name || '').trim().split(' ')[0] || '';
      const copy = buildWarningCopy({ firstName, reason: report.reason, message: body.message });
      await svc.integrations.Core.SendEmail({
        to: member.email,
        subject: copy.subject,
        template_name: 'ModerationWarning',
        variables: { first_name: firstName, message: copy.message },
      });
      return Response.json({ ok: true, to: member.email });
    }

    if (action === 'set_hidden') {
      const profile = await loadProfile(String(body.profileId || ''));
      if (!profile) return Response.json({ error: 'Profil introuvable' }, { status: 404 });
      const hidden = body.hidden === true;
      if (profile.is_hidden !== hidden) {
        await svc.entities.Profile.update(profile.id, { is_hidden: hidden });
      }
      return Response.json({ ok: true, is_hidden: hidden });
    }

    // delete_photo
    const profile = await loadProfile(String(body.profileId || ''));
    if (!profile) return Response.json({ error: 'Profil introuvable' }, { status: 404 });
    const slot = Number(body.slot);
    const field = PHOTO_FIELDS[slot];
    if (!field) return Response.json({ error: 'Photo inconnue' }, { status: 400 });

    const update = { [field]: '' };
    if (slot === 1) update.photo1_verified = false;
    await svc.entities.Profile.update(profile.id, update);

    return Response.json({ ok: true, slot, removed_url: profile[field] || '' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}