import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Le texte d'un signalement est contrôlé par l'utilisateur : il doit traverser
// l'email comme DONNÉE, jamais comme HTML. On neutralise les entités HTML et
// on borne la longueur avant injection.
function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function sanitizeField(value, maxLength = 500) {
  if (typeof value !== 'string') return '—';
  const cleaned = value.replace(/[\u0000-\u001F\u007F]+/g, ' ').trim().slice(0, maxLength);
  return cleaned ? escapeHtml(cleaned) : '—';
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const report = body?.data;
    if (!report || !report.reported_profile_id) {
      return Response.json({ ok: true, skipped: true });
    }

    const profileId = report.reported_profile_id;
    const svc = base44.asServiceRole;

    // Compter les signalements en attente sur ce profil
    const reports = await svc.entities.Report.filter({ reported_profile_id: profileId, status: 'pending' });
    const count = Array.isArray(reports) ? reports.length : 0;

    // Seuil de 2 signalements : plus de masquage automatique.
    // L'admin est averti (email + alerte dans l'espace de modération) et le
    // masquage n'a lieu qu'après confirmation explicite d'un modérateur.
    const thresholdReached = count >= 2;

    // Prévenir les administrateurs par email — query only admins (not all users)
    let adminsNotified = 0;
    try {
      const admins = await svc.entities.User.filter({ role: 'admin' });
      const adminEmails = (Array.isArray(admins) ? admins : [])
        .filter(u => u.role === 'admin' && u.email)
        .map(u => u.email);

      if (adminEmails.length === 0) {
        console.error('handleReportCreated: No admins found to notify for report on profile', profileId);
      } else {
        const subject = thresholdReached
          ? `🚨 ToDay — Seuil de signalements atteint (${count})`
          : `🚩 ToDay — Nouveau signalement (${count})`;
        const bodyText = [
          'Bonjour,',
          '',
          'Un nouveau signalement a été reçu sur ToDay.',
          '',
          `Profil signalé : ${sanitizeField(profileId, 80)}`,
          `Propriétaire (user_id) : ${sanitizeField(report.reported_user_id, 80)}`,
          `Motif : ${sanitizeField(report.reason, 40)}`,
          `Détail : ${sanitizeField(report.detail, 500)}`,
          `Signalements en attente : ${count}`,
          '',
          thresholdReached
            ? "⚠️ Le seuil de 2 signalements est atteint. Le profil reste visible : le masquage doit être CONFIRMÉ par un modérateur dans l'espace de modération."
            : 'Le profil reste visible. Au 2e signalement, le masquage devra être confirmé par un modérateur.',
          '',
          '— Modération ToDay',
        ].join('\n');
        for (const email of adminEmails) {
          await svc.integrations.Core.SendEmail({ to: email, subject, body: bodyText });
          adminsNotified++;
        }
      }
    } catch (e) {
      // L'email est best-effort : ne pas faire échouer la fonction.
      console.error('handleReportCreated: email notification failed:', e?.message || e);
    }

    return Response.json({ ok: true, count, thresholdReached, adminsNotified });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}