import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { cleanChallengeMarkers, markPersonalRefusalLockout } from '../../shared/challenge-cleanup.ts';
import { appendMessageOnce } from '../../shared/append-once.ts';
import { threadSnapshot, transitionThreadState, computeThreadKey, findThread, findLock, acquireLock, acquireOrVerifyLock, releaseLock, deleteLock } from '../../shared/datethread.ts';
import { msgChallengeWin, msgChallengeLost, msgPlaceProposal, msgDateConfirmed, msgPlaceRefusedFinal, msgPlaceRefusedNonFinal, msgLockCancelledAfterConfirm, msgLockAlreadyHasDate, msgWinnerUnavailable, msgLoserAlreadyHasDate, msgWaitingAcceptance, msgRpsResult } from '../../shared/messages.ts';
import { suspendOtherInteractions, resumeSuspendedInteractions } from '../../shared/stale-cleanup.ts';
import { notifyMessagePush, PUSH } from '../../shared/push.ts';

// Livrer le résultat RPS au gagnant ou au perdant (contourne la RLS en service role)
// type: 'notifyWinner' → demande au gagnant de choisir un lieu
// type: 'notifyLoser'  → envoie la proposition de lieu au perdant
// type: 'resolveRps'   → résolution PPC côté serveur : verdict, transition + messages des deux boîtes
Deno.serve(async (req) => {
  const transitions = [];
  let lock = null;
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { type, recipientUserId, senderProfile, place, time, address, dateKey, winnerUserId: payloadWinnerUserId, loserName, loserUserId, reasons: reasonsParam, opponentUserId: payloadOpponentUserId, playerChoice: payloadPlayerChoice, opponentChoice: _payloadOpponentChoiceIgnored } = await req.json();
    const displayTime = new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' });
    const senderName = senderProfile?.name || 'Quelqu\'un';
    // Snapshot photo du caller (counterpart dans tous les branches = user.id) — résolu depuis l'entité Profile
    const myProfiles = await base44.entities.Profile.filter({ user_id: user.id });
    const myPhoto = myProfiles[0]?.photo_url || '';
    let finalRefusal = false;

    // Resolve the counterpart's photo (the person named in profile_name) from senderProfile,
    // with a server-side lookup fallback. profile_photo must always be the counterpart's photo.
    async function resolveCounterpartPhoto(sp) {
      if (sp?.photo) return sp.photo;
      if (sp?.user_id) {
        try {
          const ps = await base44.asServiceRole.entities.Profile.filter({ user_id: sp.user_id });
          return ps[0]?.photo_url || '';
        } catch {}
      }
      return '';
    }

    // Normaliser place_json : si le frontend envoie un place pré-concaténé
    // ("name à time · address"), le parser en structure {name, time, address}.
    function normalizePlace(placeStr, timeStr, addressStr) {
      if (placeStr && placeStr.includes(' à ')) {
        const match = placeStr.match(/^(.+?) à ([^·]+?)(?: · (.+))?$/);
        if (match) {
          return { name: match[1].trim(), time: match[2].trim(), address: (match[3] || addressStr || '').trim() };
        }
      }
      return { name: placeStr || '', time: timeStr || '', address: addressStr || '' };
    }

    if (type === 'notifyWinner') {
      // Autorisé caller = LE PERDANT (notifie le gagnant qu'il a gagné). Aucun winnerUserId trusté.
      // Résoudre la photo (lecture) avant de paralléliser les écritures
      const counterpartPhoto = await resolveCounterpartPhoto(senderProfile);
      // Écritures indépendantes (UserMessage, UserSession, DateThread) — parallélisées
      const transitionPromise = transitionThreadState(base44, computeThreadKey(dateKey, user.id, recipientUserId), 'ppc_resolved', {
        winner_user_id: recipientUserId,
        loser_profile_id: String(senderProfile?.id || ''),
      });
      const [winnerMessage, , transition] = await Promise.all([
        base44.asServiceRole.entities.UserMessage.create({
          user_id: recipientUserId,
          date_key: dateKey,
          sender: senderName,
          text: msgChallengeWin(senderName),
          is_system: false,
          profile_name: senderName,
          profile_id: String(senderProfile?.user_id || ''),
          thread_key: senderName,
          action_json: JSON.stringify({ type: 'winnerChoosePlace', loserProfile: { id: senderProfile?.id, user_id: senderProfile?.user_id, name: senderName } }),
          profile_photo: counterpartPhoto,
          timer_start_time: Date.now(),
          display_time: displayTime,
        }),
        cleanChallengeMarkers(base44, user.id, recipientUserId, dateKey),
        transitionPromise,
      ]);
      transitions.push(threadSnapshot(transition));
      notifyMessagePush(base44, { message: winnerMessage, fromUserId: user.id, override: PUSH.challengeWon(senderName) });
    } else if (type === 'notifyLoser') {
      // Autorisé caller = LE GAGNANT (propose un lieu au perdant). user.id = winner.
      // GARDE À LA PROPOSITION (addition #2): si le gagnant a un lock actif, refuser.
      const winnerLock = await findLock(base44, dateKey, user.id);
      lock = winnerLock;
      if (winnerLock?.locked) {
        const lockMsg = winnerLock.reason === 'cancelled_after_confirm'
          ? msgLockCancelledAfterConfirm()
          : msgLockAlreadyHasDate();
        const loserProfilesForLock = await base44.asServiceRole.entities.Profile.filter({ user_id: recipientUserId });
        const loserNameForLock = loserProfilesForLock[0]?.display_name || 'ce profil';
        await base44.entities.UserMessage.create({
          user_id: user.id, date_key: dateKey, sender: 'Système',
          text: lockMsg, is_system: true, profile_name: loserNameForLock,
          profile_id: String(recipientUserId), thread_key: loserNameForLock,
          display_time: displayTime,
        });
        return Response.json({ blocked: true, reason: winnerLock.reason, lock, transitions });
      }
      // Lectures indépendantes (Profile + UserMessage du perdant + photo) — parallélisées
      const [loserProfiles, oldThreadMsgs, counterpartPhoto] = await Promise.all([
        base44.asServiceRole.entities.Profile.filter({ user_id: recipientUserId }),
        base44.asServiceRole.entities.UserMessage.filter({
          user_id: recipientUserId, date_key: dateKey, profile_name: senderName
        }, '-created_date', 500),
        resolveCounterpartPhoto(senderProfile),
      ]);
      const loserDisplayName = loserProfiles[0]?.display_name || 'Quelqu\'un';
      const loserPhoto = loserProfiles[0]?.photo_url || '';
      // Garde d'idempotence : lire les anciens messages « En attente » du gagnant pour ce thread.
      // Si un message identique (même lieu/heure/adresse) existe déjà, on saute la création
      // (double appel réseau). Les « En attente » d'une proposition précédente (lieu différent)
      // sont fermés avant la création du nouveau.
      const winnerOldWaitingMsgs = await base44.asServiceRole.entities.UserMessage.filter({
        user_id: user.id, date_key: dateKey, profile_name: loserDisplayName
      }, '-created_date', 500);
      const waitingText = msgWaitingAcceptance(loserDisplayName, place, time, address);
      const isClosedMsg = (m: any) => m.action_json === JSON.stringify({ state: 'closed' });
      const alreadyHasIdenticalWaiting = winnerOldWaitingMsgs.some(m => m.text === waitingText && !isClosedMsg(m));
      const closeOldWaitingMsgs = Promise.all(winnerOldWaitingMsgs
        .filter(m => m.text?.includes("En attente d'acceptation") && !isClosedMsg(m) && m.text !== waitingText)
        .map(m => base44.asServiceRole.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) }).catch(e => console.error('UserMessage.close waiting (service role) failed:', e)))
      );
      // Fermer (append-only) les anciens messages de proposition et de refus du thread du perdant
      // (re-proposition après refus cas A : l'ancien loserAccept et le refus sont marqués fermés)
      const closeOldMsgs = Promise.all(oldThreadMsgs
        .filter(m => {
          if (m.text?.includes('Tu as refusé')) return true;
          if (m.action_json) {
            try { const a = JSON.parse(m.action_json); return a.type === 'loserAccept'; } catch { return false; }
          }
          return false;
        })
        .map(m => base44.asServiceRole.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) }).catch(e => console.error('UserMessage.close (service role) failed:', e)))
      );
      // Écritures indépendantes — parallélisées. Les deux écritures principales (proposition au
      // perdant + miroir « En attente » au gagnant) sont attendues AVANT la réponse de succès.
      // Pas de catch silencieux sur ces deux creates : l'échec remonte via le catch global.
      const transitionPromise = transitionThreadState(base44, computeThreadKey(dateKey, user.id, recipientUserId), 'place_proposed', {
        place_json: JSON.stringify(normalizePlace(place, time, address)),
        winner_profile_id: String(senderProfile?.id || ''),
      });
      const [, placeMessage, , transition] = await Promise.all([
        // Write 1: fermer les anciens messages du perdant (append-only)
        closeOldMsgs,
        // Write 2: nouvelle proposition au perdant
        base44.asServiceRole.entities.UserMessage.create({
          user_id: recipientUserId,
          date_key: dateKey,
          sender: senderName,
          text: msgPlaceProposal(senderName, place, time, address),
          is_system: false,
          profile_name: senderName,
          profile_id: String(senderProfile?.user_id || ''),
          thread_key: senderName,
          action_json: JSON.stringify({
            type: 'loserAccept',
            place: `${place} à ${time}${address ? ` · ${address}` : ''}`,
            profileId: senderProfile?.id,
            profileName: senderName,
            winnerUserId: user.id,
            loserName: loserDisplayName,
          }),
          profile_photo: counterpartPhoto,
          timer_start_time: Date.now(),
          display_time: displayTime,
        }),
        // Write 3: nettoyer les marqueurs (idempotent)
        cleanChallengeMarkers(base44, user.id, recipientUserId, dateKey),
        // Write 4: transition DateThread → place_proposed
        transitionPromise,
        // Write 5: miroir « En attente » dans la boîte du gagnant + fermeture des anciens.
        // Idempotent : skip si un message identique existe déjà (double appel).
        Promise.all([
          closeOldWaitingMsgs,
          alreadyHasIdenticalWaiting
            ? Promise.resolve(null)
            : base44.asServiceRole.entities.UserMessage.create({
                user_id: user.id,
                date_key: dateKey,
                sender: 'Système',
                text: waitingText,
                is_system: true,
                profile_name: loserDisplayName,
                profile_id: String(recipientUserId),
                profile_photo: loserPhoto,
                thread_key: loserDisplayName,
                display_time: displayTime,
              }),
        ]),
      ]);
      transitions.push(threadSnapshot(transition));
      notifyMessagePush(base44, { message: placeMessage, fromUserId: user.id, override: PUSH.placeProposed(senderName) });
    } else if (type === 'notifyWinnerConfirmed') {
      // Autorisé caller = LE PERDANT (accepte le lieu). winnerUserId = opponent, validé contre match réel.
      // LOCK ATOMIQUE (compare-and-swap via updateMany) — la garantie vient de MongoDB,
      // pas du code: seul le premier appel peut flipper has_accepted_date de false→true.
      // Le deuxième appel ne matche plus la garde → updated=0 → confirmation refusée.
      if (!payloadWinnerUserId) return Response.json({ error: 'Missing winnerUserId' }, { status: 400 });
      const myMsgsConfirm = await base44.entities.UserMessage.filter({ user_id: user.id, date_key: dateKey }, '-created_date', 500);
      const hasMatchConfirm = myMsgsConfirm.some(m => {
        if (!m.action_json) return false;
        try { const a = JSON.parse(m.action_json); return a.type === 'loserAccept' && a.winnerUserId === payloadWinnerUserId; } catch { return false; }
      });
      if (!hasMatchConfirm) return Response.json({ error: 'Forbidden: no matching challenge found' }, { status: 403 });
      const winnerUserId = payloadWinnerUserId;

      // Résoudre nom + photo du gagnant (pour les messages de refus)
      const winnerProfilesInfo = await base44.asServiceRole.entities.Profile.filter({ user_id: winnerUserId });
      const winnerName = winnerProfilesInfo[0]?.display_name || 'Date';
      const winnerPhoto = winnerProfilesInfo[0]?.photo_url || '';

      // ÉTAPE 2: Lock via DateLock (CAS atomique sur `locked`).
      // Le lock {dateKey}_{winnerUserId} survit à l'annulation (reason mise à jour).
      const threadKey = computeThreadKey(dateKey, user.id, winnerUserId);
      const lockResult = await acquireOrVerifyLock(base44, dateKey, winnerUserId, 'date_confirmed', threadKey);
      lock = lockResult.lock;

      if (!lockResult.acquired) {
        // Lock rejeté — le gagnant a déjà un date (ou a annulé un date confirmé).
        // Addition #3: clôture du fil → no_match (clos pour la journée, aucun bouton restant).
        // stale_closed: true — le gagnant a un date ailleurs ; quand il est libéré,
        // resumeSuspendedInteractions notifie le perdant qu'il est à nouveau dispo.
        transitions.push(threadSnapshot(await transitionThreadState(base44, threadKey, 'no_match', { stale_closed: true })));
        // Addition #4: wording intemporel — ne référence jamais un état changeant.
        await base44.entities.UserMessage.create({
          user_id: user.id, date_key: dateKey, sender: 'Système',
          text: msgWinnerUnavailable(winnerName),
          is_system: true, profile_name: winnerName, profile_id: String(winnerUserId),
          profile_photo: winnerPhoto, thread_key: winnerName, display_time: displayTime,
        });
        return Response.json({ blocked: true, reason: lockResult.lock?.reason || 'winner_already_has_date', lock, transitions });
      }

      // Acquérir aussi le lock du perdant (caller) — les deux parties deviennent indisponibles.
      // Si le perdant a déjà un date, libérer le lock du gagnant et refuser.
      const loserLockResult = await acquireOrVerifyLock(base44, dateKey, user.id, 'date_confirmed', threadKey);
      if (!loserLockResult.acquired) {
        // Ne libérer le lock du gagnant que si on l'a acquis dans cet appel (pas s'il était déjà posé)
        if (!lockResult.alreadyHeld) {
          await releaseLock(base44, dateKey, winnerUserId);
        }
        lock = loserLockResult.lock;
        transitions.push(threadSnapshot(await transitionThreadState(base44, threadKey, 'no_match', { stale_closed: true })));
        await base44.entities.UserMessage.create({
          user_id: user.id, date_key: dateKey, sender: 'Système',
          text: msgLoserAlreadyHasDate(),
          is_system: true, profile_name: winnerName, profile_id: String(winnerUserId),
          profile_photo: winnerPhoto, thread_key: winnerName, display_time: displayTime,
        });
        return Response.json({ blocked: true, reason: loserLockResult.lock?.reason || 'loser_already_has_date', lock, transitions });
      }

      // ── Lock gagné — procéder avec la confirmation ──
      // Shadow: écrire les flags existants (has_accepted_date, accepted_date_details) pour la compat.
      // Locks déjà acquis séquentiellement ci-dessus (lock winner puis lock loser) ;
      // les flags et écritures ci-dessous sont post-lock, indépendants entre eux.
      const lockDetails = JSON.stringify({ profileId: String(user.id), profileName: loserName, place, confirmedAt: new Date().toISOString() });
      // Lecture nécessaire pour décider update vs create du session
      const winnerSessionsPre = await base44.asServiceRole.entities.UserSession.filter({ user_id: winnerUserId, date_key: dateKey });
      // Transition d'abord (authoritaire) — si elle échoue, rien d'autre n'écrit, pas de faux succès.
      const transition = await transitionThreadState(base44, computeThreadKey(dateKey, user.id, winnerUserId), 'accepted', {
        place_json: JSON.stringify(normalizePlace(place, '', '')),
      });
      transitions.push(threadSnapshot(transition));
      // Écritures restantes (post-transition) — parallélisées
      const [, , confirmMessage] = await Promise.all([
        // Write 1: shadow session (update ou create selon existence)
        winnerSessionsPre[0]
          ? base44.asServiceRole.entities.UserSession.update(winnerSessionsPre[0].id, {
              has_accepted_date: true, accepted_date_details: lockDetails,
            }).catch(e => console.error('Shadow has_accepted_date write failed:', e))
          : base44.asServiceRole.entities.UserSession.create({
              user_id: winnerUserId, date_key: dateKey, has_accepted_date: true, accepted_date_details: lockDetails,
            }).catch(e => console.error('Shadow session create failed:', e)),
        // Write 2: profile accepted_date_key
        winnerProfilesInfo[0]
          ? base44.asServiceRole.entities.Profile.update(winnerProfilesInfo[0].id, { accepted_date_key: dateKey })
          : Promise.resolve(),
        // Write 3: message de confirmation au gagnant
        base44.asServiceRole.entities.UserMessage.create({
          user_id: winnerUserId, date_key: dateKey, sender: loserName,
          text: msgDateConfirmed(place),
          is_system: true, profile_name: loserName, profile_id: String(user.id),
          profile_photo: myPhoto, thread_key: loserName, display_time: displayTime,
        }),
        // Write 4: nettoyer les marqueurs challenged_profiles
        cleanChallengeMarkers(base44, user.id, winnerUserId, dateKey),
      ]);
      notifyMessagePush(base44, { message: confirmMessage, fromUserId: user.id, override: PUSH.dateConfirmed(loserName) });

      // Nettoyer les propositions de lieu périmées : le gagnant et le perdant
      // viennent d'être verrouillés. S'ils avaient proposé un lieu à d'autres
      // personnes (en attente de réponse), ces propositions sont désormais closes.
      await Promise.all([
        suspendOtherInteractions(base44, dateKey, user.id, threadKey, displayTime),
        suspendOtherInteractions(base44, dateKey, winnerUserId, threadKey, displayTime),
      ]).catch(e => console.error('suspendOtherInteractions failed:', e));
    } else if (type === 'notifyChallengeLost') {
      // Autorisé caller = LE GAGNANT défié (notifie le challenger qu'il a perdu). Aucun winnerUserId trusté.
      // Le challenger reçoit un message immédiat lui disant qu'il a perdu
      // Résoudre la photo (lecture) avant de paralléliser les écritures
      const counterpartPhoto = await resolveCounterpartPhoto(senderProfile);
      // Écritures indépendantes (UserMessage, UserSession, DateThread) — parallélisées
      const transitionPromise = transitionThreadState(base44, computeThreadKey(dateKey, user.id, recipientUserId), 'ppc_resolved', {
        winner_user_id: user.id,
      });
      const [lostMessage, , transition] = await Promise.all([
        base44.asServiceRole.entities.UserMessage.create({
          user_id: recipientUserId,
          date_key: dateKey,
          sender: senderName,
          text: msgChallengeLost(senderName),
          is_system: true,
          profile_name: senderName,
          profile_id: String(senderProfile?.user_id || ''),
          profile_photo: counterpartPhoto,
          thread_key: senderName,
          timer_start_time: Date.now(),
          display_time: displayTime,
        }),
        cleanChallengeMarkers(base44, user.id, recipientUserId, dateKey),
        transitionPromise,
      ]);
      transitions.push(threadSnapshot(transition));
      notifyMessagePush(base44, { message: lostMessage, fromUserId: user.id, override: PUSH.challengeLost(senderName) });
    } else if (type === 'notifyWinnerRefused') {
      // Autorisé caller = LE PERDANT (refuse le lieu). winnerUserId = opponent, validé contre match réel.
      if (!payloadWinnerUserId) return Response.json({ error: 'Missing winnerUserId' }, { status: 400 });
      const myMsgsRefused = await base44.entities.UserMessage.filter({ user_id: user.id, date_key: dateKey }, '-created_date', 500);
      const hasMatchRefused = myMsgsRefused.some(m => {
        if (!m.action_json) return false;
        try { const a = JSON.parse(m.action_json); return a.type === 'loserAccept' && a.winnerUserId === payloadWinnerUserId; } catch { return false; }
      });
      if (!hasMatchRefused) return Response.json({ error: 'Forbidden: no matching challenge found' }, { status: 403 });
      const winnerUserId = payloadWinnerUserId;

      const reasons = Array.isArray(reasonsParam) ? reasonsParam : [];
      const hasPersonal = reasons.includes('personal');

      // Seules les raisons personnelles ferment définitivement la pair.
      // Refus lieu/nourriture (Cas A) → le gagnant peut re-proposer sans limite.
      const isFinal = hasPersonal;
      finalRefusal = isFinal;

      if (isFinal) {
        // ── Refus DÉFINITIF (raison personnelle uniquement) ──
        // Comportement validé : "Pas de match", pair fermé, personne bloqué.
        // Lectures indépendantes (UserSession + Profile des deux côtés) — parallélisées
        const [refuserSessions, refuserProfiles, winnerSessionsRefuse, winnerProfilesRefuse] = await Promise.all([
          base44.entities.UserSession.filter({ user_id: user.id, date_key: dateKey }),
          base44.entities.Profile.filter({ user_id: user.id }),
          base44.asServiceRole.entities.UserSession.filter({ user_id: winnerUserId, date_key: dateKey }),
          base44.asServiceRole.entities.Profile.filter({ user_id: winnerUserId }),
        ]);
        // Écritures indépendantes (UserMessage, UserSession, Profile, DateThread) — parallélisées
        const transitionPromise = transitionThreadState(base44, computeThreadKey(dateKey, user.id, winnerUserId), 'no_match', {
          refusal_reasons: JSON.stringify(reasons),
        });
        const [finalRefusalMessage, , , , , , transition] = await Promise.all([
          // Write 1: message au gagnant
          base44.asServiceRole.entities.UserMessage.create({
            user_id: winnerUserId,
            date_key: dateKey,
            sender: loserName,
            text: msgPlaceRefusedFinal(loserName, reasons),
            is_system: true,
            profile_name: loserName,
            profile_id: String(user.id),
            profile_photo: myPhoto,
            thread_key: loserName,
            display_time: displayTime,
          }),
          // Write 2: reset refuser session
          refuserSessions[0]
            ? base44.entities.UserSession.update(refuserSessions[0].id, { has_accepted_date: false, accepted_date_details: null })
            : Promise.resolve(),
          // Write 3: reset refuser profile
          refuserProfiles[0]
            ? base44.entities.Profile.update(refuserProfiles[0].id, { accepted_date_key: null })
            : Promise.resolve(),
          // Write 4: reset winner session
          winnerSessionsRefuse[0]
            ? base44.asServiceRole.entities.UserSession.update(winnerSessionsRefuse[0].id, { has_accepted_date: false, accepted_date_details: null })
            : Promise.resolve(),
          // Write 5: reset winner profile
          winnerProfilesRefuse[0]
            ? base44.asServiceRole.entities.Profile.update(winnerProfilesRefuse[0].id, { accepted_date_key: null })
            : Promise.resolve(),
          // Write 6: marquer la paire comme bloquée (refus personnel) — keep marker as 'personal_refusal'
          markPersonalRefusalLockout(base44, user.id, winnerUserId, dateKey),
          // Write 7: transition DateThread → no_match
          transitionPromise,
        ]);
        transitions.push(threadSnapshot(transition));

        notifyMessagePush(base44, { message: finalRefusalMessage, fromUserId: user.id, override: PUSH.placeRefused(loserName, true) });

        // Refus définitif → les deux parties sont libérées (personne bloqué).
        // Libérer les locks + reprendre leurs interactions suspendues.
        await Promise.all([
          deleteLock(base44, dateKey, user.id),
          deleteLock(base44, dateKey, winnerUserId),
          resumeSuspendedInteractions(base44, dateKey, user.id, displayTime),
          resumeSuspendedInteractions(base44, dateKey, winnerUserId, displayTime),
        ]);
      } else {
        // ── Cas A : refus NON définitif (lieu et/ou nourriture, pas de raison personnelle) ──
        // La pair reste OUVERTE. Le gagnant peut re-proposer un autre lieu ou annuler.
        // AUCUN changement de flags (la proposition ne bloque jamais).
        const loserProfiles = await base44.entities.Profile.filter({ user_id: user.id });
        const loserProfileData = loserProfiles[0] ? {
          id: loserProfiles[0].id,
          user_id: user.id,
          name: loserProfiles[0].display_name || loserName,
        } : { id: '', user_id: user.id, name: loserName };

        // Écritures indépendantes (UserMessage + DateThread) — parallélisées
        const transitionPromise = transitionThreadState(base44, computeThreadKey(dateKey, user.id, winnerUserId), 'place_refused', {
          refusal_reasons: JSON.stringify(reasons),
        });
        const [nonFinalRefusalMessage, transition] = await Promise.all([
          base44.asServiceRole.entities.UserMessage.create({
            user_id: winnerUserId,
            date_key: dateKey,
            sender: loserName,
            text: msgPlaceRefusedNonFinal(loserName, reasons),
            is_system: true,
            profile_name: loserName,
            profile_id: String(user.id),
            profile_photo: myPhoto,
            thread_key: loserName,
            action_json: JSON.stringify({
              type: 'refusalWithReasons',
              reasons,
              loserProfile: loserProfileData,
              winnerUserId,
            }),
            display_time: displayTime,
          }),
          transitionPromise,
        ]);
        transitions.push(threadSnapshot(transition));
        notifyMessagePush(base44, { message: nonFinalRefusalMessage, fromUserId: user.id, override: PUSH.placeRefused(loserName, false) });
      }
    } else if (type === 'resolveRps') {
      // ── Résolution PPC côté serveur (incrément 1a) ──
      // Identité du joueur = auth.me() — JAMAIS fournie par le client.
      // Entrée : { opponentUserId, playerChoice, opponentChoice, dateKey }
      // Le champ opponentChoice du payload est IGNORÉ (point 9) : il continue de circuler pour ne
      // pas casser le client publié, mais le verdict ne repose que sur playerChoice (payload du
      // joueur authentifié) + la main relue en base. Les 4 types legacy restent inchangés.
      const RPS_CHOICES = ['✊', '✋', '✌️'];
      if (!payloadOpponentUserId) return Response.json({ error: 'Missing opponentUserId' }, { status: 400 });
      if (payloadOpponentUserId === user.id) {
        return Response.json({ error: 'opponentUserId must differ from the authenticated user' }, { status: 400 });
      }
      if (!RPS_CHOICES.includes(payloadPlayerChoice)) {
        return Response.json({ error: 'Invalid choice (expected ✊, ✋ or ✌️)' }, { status: 400 });
      }

      const rpsThreadKey = computeThreadKey(dateKey, user.id, payloadOpponentUserId);
      const rpsThread = await findThread(base44, rpsThreadKey);
      if (!rpsThread) {
        return Response.json({ success: false, error: 'THREAD_NOT_FOUND', code: 'THREAD_NOT_FOUND', threadKey: rpsThreadKey }, { status: 409 });
      }

      // Main de l'adversaire = RELECTURE SERVEUR : le message de défi écrit par deliverChallenge
      // dans la boîte du joueur authentifié (celui qui répond au défi), identifié par
      // profile_id = user_id du challengeur. Aucun repli sur le payload : absent ou illisible → 409.
      const rpsChallengeMsgs = await base44.asServiceRole.entities.UserMessage.filter(
        { user_id: user.id, date_key: dateKey }, '-created_date', 500
      );
      const rpsChallengeMsg = rpsChallengeMsgs.find(m => {
        if (String(m.profile_id || '') !== String(payloadOpponentUserId)) return false;
        try { return JSON.parse(m.action_json || 'null')?.type === 'incomingChallenge'; } catch { return false; }
      });
      let rpsOpponentChoice = null;
      if (rpsChallengeMsg?.action_json) {
        try { rpsOpponentChoice = JSON.parse(rpsChallengeMsg.action_json)?.opponentChoice ?? null; } catch { rpsOpponentChoice = null; }
      }
      if (typeof rpsOpponentChoice !== 'string' || !RPS_CHOICES.includes(rpsOpponentChoice)) {
        return Response.json({ success: false, error: 'OPPONENT_CHOICE_NOT_FOUND', code: 'OPPONENT_CHOICE_NOT_FOUND', threadKey: rpsThreadKey }, { status: 409 });
      }

      // Verdict brut côté joueur — règles identiques au frontend (RpsFlow:12-16)
      const rpsBeats = { '✊': '✌️', '✋': '✊', '✌️': '✋' };
      const rpsVerdict = payloadPlayerChoice === rpsOpponentChoice
        ? 'draw'
        : (rpsBeats[payloadPlayerChoice] === rpsOpponentChoice ? 'win' : 'lose');

      // Gagnant : verdict brut ; en cas d'égalité, le challengeur (règle de l'app)
      let rpsWinnerUserId;
      if (rpsVerdict === 'win') {
        rpsWinnerUserId = user.id;
      } else if (rpsVerdict === 'lose') {
        rpsWinnerUserId = payloadOpponentUserId;
      } else {
        const rpsChallenger = rpsThread.challenger_user_id;
        if (rpsChallenger !== user.id && rpsChallenger !== payloadOpponentUserId) {
          return Response.json({ success: false, error: 'UNKNOWN_CHALLENGER', code: 'UNKNOWN_CHALLENGER', threadKey: rpsThreadKey }, { status: 409 });
        }
        rpsWinnerUserId = rpsChallenger;
      }

      // Fil déjà résolu avec le même gagnant → SEULE la transition est sautée. Les écritures
      // (messages append-once + nettoyage des marqueurs) sont rejouées plus bas : elles sont
      // idempotentes par construction, donc un retry auto-répare un appel mort en cours de route
      // sans jamais créer de doublon ni re-transitionner le fil.
      const rpsAlreadyResolved = rpsThread.state === 'ppc_resolved';
      if (rpsAlreadyResolved && rpsThread.winner_user_id !== rpsWinnerUserId) {
        return Response.json({ success: false, error: 'ALREADY_RESOLVED_OTHER_WINNER', code: 'ALREADY_RESOLVED_OTHER_WINNER', state: threadSnapshot(rpsThread) }, { status: 409 });
      }
      // Seul un fil en attente de challenge est résoluble — tout état terminal est un 409 explicite
      if (!rpsAlreadyResolved && rpsThread.state !== 'pending_challenge') {
        return Response.json({ success: false, error: 'UNEXPECTED_THREAD_STATE', code: 'UNEXPECTED_THREAD_STATE', state: threadSnapshot(rpsThread) }, { status: 409 });
      }

      // Profils des deux joueurs (noms, photos, loserProfile)
      const [rpsPlayerProfiles, rpsOpponentProfiles] = await Promise.all([
        base44.asServiceRole.entities.Profile.filter({ user_id: user.id }),
        base44.asServiceRole.entities.Profile.filter({ user_id: payloadOpponentUserId }),
      ]);
      const rpsPlayerProfile = rpsPlayerProfiles[0];
      const rpsOpponentProfile = rpsOpponentProfiles[0];
      if (!rpsPlayerProfile || !rpsOpponentProfile) {
        return Response.json({ success: false, error: 'PROFILE_NOT_FOUND', code: 'PROFILE_NOT_FOUND' }, { status: 409 });
      }
      const rpsPlayerLean = { id: rpsPlayerProfile.id, user_id: user.id, name: rpsPlayerProfile.display_name || 'Quelqu\'un' };
      const rpsOpponentLean = { id: rpsOpponentProfile.id, user_id: payloadOpponentUserId, name: rpsOpponentProfile.display_name || 'Quelqu\'un' };
      const rpsPlayerWon = rpsWinnerUserId === user.id;
      const rpsPlayerPhoto = rpsPlayerProfile.photo_url || '';
      const rpsOpponentPhoto = rpsOpponentProfile.photo_url || '';
      const rpsNow = Date.now();

      // 1. Transition autoritaire du fil → ppc_resolved (garde de version).
      //    Sautée uniquement si le fil est déjà résolu (mode réparation).
      let rpsTransitionSnapshot;
      if (rpsAlreadyResolved) {
        rpsTransitionSnapshot = threadSnapshot(rpsThread);
      } else {
        const rpsTransition = await transitionThreadState(base44, rpsThreadKey, 'ppc_resolved', {
          winner_user_id: rpsWinnerUserId,
          loser_profile_id: String(rpsPlayerWon ? rpsOpponentLean.id : rpsPlayerLean.id),
        });
        rpsTransitionSnapshot = threadSnapshot(rpsTransition);
        transitions.push(rpsTransitionSnapshot);
      }

      // 2. Messages des deux boîtes, via append-once (rejoué à chaque appel : ne crée que les
      //    messages manquants, jamais de doublon).
      //    Formes identiques aux écritures legacy : 🏆 winnerChoosePlace (notifyWinner:61-74)
      //    et 😔 perdant (notifyChallengeLost:305-317) ; la ligne neutre du joueur reprend
      //    la forme du message client historique (ToDay4:321 pushMessage).
      const rpsBoxes = [
        { ownerUserId: user.id, counterpart: rpsOpponentLean, counterpartPhoto: rpsOpponentPhoto, won: rpsPlayerWon, withResult: true },
        { ownerUserId: rpsOpponentLean.user_id, counterpart: rpsPlayerLean, counterpartPhoto: rpsPlayerPhoto, won: !rpsPlayerWon, withResult: false },
      ];
      const rpsMessages = [];
      // Message d'issue réellement créé dans la boîte de l'adversaire (source du push).
      let opponentPushMessage = null;
      for (const rpsBox of rpsBoxes) {
        if (rpsBox.withResult) {
          const rpsResultWrite = await appendMessageOnce(base44, {
            user_id: rpsBox.ownerUserId,
            date_key: dateKey,
            sender: 'Système',
            text: msgRpsResult(rpsBox.counterpart.name, payloadPlayerChoice, rpsOpponentChoice, rpsVerdict),
            is_system: true,
            profile_name: rpsBox.counterpart.name,
            profile_id: rpsBox.counterpart.user_id,
            thread_key: rpsBox.counterpart.name,
            display_time: displayTime,
          });
          rpsMessages.push({ user_id: rpsBox.ownerUserId, text: rpsResultWrite.message?.text || null, created: rpsResultWrite.created });
        }
        const rpsOutcomeWrite = await appendMessageOnce(base44, {
          user_id: rpsBox.ownerUserId,
          date_key: dateKey,
          sender: rpsBox.counterpart.name,
          text: rpsBox.won ? msgChallengeWin(rpsBox.counterpart.name) : msgChallengeLost(rpsBox.counterpart.name),
          is_system: !rpsBox.won,
          profile_name: rpsBox.counterpart.name,
          profile_id: rpsBox.counterpart.user_id,
          thread_key: rpsBox.counterpart.name,
          ...(rpsBox.won
            ? { action_json: JSON.stringify({ type: 'winnerChoosePlace', loserProfile: { id: rpsBox.counterpart.id, user_id: rpsBox.counterpart.user_id, name: rpsBox.counterpart.name } }) }
            : {}),
          profile_photo: rpsBox.counterpartPhoto,
          timer_start_time: rpsNow,
          display_time: displayTime,
        });
        rpsMessages.push({ user_id: rpsBox.ownerUserId, text: rpsOutcomeWrite.message?.text || null, created: rpsOutcomeWrite.created });
        // Idempotence : seul un message réellement créé peut déclencher un push.
        if (rpsOutcomeWrite.created && rpsBox.ownerUserId === payloadOpponentUserId) {
          opponentPushMessage = rpsOutcomeWrite.message;
        }
      }

      // 3. Nettoyage des marqueurs challenged_profiles des deux côtés
      await cleanChallengeMarkers(base44, user.id, payloadOpponentUserId, dateKey);

      // 4. Push à l'adversaire uniquement (jamais au joueur qui vient de jouer).
      //    Gated sur la création réelle du message → un rejeu (réparation) n'envoie rien.
      if (opponentPushMessage) {
        notifyMessagePush(base44, {
          message: opponentPushMessage,
          fromUserId: user.id,
          override: rpsPlayerWon ? PUSH.challengeLost(rpsPlayerLean.name) : PUSH.challengeWon(rpsPlayerLean.name),
        });
      }

      return Response.json({
        success: true,
        result: rpsVerdict,
        winnerUserId: rpsWinnerUserId,
        idempotent: rpsAlreadyResolved,
        transition: rpsTransitionSnapshot,
        messages: rpsMessages,
      });
    } else {
      // Type inconnu — ne pas silencieusement réussir (anti-échec-silencieux)
      if (!type) return Response.json({ error: 'Missing type' }, { status: 400 });
      return Response.json({ error: `Unknown type: ${type}` }, { status: 400 });
    }

    return Response.json({ success: true, transitions, lock });
  } catch (error) {
    return Response.json({ success: false, error: error.message, code: error.code || 'WRITE_FAILED', transitions, lock, actualState: error.state ?? null }, { status: error.status || 500 });
  }
});