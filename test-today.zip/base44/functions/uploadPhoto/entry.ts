import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

const CLOUD_NAME = Deno.env.get('CLOUDINARY_CLOUD_NAME');
const API_KEY = Deno.env.get('CLOUDINARY_API_KEY');
const API_SECRET = Deno.env.get('CLOUDINARY_API_SECRET');

async function sha1(message) {
  const encoder = new TextEncoder();
  const data = encoder.encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-1', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { base64, slot = 1 } = await req.json();
    if (!base64) {
      return Response.json({ error: 'base64 required' }, { status: 400 });
    }

    // Sécurité : le champ user_id envoyé par le client est totalement ignoré.
    // L'attribution de l'upload (public_id Cloudinary), du quota et de l'historique
    // de photos se fait uniquement sur l'utilisateur authentifié du contexte serveur.
    const userId = user.id;

    // Barrière serveur : refuser les images > 5 Mo
    const base64Data = base64.includes(',') ? base64.split(',')[1] : base64;
    const approxBytes = Math.ceil((base64Data.length * 3) / 4);
    const MAX_BYTES = 5 * 1024 * 1024;
    if (approxBytes > MAX_BYTES) {
      return Response.json({ error: `Image trop lourde (${(approxBytes / 1024 / 1024).toFixed(1)} Mo, max 5 Mo)` }, { status: 400 });
    }

    // Quota global : 3 changements de photos tous les 3 jours, tous slots confondus
    // Un premier upload sur un slot vide ne compte pas comme changement
    const WINDOW_MS = 3 * 24 * 60 * 60 * 1000;
    const MAX_CHANGES = 3;
    const slotField = `last_photo_update_${slot}`;
    const profiles = await base44.entities.Profile.filter({ user_id: userId });
    const existingProfile = profiles[0];
    const now = Date.now();
    const slotHasPhoto = slot === 1 ? !!existingProfile?.photo_url : slot === 2 ? !!existingProfile?.photo_url_2 : !!existingProfile?.photo_url_3;
    const isFirstUpload = !slotHasPhoto;
    const history = Array.isArray(existingProfile?.photo_change_history) ? existingProfile.photo_change_history : [];
    const recent = history.map(ts => new Date(ts).getTime()).filter(t => now - t < WINDOW_MS);
    if (!isFirstUpload && recent.length >= MAX_CHANGES) {
      const oldest = Math.min(...recent);
      return Response.json({
        error: 'cooldown',
        remaining_ms: WINDOW_MS - (now - oldest)
      }, { status: 403 });
    }

    const timestamp = Math.floor(Date.now() / 1000);
    const publicId = `today_profiles/${userId}_${timestamp}`;
    // Cloudinary requires params sorted alphabetically before the secret
    const paramsToSign = `public_id=${publicId}&timestamp=${timestamp}`;
    const signature = await sha1(paramsToSign + API_SECRET);

    const formData = new FormData();
    // Si base64 ne commence pas par 'data:', on l'ajoute
    const dataUrl = base64.startsWith('data:') ? base64 : `data:image/jpeg;base64,${base64}`;
    formData.append('file', dataUrl);
    formData.append('public_id', publicId);
    formData.append('timestamp', timestamp.toString());
    formData.append('api_key', API_KEY);
    formData.append('signature', signature);

    const uploadRes = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!uploadRes.ok) {
      const err = await uploadRes.text();
      return Response.json({ error: `Upload failed: ${err}` }, { status: 500 });
    }

    const data = await uploadRes.json();

    // Vérifier que l'URL retournée par Cloudinary est réellement accessible (HEAD).
    // Si elle ne répond pas 2xx, on rejette la sauvegarde — aucun historique n'est écrit.
    const secureUrl = data.secure_url;
    if (!secureUrl) {
      console.error('[uploadPhoto] Cloudinary returned no secure_url', JSON.stringify(data));
      return Response.json({ error: 'Upload failed: no URL returned' }, { status: 502 });
    }
    try {
      const headRes = await fetch(secureUrl, { method: 'HEAD', redirect: 'manual' });
      if (!headRes.ok && headRes.status !== 0) {
        console.error(`[uploadPhoto] HEAD check failed for ${secureUrl} — status ${headRes.status}`);
        return Response.json({ error: `Photo introuvable après upload (HTTP ${headRes.status}). Réessaie.` }, { status: 502 });
      }
    } catch (headErr) {
      // Certains serveurs refusent HEAD → fallback GET sans corps
      try {
        const getRes = await fetch(secureUrl, { method: 'GET', redirect: 'manual' });
        if (!getRes.ok && getRes.status !== 0) {
          console.error(`[uploadPhoto] GET fallback failed for ${secureUrl} — status ${getRes.status}`);
          return Response.json({ error: `Photo introuvable après upload (HTTP ${getRes.status}). Réessaie.` }, { status: 502 });
        }
      } catch (getErr) {
        console.error(`[uploadPhoto] URL verification unreachable for ${secureUrl}:`, getErr?.message || getErr);
        return Response.json({ error: 'Impossible de vérifier la photo après upload. Réessaie.' }, { status: 502 });
      }
    }

    // Enregistrer le changement dans l'historique global (quota 3 / 3 jours) + slot pour affichage
    // Un premier upload sur un slot vide n'ajoute pas d'entrée dans l'historique
    if (existingProfile) {
      // Si la photo 1 change (slot 1), remettre photo1_verified à false
      const photo1Reset = slot === 1 ? { photo1_verified: false } : {};
      if (isFirstUpload) {
        await base44.entities.Profile.update(existingProfile.id, {
          [slotField]: new Date().toISOString(),
          ...photo1Reset,
        });
      } else {
        const newHistory = [...recent, now].slice(-MAX_CHANGES).map(t => new Date(t).toISOString());
        await base44.entities.Profile.update(existingProfile.id, {
          [slotField]: new Date().toISOString(),
          photo_change_history: newHistory,
          ...photo1Reset,
        });
      }
    }
    return Response.json({ url: secureUrl });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});