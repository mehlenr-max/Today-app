import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { threadSnapshot, transitionThreadState, computeThreadKey } from '../../shared/datethread.ts';
import { msgPlaceChanged, msgPlaceChangedSelf } from '../../shared/messages.ts';
import { notifyMessagePush, PUSH } from '../../shared/push.ts';

// Changement de lieu d'un date déjà confirmé.
// Le current user (proposer) propose un nouveau lieu à recipientUserId (l'autre personne).
// - Supprime les anciens messages "Date confirmé" des deux côtés
// - Supprime les anciennes propositions (loserAccept) côté destinataire
// - Envoie une nouvelle proposition (loserAccept + isPlaceChange) au destinataire
// La logique de notification est identique à la proposition initiale (deliverResult notifyLoser).
// BLOCAGE : le proposant ET le destinataire RESTENT bloqués pendant l'attente de la réponse
// (locks date_confirmed, flags de session et accepted_date_key conservés). Proposer un
// changement de lieu ne libère jamais personne — sinon ce serait un contournement des règles.
Deno.serve(async (req) => {
  const transitions = [];
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { recipientUserId, senderProfile, place, time, address, dateKey } = await req.json();
    if (!recipientUserId) return Response.json({ error: 'Missing recipientUserId' }, { status: 400 });

    const displayTime = new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' });
    const senderName = senderProfile?.name || 'Quelqu\'un';
    const myProfiles = await base44.entities.Profile.filter({ user_id: user.id });
    const myPhoto = myProfiles[0]?.photo_url || '';

    // 1. Fermer (append-only) les anciens "Date confirmé" + winnerChoosePlace + refusalWithReasons
    //    du proposer (current user) avec le destinataire — pour que le proposer voie "En attente"
    //    et non un vieux bouton "Choisir le lieu" après un changement de lieu.
    const myMsgs = await base44.entities.UserMessage.filter({ user_id: user.id, date_key: dateKey }, '-created_date', 500);
    await Promise.all(
      myMsgs
        .filter(m => m.profile_id === recipientUserId && (
          m.text?.includes('Date confirmé') ||
          m.action_json?.includes('winnerChoosePlace') ||
          m.action_json?.includes('refusalWithReasons')
        ))
        .map(m => base44.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) }).catch(e => console.error('changeDatePlace: self close failed:', e)))
    );

    // 2. Fermer (append-only) les anciens "Date confirmé" + propositions (loserAccept) + refus
    //    du destinataire pour que la nouvelle proposition soit la seule visible.
    const otherMsgs = await base44.asServiceRole.entities.UserMessage.filter({ user_id: recipientUserId, date_key: dateKey }, '-created_date', 500);
    await Promise.all(
      otherMsgs
        .filter(m => m.profile_name === senderName && (
          m.text?.includes('Date confirmé') ||
          m.text?.includes('Tu as refusé') ||
          m.text?.includes('a changé le lieu') ||
          m.text?.includes('te propose un lieu') ||
          m.action_json?.includes('loserAccept') ||
          m.action_json?.includes('refusalWithReasons')
        ))
        .map(m => base44.asServiceRole.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) }).catch(e => console.error('changeDatePlace: cross-user close failed:', e)))
    );

    // 3. Récupérer le nom du destinataire pour l'action
    const recipientProfiles = await base44.asServiceRole.entities.Profile.filter({ user_id: recipientUserId });
    const recipientName = recipientProfiles[0]?.display_name || 'Quelqu\'un';

    // 4. Aucune libération : le date reste accepté pendant toute la renégociation du lieu.
    // Les locks date_confirmed, les flags de session (has_accepted_date) et les
    // accepted_date_key des DEUX parties sont conservés ; leurs autres interactions
    // restent suspendues. Le blocage ne se lève que par une acceptation du nouveau lieu
    // (les deux restent bloqués) ou par un refus pour raisons personnelles du destinataire
    // (deliverResult notifyWinnerRefused, branche isFinal → libération des deux).
    // Cela empêche de se libérer en proposant un changement de lieu.

    // 5. Envoyer la nouvelle proposition au destinataire (même logique que notifyLoser + isPlaceChange)
    const placeChangeMessage = await base44.asServiceRole.entities.UserMessage.create({
      user_id: recipientUserId,
      date_key: dateKey,
      sender: senderName,
      text: msgPlaceChanged(senderName, place, time, address),
      is_system: false,
      profile_name: senderName,
      profile_id: String(user.id),
      thread_key: senderName,
      action_json: JSON.stringify({
        type: 'loserAccept',
        place: `${place} à ${time}${address ? ` · ${address}` : ''}`,
        profileId: senderProfile?.id,
        profileName: senderName,
        winnerUserId: user.id,
        loserName: recipientName,
        isPlaceChange: true,
      }),
      profile_photo: myPhoto,
      timer_start_time: Date.now(),
      display_time: displayTime,
    });

    notifyMessagePush(base44, {
      message: placeChangeMessage,
      fromUserId: user.id,
      override: PUSH.placeChanged(senderName),
    });

    // 6. Tracer le changement de lieu côté expéditeur (gagnant)
    // timer_start_time obligatoire : sans lui, getTimeRemaining retourne null côté
    // proposant et l'auto-annulation à l'expiration du chrono ne se déclenche jamais.
    await base44.entities.UserMessage.create({
      user_id: user.id,
      date_key: dateKey,
      sender: 'Vous',
      text: msgPlaceChangedSelf(place, time, address, recipientName),
      is_system: true,
      profile_name: recipientName,
      profile_id: recipientUserId,
      thread_key: recipientName,
      timer_start_time: Date.now(),
      display_time: displayTime,
    });

    // SHADOW: accepted → place_proposed (retour à la routine pré-acceptation)
    transitions.push(threadSnapshot(await transitionThreadState(base44, computeThreadKey(dateKey, user.id, recipientUserId), 'place_proposed', {
      place_json: JSON.stringify({ name: place, address: address || '', time }),
    })));

    return Response.json({ success: true, transitions });
  } catch (error) {
    return Response.json({ success: false, error: error.message, code: error.code || 'WRITE_FAILED', transitions, actualState: error.state ?? null }, { status: error.status || 500 });
  }
});