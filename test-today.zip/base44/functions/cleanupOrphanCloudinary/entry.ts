import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Lists Cloudinary assets under today_profiles/ whose user_id no longer exists in Profile,
// and destroys them. Runs after cleanupOrphanProfiles in the hourly workflow.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Sécurité : purge réservée aux administrateurs (même garde que cleanupOrphanProfiles
    // et clearAcceptedDates). Aucun asset Cloudinary n'est listé ni supprimé avant ce contrôle.
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const svc = base44.asServiceRole;

    const CLOUD_NAME = Deno.env.get('CLOUDINARY_CLOUD_NAME');
    const API_KEY = Deno.env.get('CLOUDINARY_API_KEY');
    const API_SECRET = Deno.env.get('CLOUDINARY_API_SECRET');
    if (!CLOUD_NAME || !API_KEY || !API_SECRET) {
      return Response.json({ error: 'Cloudinary credentials not configured' }, { status: 500 });
    }
    const auth = btoa(`${API_KEY}:${API_SECRET}`);

    // 1) Collect all valid Profile user_ids (paginated)
    const validUserIds = new Set();
    const MAX_ITERATIONS = 10000;
    const PAGE_SIZE = 500;
    for (let iter = 0; iter < MAX_ITERATIONS; iter++) {
      const profiles = await svc.entities.Profile.list('created_date', PAGE_SIZE, iter * PAGE_SIZE, ['user_id']);
      if (!profiles || profiles.length === 0) break;
      profiles.forEach(p => { if (p.user_id) validUserIds.add(p.user_id); });
      if (profiles.length < PAGE_SIZE) break;
    }

    // 2) List all Cloudinary resources under today_profiles/ prefix (paginated via next_cursor)
    const orphanPublicIds = [];
    let cursor = null;
    let hasMore = true;
    while (hasMore) {
      let url = `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/resources/image/upload?prefix=today_profiles/&max_results=500&type=upload`;
      if (cursor) url += `&next_cursor=${cursor}`;
      const listRes = await fetch(url, { headers: { Authorization: `Basic ${auth}` } });
      if (!listRes.ok) {
        const errText = await listRes.text();
        return Response.json({ error: `Cloudinary list failed (${listRes.status}): ${errText}` }, { status: 500 });
      }
      const data = await listRes.json();
      const resources = data.resources || [];
      for (const r of resources) {
        // public_id format: today_profiles/${userId}_${timestamp}
        const match = r.public_id?.match(/^today_profiles\/([^_]+)_/);
        if (match) {
          const userId = match[1];
          if (!validUserIds.has(userId)) {
            orphanPublicIds.push(r.public_id);
          }
        }
      }
      if (data.next_cursor) {
        cursor = data.next_cursor;
      } else {
        hasMore = false;
      }
    }

    // 3) Batch delete orphaned resources (chunked — Cloudinary allows up to 100 public_ids per call)
    let deleted = 0;
    for (let i = 0; i < orphanPublicIds.length; i += 100) {
      const chunk = orphanPublicIds.slice(i, i + 100);
      try {
        const delRes = await fetch(
          `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/resources/image/upload`,
          {
            method: 'DELETE',
            headers: {
              Authorization: `Basic ${auth}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ public_ids: chunk }),
          }
        );
        if (delRes.ok) {
          const delData = await delRes.json();
          // Count actual deletions from the response
          const deletedMap = delData.deleted || {};
          deleted += Object.values(deletedMap).filter((v) => v === 'deleted').length;
        } else {
          console.error(`cleanupOrphanCloudinary: batch delete failed (${delRes.status})`);
        }
      } catch (e) {
        console.error('cleanupOrphanCloudinary: batch delete error:', e?.message || e);
      }
    }

    return Response.json({ success: true, deleted, totalOrphans: orphanPublicIds.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});