import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const MAX_REPORTS = 300;

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Accès réservé aux administrateurs' }, { status: 403 });
    }

    const svc = base44.asServiceRole;
    const res = await svc.entities.Report.list('-created_date', MAX_REPORTS);
    const reports = Array.isArray(res) ? res : (res?.items || []);

    // Un seul appel groupé pour les profils signalés (jamais un get par id)
    const profileIds = [...new Set(reports.map(r => r.reported_profile_id).filter(Boolean))];
    const byId = {};
    if (profileIds.length > 0) {
      const profiles = await svc.entities.Profile.filter({ id: { $in: profileIds } });
      (Array.isArray(profiles) ? profiles : []).forEach(p => { byId[p.id] = p; });
    }

    // Signalements en attente par profil — calculé côté serveur
    const pendingByProfile = {};
    reports.forEach(r => {
      if ((r.status || 'pending') === 'pending' && r.reported_profile_id) {
        pendingByProfile[r.reported_profile_id] = (pendingByProfile[r.reported_profile_id] || 0) + 1;
      }
    });

    const enriched = reports.map(r => {
      const p = byId[r.reported_profile_id];
      return {
        id: r.id,
        pending_count: pendingByProfile[r.reported_profile_id] || 0,
        reason: r.reason,
        detail: r.detail || '',
        status: r.status || 'pending',
        created_date: r.created_date,
        reported_profile_id: r.reported_profile_id || '',
        reported_user_id: r.reported_user_id || '',
        profile: p ? {
          id: p.id,
          display_name: p.display_name || '',
          photo_url: p.photo_url || '',
          age: p.age || null,
          city: p.city || '',
          is_hidden: p.is_hidden === true,
          user_id: p.user_id || '',
        } : null,
      };
    });

    return Response.json({ reports: enriched });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}