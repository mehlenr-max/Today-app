import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Renvoie tous les profils (service role — contourne la RLS is_online)
// pour que les mini-photos s'affichent dans les onglets Messages et Jeux
// même quand le profil est hors-ligne.
// On ne renvoie que les champs d'affichage (pas personality_profile qui est lourd).
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const all = await base44.asServiceRole.entities.Profile.list('-last_online_date', 200);
    const lean = all
      .filter(p => p.user_id !== user.id)
      .map(p => ({
        id: p.id,
        user_id: p.user_id,
        display_name: p.display_name,
        age: p.age,
        gender: p.gender,
        city: p.city,
        photo_url: p.photo_url || '',
        photo_url_2: p.photo_url_2 || '',
        photo_url_3: p.photo_url_3 || '',
        time_slot: p.time_slot || '',
        five_words: p.five_words || '',
        quiz_phrase: p.quiz_phrase || '',
        astro_sign: p.astro_sign || '',
        astro_ascendant: p.astro_ascendant || '',
        education: p.education || '',
        job: p.job || '',
        height: p.height || null,
        is_vegetarian: !!p.is_vegetarian,
        own_physical_traits: p.own_physical_traits || [],
        own_personality_traits: p.own_personality_traits || [],
        personal_flaws: p.personal_flaws || [],
        desired_physical_traits: p.desired_physical_traits || [],
        last_online_date: p.last_online_date || null,
        is_online: !!p.is_online,
      }));

    return Response.json({ profiles: lean });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}