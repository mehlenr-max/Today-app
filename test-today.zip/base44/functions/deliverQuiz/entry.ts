import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { msgQuizProposal } from '../../shared/messages.ts';
import { notifyMessagePush } from '../../shared/push.ts';

// Envoie 5 questions de quiz à un profil cible (contourne la RLS en service role)
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { recipientUserId, questions, gameType, dateKey } = await req.json();
    if (!recipientUserId || !dateKey || !Array.isArray(questions) || questions.length === 0) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }
    const effectiveGameType = gameType || 'thisOrThat';

    // Récupérer le profil de l'expéditeur
    const myProfiles = await base44.entities.Profile.filter({ user_id: user.id });
    const myProfile = myProfiles[0];
    const askerName = myProfile?.display_name || user.full_name || 'Quelqu\'un';
    const displayTime = new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' });

    // Vérifier si le destinataire a bloqué l'expéditeur
    const recipientProfiles = await base44.asServiceRole.entities.Profile.filter({ user_id: recipientUserId });
    const recipientProfile = recipientProfiles[0];
    // Valider que le destinataire a un profil existant et actif (non masqué)
    if (!recipientProfile || recipientProfile.is_hidden) {
      return Response.json({ error: 'Recipient profile not available' }, { status: 404 });
    }
    if (recipientProfile?.blocked_profile_ids?.includes(String(myProfile?.id))) {
      return Response.json({ success: true, blocked: true });
    }

    // Vérifier le quota : 2 propositions par pair sur 30 jours glissants (quiz_proposed_map)
    // Format : { targetUserId: [ISO timestamp, ISO timestamp, ...] }
    const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
    let proposedMap = {};
    try { proposedMap = myProfile?.quiz_proposed_map ? JSON.parse(myProfile.quiz_proposed_map) : {}; } catch {}

    // Per-pair, per-game-type check : max 1 proposition per game type per 30 days
    // (2 games max per pair = 1 "This or That" + 1 "Je n'ai jamais")
    const targetData = proposedMap[recipientUserId];
    const targetGameTs = (!targetData || Array.isArray(targetData)) ? [] : (targetData[effectiveGameType] || []);
    const recentGameTs = targetGameTs.filter(ts => new Date(ts).getTime() > thirtyDaysAgo);
    if (recentGameTs.length >= 1) {
      return Response.json({ blocked: true, reason: 'already_sent', message: `Tu as déjà proposé ce jeu à ${recipientProfile?.display_name || 'cette personne'} ce mois-ci.` }, { status: 409 });
    }

    // ── Écriture AUTHORITAIRE du quota (quiz_proposed_map) AVANT l'envoi du message ──
    // Phase 5 fix : le quota doit être incrémenté avant l'envoi pour être fiable.
    // Si l'écriture échoue → erreur propagée (500), AUCUN message envoyé, aucun état modifié.
    if (!myProfile?.id) {
      return Response.json({ error: 'Sender profile not found — cannot enforce quota' }, { status: 500 });
    }
    const nowIso = new Date().toISOString();
    // Prune entries older than 30 days to avoid unbounded growth
    const cleanedMap = {};
    for (const [uid, data] of Object.entries(proposedMap)) {
      if (Array.isArray(data)) continue; // skip old format
      if (typeof data !== 'object' || data === null) continue;
      const cleanedTypes = {};
      for (const [gtype, timestamps] of Object.entries(data)) {
        if (Array.isArray(timestamps)) {
          const recent = timestamps.filter(ts => new Date(ts).getTime() > thirtyDaysAgo);
          if (recent.length > 0) cleanedTypes[gtype] = recent;
        }
      }
      if (Object.keys(cleanedTypes).length > 0) cleanedMap[uid] = cleanedTypes;
    }
    // Append new timestamp for this target + game type
    const existing = cleanedMap[recipientUserId] || {};
    const existingTs = Array.isArray(existing[effectiveGameType]) ? existing[effectiveGameType] : [];
    cleanedMap[recipientUserId] = { ...existing, [effectiveGameType]: [...existingTs, nowIso] };
    // Écriture autoritaire — pas de catch. Si elle échoue, l'erreur se propage au handler top-level.
    await base44.entities.Profile.update(myProfile.id, {
      quiz_proposed_map: JSON.stringify(cleanedMap)
    });

    // ── Envoi du message au destinataire ──
    // Si l'envoi échoue après l'incrément du quota, on compense en retirant le timestamp
    // qu'on vient d'ajouter (best-effort — documenté). L'erreur originale est propagée.
    try {
      const quizMessage = await base44.asServiceRole.entities.UserMessage.create({
        user_id: recipientUserId,
        date_key: dateKey,
        sender: askerName,
        text: msgQuizProposal(askerName),
        is_system: false,
        profile_name: askerName,
        profile_id: String(user.id),
        thread_key: askerName,
        action_json: JSON.stringify({
          type: 'quizQuestions',
          gameType: gameType || null,
          questions,
          askerUserId: user.id,
          askerName,
        }),
        profile_photo: myProfile?.photo_url || '',
        display_time: displayTime,
      });
      notifyMessagePush(base44, { message: quizMessage, fromUserId: user.id });
    } catch (sendErr) {
      // Compensation best-effort : retirer le timestamp qu'on vient d'ajouter au quota.
      // Si la compensation échoue aussi (double panne DB), l'utilisateur a consommé un quota
      // sans jeu envoyé — cas rare accepté. L'erreur originale est propagée au caller.
      try {
        const rbProfiles = await base44.entities.Profile.filter({ user_id: user.id });
        const rbProfile = rbProfiles[0];
        if (rbProfile?.quiz_proposed_map) {
          let rbMap = {};
          try { rbMap = JSON.parse(rbProfile.quiz_proposed_map); } catch {}
          if (rbMap[recipientUserId]?.[effectiveGameType]) {
            const tsList = rbMap[recipientUserId][effectiveGameType];
            const idx = tsList.indexOf(nowIso);
            if (idx >= 0) tsList.splice(idx, 1);
            if (tsList.length === 0) {
              delete rbMap[recipientUserId][effectiveGameType];
              if (Object.keys(rbMap[recipientUserId]).length === 0) delete rbMap[recipientUserId];
            }
            await base44.entities.Profile.update(rbProfile.id, {
              quiz_proposed_map: JSON.stringify(rbMap)
            });
          }
        }
      } catch (rollbackErr) {
        console.error('deliverQuiz: quota rollback failed (best-effort):', rollbackErr?.message || rollbackErr);
      }
      throw sendErr;
    }

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});