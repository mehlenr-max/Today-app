import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

function getParisDateKey() {
  const now = new Date();
  const p = new Date(now.toLocaleString('en-US', { timeZone: 'Europe/Paris' }));
  return `${p.getFullYear()}-${String(p.getMonth() + 1).padStart(2, '0')}-${String(p.getDate()).padStart(2, '0')}`;
}

function getParisDateKeyFromDate(isoDate) {
  if (!isoDate) return '';
  const d = new Date(isoDate);
  if (isNaN(d.getTime())) return '';
  const p = new Date(d.toLocaleString('en-US', { timeZone: 'Europe/Paris' }));
  return `${p.getFullYear()}-${String(p.getMonth() + 1).padStart(2, '0')}-${String(p.getDate()).padStart(2, '0')}`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const todayKey = getParisDateKey();
    const svc = base44.asServiceRole;

    // Passe is_online=false pour tout profil qui ne s'est pas connecté aujourd'hui (Europe/Paris).
    // is_online ne contrôle plus la visibilité du deck (fenêtre glissante de 7 jours sur last_online_date) ;
    // ce badge indique seulement l'activité du jour. explicitly_offline n'est jamais touché ici.

    // Phase 1: Lecture paginée des profils online — collecte des IDs à désactiver.
    const idsToDeactivate = [];
    let cursor = undefined;
    let hasMore = true;
    let iterations = 0;
    const MAX_ITERATIONS = 10000;
    while (hasMore && iterations < MAX_ITERATIONS) {
      const page = await svc.entities.Profile.filter(
        { is_online: true },
        { sort: 'created_date', limit: 500, cursor, fields: ['id', 'last_online_date', 'updated_date'] }
      );
      const profiles = page.items || [];
      for (const p of profiles) {
        const lastOnline = p.last_online_date || p.updated_date;
        const lastKey = getParisDateKeyFromDate(lastOnline);
        if (lastKey && lastKey !== todayKey) {
          idsToDeactivate.push(p.id);
        }
      }
      cursor = page.next_cursor;
      hasMore = !!page.has_more;
      iterations++;
      if (profiles.length === 0) break;
    }
    if (iterations >= MAX_ITERATIONS) console.warn('autoOfflineInactive: pagination hit MAX_ITERATIONS');

    // Phase 2: bulkUpdate par chunks de 500 — un seul update { is_online: false }.
    let deactivated = 0;
    for (let i = 0; i < idsToDeactivate.length; i += 500) {
      const chunk = idsToDeactivate.slice(i, i + 500);
      const updates = chunk.map(id => ({ id, is_online: false }));
      await svc.entities.Profile.bulkUpdate(updates);
      deactivated += chunk.length;
    }

    return Response.json({ success: true, deactivated });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});