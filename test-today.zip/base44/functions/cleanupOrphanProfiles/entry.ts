import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Nettoie les profils orphelins : ceux dont le compte utilisateur (User) n'existe plus.
// Se déclenche via une automation planifiée — aucun utilisateur authentifié.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const svc = base44.asServiceRole;

    const MAX_ITERATIONS = 10000;
    const PAGE_SIZE = 500;

    // 1) Collect all valid user IDs (paginated)
    const validUserIds = new Set();
    let userIter;
    for (userIter = 0; userIter < MAX_ITERATIONS; userIter++) {
      const users = await svc.entities.User.list('-created_date', PAGE_SIZE, userIter * PAGE_SIZE, ['id']);
      if (!users || users.length === 0) break;
      users.forEach(u => validUserIds.add(u.id));
      if (users.length < PAGE_SIZE) break;
    }
    if (userIter >= MAX_ITERATIONS) console.warn('cleanupOrphanProfiles: User pagination hit MAX_ITERATIONS (10000)');

    // 2) Read all profiles page by page, collect orphan IDs (read phase — stable pagination)
    const orphanIds = [];
    let profileIter;
    for (profileIter = 0; profileIter < MAX_ITERATIONS; profileIter++) {
      const profiles = await svc.entities.Profile.list('created_date', PAGE_SIZE, profileIter * PAGE_SIZE, ['id', 'user_id']);
      if (!profiles || profiles.length === 0) break;
      for (const p of profiles) {
        if (p.user_id && !validUserIds.has(p.user_id)) orphanIds.push(p.id);
      }
      if (profiles.length < PAGE_SIZE) break;
    }
    if (profileIter >= MAX_ITERATIONS) console.warn('cleanupOrphanProfiles: Profile pagination hit MAX_ITERATIONS (10000)');

    // 3) Batch delete orphans (delete phase — chunked)
    let deleted = 0;
    for (let i = 0; i < orphanIds.length; i += 100) {
      const chunk = orphanIds.slice(i, i + 100);
      await svc.entities.Profile.deleteMany({ id: { $in: chunk } });
      deleted += chunk.length;
    }

    return Response.json({ success: true, deleted, totalOrphans: orphanIds.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});