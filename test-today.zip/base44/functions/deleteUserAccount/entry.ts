import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Supprimer toutes les données de l'utilisateur (service role pour bypass RLS)
    const userId = user.id;

    // Destroy Cloudinary assets (best-effort — must NOT block account deletion)
    try {
      const CLOUD_NAME = Deno.env.get('CLOUDINARY_CLOUD_NAME');
      const API_KEY = Deno.env.get('CLOUDINARY_API_KEY');
      const API_SECRET = Deno.env.get('CLOUDINARY_API_SECRET');
      if (CLOUD_NAME && API_KEY && API_SECRET) {
        const auth = btoa(`${API_KEY}:${API_SECRET}`);
        const delRes = await fetch(
          `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/resources/image/upload?prefix=today_profiles/${userId}_`,
          { method: 'DELETE', headers: { Authorization: `Basic ${auth}` } }
        );
        if (!delRes.ok) {
          const errText = await delRes.text();
          console.error(`deleteUserAccount: Cloudinary delete-by-prefix failed (${delRes.status}): ${errText}`);
        }
      }
    } catch (e) {
      console.error('deleteUserAccount: Cloudinary cleanup failed:', e?.message || e);
    }

    // Messages reçus par l'utilisateur (user_id) + messages qu'il a envoyés
    // aux autres (stockés chez le destinataire avec profile_id = son user_id).
    await base44.asServiceRole.entities.UserMessage.deleteMany({ user_id: userId });
    await base44.asServiceRole.entities.UserMessage.deleteMany({ profile_id: userId });
    await base44.asServiceRole.entities.UserSession.deleteMany({ user_id: userId });
    await base44.asServiceRole.entities.Profile.deleteMany({ user_id: userId });

    return Response.json({ success: true, userId });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}