import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// ─── Scoring : importé depuis le module partagé (base44/shared/scoring.ts) ────
// Fin de la réplique inline — la logique de scoring vit maintenant dans
// base44/shared/scoring.ts (copie backend de src/lib/scoring.js).
// Le test de parité (verifyScoringParity) garantit l'identité des deux copies.
import {
  getDistanceKm,
  ageMatchesRange,
  distanceMatchesRange,
  calculateMatchScore,
  getCosmicScore,
  getGlobalScore,
  calculatePersonalityCompatibility,
} from '../../shared/scoring.ts';

function getParisDateKey() {
  const now = new Date();
  const p = new Date(now.toLocaleString('en-US', { timeZone: 'Europe/Paris' }));
  return `${p.getFullYear()}-${String(p.getMonth() + 1).padStart(2, '0')}-${String(p.getDate()).padStart(2, '0')}`;
}

// Date clé Paris (YYYY-MM-DD) pour une date ISO donnée — filtre de visibilité "même jour"
function getParisDateKeyFromDate(isoDate) {
  if (!isoDate) return '';
  const d = new Date(isoDate);
  if (isNaN(d.getTime())) return '';
  const p = new Date(d.toLocaleString('en-US', { timeZone: 'Europe/Paris' }));
  return `${p.getFullYear()}-${String(p.getMonth() + 1).padStart(2, '0')}-${String(p.getDate()).padStart(2, '0')}`;
}

function safeJsonParse(s, fallback) {
  try { return JSON.parse(s || (typeof fallback === 'object' ? '' : s)) ; } catch { return fallback; }
}

// ─── Handler ──────────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const userId = user.id;
    const dk = getParisDateKey();

    // 1) Profil du user + session du jour + messages : en parallèle (1 round-trip DB groupé)
    const [profiles, sessions, msgs] = await Promise.all([
      base44.entities.Profile.filter({ user_id: userId }),
      base44.entities.UserSession.filter({ user_id: userId, date_key: dk }),
      base44.entities.UserMessage.filter({ user_id: userId, date_key: dk }, 'created_date', 100),
    ]);

    const myProfile = profiles[0] || null;

    // Rafraîchit la date de dernière connexion : c'est elle qui décide de la visibilité
    // dans le deck des autres membres (fenêtre de 7 jours). Une écriture max par 5 minutes.
    if (myProfile && !myProfile.explicitly_offline) {
      const lastMs = myProfile.last_online_date ? new Date(myProfile.last_online_date).getTime() : 0;
      if (Date.now() - lastMs > 5 * 60 * 1000) {
        const nowIso = new Date().toISOString();
        myProfile.last_online_date = nowIso;
        myProfile.is_online = true;
        try {
          await base44.asServiceRole.entities.Profile.update(myProfile.id, { last_online_date: nowIso, is_online: true });
        } catch (e) { console.error('last_online_date refresh failed:', e); }
      }
    }

    // Session : récupère ou crée (comme getOrCreateSession côté client)
    let session = sessions[0] || null;
    if (!session) {
      session = await base44.entities.UserSession.create({
        user_id: userId, date_key: dk, is_online: false, has_accepted_date: false,
        match_count: 0, challenged_profiles: '{}', challenge_dates: '{}', passed_profiles: '{}', physical_affinity: '{}',
      });
    }

    // Messages mappés (identique à getMessagesForToday)
    const messages = msgs.map(m => ({
      ...m,
      action: m.action_json ? (() => { try { return JSON.parse(m.action_json); } catch { return null; } })() : null,
      timerStartTime: m.timer_start_time || null,
    }));

    // Préférences : session en priorité, sinon profil persisté
    let prefs = null;
    let createPrefs = null;
    try {
      createPrefs = session.create_prefs ? JSON.parse(session.create_prefs) : null;
    } catch { createPrefs = null; }
    if (!createPrefs && myProfile?.create_prefs) {
      try { createPrefs = JSON.parse(myProfile.create_prefs); } catch { createPrefs = null; }
    }
    let affinityMap = {};
    try { affinityMap = session.physical_affinity ? JSON.parse(session.physical_affinity) : {}; } catch {}
    if (createPrefs) prefs = { ...createPrefs, physicalAffinityMap: affinityMap };

    // 2) Candidats scorés (uniquement si profil complet + prefs + pas de date acceptée)
    let candidates = [];
    const profileComplete = myProfile && myProfile.display_name && myProfile.age && myProfile.gender && myProfile.photo_url;
    const hasAccepted = !!myProfile?.accepted_date_key;

    if (profileComplete && !hasAccepted && prefs) {
      // Profil de personnalité du user (test de personnalité) — parsé une fois
      let myPersonalityProfile = null;
      try { myPersonalityProfile = myProfile?.personality_profile ? JSON.parse(myProfile.personality_profile) : null; } catch {}

      const PROJECTION = [
        'user_id', 'display_name', 'age', 'gender', 'city', 'photo_url', 'photo_url_2', 'photo_url_3',
        'education', 'job', 'height', 'seeking', 'astro_sign', 'astro_ascendant',
        'own_physical_traits', 'own_personality_traits', 'personal_flaws', 'desired_physical_traits',
        'likes', 'five_words', 'quiz_phrase', 'time_slot', 'is_vegetarian',
        'desired_age_range',
        'last_online_date', 'accepted_date_key', 'personality_profile', 'blocked_profile_ids', 'is_hidden', 'explicitly_offline', 'is_online',
      ];
      const todayKey = dk;

      // Admins : badge « admin » affiché en rouge sur les photos du deck
      let adminUserIds = new Set();
      try {
        const admins = await base44.asServiceRole.entities.User.filter({ role: 'admin' });
        adminUserIds = new Set((admins || []).map(u => u.id));
      } catch (e) { console.error('admin lookup failed:', e); }

      // Cost-bounded pagination: widen the candidate pool beyond 50 profiles.
      // At current small scale (<50 profiles) page 1 returns <50 → stops after 1 page (same as before).
      // At scale: loads up to 5 pages (250 profiles) to find candidates after exclusions.
      const MAX_PAGES = 5;
      const PAGE_SIZE = 50;
      for (let page = 0; page < MAX_PAGES; page++) {
        const all = await base44.asServiceRole.entities.Profile.list('-last_online_date', PAGE_SIZE, page * PAGE_SIZE, PROJECTION);
        if (!all || all.length === 0) break;
        for (const p of all) {
        if (p.user_id === userId) continue;
        // Profil bloqué par l'utilisateur → masqué du deck
        if (Array.isArray(myProfile?.blocked_profile_ids) && myProfile.blocked_profile_ids.includes(p.id)) continue;
        // L'utilisateur est bloqué par ce profil → masqué aussi
        if (Array.isArray(p.blocked_profile_ids) && p.blocked_profile_ids.includes(myProfile.id)) continue;
        // Profil masqué par modération (signalements) → masqué du deck
        if (p.is_hidden) continue;
        // Profil mis hors-ligne explicitement (toggle) → masqué du deck immédiatement
        if (p.explicitly_offline) continue;
        if (p.gender !== prefs.seeking) continue;
        if (prefs.myGender && p.seeking && p.seeking !== prefs.myGender) continue;
        if (!ageMatchesRange(p.age, prefs.ageRange)) continue;
        // Réciprocité d'âge : mon âge doit aussi correspondre aux tranches recherchées par le candidat.
        // Si le candidat n'a pas de tranches enregistrées, on tolère (comme pour le genre).
        const theirAgeRange = p.desired_age_range
          ? String(p.desired_age_range).split('|').filter(Boolean)
          : [];
        if (theirAgeRange.length > 0 && !ageMatchesRange(myProfile.age, theirAgeRange)) continue;
        const dist = getDistanceKm(prefs.myCity, p.city);
        if (!distanceMatchesRange(dist, prefs.distance)) continue;
        if (prefs.minHeight && p.height < prefs.minHeight) continue;
        // Un profil est visible s'il est en ligne maintenant, ou s'il s'est connecté
        // dans les 7 derniers jours (fenêtre glissante)
        const ONLINE_WINDOW_MS = 7 * 24 * 60 * 60 * 1000;
        const recentlyOnline = !!p.last_online_date && (Date.now() - new Date(p.last_online_date).getTime()) <= ONLINE_WINDOW_MS;
        if (!p.is_online && !recentlyOnline) continue;
        if (p.accepted_date_key === todayKey) continue;

        // Profil normalisé pour le scoring (camelCase)
        const np = {
          ...p,
          ownPhysicalTraits: p.own_physical_traits || [],
          ownPersonalityTraits: p.own_personality_traits || [],
          personal_flaws: p.personal_flaws || [],
          personality_profile: p.personality_profile,
        };

        const matchScore = calculateMatchScore(np, prefs, myProfile);
        const cosmicScore = getCosmicScore(myProfile, np);
        // Score de personnalité : UNIQUEMENT le test de personnalité (personality_profile).
        let theirPersonalityProfile = null;
        try { theirPersonalityProfile = p.personality_profile ? JSON.parse(p.personality_profile) : null; } catch {}
        const personalityScore = calculatePersonalityCompatibility(myPersonalityProfile, theirPersonalityProfile);
        const globalScore = getGlobalScore(matchScore, cosmicScore, personalityScore);

        // Objet LEAN renvoyé au client — SANS personality_profile
        candidates.push({
          id: p.id,
          user_id: p.user_id,
          display_name: p.display_name,
          age: p.age,
          gender: p.gender,
          city: p.city,
          photo_url: p.photo_url,
          photo_url_2: p.photo_url_2 || null,
          photo_url_3: p.photo_url_3 || null,
          education: p.education || '',
          job: p.job || '',
          height: p.height || null,
          seeking: p.seeking || '',
          astro_sign: p.astro_sign || '',
          astro_ascendant: p.astro_ascendant || '',
          own_physical_traits: p.own_physical_traits || [],
          own_personality_traits: p.own_personality_traits || [],
          personal_flaws: p.personal_flaws || [],
          desired_physical_traits: p.desired_physical_traits || [],
          likes: p.likes || [],
          five_words: p.five_words || '',
          quiz_phrase: p.quiz_phrase || '',
          time_slot: p.time_slot || '',
          is_vegetarian: p.is_vegetarian || false,
          is_admin: adminUserIds.has(p.user_id),
          last_online_date: p.last_online_date || '',
          is_online: Boolean(p.is_online),
          matchScore,
          cosmicScore,
          personalityScore,
          globalScore,
        });
      }
        if (all.length < PAGE_SIZE) break; // no more pages — stop paginating
      }
    }

    // Session parsée pour le client (évite les 9 appels today-store)
    let parsedChallenged = {};
    let parsedPassed = {};
    let parsedChallengeDates = {};
    try { parsedChallenged = session.challenged_profiles ? JSON.parse(session.challenged_profiles) : {}; } catch {}
    try { parsedPassed = session.passed_profiles ? JSON.parse(session.passed_profiles) : {}; } catch {}
    try { parsedChallengeDates = myProfile?.challenge_dates_map ? JSON.parse(myProfile.challenge_dates_map) : {}; } catch {}

    return Response.json({
      profile: myProfile,
      session: {
        raw: session,
        is_online: Boolean(session.is_online),
        has_accepted_date: Boolean(session.has_accepted_date),
        create_prefs: createPrefs,
        challenged_profiles: parsedChallenged,
        challenge_dates: parsedChallengeDates,
        passed_profiles: parsedPassed,
        physical_affinity: affinityMap,
      },
      messages,
      candidates,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});