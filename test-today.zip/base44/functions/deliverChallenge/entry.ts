import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { findOrCreateThread, threadSnapshot, findThread, computeThreadKey } from '../../shared/datethread.ts';
import { msgChallengeReceived } from '../../shared/messages.ts';
import { notifyMessagePush } from '../../shared/push.ts';
import { isChallengeWindowOpen, challengeWindowClosedMessage } from '../../shared/challenge-window.ts';

// Livrer un défi à un destinataire (contourne la RLS en service role)
Deno.serve(async (req) => {
  const transitions = [];
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { recipientUserId, senderProfileId, challengerProfile, opponentChoice, dateKey } = await req.json();

    if (!recipientUserId || !dateKey) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Fenêtre : défis uniquement les jeudis et samedis, de 6 h à 23 h (heure belge).
    // Exception : un administrateur peut défier toute la semaine.
    if (!isChallengeWindowOpen(new Date(), user.role === 'admin')) {
      return Response.json({ blocked: true, reason: 'challenge_window_closed', message: challengeWindowClosedMessage() }, { status: 409 });
    }

    // Valider que senderProfileId appartient bien à l'utilisateur authentifié
    let senderPhoto = '';
    if (senderProfileId) {
      const senderProfiles = await base44.asServiceRole.entities.Profile.filter({ id: senderProfileId });
      if (!senderProfiles[0] || senderProfiles[0].user_id !== user.id) {
        return Response.json({ error: 'Forbidden: sender profile does not belong to authenticated user' }, { status: 403 });
      }
      senderPhoto = senderProfiles[0]?.photo_url || '';
    }

    // 0. Vérifier si le destinataire a bloqué l'expéditeur → ignorer silencieusement
    const recipientProfiles = await base44.asServiceRole.entities.Profile.filter({ user_id: recipientUserId });
    const recipientProfile = recipientProfiles[0];
    if (recipientProfile?.blocked_profile_ids?.includes(String(senderProfileId))) {
      return Response.json({ success: true, blocked: true });
    }

    // 0b. Vérifier qu'il n'y a pas de défi entrant en attente du destinataire
    //     (règle : un seul défi à la fois entre deux personnes, même jour)
    const callerSessions = await base44.asServiceRole.entities.UserSession.filter({ user_id: user.id, date_key: dateKey });
    const callerSession = callerSessions[0];
    const recipientDisplayName = recipientProfile?.display_name || 'ce profil';
    if (callerSession && recipientProfile) {
      const callerChallengedMap = (() => { try { return JSON.parse(callerSession.challenged_profiles || '{}'); } catch { return {}; } })();
      // Guard existant : défi entrant en attente (cas croisé)
      if (callerChallengedMap[String(recipientProfile.id)] === 'incoming') {
        return Response.json({ blocked: true, reason: 'incoming_pending', message: `${recipientProfile?.display_name || 'Quelqu\'un'} t'a déjà envoyé un défi ! Réponds dans tes messages.` }, { status: 409 });
      }
      // NOTE : le marqueur sortant "true" n'est PAS une source de vérité serveur.
      // Il est écrit côté client (optimiste) AVANT l'appel backend, donc il faux-positif
      // sur le premier défi. La détection des doublons repose uniquement sur le guard
      // message-based ci-dessous (0c).
    }

    // 0c. Anti-doublon (robuste) : un défi non résolu existe déjà dans la boîte du destinataire
    //     On cherche le dernier incomingChallenge de cet expéditeur (par profile.id) et
    //     on vérifie qu'aucun message ultérieur du même thread ne l'a résolu.
    if (senderProfileId) {
      const recipientMsgs = await base44.asServiceRole.entities.UserMessage.filter({ user_id: recipientUserId, date_key: dateKey }, '-created_date', 500);
      recipientMsgs.sort((a, b) => (a.created_date || '').localeCompare(b.created_date || ''));
      let lastChallengeIdx = -1;
      for (let i = recipientMsgs.length - 1; i >= 0; i--) {
        try {
          const action = recipientMsgs[i].action_json ? JSON.parse(recipientMsgs[i].action_json) : null;
          if (action?.type === 'incomingChallenge' && String(action?.profile?.id) === String(senderProfileId)) {
            lastChallengeIdx = i;
            break;
          }
        } catch {}
      }
      if (lastChallengeIdx >= 0) {
        const threadKey = recipientMsgs[lastChallengeIdx].profile_name || recipientMsgs[lastChallengeIdx].thread_key || '';
        let resolved = false;
        for (let i = lastChallengeIdx + 1; i < recipientMsgs.length; i++) {
          const msg = recipientMsgs[i];
          if (threadKey && msg.profile_name !== threadKey && msg.thread_key !== threadKey) continue;
          const txt = msg.text || '';
          let action = null;
          try { action = msg.action_json ? JSON.parse(msg.action_json) : null; } catch {}
          if (action?.type === 'winnerChoosePlace' ||
              action?.type === 'playerTurn' ||
              txt.includes('Résultat PPC') ||
              txt.includes('Tu as perdu contre') ||
              txt.includes('Tu as gagné') ||
              txt.includes('Pas de match') ||
              txt.includes('Date annulé') ||
              txt.includes("n'a pas répondu") ||
              txt.includes('Date confirmé')) {
            resolved = true;
            break;
          }
        }
        if (!resolved) {
          return Response.json({ blocked: true, reason: 'already_challenged', message: `Tu as déjà envoyé un défi à ${recipientDisplayName}. Attends sa réponse.` }, { status: 409 });
        }
      }
    }

    // 0d. Anti-re-défi après toute interaction terminée : si le thread entre la paire
    //     est dans un état terminal (no_match ou cancelled), bloquer le défi dans les
    //     deux sens. Règle : un seul défi par jour entre profils — une fois qu'une
    //     interaction a eu lieu (défi, proposition, annulation), la paire est fermée.
    {
      const pairThreadKey = computeThreadKey(dateKey, user.id, recipientUserId);
      const pairThread = await findThread(base44, pairThreadKey);
      if (pairThread && (pairThread.state === 'no_match' || pairThread.state === 'cancelled')) {
        const isPersonal = pairThread.state === 'no_match' && pairThread.refusal_reasons && (() => {
          try { return JSON.parse(pairThread.refusal_reasons).includes('personal'); } catch { return false; }
        })();
        const message = isPersonal
          ? `Suite à un refus pour raisons personnelles, vous ne pouvez plus vous défier aujourd'hui.`
          : `Vous avez déjà interagi aujourd'hui. Vous ne pouvez plus vous défier.`;
        return Response.json({ blocked: true, reason: 'already_interacted', message }, { status: 409 });
      }
    }

    // 1. Marquer le défi entrant dans la session du destinataire (service role)
    const sessions = await base44.asServiceRole.entities.UserSession.filter({ user_id: recipientUserId, date_key: dateKey });
    let session = sessions[0];
    if (!session) {
      session = await base44.asServiceRole.entities.UserSession.create({
        user_id: recipientUserId,
        date_key: dateKey,
        is_online: false,
        has_accepted_date: false,
        match_count: 0,
        challenged_profiles: '{}',
        passed_profiles: '{}',
      });
    }

    const challengedMap = (() => { try { return JSON.parse(session.challenged_profiles || '{}'); } catch { return {}; } })();
    if (!challengedMap[String(senderProfileId)]) {
      challengedMap[String(senderProfileId)] = 'incoming';
      await base44.asServiceRole.entities.UserSession.update(session.id, {
        challenged_profiles: JSON.stringify(challengedMap),
      });
    }

    // 2. Créer le message dans la boîte du destinataire (service role)
    const senderName = challengerProfile?.name || 'Quelqu\'un';
    // Slim profile snapshot — only fields the UI reads (MessageGroupCard + ProfileViewModal fallback + RpsFlow)
    const leanProfile = {
      id: challengerProfile?.id,
      user_id: challengerProfile?.user_id,
      name: challengerProfile?.name,
      photo: challengerProfile?.photo,
      photo_url_2: challengerProfile?.photo_url_2 || '',
      photo_url_3: challengerProfile?.photo_url_3 || '',
      age: challengerProfile?.age,
      city: challengerProfile?.city,
      height: challengerProfile?.height || null,
      education: challengerProfile?.education || '',
      job: challengerProfile?.job || '',
      fiveWords: challengerProfile?.fiveWords || '',
      ownPhysicalTraits: challengerProfile?.ownPhysicalTraits || [],
      ownPersonalityTraits: challengerProfile?.ownPersonalityTraits || [],
      personal_flaws: challengerProfile?.personal_flaws || [],
    };
    const challengeMessage = await base44.asServiceRole.entities.UserMessage.create({
      user_id: recipientUserId,
      date_key: dateKey,
      sender: senderName,
      text: msgChallengeReceived(senderName),
      is_system: false,
      profile_name: senderName,
      profile_id: String(user.id),
      thread_key: senderName,
      action_json: JSON.stringify({ type: 'incomingChallenge', profile: leanProfile, opponentChoice }),
      profile_photo: senderPhoto,
      display_time: new Date().toLocaleTimeString('fr-FR', { timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit' }),
    });

    // Un seul push par défi réellement créé (clé = id du message).
    notifyMessagePush(base44, { message: challengeMessage, fromUserId: user.id });

    // SHADOW: créer le DateThread pending_challenge (idempotent via thread_key)
    transitions.push(threadSnapshot(await findOrCreateThread(base44, dateKey, user.id, recipientUserId, 'pending_challenge', {
      challenger_user_id: user.id,
    })));

    return Response.json({ success: true, transitions });
  } catch (error) {
    return Response.json({ success: false, error: error.message, code: error.code || 'WRITE_FAILED', transitions, actualState: error.state ?? null }, { status: error.status || 500 });
  }
});