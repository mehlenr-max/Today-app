import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

// Récupère un profil par user_id en service role (contourne la RLS is_online).
// Sert à afficher la fiche profil depuis les onglets Jeux/Messages même quand le profil est hors-ligne.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { userId } = await req.json();
    if (!userId) return Response.json({ error: 'Missing userId' }, { status: 400 });

    const profiles = await base44.asServiceRole.entities.Profile.filter({ user_id: userId });
    const profile = profiles[0];
    if (!profile) return Response.json({ error: 'Not found' }, { status: 404 });

    return Response.json({ profile });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});