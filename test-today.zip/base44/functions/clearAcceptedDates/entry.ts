import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const svc = base44.asServiceRole;

    // Date du jour en Europe/Brussels
    const today = new Date();
    const todayKey = today.toLocaleDateString('fr-CA', { timeZone: 'Europe/Brussels' });

    // Phase 1: Read all profiles page by page (stable pagination — no updates during read),
    // collect IDs whose accepted_date_key is set and not today.
    // Sort by created_date (stable — doesn't shift on update like -updated_date would).
    const MAX_ITERATIONS = 10000;
    const PAGE_SIZE = 500;
    const idsToClear = [];
    let iter;
    for (iter = 0; iter < MAX_ITERATIONS; iter++) {
      const profiles = await svc.entities.Profile.list('created_date', PAGE_SIZE, iter * PAGE_SIZE, ['id', 'accepted_date_key']);
      if (!profiles || profiles.length === 0) break;
      for (const p of profiles) {
        if (p.accepted_date_key && p.accepted_date_key !== todayKey) idsToClear.push(p.id);
      }
      if (profiles.length < PAGE_SIZE) break;
    }
    if (iter >= MAX_ITERATIONS) console.warn('clearAcceptedDates: MAX_ITERATIONS (10000) reached — some profiles may remain');

    // Phase 2: Batch update (chunked to stay within bulkUpdate's 500-record limit)
    let cleared = 0;
    for (let i = 0; i < idsToClear.length; i += 100) {
      const chunk = idsToClear.slice(i, i + 100);
      const updates = chunk.map(id => ({ id, accepted_date_key: null }));
      await svc.entities.Profile.bulkUpdate(updates);
      cleared += chunk.length;
    }

    return Response.json({ success: true, cleared, today: todayKey });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});