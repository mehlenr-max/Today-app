import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Seul un admin peut réinitialiser
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const svc = base44.asServiceRole;

    // Date du jour en Europe/Brussels
    const today = new Date();
    const todayKey = today.toLocaleDateString('fr-CA', { timeZone: 'Europe/Brussels' });

    // 1. Supprimer tous les messages d'aujourd'hui (date_key = today)
    const todayMessages = await svc.entities.UserMessage.filter({ date_key: todayKey });
    const msgIds = Array.isArray(todayMessages) ? todayMessages.map(m => m.id) : (todayMessages.items || []).map(m => m.id);
    let deletedMessages = 0;
    if (msgIds.length > 0) {
      const res = await svc.entities.UserMessage.deleteMany({ date_key: todayKey });
      deletedMessages = msgIds.length;
    }

    // 2. Supprimer toutes les sessions d'aujourd'hui (date_key = today)
    const todaySessions = await svc.entities.UserSession.filter({ date_key: todayKey });
    const sessIds = Array.isArray(todaySessions) ? todaySessions.map(s => s.id) : (todaySessions.items || []).map(s => s.id);
    let deletedSessions = 0;
    if (sessIds.length > 0) {
      await svc.entities.UserSession.deleteMany({ date_key: todayKey });
      deletedSessions = sessIds.length;
    }

    // 3. Réinitialiser accepted_date_key = today sur les profils (pour débloquer le deck)
    const profilesWithDate = await svc.entities.Profile.filter({ accepted_date_key: todayKey });
    const profileList = Array.isArray(profilesWithDate) ? profilesWithDate : (profilesWithDate.items || []);
    let clearedDates = 0;
    if (profileList.length > 0) {
      const updates = profileList.map(p => ({ id: p.id, accepted_date_key: null }));
      for (let i = 0; i < updates.length; i += 500) {
        await svc.entities.Profile.bulkUpdate(updates.slice(i, i + 500));
      }
      clearedDates = profileList.length;
    }

    // 4. Supprimer les DateLock du jour (débloque les utilisateurs verrouillés)
    const todayLocks = await svc.entities.DateLock.filter({ date_key: todayKey });
    const lockList = Array.isArray(todayLocks) ? todayLocks : (todayLocks.items || []);
    let deletedLocks = 0;
    if (lockList.length > 0) {
      await svc.entities.DateLock.deleteMany({ date_key: todayKey });
      deletedLocks = lockList.length;
    }

    // 5. Supprimer les DateThread du jour (reset des états de thread)
    const todayThreads = await svc.entities.DateThread.filter({ date_key: todayKey });
    const threadList = Array.isArray(todayThreads) ? todayThreads : (todayThreads.items || []);
    let deletedThreads = 0;
    if (threadList.length > 0) {
      await svc.entities.DateThread.deleteMany({ date_key: todayKey });
      deletedThreads = threadList.length;
    }

    return Response.json({
      success: true,
      today: todayKey,
      deletedMessages,
      deletedSessions,
      clearedDates,
      deletedLocks,
      deletedThreads,
    });
  } catch (error) {
    console.error('resetTodayInteractions error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});