// ─────────────────────────────────────────────────────────────────────────────
// Templates centralisés pour les messages système de ToDay.
// Toutes les chaînes envoyées par les backend functions sont définies ici.
//
// ⚠️ Les sentinelles frontend (.includes('Date confirmé'), .includes('Pas de match'),
// .includes('Date annulé'), .includes('Tu as refusé'), etc.) dépendent des sous-chaînes
// exactes — ne pas modifier le texte sans mettre à jour le frontend en parallèle.
//
// Ce module est la source de vérité pour les messages backend.
// Le frontend (MessagesTab.jsx, MessageGroupCard.jsx) utilise des .includes() sur ces
// mêmes sous-chaînes pour détecter le type de message — la parité est implicite.
// ─────────────────────────────────────────────────────────────────────────────

// ── Constantes ──

export const REFUSAL_REASON_LABELS: Record<string, string> = {
  place: "L'endroit",
  food: "La nourriture",
  personal: "Raisons personnelles",
};

// ── Messages de défi (RPS) ──

export function msgChallengeWin(senderName: string): string {
  return `🏆 Tu as gagné le défi contre ${senderName} ! Choisis le lieu du date.`;
}

export function msgChallengeLost(senderName: string): string {
  return `😔 Tu as perdu contre ${senderName}. Le gagnant choisit le lieu.`;
}

// Ligne de résultat neutre du PPC, écrite dans la boîte du joueur qui résout le jeu.
// Parité avec le texte composé côté client avant la migration (RpsFlow:319) : la sous-chaîne
// « Résultat PPC » est une sentinelle (deliverChallenge:80) — ne pas la modifier.
export function msgRpsResult(profileName: string, choice: string, oChoice: string, verdict: 'win' | 'lose' | 'draw'): string {
  const head = `Résultat PPC avec ${profileName} : ${choice} vs ${oChoice}`;
  if (verdict === 'draw') return `${head} — Égalité → le challenger gagne`;
  return `${head} — ${verdict === 'win' ? 'Tu gagnes !' : `${profileName} gagne !`}`;
}

export function msgChallengeReceived(senderName: string): string {
  return `🎮 ${senderName} t'envoie un défi ! À toi de jouer.`;
}

// ── Messages de proposition de lieu ──

export function msgPlaceProposal(senderName: string, place: string, time: string, address?: string): string {
  return `📍 ${senderName} te propose un lieu : "${place}" à ${time}${address ? `\n📍 ${address}` : ''}`;
}

export function msgPlaceChanged(senderName: string, place: string, time: string, address?: string): string {
  return `🔄 ${senderName} a changé le lieu : "${place}" à ${time}${address ? `\n📍 ${address}` : ''}`;
}

export function msgPlaceChangedSelf(place: string, time: string, address: string | undefined, recipientName: string): string {
  return `🔄 Tu as changé le lieu à : "${place}" à ${time}${address ? `\n📍 ${address}` : ''}\nDans l'attente d'acceptation de ${recipientName}.`;
}

// ── Message d'attente côté gagnant (miroir de la proposition, dans la boîte du gagnant) ──
// Créé par deliverResult/notifyLoser en même temps que la proposition au perdant.
// Wording identique au pushMessage frontend supprimé (ToDay4.jsx ancienne ligne 593).

export function msgWaitingAcceptance(loserName: string, place: string, time: string, address?: string): string {
  const addrLine = address ? `\n📍 ${address}` : '';
  return `⏳ En attente d'acceptation du lieu par ${loserName}...\n📍 "${place}" à ${time}${addrLine}`;
}

// ── Messages de confirmation ──

export function msgDateConfirmed(place: string): string {
  return `✅ Date confirmé !\n📍 ${place}`;
}

// ── Messages de refus ──

export function buildReasonsText(reasons: string[]): string {
  return reasons.map(r => REFUSAL_REASON_LABELS[r] || r).join(', ');
}

export function msgPlaceRefusedFinal(loserName: string, reasons: string[]): string {
  const reasonsText = buildReasonsText(reasons);
  const reasonsSuffix = reasonsText ? `\nRaison(s) : ${reasonsText}` : '';
  return `❌ ${loserName} a refusé ta proposition de lieu. Pas de match.${reasonsSuffix}\nVous ne pouvez plus vous défier aujourd'hui.`;
}

export function msgPlaceRefusedNonFinal(loserName: string, reasons: string[]): string {
  const reasonsText = buildReasonsText(reasons);
  return `❌ ${loserName} a refusé ta proposition de lieu.\nRaison(s) : ${reasonsText}\nTu peux choisir un autre lieu ou annuler.`;
}

// ── Message de disponibilité (l'utilisateur libéré est à nouveau dispo) ──

export function msgAvailableAgain(name: string): string {
  return `✅ ${name} est à nouveau disponible.`;
}

// ── Messages de suspension / reprise d'interaction ──
// Quand un utilisateur confirme un date ailleurs, ses autres interactions sont
// suspendues (stade préservé). Elles reprennent au même stade après libération.

export function msgSuspendedOther(name: string): string {
  return `⏸️ ${name} n'est plus disponible (a confirmé un date ailleurs). Votre interaction est suspendue — elle reprendra si ${name} est libéré.`;
}

export function msgSuspendedSelf(name: string): string {
  return `⏸️ Ton interaction avec ${name} est suspendue. Tu as confirmé un autre date.`;
}

export function msgResumedOther(name: string): string {
  return `✅ ${name} est à nouveau disponible. Votre interaction reprend là où elle en était.`;
}

export function msgResumedSelf(name: string): string {
  return `✅ Ton interaction avec ${name} reprend là où elle en était.`;
}

// ── Messages d'annulation ──

export function msgDateCancelledSelf(otherName: string): string {
  return `❌ Date annulé. Tu as annulé le rendez-vous avec ${otherName}.`;
}

export function msgNoMatchSelf(otherName: string): string {
  return `❌ Pas de match. Tu as annulé le rendez-vous avec ${otherName}.`;
}

export function msgDateCancelledOther(myName: string): string {
  return `❌ Date annulé. ${myName} a annulé le rendez-vous.`;
}

export function msgNoMatchOther(myName: string): string {
  return `❌ Pas de match. ${myName} a annulé le rendez-vous.`;
}

// ── Messages de blocage (lock) ──

export function msgLockCancelledAfterConfirm(): string {
  return `Tu as annulé un date confirmé — tu ne peux pas proposer de nouveau date aujourd'hui.`;
}

export function msgLockAlreadyHasDate(): string {
  return `Tu as déjà un date aujourd'hui.`;
}

export function msgWinnerUnavailable(winnerName: string): string {
  return `❌ ${winnerName} n'est plus disponible pour un date aujourd'hui.`;
}

export function msgLoserAlreadyHasDate(): string {
  return `❌ Tu as déjà un date aujourd'hui.`;
}

// ── Messages de quiz ──

export function msgQuizProposal(askerName: string): string {
  return `🎮 ${askerName} te propose un jeu ! Va dans l'onglet 🎲 pour jouer.`;
}

export function msgQuizAnswers(responderName: string, qaText: string): string {
  return `🎮 ${responderName} a joué !\n\n${qaText}`;
}

// ── Messages de gage (date card) ──

export function msgDateCardDrawn(otherName: string): string {
  return `🃏 Tu as pioché un gage ! ${otherName} le recevra et te le demandera ce soir.`;
}

export function msgDateCardReceived(myName: string, gage: string): string {
  return `🃏 ${myName} a pioché un gage pour ce soir :\n\n« ${gage} »\n\nDemande à ${myName} de le réaliser pendant votre date !`;
}