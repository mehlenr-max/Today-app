// Helpers pour les DateThreads + DateLocks (refonte DateThread).
// Service role uniquement — les threads/locks ne sont pas accessibles aux utilisateurs.
// ÉTAPE 2: les transitions DateThread utilisent la garde de version (optimistic locking).
// Le lock DateLock {dateKey}_{userId} survit à l'annulation (reason mise à jour).

export function computeThreadKey(dateKey: string, userAId: string, userBId: string): string {
  const [a, b] = [userAId, userBId].sort();
  return `${dateKey}_${a}_${b}`;
}

export function computeLockKey(dateKey: string, userId: string): string {
  return `${dateKey}_${userId}`;
}

// Trouve ou crée un DateThread (idempotent via thread_key).
export async function findOrCreateThread(base44, dateKey: string, userAId: string, userBId: string, initialState: string, extra: Record<string, any> = {}) {
  const svc = base44.asServiceRole;
  const threadKey = computeThreadKey(dateKey, userAId, userBId);
  const existing = await svc.entities.DateThread.filter({ thread_key: threadKey });
  if (existing[0]) return existing[0];
  const [a, b] = [userAId, userBId].sort();
  // Idempotent : upsert par thread_key au lieu de create. Si un appel concurrent a déjà
  // créé le thread entre le filter et l'upsert, l'upsert réutilise l'existant (même key)
  // au lieu de créer un doublon. Les deux appels concurrents écrivent les mêmes valeurs
  // (initialState, version:1, extra) — le second upsert est un no-op (données identiques).
  await svc.entities.DateThread.upsert(
    [{ thread_key: threadKey, date_key: dateKey, user_a_id: a, user_b_id: b, state: initialState, version: 1, ...extra }],
    { key: 'thread_key' }
  );
  const result = await svc.entities.DateThread.filter({ thread_key: threadKey });
  return result[0];
}

function integrityError(code, message, status, state = null) {
  return Object.assign(new Error(message), { code, status, state });
}

export function threadSnapshot(thread) {
  return { id: thread.id, thread_key: thread.thread_key, state: thread.state, version: thread.version, place_json: thread.place_json || null };
}

// Transition d'état avec garde de version : tout échec est explicite.
export async function transitionThreadState(base44, threadKey: string, newState: string, extra: Record<string, any> = {}) {
  const svc = base44.asServiceRole;
  const existing = await svc.entities.DateThread.filter({ thread_key: threadKey });
  if (!existing[0]) throw integrityError('THREAD_NOT_FOUND', `DateThread introuvable : ${threadKey}`, 409);
  const current = existing[0];
  const expectedVersion = current.version || 1;
  // Si on transitionne vers accepted, poser has_been_confirmed=true (fait historique, jamais remis à false).
  // Backfill implicite : les threads antérieurs au fix qui transitionnent vers accepted le reçoivent ici.
  const extraWithConfirmed = newState === 'accepted' ? { ...extra, has_been_confirmed: true } : extra;
  const result = await svc.entities.DateThread.updateMany(
    { thread_key: threadKey, version: expectedVersion },
    { $set: { state: newState, version: expectedVersion + 1, ...extraWithConfirmed } }
  );
  const updated = (await svc.entities.DateThread.filter({ thread_key: threadKey }))[0];
  const actualState = updated ? threadSnapshot(updated) : null;
  if (result?.updated !== 1) {
    throw integrityError('THREAD_VERSION_CONFLICT', `Transition ${threadKey} vers ${newState} non appliquée`, 409, actualState);
  }
  if (!updated || updated.state !== newState || updated.version !== expectedVersion + 1) {
    throw integrityError('THREAD_STATE_MISMATCH', `État relu différent de la transition demandée : ${threadKey}`, 409, actualState);
  }
  return updated;
}

// Trouve un thread par clé.
export async function findThread(base44, threadKey: string) {
  const svc = base44.asServiceRole;
  const existing = await svc.entities.DateThread.filter({ thread_key: threadKey });
  return existing[0] || null;
}

// ── DateLock helpers ──

// Trouve le lock d'un utilisateur pour une date.
export async function findLock(base44, dateKey: string, userId: string) {
  const svc = base44.asServiceRole;
  const lockKey = computeLockKey(dateKey, userId);
  const existing = await svc.entities.DateLock.filter({ lock_key: lockKey });
  return existing[0] || null;
}

// Acquiert le lock pour un utilisateur (CAS atomique sur `locked`).
// Retourne { acquired: boolean, lock: DateLock | null }.
// Si le lock existe déjà (locked=true), acquired=false.
//
// IDEMPOTENCE: upsert par lock_key empêche les doublons sous double-clic.
// Deux appels concurrents ne créent qu'un seul record (l'upsert réutilise l'existant).
// Le CAS updateMany garantit qu'un seul appel peut flipper locked de false→true.
export async function acquireLock(base44, dateKey: string, userId: string, reason: string, threadKey: string) {
  const svc = base44.asServiceRole;
  const lockKey = computeLockKey(dateKey, userId);

  // Upsert idempotent par lock_key : crée un seul record (locked=false par défaut),
  // ou réutilise l'existant sans écraser `locked` (non inclus dans l'upsert).
  await svc.entities.DateLock.upsert(
    [{ lock_key: lockKey, user_id: userId, date_key: dateKey, reason: 'date_confirmed' }],
    { key: 'lock_key' }
  );

  // CAS atomique: seul le premier appel peut flipper locked de false→true.
  const casResult = await svc.entities.DateLock.updateMany(
    { lock_key: lockKey, locked: { $ne: true } },
    { $set: { locked: true, reason, thread_key: threadKey } }
  );

  const lockRecord = (await svc.entities.DateLock.filter({ lock_key: lockKey }))[0];
  if (!lockRecord || lockRecord.locked !== true) {
    throw integrityError('LOCK_NOT_ACQUIRED', `Aucun verrou actif après acquisition : ${lockKey}`, 500, lockRecord || null);
  }
  if (casResult?.updated === 0) return { acquired: false, lock: lockRecord };
  if (casResult?.updated !== 1) {
    // Doublon résiduel (race ou artefact pré-existant) — incohérent, refuser.
    throw integrityError('LOCK_STATE_MISMATCH', `Acquisition du verrou incohérente (updated=${casResult?.updated}) : ${lockKey}`, 409, lockRecord);
  }
  return { acquired: true, lock: lockRecord };
}

// Acquiert le lock ou vérifie qu'il est déjà acquis sur CE thread (changement de lieu).
// - alreadyHeld=true + acquired=true : lock déjà posé sur ce thread (re-confirmation) — ne pas libérer.
// - acquired=true + alreadyHeld=false : lock nouvellement acquis — à libérer si l'autre partie échoue.
// - acquired=false : le lock est actif sur un AUTRE thread → conflit, bloquer.
export async function acquireOrVerifyLock(base44, dateKey: string, userId: string, reason: string, threadKey: string) {
  const svc = base44.asServiceRole;
  const lockKey = computeLockKey(dateKey, userId);
  const existing = await svc.entities.DateLock.filter({ lock_key: lockKey });

  // Lock déjà acquis sur CE thread → re-confirmation (changement de lieu après acceptation)
  if (existing[0]?.locked && existing[0]?.thread_key === threadKey) {
    return { acquired: true, lock: existing[0], alreadyHeld: true };
  }

  // Lock actif sur un AUTRE thread → conflit, bloquer
  if (existing[0]?.locked) {
    return { acquired: false, lock: existing[0], alreadyHeld: false };
  }

  // Pas de lock actif → acquisition normale (CAS atomique via upsert idempotent)
  const result = await acquireLock(base44, dateKey, userId, reason, threadKey);
  if (result.acquired) return { ...result, alreadyHeld: false };
  // Lock non acquis — vérifier s'il est sur CE thread (double-clic / re-confirmation).
  // Le CAS a échoué (updated=0) car le lock est déjà locked=true. Si c'est sur le même
  // thread, c'est une re-confirmation idempotente — ne pas bloquer.
  if (result.lock?.locked && result.lock?.thread_key === threadKey) {
    return { acquired: true, lock: result.lock, alreadyHeld: true };
  }
  return { ...result, alreadyHeld: false };
}

// Met à jour la raison du lock (pour l'annulation après confirmation).
// Le lock reste locked=true, seule la reason change.
export async function updateLockReason(base44, dateKey: string, userId: string, newReason: string, threadKey: string) {
  const svc = base44.asServiceRole;
  const lockKey = computeLockKey(dateKey, userId);
  const existing = await svc.entities.DateLock.filter({ lock_key: lockKey });
  if (!existing[0]) {
    await svc.entities.DateLock.create({
      lock_key: lockKey, user_id: userId, date_key: dateKey,
      locked: true, reason: newReason, thread_key: threadKey,
    });
  } else {
    await svc.entities.DateLock.update(existing[0].id, { reason: newReason, thread_key: threadKey });
  }
  const actual = (await svc.entities.DateLock.filter({ lock_key: lockKey }))[0];
  if (!actual || actual.locked !== true || actual.reason !== newReason || actual.thread_key !== threadKey) {
    throw integrityError('LOCK_STATE_MISMATCH', `Mise à jour du verrou non vérifiée : ${lockKey}`, 409, actual || null);
  }
  return actual;
}

// Libère un lock (locked → false) — utilisé pour annuler une acquisition si la
// deuxième partie du CAS double échoue. Le lock reste en place (reason inchangé).
export async function releaseLock(base44, dateKey: string, userId: string) {
  const svc = base44.asServiceRole;
  const lockKey = computeLockKey(dateKey, userId);
  const result = await svc.entities.DateLock.updateMany(
    { lock_key: lockKey, locked: true },
    { $set: { locked: false } }
  );
  const actual = (await svc.entities.DateLock.filter({ lock_key: lockKey }))[0];
  if (!actual || actual.locked !== false) {
    throw integrityError('LOCK_RELEASE_FAILED', `Verrou non libéré : ${lockKey}`, 500, actual || null);
  }
  return actual;
}

// Supprime le lock d'un utilisateur — utilisé à l'annulation d'un date confirmé
// pour libérer l'autre partie (son lock est supprimé, elle peut dater à nouveau).
export async function deleteLock(base44, dateKey: string, userId: string) {
  const svc = base44.asServiceRole;
  const lockKey = computeLockKey(dateKey, userId);
  const existing = await svc.entities.DateLock.filter({ lock_key: lockKey });
  if (existing[0]) {
    await svc.entities.DateLock.delete(existing[0].id);
  }
}