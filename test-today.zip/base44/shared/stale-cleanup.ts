import { msgSuspendedOther, msgSuspendedSelf, msgResumedOther, msgResumedSelf, msgAvailableAgain } from './messages.ts';
import { transitionThreadState, computeThreadKey } from './datethread.ts';

// Stades actifs d'une interaction (tout sauf terminal/suspendu).
const ACTIVE_STATES = ['pending_challenge', 'ppc_resolved', 'place_proposed', 'place_refused'];
const ACTION_TYPES = ['incomingChallenge', 'loserAccept', 'playerTurn', 'winnerChoosePlace', 'refusalWithReasons'];

// ── Helpers : remplacement des messages système répétitifs ──
// Identifie les messages de suspension et de reprise pour ne garder que le plus récent
// par fil (user_id + thread_key), évitant l'accumulation quand l'autre profil enchaîne
// les dates avec d'autres personnes.

function isSuspensionMsg(text: string): boolean {
  return !!text && text.includes('suspendue');
}

function isResumptionMsg(text: string): boolean {
  if (!text) return false;
  if (text.includes('suspendue')) return false; // msgSuspendedOther contient "reprendra"
  return text.includes('à nouveau disponible') || text.includes('reprend');
}

async function deletePreviousSystemMsgs(svc, userId: string, threadKey: string, predicate: (text: string) => boolean) {
  try {
    const msgs = await svc.entities.UserMessage.filter({ user_id: userId, thread_key: threadKey }, '-created_date', 50);
    const toDelete = msgs.filter(m => m.is_system && predicate(m.text || ''));
    await Promise.all(toDelete.map(m => svc.entities.UserMessage.delete(m.id).catch(() => {})));
  } catch (e) {
    console.error('deletePreviousSystemMsgs: failed:', e);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SUSPENSION : quand un utilisateur confirme un date, ses autres interactions
// sont suspendues (pas fermées). Le stade est préservé dans suspended_from_state
// pour reprendre exactement au même point après libération.
// ─────────────────────────────────────────────────────────────────────────────

// Suspendre toutes les interactions actives d'un utilisateur qui vient d'être
// verrouillé (date confirmé ailleurs). Remplace l'ancien cleanupStaleProposals
// qui fermait définitivement en no_match.
//
// Couvre TOUS les stades actifs (pending_challenge, ppc_resolved, place_proposed,
// place_refused) — pas seulement place_proposed comme l'ancien cleanup.
export async function suspendOtherInteractions(base44, dateKey: string, lockedUserId: string, confirmedThreadKey: string, displayTime: string) {
  const svc = base44.asServiceRole;
  const threads = await svc.entities.DateThread.filter({
    date_key: dateKey,
    state: { $in: ACTIVE_STATES },
    $or: [{ user_a_id: lockedUserId }, { user_b_id: lockedUserId }],
  });

  for (const thread of threads) {
    if (thread.thread_key === confirmedThreadKey) continue;
    try {
      const otherUserId = thread.user_a_id === lockedUserId ? thread.user_b_id : thread.user_a_id;
      const previousState = thread.state;

      const [lockedProfiles, otherProfiles] = await Promise.all([
        svc.entities.Profile.filter({ user_id: lockedUserId }),
        svc.entities.Profile.filter({ user_id: otherUserId }),
      ]);
      const lockedName = lockedProfiles[0]?.display_name || "Quelqu'un";
      const otherName = otherProfiles[0]?.display_name || 'Date';
      const lockedPhoto = lockedProfiles[0]?.photo_url || '';
      const otherPhoto = otherProfiles[0]?.photo_url || '';

      // Un défi resté sans réponse n'est pas une interaction (pas de match) : la
      // suspension est silencieuse — aucun message de suspension ni de reprise.
      const isInteraction = !!thread.winner_user_id || previousState !== 'pending_challenge';

      // Suspendre les actions en attente (préserver l'original pour la reprise)
      await suspendActionsBetween(base44, dateKey, lockedUserId, otherUserId);

      // Supprimer les anciens messages de suspension de ce fil (un seul par fil)
      await Promise.all([
        deletePreviousSystemMsgs(svc, otherUserId, lockedName, isSuspensionMsg),
        deletePreviousSystemMsgs(svc, lockedUserId, otherName, isSuspensionMsg),
        ...(isInteraction ? [] : [
          deletePreviousSystemMsgs(svc, otherUserId, lockedName, isResumptionMsg),
          deletePreviousSystemMsgs(svc, lockedUserId, otherName, isResumptionMsg),
        ]),
      ]);

      // Messages de suspension des deux côtés — uniquement pour une vraie interaction
      if (isInteraction) await Promise.all([
        svc.entities.UserMessage.create({
          user_id: otherUserId, date_key: dateKey, sender: 'Système',
          text: msgSuspendedOther(lockedName),
          is_system: true, profile_name: lockedName, profile_id: lockedUserId,
          profile_photo: lockedPhoto, thread_key: lockedName, display_time: displayTime,
        }),
        svc.entities.UserMessage.create({
          user_id: lockedUserId, date_key: dateKey, sender: 'Système',
          text: msgSuspendedSelf(otherName),
          is_system: true, profile_name: otherName, profile_id: otherUserId,
          profile_photo: otherPhoto, thread_key: otherName, display_time: displayTime,
        }),
      ]);

      // Transition vers suspended en préservant le stade
      await transitionThreadState(base44, thread.thread_key, 'suspended', {
        suspended_from_state: previousState,
      });
    } catch (e) {
      console.error('suspendOtherInteractions: thread suspend failed:', thread.thread_key, e);
    }
  }
}

// Suspendre les actions en attente entre deux utilisateurs — préserve l'action
// originale dans le action_json fermé : {state:'closed', suspended_action:{...}}.
// Au moment de la reprise, resumeActionsBetween restaure l'action depuis ce champ.
async function suspendActionsBetween(base44, dateKey: string, userAId: string, userBId: string) {
  const svc = base44.asServiceRole;
  const closeSide = async (userId: string, otherUserId: string) => {
    const msgs = await svc.entities.UserMessage.filter({ user_id: userId, date_key: dateKey, profile_id: otherUserId }, '-created_date', 200);
    await Promise.all(msgs.filter(m => {
      if (!m.action_json) return false;
      try {
        const a = JSON.parse(m.action_json);
        return a && ACTION_TYPES.includes(a.type) && a.state !== 'closed';
      } catch { return false; }
    }).map(m => {
      let original;
      try { original = JSON.parse(m.action_json); } catch { return; }
      return svc.entities.UserMessage.update(m.id, {
        action_json: JSON.stringify({ state: 'closed', suspended_action: original }),
      }).catch((e: any) => console.error('suspendActionsBetween: close failed:', e));
    }));
  };
  await Promise.all([closeSide(userAId, userBId), closeSide(userBId, userAId)]);
}

// ─────────────────────────────────────────────────────────────────────────────
// REPRISE : quand un utilisateur est libéré (annulation de son date confirmé),
// ses interactions suspendues reprennent au stade précédemment enregistré.
// ─────────────────────────────────────────────────────────────────────────────

// Reprendre les interactions suspendues d'un utilisateur libéré.
// Restaure le stade (suspended_from_state) et les actions associées.
// Gère aussi les threads legacy (stale_closed + no_match) en notifiant sans reprendre.
export async function resumeSuspendedInteractions(base44, dateKey: string, freedUserId: string, displayTime: string) {
  const svc = base44.asServiceRole;

  const freedProfiles = await svc.entities.Profile.filter({ user_id: freedUserId });
  const freedName = freedProfiles[0]?.display_name || "Quelqu'un";
  const freedPhoto = freedProfiles[0]?.photo_url || '';

  // 1. Threads suspendus (nouveau système) — reprendre au stade précédent
  const suspendedThreads = await svc.entities.DateThread.filter({
    date_key: dateKey,
    state: 'suspended',
    $or: [{ user_a_id: freedUserId }, { user_b_id: freedUserId }],
  });

  for (const thread of suspendedThreads) {
    const otherUserId = thread.user_a_id === freedUserId ? thread.user_b_id : thread.user_a_id;
    const previousState = thread.suspended_from_state || 'place_proposed';
    // Un défi resté sans réponse n'est pas une interaction : reprise silencieuse.
    const isInteraction = !!thread.winner_user_id || previousState !== 'pending_challenge';
    try {
      const otherProfiles = await svc.entities.Profile.filter({ user_id: otherUserId });
      const otherName = otherProfiles[0]?.display_name || 'Date';
      const otherPhoto = otherProfiles[0]?.photo_url || '';

      // Restaurer les actions suspendues
      await resumeActionsBetween(base44, dateKey, freedUserId, otherUserId);

      // Supprimer les anciens messages de reprise de ce fil (un seul par fil)
      await Promise.all([
        deletePreviousSystemMsgs(svc, otherUserId, freedName, isResumptionMsg),
        deletePreviousSystemMsgs(svc, freedUserId, otherName, isResumptionMsg),
        ...(isInteraction ? [] : [
          deletePreviousSystemMsgs(svc, otherUserId, freedName, isSuspensionMsg),
          deletePreviousSystemMsgs(svc, freedUserId, otherName, isSuspensionMsg),
        ]),
      ]);

      // Messages de reprise des deux côtés — uniquement pour une vraie interaction
      if (isInteraction) await Promise.all([
        svc.entities.UserMessage.create({
          user_id: otherUserId, date_key: dateKey, sender: 'Système',
          text: msgResumedOther(freedName),
          is_system: true, profile_name: freedName, profile_id: freedUserId,
          profile_photo: freedPhoto, thread_key: freedName, display_time: displayTime,
        }),
        svc.entities.UserMessage.create({
          user_id: freedUserId, date_key: dateKey, sender: 'Système',
          text: msgResumedSelf(otherName),
          is_system: true, profile_name: otherName, profile_id: otherUserId,
          profile_photo: otherPhoto, thread_key: otherName, display_time: displayTime,
        }),
      ]);

      // Transition vers le stade précédent
      await transitionThreadState(base44, thread.thread_key, previousState);
    } catch (e) {
      console.error('resumeSuspendedInteractions: thread resume failed:', thread.thread_key, e);
    }
  }

  // 2. Threads legacy (stale_closed + no_match) — notifier sans reprendre
  const legacyThreads = await svc.entities.DateThread.filter({
    date_key: dateKey,
    state: 'no_match',
    stale_closed: true,
    $or: [{ user_a_id: freedUserId }, { user_b_id: freedUserId }],
  });

  for (const thread of legacyThreads) {
    // Un défi resté sans réponse n'est pas une interaction : pas de notification de reprise.
    if (!thread.winner_user_id) continue;
    const otherUserId = thread.user_a_id === freedUserId ? thread.user_b_id : thread.user_a_id;
    try {
      const otherProfiles = await svc.entities.Profile.filter({ user_id: otherUserId });
      const otherName = otherProfiles[0]?.display_name || 'Date';
      const otherPhoto = otherProfiles[0]?.photo_url || '';

      // Supprimer les anciens messages de disponibilité de ce fil (un seul par fil)
      await Promise.all([
        deletePreviousSystemMsgs(svc, otherUserId, freedName, isResumptionMsg),
        deletePreviousSystemMsgs(svc, freedUserId, otherName, isResumptionMsg),
      ]);

      await Promise.all([
        svc.entities.UserMessage.create({
          user_id: otherUserId, date_key: dateKey, sender: 'Système',
          text: msgAvailableAgain(freedName),
          is_system: true, profile_name: freedName, profile_id: freedUserId,
          profile_photo: freedPhoto, thread_key: freedName, display_time: displayTime,
        }),
        svc.entities.UserMessage.create({
          user_id: freedUserId, date_key: dateKey, sender: 'Système',
          text: msgAvailableAgain(otherName),
          is_system: true, profile_name: otherName, profile_id: otherUserId,
          profile_photo: otherPhoto, thread_key: otherName, display_time: displayTime,
        }),
      ]);
      await svc.entities.DateThread.update(thread.id, { stale_closed: false });
    } catch (e) {
      console.error('resumeSuspendedInteractions: legacy notify failed:', thread.thread_key, e);
    }
  }
}

// Restaurer les actions suspendues entre deux utilisateurs — remet l'action_json
// original depuis le champ suspended_action du action_json fermé.
async function resumeActionsBetween(base44, dateKey: string, userAId: string, userBId: string) {
  const svc = base44.asServiceRole;
  const restoreSide = async (userId: string, otherUserId: string) => {
    const msgs = await svc.entities.UserMessage.filter({ user_id: userId, date_key: dateKey, profile_id: otherUserId }, '-created_date', 200);
    await Promise.all(msgs.filter(m => {
      if (!m.action_json) return false;
      try {
        const a = JSON.parse(m.action_json);
        return a?.state === 'closed' && a?.suspended_action;
      } catch { return false; }
    }).map(m => {
      let a;
      try { a = JSON.parse(m.action_json); } catch { return; }
      if (!a?.suspended_action) return;
      return svc.entities.UserMessage.update(m.id, {
        action_json: JSON.stringify(a.suspended_action),
      }).catch((e: any) => console.error('resumeActionsBetween: restore failed:', e));
    }));
  };
  await Promise.all([restoreSide(userAId, userBId), restoreSide(userBId, userAId)]);
}

// ─────────────────────────────────────────────────────────────────────────────
// PAIRE ANNULÉE — notification directe entre les deux participants quand les
// DEUX sont libérés (renégociation annulée ou proposition non confirmée).
// ─────────────────────────────────────────────────────────────────────────────

export async function notifyPairAvailableAgain(base44, dateKey: string, userAId: string, userBId: string, nameA: string, nameB: string, photoA: string, photoB: string, displayTime: string) {
  const svc = base44.asServiceRole;
  // Un défi resté sans réponse n'est pas une interaction (pas de match) : pas de message de reprise.
  const existing = await svc.entities.DateThread.filter({ thread_key: computeThreadKey(dateKey, userAId, userBId) });
  if (existing[0] && !existing[0].winner_user_id) return;
  // Supprimer les anciens messages de disponibilité de ce fil (un seul par fil)
  await Promise.all([
    deletePreviousSystemMsgs(svc, userAId, nameB, isResumptionMsg),
    deletePreviousSystemMsgs(svc, userBId, nameA, isResumptionMsg),
  ]);
  await Promise.all([
    svc.entities.UserMessage.create({
      user_id: userAId, date_key: dateKey, sender: 'Système',
      text: msgAvailableAgain(nameB),
      is_system: true, profile_name: nameB, profile_id: userBId,
      profile_photo: photoB, thread_key: nameB, display_time: displayTime,
    }),
    svc.entities.UserMessage.create({
      user_id: userBId, date_key: dateKey, sender: 'Système',
      text: msgAvailableAgain(nameA),
      is_system: true, profile_name: nameA, profile_id: userAId,
      profile_photo: photoA, thread_key: nameA, display_time: displayTime,
    }),
  ]);
}

// Ferme les messages d'action en attente entre deux utilisateurs — libère le frontend
// des boutons/badges qui bloqueraient un nouveau défi après annulation.
// Utilisé pour la paire annulée elle-même (pas de préservation nécessaire).
export async function closePendingActionsBetween(base44, dateKey: string, userAId: string, userBId: string) {
  const svc = base44.asServiceRole;
  const closeSide = async (userId: string, otherUserId: string) => {
    const msgs = await svc.entities.UserMessage.filter({ user_id: userId, date_key: dateKey, profile_id: otherUserId }, '-created_date', 200);
    await Promise.all(msgs.filter(m => {
      if (!m.action_json) return false;
      try {
        const a = JSON.parse(m.action_json);
        return a && ACTION_TYPES.includes(a.type) && a.state !== 'closed';
      } catch { return false; }
    }).map(m => svc.entities.UserMessage.update(m.id, { action_json: JSON.stringify({ state: 'closed' }) }).catch((e: any) => console.error('closePendingActions failed:', e))));
  };
  await Promise.all([closeSide(userAId, userBId), closeSide(userBId, userAId)]);
}