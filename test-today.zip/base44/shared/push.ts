// ─────────────────────────────────────────────────────────────────────────────
// Notifications push natives (iOS / Android) — envoi serveur uniquement.
//
// Point d'entrée unique des fonctions backend :
//   notifyMessagePush(base44, { message, fromUserId, override?, senderName? })
//
// Le message créé en base est la seule source de vérité : son id sert de clé
// d'idempotence, donc un retry (ou une écriture append-once rejouée) n'envoie
// jamais un deuxième push.
//
// Toute la décision et l'envoi vivent dans push-core.ts (testable hors runtime).
// Ici : uniquement le maintien en vie de la tâche après la réponse HTTP.
// Aucune de ces fonctions ne jette et aucune ne modifie la réponse de l'appelant.
// ─────────────────────────────────────────────────────────────────────────────

import { waitUntil } from 'base44:runtime';
import { dispatchMessagePush, sendWithDedupe, decideMessagePush, buildPushBody, messageKind, PUSH_TITLE } from './push-core.ts';

export { decideMessagePush, buildPushBody, messageKind, PUSH_TITLE };

// Textes des notifications existantes des flux de date (informatives).
// Les deux cas « nouveau message » / « nouveau jeu » utilisent les textes
// par défaut de push-core.ts (titre « ToDay ») et ne passent pas par ici.
export const PUSH = {
  challengeWon: (name: string) => ({
    title: 'Tu as gagné ! 🏆',
    body: `${name} a perdu le défi. Choisis le lieu du date.`,
  }),
  challengeLost: (name: string) => ({
    title: 'Défi terminé',
    body: `Tu as perdu le défi contre ${name}.`,
  }),
  placeProposed: (name: string) => ({
    title: 'Nouveau lieu proposé',
    body: `${name} te propose un lieu pour votre date.`,
  }),
  placeChanged: (name: string) => ({
    title: 'Lieu modifié',
    body: `${name} a changé le lieu du date.`,
  }),
  dateConfirmed: (name: string) => ({
    title: 'Date confirmé 🎉',
    body: `Ton date avec ${name} est confirmé.`,
  }),
  placeRefused: (name: string, isFinal: boolean) => ({
    title: 'Proposition refusée',
    body: isFinal
      ? `${name} a refusé le lieu. Pas de match.`
      : `${name} a refusé le lieu. Tu peux en proposer un autre.`,
  }),
  dateCancelled: (name: string) => ({
    title: 'Date annulé',
    body: `${name} a annulé le rendez-vous.`,
  }),
  noMatch: (name: string) => ({
    title: 'Pas de match',
    body: `${name} a annulé le rendez-vous.`,
  }),
};

function onError(e: any) {
  console.warn('push failed:', e?.message || e);
  return { sent: false, skipped: 'error' };
}

function background(task: Promise<any>) {
  try {
    waitUntil(task);
  } catch {
    // Runtime sans waitUntil : la tâche continue, l'erreur est déjà avalée.
  }
  return task;
}

// Envoi bas niveau (titre/corps fournis). Renvoie une promesse pour les tests ;
// les appelants l'ignorent : la réponse HTTP part sans attendre le service push.
export function notifyPush(base44: any, input: any) {
  const task = sendWithDedupe(base44, input).catch(onError);
  return background(task);
}

// Envoi à partir d'un UserMessage réellement créé (dans la boîte d'un AUTRE
// utilisateur). override = texte spécifique aux flux de date.
export function notifyMessagePush(base44: any, input: any) {
  const task = dispatchMessagePush(base44, input).catch(onError);
  return background(task);
}