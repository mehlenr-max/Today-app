// Fenêtre des défis : uniquement les jeudis et samedis, de 6 h à 23 h (heure belge).
// Jumeau serveur de src/lib/challenge-window.js — même règle, calculée sur Europe/Brussels.

export const CHALLENGE_ALLOWED_WEEKDAYS = [4, 6]; // 0 = dimanche
export const CHALLENGE_OPEN_HOUR = 6;
export const CHALLENGE_CLOSE_HOUR = 23;

const WEEKDAY_INDEX: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

function brusselsClock(now: Date) {
  const parts: Record<string, string> = {};
  new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/Brussels',
    weekday: 'short',
    hour: '2-digit',
    hour12: false,
  })
    .formatToParts(now)
    .forEach((p) => { parts[p.type] = p.value; });
  return { weekday: WEEKDAY_INDEX[parts.weekday], hour: Number(parts.hour) % 24 };
}

export function getChallengeWindow(now: Date = new Date()) {
  const { weekday, hour } = brusselsClock(now);

  const isAllowedDay = CHALLENGE_ALLOWED_WEEKDAYS.includes(weekday);
  const isBeforeWindow = isAllowedDay && hour < CHALLENGE_OPEN_HOUR;
  const isAfterWindow = isAllowedDay && hour >= CHALLENGE_CLOSE_HOUR;
  const isOpen = isAllowedDay && !isBeforeWindow && !isAfterWindow;

  let daysUntil = 0;
  if (!isOpen) {
    for (let d = isBeforeWindow ? 0 : 1; d <= 7; d++) {
      if (CHALLENGE_ALLOWED_WEEKDAYS.includes((weekday + d) % 7)) {
        daysUntil = d;
        break;
      }
    }
  }

  return { isOpen, isAllowedDay, isBeforeWindow, isAfterWindow, daysUntil };
}

// L'administrateur peut défier toute la semaine, sans restriction de jour ni d'heure.
export function isChallengeWindowOpen(now: Date = new Date(), isAdmin: boolean = false): boolean {
  return isAdmin || getChallengeWindow(now).isOpen;
}

export function challengeWindowClosedMessage(now: Date = new Date()): string {
  const { daysUntil } = getChallengeWindow(now);
  const label = `${daysUntil} jour${daysUntil > 1 ? 's' : ''}`;
  return `Les défis ne sont possibles que les JEUDIS et SAMEDIS, de 6 h à 23 h (heure belge). Prochaine ouverture dans ${label}.`;
}