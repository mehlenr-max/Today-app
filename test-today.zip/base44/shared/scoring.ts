// ─── Module de scoring backend (jumeau isomorphe de src/lib/scoring.js) ────────
// Toute la logique de scoring et ses constantes (morphologie, astro, personnalité,
// poids, globalScore) vit ici. Ce fichier est la COPIE BACKEND de src/lib/scoring.js.
//
// ⚠️  JUMEAU ISOMORPHE : ce fichier a un jumeau en src/lib/scoring.js.
// Toute modification DOIT être répercutée dans les deux, puis validée par le test
// de parité scripts/verify-scoring-parity.js. Ne jamais modifier une copie sans
// l'autre — le test échoue si les deux divergent.
//
// ⚠️  CONTRAINTE PLATEFORME : le frontend ne peut pas importer depuis base44/shared/
// et le backend ne peut pas importer depuis src/. Deux copies sont inévitables.
// Le test de parité (scripts/verify-scoring-parity.js) compare le contenu des deux
// fichiers et vérifie que les scores calculés sont identiques sur cas représentatifs.

// ─── Constantes likes (genre préféré inféré depuis les likes) ─────────────────

export const LIKE_ITEMS_FOR_WOMEN = [
  "Confiance en soi", "Sens de l'humour", "Ambition / motivation", "Gentillesse et empathie",
  "Intelligence et curiosité", "Physique soigné", "Stabilité émotionnelle", "Homme Alpha",
  "Authenticité", "Aisance sociale", "Bad boy au grand coeur",
];
export const LIKE_ITEMS_FOR_MEN = [
  "La féminité", "La confiance en soi", "Le sens de l'humour", "La gentillesse",
  "L'intelligence", "La complicité / bonne communication", "L'authenticité (être naturelle)",
  "L'attention et le soutien", "L'attirance physique / le charme", "La loyauté / fidélité",
];

// ─── Villes + distance ────────────────────────────────────────────────────────

export const CITY_COORDINATES = {
  'Bruxelles': { lat: 50.8503, lon: 4.3517 },
  'Anvers': { lat: 51.2194, lon: 4.4025 },
  'Gand': { lat: 51.0543, lon: 3.7174 },
  'Charleroi': { lat: 50.4108, lon: 4.4446 },
  'Liège': { lat: 50.6326, lon: 5.5797 },
  'Bruges': { lat: 51.2093, lon: 3.2247 },
  'Louvain': { lat: 50.8798, lon: 4.7005 },
  'Mons': { lat: 50.4542, lon: 3.9523 },
  'Tournai': { lat: 50.6071, lon: 3.3893 },
  'Malines': { lat: 51.0259, lon: 4.4775 },
  'Alost': { lat: 50.9360, lon: 4.0355 },
  'Ypres': { lat: 50.8514, lon: 2.8850 },
  'Audenarde': { lat: 50.8440, lon: 3.6069 },
  'Seraing': { lat: 50.6000, lon: 5.8667 },
  'La Louvière': { lat: 50.4769, lon: 4.1871 },
};

export function getDistanceKm(cityA, cityB) {
  const from = CITY_COORDINATES[cityA];
  const to = CITY_COORDINATES[cityB];
  if (!from || !to) return null;
  const R = 6371;
  const dLat = (to.lat - from.lat) * Math.PI / 180;
  const dLon = (to.lon - from.lon) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(from.lat*Math.PI/180) * Math.cos(to.lat*Math.PI/180) * Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

// ─── Filtres âge + distance ───────────────────────────────────────────────────

export function ageMatchesRange(age, ageRange) {
  const ranges = Array.isArray(ageRange) ? ageRange : (typeof ageRange === 'string' ? ageRange.split('|').filter(Boolean) : []);
  if (!ranges.length) return true;
  return ranges.some(r => {
    if (r === '18-25') return age >= 18 && age <= 25;
    if (r === '25-35') return age >= 25 && age <= 35;
    if (r === '35-45') return age >= 35 && age <= 45;
    if (r === '45+') return age >= 45;
    return false;
  });
}

export function distanceMatchesRange(distKm, range) {
  if (distKm === null) return false;
  if (range === '0-5') return distKm <= 5;
  if (range === '0-10') return distKm <= 10;
  if (range === '0-20') return distKm <= 20;
  if (range === '20+') return true;
  return true;
}

// ─── Genre préféré inféré depuis les likes ────────────────────────────────────

export function inferProfilePreferredGender(profile) {
  const likes = profile?.likes || [];
  let prefersMenScore = 0;
  let prefersWomenScore = 0;
  likes.forEach(item => {
    if (LIKE_ITEMS_FOR_WOMEN.includes(item)) prefersMenScore += 1;
    if (LIKE_ITEMS_FOR_MEN.includes(item)) prefersWomenScore += 1;
  });
  if (prefersMenScore === prefersWomenScore) return 'all';
  return prefersMenScore > prefersWomenScore ? 'garçon' : 'fille';
}

export function isGenderCompatible(profile, userIdentity) {
  if (!userIdentity) return true;
  const preferredGender = inferProfilePreferredGender(profile);
  if (preferredGender === 'all') return true;
  return preferredGender === userIdentity;
}

// ─── Morphologie ──────────────────────────────────────────────────────────────

// Matrice de proximité morphologique : 'identical' (+50), 'close' (+25), 'opposite' (-25)
// Permet de distinguer un profil proche du critère recherché d'un profil très opposé.
export const MORPHOLOGY_PROXIMITY = {
  // Morphologies femmes
  'fine':       { 'fine': 'identical', 'sportive': 'close', 'equilibree': 'close', 'pulpeuse': 'opposite', 'genereuse': 'opposite' },
  'sportive':   { 'sportive': 'identical', 'fine': 'close', 'equilibree': 'close', 'pulpeuse': 'opposite', 'genereuse': 'opposite' },
  'equilibree': { 'equilibree': 'identical', 'fine': 'close', 'sportive': 'close', 'pulpeuse': 'close', 'genereuse': 'close' },
  'pulpeuse':   { 'pulpeuse': 'identical', 'genereuse': 'close', 'equilibree': 'close', 'fine': 'opposite', 'sportive': 'opposite' },
  'genereuse':  { 'genereuse': 'identical', 'pulpeuse': 'close', 'equilibree': 'close', 'fine': 'opposite', 'sportive': 'opposite' },
  // Morphologies hommes
  'elance':     { 'elance': 'identical', 'athletique': 'close', 'normal': 'close', 'rond': 'opposite', 'massif': 'opposite' },
  'athletique': { 'athletique': 'identical', 'elance': 'close', 'normal': 'close', 'massif': 'close', 'rond': 'opposite' },
  'normal':     { 'normal': 'identical', 'elance': 'close', 'athletique': 'close', 'rond': 'close', 'massif': 'close' },
  'rond':       { 'rond': 'identical', 'massif': 'close', 'normal': 'close', 'elance': 'opposite', 'athletique': 'opposite' },
  'massif':     { 'massif': 'identical', 'rond': 'close', 'athletique': 'close', 'normal': 'close', 'elance': 'opposite' },
};

export const PROXIMITY_POINTS = { identical: 50, close: 25, opposite: -25 };

// Table 3×3 de compatibilité physique (p1 = ce que JE cherche vs ce qu'il/elle est,
// p2 = ce qu'il/elle cherche vs ce que JE suis). Chaque cellule = score de base 0-100.
// Proximité inconnue (préférences non renseignées) → traitée comme 'close' (neutre).
export const MORPHOLOGY_TABLE = {
  identical: { identical: 95, close: 82, opposite: 45 },  // Excellent / Très bon / Mauvais
  close:     { identical: 82, close: 65, opposite: 45 },  // Très bon / Moyen / Mauvais
  opposite:  { identical: 45, close: 45, opposite: 25 },  // Mauvais / Mauvais / Très mauvais
};

// Meilleure proximité morphologique parmi les traits recherchés (identical > close > opposite).
export function bestMorphologyProximity(desiredTraits, morphology) {
  if (!desiredTraits?.length || !morphology) return null;
  const order = { identical: 3, close: 2, opposite: 1 };
  let best = null;
  for (const d of desiredTraits) {
    const prox = MORPHOLOGY_PROXIMITY[d]?.[morphology];
    if (prox && (best === null || order[prox] > order[best])) best = prox;
  }
  return best;
}

export function calculateMatchScore(profile, prefs, myProfile) {
  const desiredTraits = prefs?.desiredTraits || prefs?.physicalTraits || [];
  const identity = prefs?.seeking || '';
  const affinityMap = prefs?.physicalAffinityMap || {};

  // CONDITION ÉLIMINATOIRE : genre incompatible → 0
  if (identity && !isGenderCompatible(profile, identity)) return 0;

  const profileMorphology = profile.ownPhysicalTraits?.[0] || profile.morphology || '';
  const myMorphology = myProfile?.own_physical_traits?.[0] || myProfile?.ownPhysicalTraits?.[0] || '';

  // p1 : ce que JE cherche vs ce qu'il/elle EST ; p2 : ce qu'il/elle CHERCHE vs ce que JE suis.
  // Proximité inconnue → 'close' (neutre, ni match ni miss net).
  const p1 = bestMorphologyProximity(desiredTraits, profileMorphology) ?? 'close';
  const p2 = bestMorphologyProximity(
    profile.desired_physical_traits || profile.desiredPhysicalTraits || [],
    myMorphology,
  ) ?? 'close';

  let score = MORPHOLOGY_TABLE[p1][p2];

  // --- Affinité physique apprise (bonus progressif, plafonné à +15) ---
  if (Object.keys(affinityMap).length > 0 && profileMorphology) {
    const affinityScore = affinityMap[profileMorphology] || 0;
    if (affinityScore > 0) score += Math.min(15, Math.round(Math.log2(affinityScore + 1) * 5));
  }

  return Math.max(0, Math.min(100, Math.round(score)));
}

// ─── Astro / cosmique ─────────────────────────────────────────────────────────

export const ELEMENT_MAP = {
  'Bélier': 'FEU', 'Lion': 'FEU', 'Sagittaire': 'FEU',
  'Taureau': 'TERRE', 'Vierge': 'TERRE', 'Capricorne': 'TERRE',
  'Gémeaux': 'AIR', 'Balance': 'AIR', 'Verseau': 'AIR',
  'Cancer': 'EAU', 'Scorpion': 'EAU', 'Poissons': 'EAU',
};

export function getElement(sign) {
  return ELEMENT_MAP[sign] || null;
}

export function getCompatibility(a, b) {
  const base = {
    FEU:   { FEU: 90, AIR: 95, TERRE: 70, EAU: 55 },
    TERRE: { TERRE: 90, EAU: 95, AIR: 55, FEU: 70 },
    AIR:   { AIR: 90, FEU: 95, EAU: 70, TERRE: 55 },
    EAU:   { EAU: 90, TERRE: 95, AIR: 70, FEU: 55 },
  };

  if (!a?.element || !b?.element) return 0;
  let score = base[a.element]?.[b.element] ?? 50;

  if (a.ascendant && b.ascendant && a.ascendant === b.ascendant) score += 5;
  if (a.element === b.element) score += 5;

  return Math.max(0, Math.min(100, score));
}

export function getCosmicScore(myProfile, targetProfile) {
  if (!myProfile?.astro_sign || !targetProfile?.astro_sign) return null;
  const myElement = getElement(myProfile.astro_sign);
  const theirElement = getElement(targetProfile.astro_sign);
  if (!myElement || !theirElement) return null;
  return getCompatibility(
    { element: myElement, ascendant: myProfile.astro_ascendant },
    { element: theirElement, ascendant: targetProfile.astro_ascendant }
  );
}

// ─── Personnalité ─────────────────────────────────────────────────────────────

// Dimension unique de référence pour les barres ET le score général.
export const PERSONALITY_DIMENSIONS = [
  { key: 'social', label: 'Social' },
  { key: 'emotionnel', label: 'Émotionnel' },
  { key: 'modeVie', label: 'Mode de vie' },
  { key: 'relationnel', label: 'Relationnel' },
  { key: 'valeurs', label: 'Valeurs' },
];

// Weights
export const WEIGHTS = { valeurs: 0.30, relationnel: 0.25, emotionnel: 0.20, modeVie: 0.15, social: 0.10 };

// Lecture du champ personality_profile (stocké en JSON sur l'entité Profile).
export function parsePersonalityProfile(value) {
  if (!value) return null;
  if (typeof value === 'object') return value;
  try { return JSON.parse(value); } catch { return null; }
}

// CALCUL UNIQUE de la compatibilité de personnalité : en une seule passe, il produit
// les compatibilités par dimension ET le score général qui en dérive. Tous les écrans
// utilisent ce résultat, jamais un calcul parallèle.
// Une dimension compte seulement si les DEUX profils ont une valeur numérique
// (0 est un score valide). Le score général est la moyenne pondérée des mêmes
// dimensions, poids normalisés sur celles qui sont disponibles.
export function getPersonalityCompatibility(profileA, profileB) {
  if (!profileA || !profileB) return { score: null, dimensions: [] };
  const isNum = (v) => typeof v === 'number' && !isNaN(v);
  const clamp = (v) => Math.max(0, Math.min(100, v));
  const dimensions = [];
  let total = 0;
  let totalWeight = 0;
  for (const dim of PERSONALITY_DIMENSIONS) {
    const a = profileA[dim.key];
    const b = profileB[dim.key];
    if (!isNum(a) || !isNum(b)) continue;
    const value = Math.round(100 - Math.abs(clamp(a) - clamp(b)));
    dimensions.push({ ...dim, value });
    const weight = WEIGHTS[dim.key];
    total += value * weight;
    totalWeight += weight;
  }
  const score = totalWeight > 0 ? Math.round(total / totalWeight) : null;
  return { score, dimensions };
}

// Compatibilités par dimension — dérivées du calcul unique.
export function getPersonalityDimensionScores(profileA, profileB) {
  return getPersonalityCompatibility(profileA, profileB).dimensions;
}

// Score général — dérivé du calcul unique.
export function calculatePersonalityCompatibility(profileA, profileB) {
  return getPersonalityCompatibility(profileA, profileB).score;
}

// ─── Score global (pondération des 3 scores) ─────────────────────────────────
// Utilisé côté backend (getBrowseDeck) pour scorer les candidats du deck.
// Le frontend reçoit globalScore pré-calculé — ne le recalcule pas.

// SCORE GLOBAL UNIQUE de l'app (deck ET fiche profil) :
//   physique 50 % · personnalité 25 % · astral 25 %.
// Les poids sont renormalisés sur les seules composantes disponibles, pour que le
// score reste comparable quand un profil n'a pas de test de personnalité ou de thème.
// C'est LA valeur affichée (pastille + étiquette) et celle qui classe le deck.
export function getGlobalScore(matchScore, cosmicScore, personalityScore) {
  const scores = [];
  if (matchScore != null) scores.push({ value: matchScore, weight: 0.50 });
  if (cosmicScore != null && cosmicScore > 0) scores.push({ value: cosmicScore, weight: 0.25 });
  // Score de personnalité basé UNIQUEMENT sur le test de personnalité (personality_profile).
  if (personalityScore != null && personalityScore > 0) scores.push({ value: personalityScore, weight: 0.25 });
  if (scores.length === 0) return 50;
  const totalWeight = scores.reduce((s, sc) => s + sc.weight, 0);
  let weighted = 0;
  scores.forEach(sc => { weighted += sc.value * (sc.weight / totalWeight); });
  return Math.round(Math.max(30, Math.min(99, weighted)));
}