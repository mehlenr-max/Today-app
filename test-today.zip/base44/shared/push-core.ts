// ─────────────────────────────────────────────────────────────────────────────
// Cœur des notifications push natives — AUCUN import plateforme.
//
// Ce module ne dépend ni de "base44:runtime" ni d'un client HTTP : il reçoit le
// client Base44 en argument. C'est ce qui permet de le tester hors runtime
// (scripts/verify-push.ts) avec un faux client et de prouver la règle
// « exactement un push par message réellement créé ».
//
// Règles d'envoi (décidées ici, jamais ailleurs) :
//   - un seul push par message (clé d'idempotence = id du UserMessage) ;
//   - jamais d'envoi à soi-même ;
//   - jamais d'envoi pour un message sans personne identifiée (système) ;
//   - jamais d'envoi si le destinataire n'existe pas ;
//   - un compte admin reçoit ses notifications normalement ;
//   - tout envoi écarté est tracé avec son motif exact.
// Aucune de ces fonctions ne jette : l'appelant garde son statut HTTP et sa
// réponse, quoi qu'il arrive au service push.
// ─────────────────────────────────────────────────────────────────────────────

export const PUSH_TITLE = 'ToDay';

export type PushLang = 'fr' | 'nl' | 'en';

// Textes des deux cas couverts. Ne jamais y mettre de contenu de message.
const BODIES: Record<PushLang, Record<string, (name: string) => string>> = {
  fr: {
    message: (name) => `Nouveau message de ${name}`,
    ppc: (name) => `${name} te lance un défi`,
    quiz: (name) => `${name} te lance un défi quiz`,
  },
  nl: {
    message: (name) => `Nieuw bericht van ${name}`,
    ppc: (name) => `${name} daagt je uit`,
    quiz: (name) => `${name} daagt je uit voor een quiz`,
  },
  en: {
    message: (name) => `New message from ${name}`,
    ppc: (name) => `${name} is challenging you`,
    quiz: (name) => `${name} sent you a quiz challenge`,
  },
};

export function normalizeLang(value: any) {
  const code = String(value || '').slice(0, 2).toLowerCase();
  return (code === 'nl' || code === 'en' ? code : 'fr') as PushLang;
}

export function buildPushBody(kind: any, senderName: any, lang: any) {
  const dict = BODIES[normalizeLang(lang)] || BODIES.fr;
  return (dict[kind] || dict.message)(senderName);
}

// Nature du message : défi PPC, défi quiz, ou message ordinaire.
export function messageKind(message: any) {
  let action = null;
  try { action = message?.action_json ? JSON.parse(message.action_json) : null; } catch { action = null; }
  if (action?.type === 'incomingChallenge') return 'ppc';
  if (action?.type === 'quizQuestions') return 'quiz';
  return 'message';
}

// Motif exact pour lequel un envoi est écarté — null = envoi autorisé.
// Seuls trois cas restent écartés :
//   - le destinataire est l'auteur du message lui-même ;
//   - le destinataire n'existe pas ;
//   - le message est purement système (aucun utilisateur émetteur réel).
// Un compte admin reçoit ses notifications comme n'importe quel membre.
export function pushSkipReason({ message, fromUserId, recipientUser, recipientLookupFailed, senderName }: any) {
  if (!message || !message.id) return 'message_invalide';
  if (!message.user_id) return 'destinataire_absent';

  const toUserId = String(message.user_id);
  const senderUserId = String(message.profile_id || fromUserId || '');

  // Message purement système : aucun utilisateur émetteur réel.
  if (!senderUserId) return 'emetteur_systeme';

  // Le destinataire est l'auteur du message lui-même.
  if (senderUserId === toUserId) return 'soi_meme';

  const name = String(senderName || message.profile_name || message.sender || '').trim();
  if (!name || name === 'Système' || name === 'Vous') return 'emetteur_systeme';

  // Destinataire inexistant — uniquement si la recherche a abouti sans résultat
  // (une recherche en échec ne doit pas supprimer la notification).
  if (!recipientLookupFailed && !recipientUser) return 'destinataire_inexistant';

  return null;
}

// Décision pure : null = aucun envoi. Sinon, tout ce qu'il faut pour envoyer.
export function decideMessagePush({ message, fromUserId, recipientUser, recipientLookupFailed, override, senderName }: any) {
  if (pushSkipReason({ message, fromUserId, recipientUser, recipientLookupFailed, senderName })) return null;

  const toUserId = String(message.user_id);
  const name = String(senderName || message.profile_name || message.sender || '').trim();
  const kind = messageKind(message);

  return {
    toUserId,
    kind,
    title: override?.title || PUSH_TITLE,
    body: override?.body || buildPushBody(kind, name, recipientUser?.language),
    link: override?.link || '/',
    dedupeKey: `msg:${message.id}`,
  };
}

// Envoi effectif, protégé par la clé d'idempotence. Ne jette jamais.
export async function sendWithDedupe(base44: any, input: any) {
  const { toUserId, title, body, link, dedupeKey, kind } = input || {};
  if (!base44 || !toUserId || !title || !dedupeKey) {
    return { sent: false, skipped: 'missing_fields' };
  }

  const svc = base44.asServiceRole?.entities?.PushLog;
  let log: any = null;

  // Réservation de la clé : un retry retombe sur la ligne existante et n'envoie rien.
  try {
    const existing = await svc.filter({ dedupe_key: dedupeKey }, '-created_date', 1);
    if (Array.isArray(existing) && existing.length > 0) {
      return { sent: false, skipped: 'duplicate' };
    }
    log = await svc.create({
      dedupe_key: dedupeKey,
      user_id: String(toUserId),
      kind: kind || 'message',
      title,
      status: 'pending',
    });
  } catch (e: any) {
    // Journal indisponible : on n'empêche pas la notification, on la trace.
    console.warn('PushLog claim failed:', e?.message || e);
  }

  try {
    // Diagnostic : on trace le destinataire réel (id utilisateur Base44) puis la réponse brute.
    console.info('PUSH: tentative ->', String(toUserId));
    const raw = await base44.asServiceRole.integrations.Core.SendPushNotification({
      user_id: String(toUserId),
      title,
      content: body || '',
      ...(link ? { action_label: 'Ouvrir ToDay', action_url: link } : {}),
    });
    console.info('PUSH: resultat ->', JSON.stringify(raw ?? null));
    if (log?.id) {
      await svc.update(log.id, { status: 'sent', sent_at: new Date().toISOString() })
        .catch((e: any) => console.warn('PushLog update failed:', e?.message || e));
    }
    return { sent: true, skipped: null };
  } catch (e: any) {
    const error = String(e?.message || e).slice(0, 300);
    console.info('PUSH: resultat ->', error);
    console.warn('SendPushNotification failed:', error);
    if (log?.id) {
      await svc.update(log.id, { status: 'failed', error }).catch(() => {});
    }
    return { sent: false, skipped: 'error', error };
  }
}

// Chaîne complète à partir d'un message : lecture du destinataire (langue, rôle),
// décision, puis envoi. Ne jette jamais.
export async function dispatchMessagePush(base44, input) {
  const { message, fromUserId, override, senderName } = input || {};

  let recipientUser: any = null;
  let recipientLookupFailed = false;
  if (message?.user_id) {
    try {
      const users = await base44.asServiceRole.entities.User.filter({ id: String(message.user_id) });
      recipientUser = Array.isArray(users) ? users[0] || null : users || null;
    } catch (e: any) {
      recipientLookupFailed = true;
      console.warn('push recipient lookup failed:', e?.message || e);
    }
  }

  const decision = decideMessagePush({ message, fromUserId, recipientUser, recipientLookupFailed, override, senderName });
  if (!decision) {
    const motif = pushSkipReason({ message, fromUserId, recipientUser, recipientLookupFailed, senderName });
    console.info('PUSH: ignore ->', String(message?.user_id || ''), `motif=${motif}`);
    return { sent: false, skipped: 'ignored', motif };
  }

  return sendWithDedupe(base44, decision);
}