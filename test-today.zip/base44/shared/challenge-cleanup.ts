// Nettoyage des marqueurs challenged_profiles pour une paire d'utilisateurs.
// Appelé à la résolution d'un défi (PPC, confirmation, refus, annulation) pour
// éviter les marqueurs fantômes ("incoming" / "true") qui bloquent les futurs défis.
// Côté serveur (service role) pour être autoritaire — pas dépendant du cache frontend.

export async function cleanChallengeMarkers(base44, userAId, userBId, dateKey) {
  if (!userAId || !userBId || !dateKey) return;
  try {
    const [profilesA, profilesB] = await Promise.all([
      base44.asServiceRole.entities.Profile.filter({ user_id: userAId }),
      base44.asServiceRole.entities.Profile.filter({ user_id: userBId }),
    ]);
    const profileAId = profilesA[0]?.id;
    const profileBId = profilesB[0]?.id;
    if (!profileAId || !profileBId) return;

    const [sessionsA, sessionsB] = await Promise.all([
      base44.asServiceRole.entities.UserSession.filter({ user_id: userAId, date_key: dateKey }),
      base44.asServiceRole.entities.UserSession.filter({ user_id: userBId, date_key: dateKey }),
    ]);

    await Promise.all([
      (async () => {
        if (sessionsA[0]) {
          let map = {};
          try { map = JSON.parse(sessionsA[0].challenged_profiles || '{}'); } catch {}
          delete map[String(profileBId)];
          await base44.asServiceRole.entities.UserSession.update(sessionsA[0].id, {
            challenged_profiles: JSON.stringify(map),
          });
        }
      })(),
      (async () => {
        if (sessionsB[0]) {
          let map = {};
          try { map = JSON.parse(sessionsB[0].challenged_profiles || '{}'); } catch {}
          delete map[String(profileAId)];
          await base44.asServiceRole.entities.UserSession.update(sessionsB[0].id, {
            challenged_profiles: JSON.stringify(map),
          });
        }
      })(),
    ]);
  } catch (e) {
    console.error('cleanChallengeMarkers failed:', e?.message || e);
  }
}

// Marque une paire comme verrouillée après une annulation (avant ou après acceptation).
// Contrairement à cleanChallengeMarkers qui supprime les marqueurs, celle-ci les pose
// à 'locked' pour que le bouton "Défier" reste désactivé sur la journée entière,
// appliquant la règle "un seul défi par jour entre profils" dans les deux sens.
export async function markPairLocked(base44, userAId, userBId, dateKey) {
  if (!userAId || !userBId || !dateKey) return;
  try {
    const [profilesA, profilesB] = await Promise.all([
      base44.asServiceRole.entities.Profile.filter({ user_id: userAId }),
      base44.asServiceRole.entities.Profile.filter({ user_id: userBId }),
    ]);
    const profileAId = profilesA[0]?.id;
    const profileBId = profilesB[0]?.id;
    if (!profileAId || !profileBId) return;

    const [sessionsA, sessionsB] = await Promise.all([
      base44.asServiceRole.entities.UserSession.filter({ user_id: userAId, date_key: dateKey }),
      base44.asServiceRole.entities.UserSession.filter({ user_id: userBId, date_key: dateKey }),
    ]);

    await Promise.all([
      (async () => {
        if (sessionsA[0]) {
          let map = {};
          try { map = JSON.parse(sessionsA[0].challenged_profiles || '{}'); } catch {}
          map[String(profileBId)] = 'locked';
          await base44.asServiceRole.entities.UserSession.update(sessionsA[0].id, {
            challenged_profiles: JSON.stringify(map),
          });
        }
      })(),
      (async () => {
        if (sessionsB[0]) {
          let map = {};
          try { map = JSON.parse(sessionsB[0].challenged_profiles || '{}'); } catch {}
          map[String(profileAId)] = 'locked';
          await base44.asServiceRole.entities.UserSession.update(sessionsB[0].id, {
            challenged_profiles: JSON.stringify(map),
          });
        }
      })(),
    ]);
  } catch (e) {
    console.error('markPairLocked failed:', e?.message || e);
  }
}

// Marque une paire comme bloquée après un refus pour raisons personnelles.
// Contrairement à cleanChallengeMarkers qui supprime les marqueurs, celle-ci
// les pose à 'personal_refusal' pour que le bouton "Défier" reste désactivé
// sur la journée et survive au rechargement de page.
export async function markPersonalRefusalLockout(base44, userAId, userBId, dateKey) {
  if (!userAId || !userBId || !dateKey) return;
  try {
    const [profilesA, profilesB] = await Promise.all([
      base44.asServiceRole.entities.Profile.filter({ user_id: userAId }),
      base44.asServiceRole.entities.Profile.filter({ user_id: userBId }),
    ]);
    const profileAId = profilesA[0]?.id;
    const profileBId = profilesB[0]?.id;
    if (!profileAId || !profileBId) return;

    const [sessionsA, sessionsB] = await Promise.all([
      base44.asServiceRole.entities.UserSession.filter({ user_id: userAId, date_key: dateKey }),
      base44.asServiceRole.entities.UserSession.filter({ user_id: userBId, date_key: dateKey }),
    ]);

    await Promise.all([
      (async () => {
        if (sessionsA[0]) {
          let map = {};
          try { map = JSON.parse(sessionsA[0].challenged_profiles || '{}'); } catch {}
          map[String(profileBId)] = 'personal_refusal';
          await base44.asServiceRole.entities.UserSession.update(sessionsA[0].id, {
            challenged_profiles: JSON.stringify(map),
          });
        }
      })(),
      (async () => {
        if (sessionsB[0]) {
          let map = {};
          try { map = JSON.parse(sessionsB[0].challenged_profiles || '{}'); } catch {}
          map[String(profileAId)] = 'personal_refusal';
          await base44.asServiceRole.entities.UserSession.update(sessionsB[0].id, {
            challenged_profiles: JSON.stringify(map),
          });
        }
      })(),
    ]);
  } catch (e) {
    console.error('markPersonalRefusalLockout failed:', e?.message || e);
  }
}