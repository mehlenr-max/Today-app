// Garde d'idempotence d'écriture des messages : n'ajoute un message que si aucune
// occurrence du même texte n'existe déjà dans le même fil (user_id + date_key + thread_key).
// Généralise l'idempotence aujourd'hui codée en dur (deliverResult:117-121) et permet
// de rejouer un appel de résolution sans créer de doublon.
// Service role : l'appelant écrit dans sa boîte ET dans celle de l'autre partie.

export async function appendMessageOnce(base44, payload) {
  const { user_id, date_key, thread_key, text } = payload || {};
  if (!user_id || !date_key || !thread_key || !text) {
    return { created: false, message: null, skipped: 'missing_fields' };
  }
  const recent = await base44.asServiceRole.entities.UserMessage.filter(
    { user_id, date_key, thread_key },
    '-created_date',
    50
  );
  const existing = recent.find(m => m.text === text);
  if (existing) return { created: false, message: existing, skipped: 'duplicate_text' };

  const message = await base44.asServiceRole.entities.UserMessage.create({ ...payload });
  return { created: true, message, skipped: null };
}