// Texte de l'avertissement de modération — source unique partagée entre
// l'aperçu présenté à l'admin et l'email réellement envoyé au membre.

export const REASON_LABELS = {
  nudity: 'Nudité',
  minor: 'Mineur',
  harassment: 'Harcèlement',
  fake: 'Faux profil',
  spam: 'Spam',
  other: 'Autre',
};

// Le texte saisi par l'admin traverse un email HTML comme DONNÉE :
// on retire les caractères de balisage, les caractères de contrôle
// et on borne la longueur avant toute injection.
export function cleanText(value, maxLength = 900) {
  if (typeof value !== 'string') return '';
  return value
    .replace(/[\u0000-\u001F\u007F]+/g, ' ')
    .replace(/[<>&]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);
}

export function buildWarningCopy({ firstName, reason, message }) {
  const reasonLabel = REASON_LABELS[reason] || REASON_LABELS.other;
  const custom = cleanText(message, 900);
  const body = custom || [
    `Un signalement (${reasonLabel.toLowerCase()}) a été enregistré sur ton profil ToDay.`,
    'Merci de vérifier que ta photo et tes échanges respectent les règles de ToDay, et de les corriger si nécessaire.',
    'Un signalement supplémentaire peut entraîner le masquage de ton profil.',
  ].join(' ');

  return {
    subject: 'ToDay — Avertissement de modération',
    reasonLabel,
    recipientName: cleanText(firstName, 60),
    message: body,
  };
}